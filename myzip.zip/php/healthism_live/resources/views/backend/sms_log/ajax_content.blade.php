<script>
    var csrf_field = "{{ csrf_token() }}";
</script>
<script src="{{ Helper::static_asset('admin-assets/js/module/common.js') }}"></script>
<div class="row">
    <form class="" method="POST" action="{{ route('admin.sms_log') }}" id="search_form" onsubmit="return false">
        {{ csrf_field() }}
        <div class="col-12">
            <div class="card">
                <div class="card-header border-bottom">
                    <h4 class="card-title">{{ __("SMS Log")  }}</h4>
                </div>
                <!--Search Form -->
                <div class="card-body mt-1">
                    <input type="hidden" name="page" id="page" value="{{ empty(app('request')->input('page')) ? 1 : app('request')->input('page')  }}">
                    <div class="row g-1">
                        <div class="col-md-3">
                            <label class="form-label" for="mobile">Mobile</label>
                            <input type="number" name="mobile" placeholder="Mobile No" class="form-control" value="{{app('request')->input('mobile')}}">
                        </div>
                        <div class="col-md-3 m-t-35">
                            <label class="form-label"></label>
                            <button type="submit" name='' class="btn btn-primary waves-effect waves-float waves-light">Search</button>
                        </div>
                    </div>
                </div>
                <hr class="my-0">
                <div class="card-datatable">
                    <?php echo parPageRecordDropDown() ?>
                    @if(!$data->isEmpty())
                    @php $start = $data->firstItem(); @endphp
                    <div class="table-responsive">
                        <table class="table table-bordered table-hover">
                            <thead>
                                <tr role="row">
                                    <th></th>
                                    <th>Mobile</th>
                                    <th>SMS</th>
                                    <th style="width: 14%;">Created At</th>
                                </tr>
                            </thead>
                            <tbody>
                                @foreach($data as $sms)
                                <tr class="f-12">
                                    <td><?= $start++; ?></td>
                                    <td valign="top">{{ $sms->mobile }}</td>
                                    <td valign="top">{{ $sms->sms_content}}</td>
                                    <td valign="top">{{ date("d/m/Y h:i A",strtotime($sms->created_at))}}</td>
                                </tr>

                                @endforeach
                            </tbody>
                        </table>
                    </div>
                    @endif
                    <?php echo pagination($data) ?>
                </div>
            </div>
        </div>
    </form>
</div>
@section('script')
<script type="text/javascript">
    $(document).ready(initCommon);
</script>

@endsection
