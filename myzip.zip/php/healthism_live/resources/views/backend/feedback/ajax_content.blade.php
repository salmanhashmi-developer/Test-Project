<script>
    var csrf_field = "{{ csrf_token() }}";
</script>
<script src="{{ Helper::static_asset('admin-assets/js/module/common.js') }}"></script>
<div class="row">
    <form class="" method="POST" action="{{ route('admin.feedback') }}" id="search_form" onsubmit="return false">
        {{ csrf_field() }}
        <div class="col-12">
            <div class="card">
                <div class="card-header border-bottom">
                    <h4 class="card-title">{{ __("Feedback")  }}</h4>
                </div>
                <!--Search Form -->
                <div class="card-body mt-1">
                    <input type="hidden" name="page" id="page" value="{{ empty(app('request')->input('page')) ? 1 : app('request')->input('page')  }}">
                    <input type="hidden" name="sort_field" id="sort_field" value="{{ app('request')->input('sort_field') }}">
                    <input type="hidden" name="sort_action" id="sort_action" value="{{ app('request')->input('sort_action') }}">
                    <div class="row g-1">
                        <div class="col-md-3">
                            <label class="form-label">Platform</label>
                            <select name="platform_id" class="form-select select2">
                                <option value="">ALL</option>
                                <?php
                                $platformId = app('request')->input('platform_id');
                                ?>
                                @foreach($platformList as $row)
                                <option value="<?= $row->id ?>" <?= $row->id == $platformId ? 'selected' : '' ?>><?= $row->name ?></option>
                                @endforeach
                            </select>
                        </div>
                        <div class="col-md-3">
                            <label class="form-label">App</label>
                            <select name="app_id" class="form-select select2">
                                <option value="">ALL</option>
                                <?php
                                $appId = app('request')->input('app_id');
                                ?>
                                @foreach($appList as $row)
                                <option value="<?= $row['id'] ?>" <?= $row['id'] == $appId ? 'selected' : '' ?>><?= $row['name'] ?></option>
                                @endforeach
                            </select>
                        </div>
                        <div class="col-md-3 m-t-35">
                            <label class="form-label"></label>
                            <button type="submit" name='' class="btn btn-primary waves-effect waves-float waves-light">Search</button>
                            <a id="refresh" data-url="/admin/feedback" class="btn btn-outline-secondary waves-effect">Reset</a>
                        </div>
                    </div>
                </div>
                <hr class="my-0">
                <div class="card-datatable">
                    <?php echo parPageRecordDropDown() ?>
                    @if(!$feedback->isEmpty())
                    @php $start = $feedback->firstItem(); @endphp
                    <div class="table-responsive">
                        <table class="table table-bordered table-hover">
                            <thead>
                                <tr role="row">
                                    <th></th>
                                    <th>User</th>
                                    <th>App</th>
                                    <th>Plateform</th>
                                    <th>description</th>
                                    <th>created_at</th>
                                </tr>
                            </thead>
                            <tbody>
                                @foreach($feedback as $data)
                                <tr class="f-12">
                                    <td><?= $start++; ?></td>
                                    <td valign="top">
                                        {{ $data->user->first_name.' '.$data->user->last_name  }}
                                        <br><span class="f-11">{{$data->user->mobile}}</span>
                                    </td>
                                    <td valign="top">{{ $data->app_id==1?'USER APP':'MERCHANT APP'  }}</td>
                                    <td valign="top">{{ $data->platform->name  }}</td>
                                    <td valign="top">
                                        {{ $data->description  }}
                                    </td>
                                    <td valign="top">{{ date("d/m/Y H:i",strtotime($data->created_at))}}</td>
                                </tr>

                                @endforeach
                            </tbody>
                        </table>
                    </div>
                    @endif
                    <?php echo pagination($feedback) ?>
                </div>
            </div>
        </div>
    </form>
</div>
@section('script')
<script type="text/javascript">
    $(document).ready(initCommon);
</script>

@endsection
