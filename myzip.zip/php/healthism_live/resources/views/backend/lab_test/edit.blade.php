@extends("backend.layouts.master")
@section('title') Test Edit @endsection
@section('content')
<script type="text/javascript" src="{{ Helper::static_asset('admin-assets/js/module/common.js') }}"></script>
<script type="text/javascript" src="{{ Helper::static_asset('admin-assets/js/module/lab.js') }}"></script>
<script type="text/javascript">$(document).ready(initTestMaster);</script>
<!-- BEGIN: Content-->
<div class="app-content content ">

    <div class="content-wrapper p-0">

        <div class="content-body">

            <div class="card" data-select2-id="14">
                <div class="card-header border-bottom">
                    <h4 class="card-title">Edit Test Details</h4>
                </div>
                <div class="card-body py-2 my-25" data-select2-id="53">
                    <!-- header section -->

                    <!-- form -->
                    @include('backend.message')

                    <form class="needs-validation" method="POST" action="{{route('admin.lab.test.update', $test->id)}}" method="POST" enctype="multipart/form-data" novalidate>
                        {{ csrf_field() }}


                        <section class="modern-horizontal-wizard">

                            <div class="bs-stepper wizard-modern modern-wizard-example">

                                <div class="bs-stepper-header">
                                    <div class="step" data-target="#account-details-modern" role="tab"
                                         id="test-details-modern-trigger">
                                        <button type="button" class="step-trigger">
                                            <span class="bs-stepper-box">
                                                <i data-feather="user" class="font-medium-3"></i>
                                            </span>
                                            <span class="bs-stepper-label">
                                                <span class="bs-stepper-title">Test Details</span>
                                            </span>
                                        </button>
                                    </div>


                                    <div class="line">
                                        <i data-feather="chevron-right" class="font-medium-2"></i>
                                    </div>
                                    <div class="step" data-target="#test-details-info" role="tab"
                                         id="test-details-info-trigger">
                                        <button type="button" class="step-trigger">
                                            <span class="bs-stepper-box">
                                                <i data-feather="file-text" class="font-medium-3"></i>
                                            </span>
                                            <span class="bs-stepper-label">
                                                <span class="bs-stepper-title">Additional Details</span>
                                            </span>
                                        </button>
                                    </div>
                                </div>

                                <div class="bs-stepper-content">
                                    <div id="account-details-modern" class="content" role="tabpanel" aria-labelledby="test-details-modern-trigger">
                                        <div class="content-header">
                                            <h5 class="mb-0"><?= ('Test Details') ?></h5>
                                        </div>
                                        <input type="hidden" name="flag" value="{{!empty($flag)?$flag:''}}">
                                        <input type="hidden" name="lab_id" value="{{$test->lab_id}}">
                                        <input type="hidden" name="lab_parent_id" value="{{$test->lab_parent_id}}">
                                        <div class="row">
                                            <div class="mb-1 col-md-4">
                                                <label class="form-label" for="name"><?= _('Name*') ?></label>
                                                <input type="text" name="name" id="name" class="form-control" placeholder="<?= _('Test Name') ?>" value="<?= post_display('name', $test->name) ?>" required/>
                                            </div>
                                            <div class="mb-1 col-md-4">
                                                <?php
                                                $genderArr = explode(',', $test->gender);
                                                $male = $female = $other = "";
                                                foreach ($genderArr as $value) {
                                                    if ($value == 'Male') {
                                                        $male = ' selected="selected" ';
                                                    }
                                                    if ($value == 'Female') {
                                                        $female = ' selected="selected" ';
                                                    }
                                                    if ($value == 'Other') {
                                                        $other = ' selected="selected" ';
                                                    }
                                                }
                                                ?>
                                                <label class="form-label" for="gender"><?= _('Gender') ?></label>
                                                <select name="gender[]" class="form-select select2" id="gender" multiple>
                                                    <option value="Male" <?php echo $male; ?>>Male</option>
                                                    <option value="Female" <?php echo $female; ?>>Female</option>
                                                    <option value="Other" <?php echo $other; ?>>Other</option>
                                                </select>
                                            </div>
                                            <div class="mb-1 col-md-4">
                                                <label class="form-label">Status</label>
                                                <select name="status_id" id="status_id" class="select2 form-select" required>
                                                    <option value="1" {{ $test->status_id=='1' ? "selected" : ''  }}>Active</option>
                                                    <option value="2" {{ $test->status_id=='2' ? "selected" : ''  }}>Inactive</option>
                                                </select>
                                            </div>
                                        </div>
                                        <div class="row">
                                            <div class="mb-1 col-md-4">
                                                <label class="form-label" for="alias_name"><?= _('Alias Name') ?></label>
                                                <input type="text" name="alias_name" id="alias_name" class="form-control" placeholder="<?= _('Alias Name') ?>" value="<?= post_display('alias_name', $test->alias_name) ?>"/>
                                            </div>
                                            <div class="mb-1 col-md-4">
                                                <label class="form-label" for="body_part"><?= _('Body Part') ?></label>
                                                <input type="text" name="body_part" id="body_part" class="form-control" placeholder="<?= _('Body Part') ?>" value="<?= post_display('body_part', $test->body_part) ?>"/>
                                            </div>
                                            <div class="mb-1 col-md-4">
                                                <label class="form-label" for="disease_name"><?= _('Disease Name') ?></label>
                                                <input type="text" name="disease_name" id="disease_name" class="form-control" placeholder="<?= _('Disease Name') ?>" value="<?= post_display('disease_name', $test->disease_name) ?>"/>
                                            </div>

                                        </div>
                                        <div class="row">
                                            <div class="mb-1 col-md-4">
                                                <label class="form-label" for="description">Description</label>
                                                <textarea name="description" id="" cols="30" rows="4" class="form-control"><?= post_display('description', $test->description) ?></textarea>
                                            </div>
                                            <div class="mb-1 col-md-4">
                                                <label class="form-label" for="requirement">Sample Type</label>
                                                <textarea name="requirement" cols="30" rows="4" class="form-control"><?= post_display('requirement', $test->requirement) ?></textarea>
                                            </div>
                                            <div class="mb-1 col-md-4">
                                                <label class="form-label" for="preparation">Preparation</label>
                                                <textarea name="preparation" cols="30" rows="4" class="form-control"><?= post_display('preparation', $test->preparation) ?></textarea>
                                            </div>
                                        </div>
                                        <div class="row">
                                            <div class="mb-1 col-md-4">
                                                <label class="form-check-label mb-50" for="is_package"><?= __('Is Package') ?></label>
                                                <div class="form-check form-check-success form-switch">
                                                    <input type="checkbox" name="is_package" class="form-check-input" <?= post_display('is_package', $test->is_package) == 1 ? 'checked' : '' ?> />
                                                </div>
                                            </div>
                                            <div class="mb-1 col-md-4">
                                                <label class="form-label">Package Category</label>
                                                <select name="package_category" id="package_category" class="select2 form-select">
                                                    <option value="" {{ $test->package_category=='' ? "selected" : ''  }}>Select Category</option>
                                                    <option value="Silver" {{ $test->package_category=='Silver' ? "selected" : ''  }}>Silver</option>
                                                    <option value="Gold" {{ $test->package_category=='Gold' ? "selected" : ''  }}>Gold</option>
                                                    <option value="Diamond" {{ $test->package_category=='Diamond' ? "selected" : ''  }}>Diamond</option>
                                                </select>
                                            </div>
                                            <div class="mb-1 col-md-4">
                                                <label class="form-label" for="e_report_hours"><?= _('E - Report Hours') ?></label>
                                                <input type="number" name="e_report_hours"  value="<?= post_display('e_report_hours', $test->e_report_hours) ?>" id="e_report_hours" class="form-control" placeholder="<?= _('E - Report Hours') ?>"  />
                                            </div>
                                        </div>
                                        <div class="row">
                                            <div class="mb-1 col-md-4">
                                                <label class="form-check-label mb-50" for="home_collection"><?= __('Home Collection') ?></label>
                                                <div class="form-check form-check-success form-switch">
                                                    <input type="checkbox" name="home_collection" class="form-check-input"  <?= post_display('home_collection', $test->home_collection) == 1 ? 'checked' : '' ?>/>
                                                </div>
                                            </div>
                                            <div class="mb-1 col-md-4">
                                                <label class="form-label" for="discount"><?= _('Discount(%)') ?></label>
                                                <input type="text" name="discount" id="discount" value="<?= post_display('discount', $test->discount) ?>" class="form-control" placeholder="<?= _('Discount') ?>"/>
                                            </div>
                                            <div class="mb-1 col-md-4">
                                                <label class="form-label" for="price"><?= _('Price(Rs)*') ?></label>
                                                <input type="number" name="price" id="price" value="<?= post_display('price', $test->price) ?>" class="form-control" placeholder="<?= _('Price') ?>"  required/>
                                            </div>
                                        </div>
                                        <div class="row">
                                            <div class="mb-1 col-md-12 mt-1 b-b-10">
                                                <span class="fw-bolder me-25">Lab Details</span>
                                            </div>
                                        </div>
                                        <div class="row">
                                            <div class="mb-1 col-md-3 mt-1">
                                                <span><?= _('Lab Name') ?></span>
                                                <br>
                                                <span class="fw-bolder me-25">{{ $test->lab->name }}</span>
                                            </div>
                                            <div class="mb-1 col-md-3 mt-1">
                                                <span><?= _('Contact Person') ?></span>
                                                <br>
                                                <span class="fw-bolder me-25">{{ $test->lab->contact_person? $test->lab->contact_person:'-' }}</span>
                                            </div>
                                            <div class="mb-1 col-md-3 mt-1">
                                                <span><?= _('Phone') ?></span>
                                                <br>
                                                <span class="fw-bolder me-25">{{ $test->lab->phone?$test->lab->phone:'-' }}</span>
                                            </div>
                                            <div class="mb-1 col-md-3 mt-1">
                                                <span><?= _('Mobile') ?></span>
                                                <br>
                                                <span class="fw-bolder me-25">{{ $test->lab->mobile? $test->lab->mobile:'-' }}</span>
                                            </div>
                                            <div class="mb-1 col-md-12 mt-1">
                                                <span><?= _('Lab Address') ?></span>
                                                <br>
                                                <span class="fw-bolder me-25">
                                                    {{ $test->lab->address1 }}, {{ $test->lab->address2 }}, {{ $test->lab->area }}
                                                    , {{ $test->lab->city->name }}, {{ $test->lab->state->name }}-, {{ $test->lab->pincode }}
                                                </span>
                                            </div>
                                            <?php if ($test->labParent) { ?>
                                                <div class="mb-1 col-md-12 mt-1">
                                                    <span><?= _('Note') ?></span>
                                                    <br>
                                                    <span class="fw-bolder me-25">This lab is working under the {{ $test->labParent->name}}</span>
                                                </div>
                                            <?php } ?>
                                        </div>
                                    </div>
                                    <div id="test-details-info" class="content" role="tabpanel" aria-labelledby="test-details-modern-trigger">
                                        <div class="row">
                                            <div class="col-md-12">
                                                <label class="form-label" for="test_count"><?= _('Total Test Count') ?></label>
                                                <input type="number" name="test_count" id="test_count" class="form-control" placeholder="<?= _('Test Count') ?>" value="<?= post_display('test_count', $test->test_count) ?>" />
                                            </div>
                                            <div class="mt-1 mb-1 col-12"><div id="error-alert" class="error"></div></div>
                                            <div class="mb-1 col-md-9">
                                                <label class="form-label">Test title</label>
                                                <!--<input data-id="title" type="text" placeholder="Test title" value="" class="form-control"/>-->
                                                <input type="text" data-id="title" class="form-control test_search" placeholder="<?= _('Search Test From Master') ?>"
                                                       value="{{app('request')->input('test')}}"/>
                                            </div>
                                            <div class="mb-1 col-md-3">
                                                <input type="hidden" name="test_desc_json" value="{{$test->test_desc_json}}" data-id="desc-json" />
                                                <a data-id="btn-add" class="btn btn-primary mt-2 me-1 waves-effect waves-float waves-light">Add</a>
                                            </div>
                                            <div class="mb-1 col-md-12">
                                                <ul class="list-group" data-id="data-list">
                                                </ul>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </section>
                        <div class="row" data-select2-id="12">
                            <div class="col-12">
                                <button type="submit" class="btn btn-primary me-1 waves-effect waves-float waves-light">Save changes</button>
                                <?php if ($flag == 'Lab') { ?>
                                    <a href="{{route('admin.lab.test', ['lab_id'=>$test->lab_id])}}" class="btn btn-outline-secondary waves-effect">Back</a>
                                <?php } else { ?>
                                    <a href="{{route('admin.lab.test')}}" class="btn btn-outline-secondary waves-effect">Back</a>
                                <?php } ?>
                            </div>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>
</div>
@endsection

