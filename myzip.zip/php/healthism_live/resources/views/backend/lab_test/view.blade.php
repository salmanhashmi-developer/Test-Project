@extends("backend.layouts.master")
@section('title') Test View @endsection
@section('content')

<!-- BEGIN: Content-->
<div class="app-content content ">

    <div class="content-wrapper p-0">

        <div class="content-body">
            @include('backend.message')
            <div class="card" data-select2-id="14">
                <div class="card-header border-bottom">
                    <h4 class="card-title">Test Details View</h4>
                </div>
                <div class="card-body py-2 my-25" data-select2-id="53">
                    <!-- header section -->

                    <!-- Modern Horizontal Wizard -->
                    <section class="modern-horizontal-wizard">
                        <div class="bs-stepper wizard-modern modern-wizard-example">
                            <div class="bs-stepper-header">
                                <div class="step" data-target="#account-details-modern" role="tab" id="account-details-modern-trigger">
                                    <button type="button" class="step-trigger">
                                        <span class="bs-stepper-box"><i data-feather="user" class="font-medium-3"></i></span>
                                        <span class="bs-stepper-label">
                                            <span class="bs-stepper-title">Test Details</span>
                                        </span>
                                    </button>
                                </div>
                                <div class="line"><i data-feather="chevron-right" class="font-medium-2"></i></div>
                                <div class="step" data-target="#personal-info-modern" role="tab" id="personal-info-modern-trigger">
                                    <button type="button" class="step-trigger">
                                        <span class="bs-stepper-box"><i data-feather="file-text" class="font-medium-3"></i></span>
                                        <span class="bs-stepper-label">
                                            <span class="bs-stepper-title">Additional Details</span>
                                        </span>
                                    </button>
                                </div>

                            </div>
                            <div class="bs-stepper-content">
                                <div style="font-size: 12px;" id="account-details-modern" class="content" role="tabpanel" aria-labelledby="account-details-modern-trigger">
                                    <div class="row">
                                        <div class="mb-1 col-md-2">
                                            <span><?= _('Name') ?></span>
                                            <br>
                                            <span class="fw-bolder me-25">{{ $test->name }}</span>
                                        </div>
                                        <div class="mb-1 col-md-2">
                                            <span><?= _('Type') ?></span><br>
                                            <span class="fw-bolder me-25">{{ $test->is_package==1?'Package':'Test' }}</span>
                                        </div>
                                        <div class="mb-1 col-md-2">
                                            <span><?= _('Category') ?></span><br>
                                            <span class="fw-bolder me-25">{{ $test->package_category }}</span>
                                        </div>
                                        <div class="mb-1 col-md-2">
                                            <span><?= _('Status') ?></span><br>
                                            <span class="fw-bolder me-25 <?php echo $test->status_id == 1 ? 'text-success' : 'text-danger'; ?>">{{ $test->status->name }}</span>
                                        </div>
                                        <div class="mb-1 col-md-2">
                                            <span><?= _('Gender') ?></span><br>
                                            <span class="fw-bolder me-25">{{ $test->gender }}</span>
                                        </div>
                                        <div class="mb-1 col-md-2">
                                            <span><?= _('Home Collection') ?></span><br>
                                            <span class="fw-bolder me-25">{{ $test->home_collection==1?'Yes':'No' }}</span>
                                        </div>
                                    </div>
                                    <div class="row" style="border-bottom: 1px solid #efefef;padding: 15px 0px;">
                                        <div class="mb-1 col-md-2">
                                            <span><?= _('Price') ?></span>
                                            <br>
                                            <span class="fw-bolder me-25"> Rs.{{ $test->price }}</span>
                                        </div>
                                        <div class="mb-1 col-md-2">
                                            <span><?= _('Discount') ?></span><br>
                                            <span class="fw-bolder me-25">{{ $test->discount }}%</span>
                                        </div>

                                        <div class="mb-1 col-md-2">
                                            <span><?= _('E Report Hours') ?></span><br>
                                            <span class="fw-bolder me-25">{{ $test->e_report_hours }} Hours</span>
                                        </div>
                                        <div class="mb-1 col-md-2">
                                            <span><?= _('Alias Name') ?></span>
                                            <br>
                                            <span class="fw-bolder me-25">{{ $test->alias_name }}</span>
                                        </div>
                                        <div class="mb-1 col-md-2">
                                            <span><?= _('Body Part') ?></span>
                                            <br>
                                            <span class="fw-bolder me-25">{{ $test->body_part }}</span>
                                        </div>
                                        <div class="mb-1 col-md-2">
                                            <span><?= _('Disease Name') ?></span>
                                            <br>
                                            <span class="fw-bolder me-25">{{ $test->disease_name }}</span>
                                        </div>
                                    </div>
                                    <div class="row">
                                        <div class="col-md-7">
                                            <div class="row">
                                                <div class="mb-1 col-md-12" style="border-bottom: 1px solid #efefef;padding: 12px 0px;line-height: 2em;">
                                                    <span><?= _('Description') ?></span>
                                                    <br>
                                                    <span class="fw-bolder me-25">{{ $test->description }}</span>
                                                </div>
                                                <div class="mb-1 col-md-12" style="border-bottom: 1px solid #efefef;padding: 12px 0px;line-height: 2em;">
                                                    <span><?= _('Preparation') ?></span>
                                                    <br>
                                                    <span class="fw-bolder me-25">{{ $test->preparation }}</span>
                                                </div>
                                                <div class="mb-1 col-md-12" style="border-bottom: 1px solid #efefef;padding: 12px 0px;line-height: 2em;">
                                                    <span><?= _('Requirement') ?></span>
                                                    <br>
                                                    <span class="fw-bolder me-25">{{ $test->requirement }}</span>
                                                </div>
                                            </div>
                                        </div>
                                        <div class="col-md-5" style="padding: 15px 18px 0px 20px;border-left: 1px solid #dfd8d8;">
                                            <div class="row">
                                                <div class="mb-1 col-md-6 mt-1">
                                                    <span><?= _('Lab Name') ?></span>
                                                    <br>
                                                    <span class="fw-bolder me-25">{{ $test->lab->name }}</span>
                                                </div>
                                                <div class="mb-1 col-md-6 mt-1">
                                                    <span><?= _('Contact Person') ?></span>
                                                    <br>
                                                    <span class="fw-bolder me-25">{{ $test->lab->contact_person? $test->lab->contact_person:'-' }}</span>
                                                </div>
                                                <div class="mb-1 col-md-12 mt-1">
                                                    <span><?= _('Lab Address') ?></span>
                                                    <br>
                                                    <span class="fw-bolder me-25">
                                                        {{ $test->lab->address1 }}, {{ $test->lab->address2 }}, {{ $test->lab->area }}
                                                        , {{ $test->lab->city->name }}, {{ $test->lab->state->name }}-, {{ $test->lab->pincode }}
                                                    </span>
                                                </div>
                                                <div class="mb-1 col-md-6 mt-1">
                                                    <span><?= _('Phone') ?></span>
                                                    <br>
                                                    <span class="fw-bolder me-25">{{ $test->lab->phone?$test->lab->phone:'-' }}</span>
                                                </div>
                                                <div class="mb-1 col-md-6 mt-1">
                                                    <span><?= _('Mobile') ?></span>
                                                    <br>
                                                    <span class="fw-bolder me-25">{{ $test->lab->mobile? $test->lab->mobile:'-' }}</span>
                                                </div>
                                                <?php if ($test->labParent) { ?>
                                                    <div class="mb-1 col-md-12 mt-1">
                                                        <span><?= _('Note') ?></span>
                                                        <br>
                                                        <span class="fw-bolder me-25">This lab is working under the {{ $test->labParent->name}}</span>
                                                    </div>
                                                <?php } ?>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                <div id="personal-info-modern" class="content f-12" role="tabpanel" aria-labelledby="personal-info-modern-trigger">
                                    <div>
                                        <div class="col-xl-12  b-b-10 d-flex align-items-start me-2">
                                            <b style="font-size: 15px;">Test Details</b> <small>(Total {{$test->test_count}} test)</small>
                                        </div>
                                        <?php
                                        if (!empty($test->test_json)) {
                                            foreach ($test->test_json as $key => $mainTest) {
                                                ?>
                                                <div class="col-xl-12 p-b-10 p-t-10 b-b-10 d-flex align-items-start me-2">
                                                    <div class="row">
                                                        <div class="col-xl-12 p-b-10 me-2">
                                                            <b><?php echo $mainTest['parent']; ?></b> 
                                                        </div>
                                                        <?php
                                                        if (!empty($mainTest['children'])) {
                                                            foreach ($mainTest['children'] as $key => $subTest) {
                                                                ?>
                                                                <div class="col-xl-12 p-b-10 me-2">
                                                                    <?php echo $subTest; ?>
                                                                </div>
                                                                <?php
                                                            }
                                                        }
                                                        ?>
                                                    </div>
                                                </div>
                                                <?php
                                            }
                                        }
                                        ?>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </section>
                    <div class="row" data-select2-id="12">
                        <div class="col-12">
                            <?php if ($flag == 'Lab') { ?>
                                <a href="{{ route('admin.lab.test.edit', ['id'=>$test->id,'flag'=>'Lab'] )  }}" class="btn btn-primary me-1 waves-effect waves-float waves-light" > Edit</a>
                                <a href="{{route('admin.lab.test', ['lab_id'=>$test->lab_id])}}" class="btn btn-outline-secondary waves-effect">Back</a>
                            <?php } else { ?>
                                <a href="{{ route('admin.lab.test.edit', ['id'=>$test->id,'flag'=>'Globle'] )  }}" class="btn btn-primary me-1 waves-effect waves-float waves-light" > Edit</a>
                                <a href="{{route('admin.lab.test')}}" class="btn btn-outline-secondary waves-effect">Back</a>
                            <?php } ?>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
@endsection
