@extends("backend.layouts.master")
@section('title') User List @endsection
@section('content')

<!-- BEGIN: Content-->
<div class="app-content content ">

    <div class="content-wrapper p-0">

        <div class="content-body">
            @include('backend.message')
            <section class="app-user-view-account">
                <div class="row">
                    <!-- User Sidebar -->
                    <div class="col-xl-12 col-lg-12 col-md-12 order-1 order-md-0">
                        <!-- User Card -->
                        <div class="card">
                            <div class="card-body">
                                <h4 class="fw-bolder border-bottom pb-50 mb-1">User Details View</h4>
                                <div class="d-flex">
                                    <div class="col-xl-8 col-lg-8 col-md-8 align-items-start me-2">
                                        <div class="info-container">
                                            <ul class="list-unstyled f-12">
                                                <li class="mb-75 mt-2">
                                                    <div class="row">
                                                        <div class="mb-1 col-md-3">
                                                            <span><?= _('First Name') ?></span>
                                                            <br>
                                                            <span class="fw-bolder me-25">{{ $user->first_name }}</span>
                                                        </div>
                                                        <div class="mb-1 col-md-3">
                                                            <span><?= _('Last Name') ?>:</span>
                                                            <br>
                                                            <span class="fw-bolder me-25">{{ $user->last_name }}</span>
                                                        </div>
                                                        <div class="mb-1 col-md-3">
                                                            <span><?= _('Mobile') ?>:</span>
                                                            <br>
                                                            <span class="fw-bolder me-25">{{ $user->mobile  }}</span>
                                                        </div>
                                                        <div class="mb-1 col-md-3">
                                                            <span><?= _('DOB') ?>:</span>
                                                            <br>
                                                            <span class="fw-bolder me-25">{{ date("d/m/Y",strtotime($user->dob))  }}</span>
                                                        </div>
                                                    </div>
                                                </li>
                                                <li class="mb-75 mt-2">
                                                    <div class="row">
                                                        <div class="mb-1 col-md-6">
                                                            <span><?= _('Email Id') ?>:</span>
                                                            <br>
                                                            <span class="fw-bolder me-25">{{ $user->email}}</span>
                                                        </div>
                                                        <div class="mb-1 col-md-3">
                                                            <span><?= _('Ref. Code') ?> : </span>
                                                            <br>
                                                            <span class="fw-bolder me-25">{{ $user->ref_code }}</span>
                                                        </div>
                                                        <div class="mb-1 col-md-3">
                                                            <span><?= _('Gender') ?>: </span>
                                                            <br>
                                                            <span class="fw-bolder me-25">{{ $user->gender }}</span>
                                                        </div>
                                                    </div>
                                                </li>
                                                <li class="mb-75 mt-2">
                                                    <div class="row">                                                        
                                                        <div class="mb-1 col-md-3">
                                                            <span><?= _('User Type') ?>:</span>
                                                            <br>
                                                            <span class="fw-bolder me-25">{{ $user->userType->name }}</span>
                                                        </div>
                                                        <div class="mb-1 col-md-3">
                                                            <span><?= _('Created Date') ?>:</span>
                                                            <br>
                                                            <span class="fw-bolder me-25">{{ date("d/m/Y",strtotime($user->created_at)) }}</span>
                                                        </div>
                                                        <div class="mb-1 col-md-3">
                                                            <span><?= _('Updated Date') ?>:</span>
                                                            <br>
                                                            <span class="fw-bolder me-25">{{ date("d/m/Y",strtotime($user->updated_at))  }}</span>
                                                        </div>
                                                        <div class="mb-1 col-md-3">
                                                            <span><?= _('Status') ?>:</span>
                                                            <br>
                                                            <span class="fw-bolder me-25">{{ $user->status->name  }}</span>
                                                        </div>
                                                    </div>
                                                </li>
                                            </ul>
                                            <div class="d-flex pt-2">
                                                <a href="{{ route('admin.user.edit', ['id'=>$user->id] )  }}" class="btn btn-primary me-1 waves-effect waves-float waves-light" >
                                                    Edit
                                                </a>
                                                <?php if ($user->user_type_id == END_USER && $user->status_id == STATUS_ACTIVE) { ?>
                                                    <a href="{{route('admin.user.plan.list', ['id'=>$user->id])}}" class="btn btn btn-outline-warning me-1 suspend-user waves-effect">View Plan</a>
                                                <?php } ?>
                                                <a href="{{route('admin.user')}}" class="btn btn-outline-secondary waves-effect">Back</a>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="col-xl-4 col-lg-4 col-md-4 d-flex align-items-start me-2">
                                        <div class="user-avatar-section">
                                            <div class="d-flex align-items-center flex-column">
                                                <?php $src = !empty($user->photo) != '' ? '/image/use_profile/' . $user->photo : '/admin-assets/images/icons/file-icons/no_document.png'; ?>
                                                <a href="<?php echo $src; ?>" class="" target="_blank"><img class="img-fluid rounded mt-1 mb-3" alt="" src="<?php echo $src; ?>" height="110" width="110" alt="User avatar"></a>                                     
                                            </div>
                                        </div>								
                                    </div>
                                </div>		
                            </div>
                            <!-- /User Card -->
                        </div>
                        <!--/ User Sidebar -->

                    </div>
                </div>
            </section>

        </div>
    </div>
</div>
@endsection
