@extends("backend.layouts.master")
@section('title') User Add @endsection
@section('content')
<!-- BEGIN: Content-->
<div class="app-content content ">

    <div class="content-wrapper p-0">

        <div class="content-body">

            <div class="card" data-select2-id="14">
                <div class="card-header border-bottom">
                    <h4 class="card-title">Add New User Details</h4>
                </div>
                <div class="card-body py-2 my-25" data-select2-id="53">
                    <!-- header section -->

                    <!-- form -->
                    @include('backend.message')

                    <form class="needs-validation" method="POST" action="{{route('admin.user.store')}}" method="POST" enctype="multipart/form-data" novalidate>
                        {{ csrf_field() }}

                        <div class="row" data-select2-id="12">
                            <div class="col-12 col-sm-6 mb-1">
                                <label class="form-label" for="user_type">User Type</label>
                                <select name="user_type_id" id='user_type' class="select2 form-select form-control">
                                    <?php
                                    $setValues = END_USER;
                                    foreach ($userTypes as $type):
                                        ?>
                                        <option value="{{ $type->id }}" {{ $setValues == $type->id ? "selected" : ''  }}>{{$type->name}}</option><?php
                                    endforeach;
                                    ?>
                                </select>

                            </div>
                            <div class="col-12 col-sm-6 mb-1">
                                <label class="form-label" for="first_name"><?= _('First Name') ?></label>
                                <input type="text" name="first_name" class="form-control" placeholder="<?= _('First Name') ?>" value="{{ post_display('first_name')  }}" required/>
                            </div>
                            <div class="col-12 col-sm-6 mb-1">
                                <label class="form-label" for="last_name"><?= _('Last Name') ?></label>
                                <input type="text" name="last_name" class="form-control" placeholder="<?= _('Last Name') ?>" value="{{ post_display('last_name')  }}" required/>
                            </div>
                            <div class="col-12 col-sm-6 mb-1">
                                <label class="form-label" for="email"><?= _('Email') ?></label>
                                <input type="email" name="email" class="form-control" placeholder="<?= _('Email') ?>" value="{{ post_display('email')  }}" required/>
                            </div>
                            <div class="col-12 col-sm-6 mb-1">
                                <label class="form-label" for="mobile"><?= _('Mobile No.') ?></label>
                                <input type="text" name="mobile" class="form-control" placeholder="<?= _('Mobile No') ?>" pattern="[0-9]+" value="{{ post_display('mobile')  }}" required/>
                            </div>
                            <div class="col-12 col-sm-6 mb-1 dynamic">
                                <label class="form-label" for="dob"><?= _('DOB') ?></label>
                                <input type="text" name="dob" class="form-control datepicker" placeholder="<?= _('DOB') ?>" value="{{ post_display('dob')  }}" />
                            </div>
                            <div class="col-12 col-sm-6 mb-1 dynamic">
                                <label class="form-label" for="blood_group">Blood Group</label>
                                <select class="form-control select2" name="blood_group">
                                    <option value="">Select Blood Group</option>
                                    <?php
                                    $setValues = post_display('blood_group');
                                    ?>
                                    @foreach($bloodGroups as $bloodGroup)
                                    <option value="<?= $bloodGroup ?>" <?= $bloodGroup == $setValues ? 'selected' : '' ?>><?= $bloodGroup ?></option>
                                    @endforeach
                                </select>

                            </div>
                            <div class="col-12 col-sm-6 mb-1 dynamic">
                                <label class="form-label" for="gender">Gender</label>
                                <select class="form-control select2" name="gender">

                                    <option value="">Select Gender</option>
                                    <?php
                                    $setValues = post_display('gender');
                                    ?>
                                    @foreach($genders as $gender)
                                    <option value="<?= $gender ?>" <?= $gender == $setValues ? 'selected' : '' ?>><?= $gender ?></option>
                                    @endforeach
                                </select>

                            </div>
                            <div class="col-12 col-sm-6 mb-1">
                                <label class="form-label" for="status_id">Status</label>
                                <select class="form-control select2" name="status_id">
                                    <?php
                                    $status = [1 => 'Active', 2 => 'In Active', 26 => 'Block'];
                                    $setValues = post_display('status_id');
                                    ?>
                                    @foreach($status as $key=>$val)
                                    <option value="<?= $key ?>" <?= $key == $setValues ? 'selected' : '' ?>><?= $val ?></option>
                                    @endforeach
                                </select>

                            </div>


                            <div class="mb-1 col-md-6 dynamic">
                                <label class="form-label" for="short_desc"><?= _('Upload Profile Pic') ?></label>

                                <div data-provides="fileupload" class="fileupload fileupload-new">

                                    <div style="width: 200px; height: 150px;" class="fileupload-new thumbnail">
                                        <?php $src = '/admin-assets/images/icons/file-icons/no_document.png'; ?>
                                        <img alt="" src="<?php echo $src; ?>">
                                    </div>

                                    <div style="max-width: 200px; max-height: 150px; line-height: 20px;" class="fileupload-preview fileupload-exists thumbnail"></div>

                                    <div style="width: 157px;">
                                        <span class="btn btn-file"><span class="fileupload-new">Select image</span>
                                            <span class="fileupload-exists">Change</span>
                                            <input type="file" accept="image/*"  name="photo"></span>
                                    </div>
                                </div>
                            </div>


                            <div class="col-12">
                                <button type="submit" class="btn btn-primary mt-1 me-1 waves-effect waves-float waves-light">Save changes</button>
                                <a class="btn btn-outline-secondary mt-1 waves-effect" href="{{ route("admin.user") }}">Back</a>
                            </div>
                        </div>
                    </form>
                    <!--/ form -->
                </div>
            </div>

        </div>


    </div>
</div>
<script>
    $('#user_type').on('change', function (e) {
        if (this.value) {
            var usertype = this.value;
        } else {
            var usertype = 1;
        }
        if (usertype == 1 || usertype == 2) {
            $('.dynamic').hide();
        } else {
            $('.dynamic').show();
        }
    });
</script>
@endsection

