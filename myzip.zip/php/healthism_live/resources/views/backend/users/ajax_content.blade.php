
<div class="row">
    <form class="" method="POST" action="{{ route('admin.user') }}" id="search_form" onsubmit="return false">
        {{ csrf_field() }}
        <div class="col-12">
            <div class="card">
                <div class="card-header border-bottom">
                    <h4 class="card-title">{{ __("User List")  }}</h4>
                    <div class="dt-action-buttons d-flex align-items-center justify-content-center justify-content-lg-end flex-lg-nowrap flex-wrap">
                        <div class="dt-buttons d-inline-flex">
                            <a class="dt-button add-new btn btn-primary" href="{{ route("admin.user.add")  }}">{{ __("Add New User")  }}</a> 
                        </div>
                    </div>
                </div>
                <!--Search Form -->
                <div class="card-body mt-2">
                    <input type="hidden" name="page" id="page" value="{{ empty(app('request')->input('page')) ? 1 : app('request')->input('page')  }}">
                    <input type="hidden" name="sort_field" id="sort_field" value="{{ app('request')->input('sort_field') }}">
                    <input type="hidden" name="sort_action" id="sort_action" value="{{ app('request')->input('sort_action') }}">
                    <div class="row g-1 mb-md-1">
                        <div class="col-md-2">
                            <label class="form-label">First Name</label>
                            <input type="text" class="form-control dt-input dt-full-name" placeholder="First Name" name="first_name" value="{{app('request')->input('first_name')}}">
                        </div>
                        <div class="col-md-2">
                            <label class="form-label">Last Name</label>
                            <input type="text" class="form-control dt-input" placeholder="Last Name" name="last_name" value="{{app('request')->input('last_name')}}">
                        </div>
                        <div class="col-md-2">
                            <label class="form-label">Mobile</label>
                            <input type="text" class="form-control dt-input" placeholder="Mobile No" name="mobile" value="{{app('request')->input('mobile')}}">
                        </div>
                        <div class="col-md-2">
                            <label class="form-label">Ref. Code</label>
                            <input type="text" class="form-control dt-input" placeholder="Ref. Code" name="ref_code" value="{{app('request')->input('ref_code')}}">
                        </div>
                        <div class="col-md-3">
                            <label class="form-label">User Type</label>
                            <select name="user_type" class="select2 form-select form-control">
                                <option value="">Type</option>
                                <?php foreach ($userType as $type): ?>
                                    <option value="{{ $type->id }}" {{ app('request')->input('user_type') == $type->id ? "selected" : ''  }}>{{$type->name}}</option><?php
                                endforeach;
                                ?>
                            </select>
                        </div>

                    </div>
                    <div class="row g-1">
                        <div class="col-md-4">
                            <label class="form-label">Email</label>
                            <input type="text" class="form-control dt-input" placeholder="Email Address" name="email" value="{{app('request')->input('email')}}">
                        </div>
                        <div class="col-md-3">
                            <div style="float:left;margin-right:5px;">
                                <label class="form-label">Start Date</label>
                                <input type="text" name="start_date" class="form-control datepicker" placeholder="Start Date" value="{{ request_display('start_date') }}" />
                            </div>
                        </div>
                        <div class="col-md-3">
                            <div style="float:left">
                                <label class="form-label">End Date</label>
                                <input type="text" name="end_date" class="form-control datepicker" placeholder="End Date" value="{{ request_display('end_date') }}" />
                            </div>
                        </div>
                        <div class="col-md-2">
                            <label class="form-label"></label>
                            <button type="submit" class="btn btn-primary mt-2 waves-effect waves-float waves-light">Search</button>
                        </div>
                    </div>
                </div>
                <hr class="my-0">
                <div class="card-datatable">
                    <?php echo parPageRecordDropDown() ?>
                    @if(!$users->isEmpty())
                    @php $start = $users->firstItem(); @endphp
                    <div class="table-responsive">

                        <table class="table table-bordered table-hover">
                            <thead>
                                <tr role="row">
                                    <th>No.</th>
                                    <th><?php echo sort_field_display('fname', 'Name'); ?> <br/> <?php echo sort_field_display('lname', ''); ?></th>
                                    <th><?php echo sort_field_display('email', 'Email'); ?></th>
                                    <th><?php echo sort_field_display('mobile', 'Mobile'); ?></th>
<!--                                    <th><?php echo sort_field_display('dob', 'Dob'); ?></th>
                                    <th><?php echo sort_field_display('bloodGroup', 'Blood Group'); ?></th>
                                    <th><?php echo sort_field_display('gender', 'Gender'); ?></th>-->
                                    <th><?php echo sort_field_display('userType', 'User Type'); ?></th>
                                    <th><?php echo sort_field_display('status', 'Status'); ?></th>
                                    <th>Created At</th>
                                    <th>Actions</th>
                                </tr>
                            </thead>
                            <tbody>
                                @foreach($users as $user)
                                <tr class="f-12">
                                    <td><?= $start++; ?></td>
                                    <td valign="top">{{ $user->first_name }}  {{ $user->last_name }}
                                        @if(!empty($user->ref_code))
                                        <br><span><b style="font-size: 9px;">(Ref. Code : {{$user->ref_code}})</b></span>
                                        @endif
                                    </td>
                                    <td valign="top">{{ $user->email}}</td>
                                    <td valign="top">{{ $user->mobile }}</td>
<!--                                    <td valign="top">{{ date("d/m/Y",strtotime($user->dob))  }}</td>
                                    <td valign="top">{{ $user->blood_group  }}</td>
                                    <td valign="top">{{ $user->gender  }}</td>-->
                                    <td valign="top">{{ $user->userType->name }}</td>
                                    <td class="<?php echo $user->status_id == STATUS_ACTIVE ? 'text-success' : 'text-danger'; ?>" valign="top">
                                        {{ $user->status->name }}
                                    </td>
                                    <td>
                                        {{ date("d M Y h:m A",strtotime($user->created_at))  }}
                                    </td>
                                    <td>
                                        <div class="text-nowrap">
                                            <a title="View Detail" href="{{  route('admin.user.view', ['id'=>$user->id] )  }}">
                                                <i data-feather="file-text" class="me-50 text-dark"></i>
                                            </a>
                                            <a title="Edit User" href="{{  route('admin.user.edit', ['id'=>$user->id] )  }}">
                                                <i data-feather="edit" class="me-50 text-dark"></i>
                                            </a>
                                            <?php if ($user->user_type_id == END_USER && $user->status_id == STATUS_ACTIVE) { ?>
                                                <a title="Add Plan" href="{{  route('admin.user.plan.list', ['id'=>$user->id] )  }}">
                                                    <i data-feather="folder-plus" class="me-50 text-dark"></i>
                                                </a>
                                            <?php } ?>
                                        </div>
                                    </td>
                                </tr>
                                @endforeach
                            </tbody>
                        </table>
                    </div>
                    @endif
                    <?php echo pagination($users) ?>
                </div>
            </div>
        </div>
    </form>

</div>
