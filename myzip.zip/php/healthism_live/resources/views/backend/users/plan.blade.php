@extends("backend.layouts.master")
@section('title') User List @endsection
@section('content')

<!-- BEGIN: Content-->
<div class="app-content content ">

    <div class="content-wrapper p-0">

        <div class="content-body">
            @include('backend.message')
            <section class="app-user-view-account">
                <div class="row">
                    <!-- User Sidebar -->
                    <div class="col-xl-12 order-1 order-md-0">
                        <!-- User Card -->
                        <div class="card">
                            <div class="card-body">
                                <h4 class="fw-bolder border-bottom pb-50 mb-1">User Details</h4>
                                <div class="info-container">
                                    <div class="row">
                                        <div class="col-12 col-sm-6 col-md-4 mb-75">
                                            <div class="fw-bolder me-25">First Name</div>
                                            <div>{{ $user->first_name  }}</div>
                                        </div>
                                        <div class="col-12 col-sm-6 col-md-4 mb-75">
                                            <div class="fw-bolder me-25">Last Name</div>
                                            <div>{{ $user->last_name  }}</div>
                                        </div>
                                        <div class="col-12 col-sm-6 col-md-4 mb-75">
                                            <div class="fw-bolder me-25">Email Id</div>
                                            <div>{{ $user->email  }}</div>
                                        </div>
                                        <div class="col-12 col-sm-6 col-md-4 mb-75">
                                            <div class="fw-bolder me-25">Mobile</div>
                                            <div>{{ $user->mobile  }}</div>
                                        </div>
                                        <div class="col-12 col-sm-6 col-md-4 mb-75">
                                            <div class="fw-bolder me-25">Status</div>
                                            <div>{{ $user->status->name  }}</span>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                <!-- /User Card -->
                            </div>
                            <!--/ User Sidebar -->
                        </div>
                    </div>
            </section>

            <div class="card">
                <div class="card-body">
                    <section id="pricing-plan">
                        <!-- title text and switch button -->
                        <div class="text-center">
                            <h1 class="mt-2">Pricing Plans</h1>
                            <p class="mb-2 pb-75">All plans here. Choose the best plan to fit your needs.</p>
                            <!--                            <div class="d-flex align-items-center justify-content-center mb-5 pb-50">
                                                            <h6 class="me-1 mb-0">Monthly</h6>
                                                            <div class="form-check form-switch">
                                                                <input type="checkbox" class="form-check-input" id="priceSwitch">
                                                                <label class="form-check-label" for="priceSwitch"></label>
                                                            </div>
                                                            <h6 class="ms-50 mb-0">Annually</h6>
                                                        </div>-->
                        </div>
                        <!--/ title text and switch button -->

                        <!-- pricing plan cards -->
                        <div class="row pricing-card">
                            <div class="col-12 col-sm-offset-2 col-sm-10 col-md-12 col-lg-offset-2 col-lg-10 mx-auto">
                                <div class="row">
                                    <?php if (!empty($plan)) { ?>
                                        <div class="col-12 col-md-4">
                                            <div class="card standard-pricing popular text-center">
                                                <div class="card-body">
                                                    <h3>{{$plan->subscription->name}}</h3>
                                                    <p class="card-text">{{$plan->subscription->member}} member for {{$plan->subscription->validity_in_days}} days</p>
                                                    <p class="card-text">Healthismplus Id : {{$plan->card_no}}</p>
                                                    <div class="annual-plan">
                                                        <div class="plan-price mt-2">
                                                            <sup class="font-medium-1 fw-bold text-primary">RS</sup>
                                                            <span class="pricing-standard-value fw-bolder text-primary">{{$plan->amount}}</span>
                                                            <sub class="pricing-duration text-body font-medium-1 fw-bold" style="text-transform: lowercase;">/{{$plan->subscription->plan_type}}</sub>
                                                        </div>
                                                        <small class="annual-pricing d-none text-muted"></small>
                                                    </div>
                                                    <ul class="list-group list-group-circle text-start">
                                                        <?php
                                                        if (!empty($plan->subscription->terms)) {
                                                            foreach ($plan->subscription->terms as $value) {
                                                                ?>
                                                                <li class="list-group-item">{{$value}}</li>
                                                                <?php
                                                            }
                                                        }
                                                        ?>
                                                    </ul>
                                                    <button class="btn w-100 btn-outline-success mt-2 waves-effect">Your current plan</button>
                                                </div>
                                            </div>
                                        </div>
                                    <?php } ?>
                                    <?php
                                    if (!empty($planList)) {
                                        foreach ($planList as $plan) {
                                            ?>
                                            <div class="col-12 col-md-4">
                                                <div class="card standard-pricing popular text-center">
                                                    <div class="card-body">
                                                        <h3>{{$plan->name}}</h3>
                                                        <p class="card-text">{{$plan->member}} member for {{$plan->validity_in_days}} days</p>
                                                        <div class="annual-plan">
                                                            <div class="plan-price mt-2">
                                                                <sup class="font-medium-1 fw-bold text-primary">RS</sup>
                                                                <span class="pricing-standard-value fw-bolder text-primary">{{$plan->price}}</span>
                                                                <sub class="pricing-duration text-body font-medium-1 fw-bold" style="text-transform: lowercase;">/{{$plan->plan_type}}</sub>
                                                            </div>
                                                            <small class="annual-pricing d-none text-muted"></small>
                                                        </div>
                                                        <ul class="list-group list-group-circle text-start">
                                                            <?php
                                                            if (!empty($plan->terms)) {
                                                                $terms = json_decode($plan->terms, true);
                                                                if (!empty($terms)) {
                                                                    foreach ($terms as $value) {
                                                                        ?>
                                                                        <li class="list-group-item">{{$value}}</li>
                                                                        <?php
                                                                    }
                                                                }
                                                            }
                                                            ?>
                                                        </ul>
                                                        <button class="btn w-100 btn-primary mt-2 waves-effect waves-float waves-light" data-user-id="{{ $user->id  }}" data-plan-id="{{$plan->id}}" data-action="buy-plan">Buy</button>
                                                    </div>
                                                </div>
                                            </div>
                                            <?php
                                        }
                                    }
                                    ?>
                                    <!--/ standard plan -->

                                </div>
                            </div>
                        </div>
                        <!--/ pricing plan cards -->
                    </section>
                </div>
            </div>
        </div>
    </div>
</div>
<script type="text/javascript">
    $("button[data-action='buy-plan']").click(function () {
        var param = new Object();
        param["user_id"] = $(this).attr("data-user-id");
        param["plan_id"] = $(this).attr("data-plan-id");
        //console.log(param);
        if (APP.BlockConcurrentReq(2000)) {
            return;
        }
        loadingOverlay("body", "show");
        jqueryAjax("{{  route('admin.user.subscription.add')  }}", param, function (res) {
            loadingOverlay("body", "hide");
            if (res.code != 200) {
                Notification.show({type: "error", msg: res.message, timeout: 3000});
                return;
            }
            Notification.show({type: "success", msg: res.message, timeout: 3000});
            window.setTimeout(function () {
                location.reload(true);
            },3000);
        }, "", "json");

    });
</script>
@endsection
