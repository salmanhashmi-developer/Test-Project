<script>
    var csrf_field = "{{ csrf_token() }}";
</script>
<script src="{{ Helper::static_asset('admin-assets/js/module/common.js') }}"></script>
<div class="row">
    <form class="" method="POST" action="{{ route('admin.user.subscription') }}" id="search_form" onsubmit="return false">
        {{ csrf_field() }}

        <div class="col-12">
            <div class="card">
                <div class="card-header border-bottom">
                    <h4 class="card-title">{{ __("User Subscription")  }}</h4>
                </div>

                <!--Search Form -->
                <div class="card-body mt-1">
                    <input type="hidden" name="page" id="page" value="{{ empty(app('request')->input('page')) ? 1 : app('request')->input('page')  }}">
                    <input type="hidden" name="sort_field" id="sort_field" value="{{ app('request')->input('sort_field') }}">
                    <input type="hidden" name="sort_action" id="sort_action" value="{{ app('request')->input('sort_action') }}">
                    <div class="row g-1 mb-md-1">
                        <div class="col-md-4">
                            <label class="form-label">Order Id</label>
                            <input type="text" class="form-control dt-input dt-full-name" placeholder="Order Id" name="order_id" value="{{app('request')->input('order_id')}}">
                        </div>
                        <div class="col-md-4">
                            <label class="form-label">Subscription</label>
                            <select name="subscription_id" class="form-select select2">
                                <option value="">ALL</option>
                                <?php
                                $subscription_id = app('request')->input('subscription_id');
                                ?>
                                @foreach($subscription as $row)
                                <option value="<?= $row->id ?>" <?= $row->id == $subscription_id ? 'selected' : '' ?>><?= $row->name ?>(<?= $row->price ?>)</option>
                                @endforeach
                            </select>
                        </div>
                        <div class="col-md-4">
                            <label class="form-label" for="user_id"><?= _('User') ?></label>
                            <input type="text" name="user" class="form-control user_search" placeholder="<?= _('Select User') ?>"
                                   value="{{app('request')->input('user')}}"/>
                            <input type="hidden" id="user_id" name="user_id" value="{{app('request')->input('user_id')}}">
                        </div>
                    </div>
                    <div class="row g-1">
                        <div class="col-md-4">
                            <label class="form-label">Status</label>
                            <select name="status_id" class="form-select select2">
                                <option value="">ALL</option>
                                <?php
                                $status_id = app('request')->input('status_id');
                                ?>
                                @foreach($statusList as $row)
                                <option value="<?= $row['id'] ?>" <?= $row['id'] == $status_id ? 'selected' : '' ?>><?= $row['name'] ?></option>
                                @endforeach
                            </select>
                        </div>
                        <div class="col-md-4">
                            <div class="col-md-12">
                                <label class="form-label">Buy Plan : Start Date - End Sate </label>
                            </div>
                            <div class="col-md-5" style="float:left;margin-right:5px;"> <input type="text" name="start_date" class="form-control datepicker" placeholder="Start Date" value="{{ request_display('start_date') }}" /></div>
                            <div class="col-md-5" style="float:left"> <input type="text" name="end_date" class="form-control datepicker" placeholder="End Date" value="{{ request_display('end_date') }}" /></div>
                        </div>
                        <div class="col-md-4" style="margin-top: 35px;">
                            <button type="submit" name='' class="btn btn-primary waves-effect waves-float waves-light">Search</button>
                            <a id="refresh" data-url="/admin/user/subscription" class="btn btn-outline-secondary waves-effect">Reset</a>
                        </div>
                    </div>
                </div>
                <hr class="my-0">
                <div class="card-datatable">
                    <?php echo parPageRecordDropDown() ?>
                    @if(!$userSubscription->isEmpty())
                    @php $start = $userSubscription->firstItem(); @endphp
                    <div class="table-responsive">
                        <table class="table table-bordered table-hover">
                            <thead>
                                <tr role="row">
                                    <!--<th></th>-->
                                    <th>Order ID</th>
                                    <th>Card No</th>
                                    <th>User</th>
                                    <th>Book By</th>
                                    <th>Buy At</th>
                                    <th>Expiry</th>
                                    <th style="width:9%;">Status</th>
                                </tr>
                            </thead>
                            <tbody>
                                @foreach($userSubscription as $data)
                                <tr class="f-12">
                                    <!--<td><?= $start++; ?></td>-->
                                    <td valign="top">{{ $data->order_id  }}</td>
                                    <td valign="top">{{ $data->card_no}}
                                        <br><span class="f-11">({{$data->subscription->name}})</span></td>
                                    <td valign="top">
                                        {{ $data->user->first_name.' '.$data->user->last_name  }}
                                        <br><span class="f-11">{{$data->user->mobile}}</span>
                                    </td>
                                    <td valign="top">
                                        <?php if (!empty($data->bookby)) { ?>
                                            {{ $data->bookby->first_name.' '.$data->bookby->last_name}}
                                            <br><span class="f-11">{{$data->bookby->mobile}}</span></td>
                                        <?php } ?>
                                    <td valign="top">{{ date("d/m/Y",strtotime($data->created_at))}}</td>
                                    <td valign="top">{{ date("d/m/Y",strtotime($data->expiry_date))}}</td>
                                    <td valign="top">{{ $data->status->name}}</td>
                                </tr>
                                @endforeach
                            </tbody>
                        </table>
                    </div>

                    @endif
                    <?php echo pagination($userSubscription) ?>

                </div>

            </div>
        </div>
    </form>

</div>
@section('script')
<script type="text/javascript">
    $(document).ready(initCommon);
</script>

@endsection