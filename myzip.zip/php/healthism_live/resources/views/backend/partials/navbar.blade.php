<!-- BEGIN: Main Menu-->
<div class="main-menu menu-fixed menu-light menu-accordion menu-shadow" data-scroll-to-active="true">
    <div class="navbar-header">
        <ul class="nav navbar-nav flex-row">
            <li class="nav-item me-auto">
                <img src="/admin-assets/images/logo/logo.png" alt="" width="200">
            </li>
            <li class="nav-item nav-toggle">
                <a class="nav-link modern-nav-toggle pe-0" data-bs-toggle="collapse">
                    <i class="d-block d-xl-none text-primary toggle-icon font-medium-4" data-feather="x">
                    </i>
                    <i class="d-none d-xl-block collapse-toggle-icon font-medium-4 ext-primary" data-feather="disc"
                       data-ticon="disc">
                    </i>
                </a>
            </li>
        </ul>
    </div>
    <div class="shadow-bottom"></div>
    <div class="main-menu-content">
        <?php if (Auth::user()->user_type_id == ADMIN) { ?>
            <ul class="navigation navigation-main" id="main-menu-navigation" data-menu="menu-navigation">
                <li class=" nav-item">
                    <a class="d-flex align-items-center" href="#">
                        <i data-feather="grid"></i>
                        <span class="menu-title text-truncate" data-i18n="User">Master</span></a>
                    <ul class="menu-content">
                        <li
                            class="{{ Helper::checkActiveMenu('admin.user,admin.user.add,admin.user.edit,admin.user.view,admin.user.plan.list') }}">
                            <a class="d-flex align-items-center" href="{{ route('admin.user') }}">
                                <i data-feather="circle"></i><span class="menu-item text-truncate"
                                                                   data-i18n="Users"><?= _('Users') ?></span></a>
                        </li>
                        <li
                            class="{{ Helper::checkActiveMenu('admin.doctor,admin.doctor.add,admin.doctor.edit,admin.doctor.view') }}">
                            <a class="d-flex align-items-center" href="{{ route('admin.doctor') }}">
                                <i data-feather="circle"></i><span class="menu-item text-truncate"
                                                                   data-i18n="Doctors"><?= _('Doctors') ?></span></a>
                        </li>
                        <li
                            class="{{ Helper::checkActiveMenu('admin.hospital,admin.hospital.add,admin.hospital.edit,admin.hospital.view') }}">
                            <a class="d-flex align-items-center" href="{{ route('admin.hospital') }}">
                                <i data-feather="circle"></i><span class="menu-item text-truncate"
                                                                   data-i18n="Hospitals"><?= _('Hospitals') ?></span></a>
                        </li>
                        <li title="Mapping Doctor Hospital"
                            class="{{ Helper::checkActiveMenu('admin.doctor.hospital.mapping,admin.doctor.hospital.mapping.add,admin.doctor.hospital.mapping.edit,admin.doctor.hospital.mapping.view,admin.doctor.hospital.slot.store,admin.doctor.hospital.slot') }}">
                            <a class="d-flex align-items-center" href="{{ route('admin.doctor.hospital.mapping') }}">
                                <i data-feather="circle"></i><span class="menu-item text-truncate"
                                                                   data-i18n="Doctor Hospital Mapping"><?= _('Mapping Doctor Hospital') ?></span></a>
                        </li>
                        <li
                            class="{{ Helper::checkActiveMenu('admin.common.service,admin.common.service.add,admin.common.service.edit,admin.common.service.view') }}">
                            <a class="d-flex align-items-center" href="{{ route('admin.common.service') }}">
                                <i data-feather="circle"></i><span class="menu-item text-truncate"
                                                                   data-i18n="Hospitals"><?= _('Common Service') ?></span></a>
                        </li>
                        <li class="{{ Helper::checkActiveMenu('admin.city,admin.city.add,admin.city.edit') }}">
                            <a class="d-flex align-items-center" href="{{ route('admin.city') }}">
                                <i data-feather="circle"></i><span class="menu-item text-truncate"
                                                                   data-i18n="City"><?= _('City') ?></span></a>
                        </li>
                    </ul>
                </li>
                <li class=" nav-item">
                    <a class="d-flex align-items-center" href="#">
                        <span><svg version="1.1" xmlns="http://www.w3.org/2000/svg"
                                   xmlns:xlink="http://www.w3.org/1999/xlink" width="50px" height="50px"
                                   viewBox="0,0,256,256">
                            <g fill="#63626a" fill-rule="nonzero" stroke="none" stroke-width="1" stroke-linecap="butt"
                               stroke-linejoin="miter" stroke-miterlimit="10" stroke-dasharray="" stroke-dashoffset="0"
                               font-family="none" font-weight="none" font-size="none" text-anchor="none"
                               style="mix-blend-mode: normal">
                            <g transform="scale(5.12,5.12)">
                            <path
                                d="M25.001,12c-0.367,0 -0.72,-0.202 -0.896,-0.553c-1.224,-2.447 -0.268,-4.359 0.5,-5.895c0.713,-1.426 1.276,-2.553 0.5,-4.105c-0.247,-0.494 -0.047,-1.095 0.447,-1.342c0.494,-0.247 1.095,-0.047 1.342,0.447c1.224,2.447 0.268,4.359 -0.5,5.895c-0.713,1.426 -1.276,2.553 -0.5,4.105c0.247,0.494 0.047,1.095 -0.447,1.342c-0.143,0.072 -0.296,0.106 -0.446,0.106zM20.001,12c-0.367,0 -0.72,-0.202 -0.896,-0.553c-1.224,-2.447 -0.268,-4.359 0.5,-5.895c0.713,-1.426 1.276,-2.553 0.5,-4.105c-0.247,-0.494 -0.047,-1.095 0.447,-1.342c0.495,-0.247 1.095,-0.047 1.342,0.447c1.224,2.447 0.268,4.359 -0.5,5.895c-0.713,1.426 -1.276,2.553 -0.5,4.105c0.247,0.494 0.047,1.095 -0.447,1.342c-0.143,0.072 -0.296,0.106 -0.446,0.106zM30.001,12c-0.367,0 -0.72,-0.202 -0.896,-0.553c-1.224,-2.447 -0.268,-4.359 0.5,-5.895c0.713,-1.426 1.276,-2.553 0.5,-4.105c-0.247,-0.494 -0.047,-1.095 0.447,-1.342c0.494,-0.248 1.095,-0.047 1.342,0.447c1.224,2.447 0.268,4.359 -0.5,5.895c-0.713,1.426 -1.276,2.553 -0.5,4.105c0.247,0.494 0.047,1.095 -0.447,1.342c-0.143,0.072 -0.296,0.106 -0.446,0.106zM42.844,45.248c-0.008,-0.128 -0.03,-0.255 -0.049,-0.382c-0.011,-0.071 -0.014,-0.144 -0.028,-0.215c-0.006,-0.03 -0.017,-0.059 -0.024,-0.088c-0.122,-0.559 -0.348,-1.101 -0.686,-1.591l-5.807,-8.42l-1.759,-2.552v0l-3.491,-5.061v-10.939c0.553,0 1,-0.448 1,-1c0,-0.552 -0.447,-1 -1,-1h-12c-0.552,0 -1,0.448 -1,1c0,0.552 0.448,1 1,1v10.938l-3.491,5.062v0l-4.338,6.291l-3.229,4.682c-0.194,0.281 -0.343,0.58 -0.466,0.888c-0.481,1.201 -0.432,2.563 0.187,3.741c0.388,0.74 0.963,1.339 1.649,1.754c0.686,0.414 1.484,0.644 2.32,0.644h26.736c1.115,0 2.157,-0.416 2.962,-1.128c0.401,-0.355 0.748,-0.778 1.007,-1.27c0.386,-0.737 0.553,-1.546 0.507,-2.343c0,-0.003 0.001,-0.007 0,-0.011zM19.5,39c0,-1.379 1.121,-2.5 2.5,-2.5c1.379,0 2.5,1.121 2.5,2.5c0,1.379 -1.121,2.5 -2.5,2.5c-1.379,0 -2.5,-1.121 -2.5,-2.5zM33.5,42.5c0,1.654 -1.346,3 -3,3c-1.654,0 -3,-1.346 -3,-3c0,-1.654 1.346,-3 3,-3c1.654,0 3,1.346 3,3zM21,27.562v-11.562h8v11.562l3.061,4.438h-14.122z">
                            </path>
                            </g>
                            </g>
                            </svg> </span>
                        <span class="menu-title text-truncate" data-i18n="Lab">Lab</span></a>
                    <ul class="menu-content">
                        <li class="{{ Helper::checkActiveMenu('admin.lab,admin.lab.add,admin.lab.edit,admin.lab.view') }}">
                            <a class="d-flex align-items-center" href="{{ route('admin.lab') }}">
                                <i data-feather="circle"></i><span class="menu-item text-truncate"
                                                                   data-i18n="Lab"><?= _('Lab Master') ?></span></a>
                        </li>
                        <li
                            class="{{ Helper::checkActiveMenu('admin.test,admin.test.add,admin.test.edit,admin.test.view') }}">
                            <a class="d-flex align-items-center" href="{{ route('admin.test') }}">
                                <i data-feather="circle"></i><span class="menu-item text-truncate"
                                                                   data-i18n="Test"><?= _('Test Master') ?></span></a>
                        </li>
                        <li
                            class="{{ Helper::checkActiveMenu('admin.lab.test,admin.lab.test.add,admin.lab.test.edit,admin.lab.test.view') }}">
                            <a class="d-flex align-items-center" href="{{ route('admin.lab.test') }}">
                                <i data-feather="circle"></i><span class="menu-item text-truncate"
                                                                   data-i18n="Lab Test"><?= _('All Lab Test') ?></span></a>
                        </li>
                        <li class="{{ Helper::checkActiveMenu('admin.lab.booking,admin.lab.booking.view') }}">
                            <a class="d-flex align-items-center" href="{{ route('admin.lab.booking') }}">
                                <i data-feather="circle"></i><span class="menu-item text-truncate"
                                                                   data-i18n="Lab Booking"><?= _('Booking Report') ?></span></a>
                        </li>
                        {{-- <li class="{{ Helper::checkActiveMenu('admin.lab.medicine,admin.lab.medicine.view')}}">
                            <a class="d-flex align-items-center" href="{{route('admin.lab.medicine')}}">
                                <i data-feather="circle"></i><span class="menu-item text-truncate" data-i18n="Lab Booking"><?= _('Booking Medicine') ?></span></a>
                        </li> --}}
                        <li class="{{ Helper::checkActiveMenu('admin.lab.booked.test,admin.lab.booked.test.view') }}">
                            <a class="d-flex align-items-center" href="{{ route('admin.lab.booked.test') }}">
                                <i data-feather="circle"></i><span class="menu-item text-truncate"
                                                                   data-i18n="Booked Test"><?= _('Book Test') ?></span></a>
                        </li>
                    </ul>
                </li>
                <li class=" nav-item">
                    <a class="d-flex align-items-center" href="#">
                        <span>
                            <?xml version="1.0" encoding="utf-8"?>
                            <!-- Generator: Adobe Illustrator 21.1.0, SVG Export Plug-In . SVG Version: 6.00 Build 0)  -->
                            <svg version="1.1" id="Layer_1" xmlns="http://www.w3.org/2000/svg"
                                 xmlns:xlink="http://www.w3.org/1999/xlink" x="0px" y="0px" viewBox="0 0 190 190"
                                 style="enable-background:new 0 0 190 190;" xml:space="preserve">
                            <style type="text/css">
                                .st0 {
                                    fill: #63626A;
                                }
                            </style>
                            <path class="st0" d="M102.3,34.1c0,2.1,0,4,0,5.9c2,0.6,4,1,5.8,1.7c11.6,4.2,19,14.7,19,27c0,22.9,0,45.8,0,68.7c0,0.6,0,1.3,0,2
                                  c-2.1,0-4,0-6.1,0c0-20.6,0-41.1,0-61.8c-35.2,0-70.2,0-105.4,0c0,24.7,0,49.4,0,74.3c24.1,0,48.3,0,72.7,0
                                  c-7.6,13.9-5.7,26.1,5.5,37.2c-0.6,0-1.2,0.1-1.7,0.1c-24.2,0-48.5,0-72.7,0c-6.1,0-10.1-3.9-10.1-10.1c0-36.9,0-73.8,0-110.7
                                  c0-13.5,9.8-25.2,23.1-27.8c0.6-0.1,1.1-0.3,1.7-0.4c0-2,0-3.9,0-6C56.7,34.1,79.4,34.1,102.3,34.1z" />
                            <path class="st0" d="M68.1,27.7c-11.1,0-22.2,0-33.3,0c-6.1,0-10-3.9-10-10.1c0-1.9,0-3.7,0-5.6c0.1-5.1,4.1-9.1,9.2-9.1
                                  c22.8,0,45.6,0,68.4,0c5.2,0,9.2,4.1,9.3,9.3c0,2,0,4,0,6c-0.1,5.5-4.1,9.5-9.6,9.5C90.7,27.8,79.4,27.7,68.1,27.7z" />
                            <path class="st0" d="M133.2,188.7c-8.5,0-17,0.6-25.3-0.2c-10.2-0.9-18-10.6-18-21c-0.1-10.6,7.6-19.9,17.8-21.5
                                  c0.6-0.1,1.3-0.3,1.9-0.3c7.8,0,15.6,0,23.6,0C133.2,160.1,133.2,174.5,133.2,188.7z" />
                            <path class="st0" d="M139.6,189.1c0-14.6,0-28.9,0-43.5c0.8,0,1.6,0,2.3,0c6.6,0,13.2-0.1,19.8,0c10.8,0.2,19.5,8.1,21.1,19.2
                                  c1.4,9.8-5,19.9-14.7,23.1c-1.6,0.5-3.3,1-4.9,1c-7.1,0.1-14.2,0.1-21.3,0.1C141.1,189.1,140.4,189.1,139.6,189.1z" />
                            <path class="st0" d="M58.8,123.9c-3.9,0-7.7,0-11.4,0c-3.1,0-4.1-1-4.1-4c0-3.6,0-7.2,0-10.9c0-2.6,1.1-3.7,3.8-3.7
                                  c3.8,0,7.6,0,11.7,0c0-3.2,0-6.2,0-9.3c0-6,0.2-6.2,6.2-6.2c1.4,0,2.8,0,4.3,0c8.5-0.1,8.3-0.3,8.2,8.3c0,2.3,0,4.6,0,7.2
                                  c3.4,0,6.8,0,10.1,0c0.7,0,1.4,0,2.1,0c2,0.1,3.2,1.2,3.3,3.3c0.1,3.9,0,7.9,0,11.8c0,2.3-1.2,3.5-3.5,3.5c-3.9,0-7.9,0-12,0
                                  c0,3.8,0,7.5,0,11.1c0,3.4-0.9,4.4-4.4,4.4c-3.5,0-7,0-10.5,0c-2.7,0-3.8-1.1-3.8-3.8C58.8,131.8,58.8,128,58.8,123.9z" />
                            </svg>

                        </span>
                        <span class="menu-title text-truncate" data-i18n="Medicines">Medicines</span></a>
                    <ul class="menu-content">
                        <li
                            class="{{ Helper::checkActiveMenu('admin.medicine.usersPrescription,admin.medicine.usersPrescription.view') }}">
                            <a class="d-flex align-items-center" href="{{ route('admin.medicine.usersPrescription') }}">
                                <i data-feather="circle"></i><span class="menu-item text-truncate"
                                                                   data-i18n="Lab Booking"><?= _('Users Prescription') ?></span></a>
                        </li>

                    </ul>
                </li>
                <li class=" nav-item">
                    <a class="d-flex align-items-center" href="#">
                        <i data-feather="menu"></i>
                        <span class="menu-title text-truncate" data-i18n="MBS">Menu Based Service</span></a>
                    <ul class="menu-content">
                        <li
                            class="{{ Helper::checkActiveMenu('admin.menu_based_service,admin.menu_based_service.add,admin.menu_based_service.edit,admin.menu_based_service.view') }}">
                            <a class="d-flex align-items-center" href="{{ route('admin.menu_based_service') }}">
                                <i data-feather="circle"></i><span class="menu-item text-truncate"
                                                                   data-i18n="Master"><?= _('Master') ?></span></a>
                        </li>
                        <li
                            class="{{ Helper::checkActiveMenu('admin.menu_based_service.facility,admin.menu_based_service.facility.view') }}">
                            <a class="d-flex align-items-center" href="{{ route('admin.menu_based_service.facility') }}">
                                <i data-feather="circle"></i><span class="menu-item text-truncate"
                                                                   data-i18n="MBS Facility"><?= _('Facility') ?></span></a>
                        </li>
                        <li
                            class="{{ Helper::checkActiveMenu('admin.menu_based_service.booking,admin.menu_based_service.booking.view') }}">
                            <a class="d-flex align-items-center" href="{{ route('admin.menu_based_service.booking') }}">
                                <i data-feather="circle"></i><span class="menu-item text-truncate"
                                                                   data-i18n="MBS Booking"><?= _('Booking Report') ?></span></a>
                        </li>
                        <!--  <li class="{{ Helper::checkActiveMenu('admin.lab.booked.test,admin.lab.booked.test.view') }}">
                                <a class="d-flex align-items-center" href="{{ route('admin.lab.booked.test') }}">
                                    <i data-feather="circle"></i><span class="menu-item text-truncate" data-i18n="Booked Test"><?= _('Book Test') ?></span></a>
                            </li>-->
                    </ul>
                </li>
                <li class="nav-item">
                    <a class="d-flex align-items-center" href="#">
                        <i data-feather="calendar"></i>
                        <span class="menu-title text-truncate" data-i18n="SBS">Subscription Based Service</span></a>
                    <ul class="menu-content">
                        <li
                            class="{{ Helper::checkActiveMenu('admin.subscription_based_service,admin.subscription_based_service.add,admin.subscription_based_service.edit,admin.subscription_based_service.view') }}">
                            <a class="d-flex align-items-center" href="{{ route('admin.subscription_based_service') }}">
                                <i data-feather="circle"></i><span class="menu-item text-truncate"
                                                                   data-i18n="Master"><?= _('Master') ?></span></a>
                        </li>
                        <li
                            class="{{ Helper::checkActiveMenu('admin.subscription_based_service.facility,admin.subscription_based_service.facility.view') }}">
                            <a class="d-flex align-items-center"
                               href="{{ route('admin.subscription_based_service.facility') }}">
                                <i data-feather="circle"></i><span class="menu-item text-truncate"
                                                                   data-i18n="SBS Facility"><?= _('Facility') ?></span></a>
                        </li>
                        <li
                            class="{{ Helper::checkActiveMenu('admin.subscription_based_service.booking,admin.subscription_based_service.booking.view') }}">
                            <a class="d-flex align-items-center"
                               href="{{ route('admin.subscription_based_service.booking') }}">
                                <i data-feather="circle"></i><span class="menu-item text-truncate"
                                                                   data-i18n="SBS Booking"><?= _('Booking Report') ?></span></a>
                        </li>
                        <!--  <li class="{{ Helper::checkActiveMenu('admin.lab.booked.test,admin.lab.booked.test.view') }}">
                                <a class="d-flex align-items-center" href="{{ route('admin.lab.booked.test') }}">
                                    <i data-feather="circle"></i><span class="menu-item text-truncate" data-i18n="Booked Test"><?= _('Book Test') ?></span></a>
                            </li>-->
                    </ul>
                </li>
                <li class=" nav-item">
                    <a class="d-flex align-items-center" href="#">
                        <i data-feather="shopping-cart"></i>
                        <span class="menu-title text-truncate" data-i18n="User">Order </span>
                    </a>
                    <ul class="menu-content">
                        <li class="{{ Helper::checkActiveMenu('admin.orders,admin.orders.view') }}">
                            <a class="d-flex align-items-center" href="{{ route('admin.orders') }}">
                                <i data-feather="circle"></i><span class="menu-item text-truncate"
                                                                   data-i18n=""><?= _('Orders') ?></span></a>
                        </li>
                        <li
                            class="{{ Helper::checkActiveMenu('admin.doctor_appointment_booking,admin.doctor_appointment_booking.view') }}">
                            <a title="Doctor Appointment Bookings" class="d-flex align-items-center"
                               href="{{ route('admin.doctor_appointment_booking') }}">
                                <i data-feather="circle"></i><span class="menu-item text-truncate"
                                                                   data-i18n=""><?= _('Doctor Appointment Bookings') ?></span></a>
                        </li>
                        <li
                            class="{{ Helper::checkActiveMenu('admin.common.service.enquiry,admin.common.service.enquiry.view') }}">
                            <a title="Common Service Enquiry" class="d-flex align-items-center"
                               href="{{ route('admin.common.service.enquiry') }}">
                                <i data-feather="circle"></i><span class="menu-item text-truncate"
                                                                   data-i18n=""><?= _('Common Service Enquiry') ?></span></a>
                        </li>
                    </ul>
                </li>
                <li class=" nav-item">
                    <a class="d-flex align-items-center" href="#">
                        <i data-feather="package"></i>
                        <span class="menu-title text-truncate" data-i18n="Other">Other </span>
                    </a>
                    <ul class="menu-content">
                        <!--                        <li class="{{ Helper::checkActiveMenu('admin.banner,admin.banner.add,admin.banner.view') }}">
                                <a class="d-flex align-items-center" href="{{ route('admin.banner') }}">
                                    <i data-feather="circle"></i><span class="menu-item text-truncate" data-i18n="Users"><?= _('App Banner') ?></span></a>
                            </li>-->
                        <li class="{{ Helper::checkActiveMenu('admin.user.subscription') }}">
                            <a class="d-flex align-items-center" href="{{ route('admin.user.subscription') }}">
                                <i data-feather="circle"></i><span class="menu-item text-truncate"
                                                                   data-i18n=""><?= _('User Subscription') ?></span></a>
                        </li>
                        <li class="{{ Helper::checkActiveMenu('admin.patient') }}">
                            <a class="d-flex align-items-center" href="{{ route('admin.patient') }}">
                                <i data-feather="circle"></i><span class="menu-item text-truncate"
                                                                   data-i18n=""><?= _('Patient') ?></span></a>
                        </li>
                        <li class="{{ Helper::checkActiveMenu('admin.complain') }}">
                            <a class="d-flex align-items-center" href="{{ route('admin.complain') }}">
                                <i data-feather="circle"></i><span class="menu-item text-truncate"
                                                                   data-i18n=""><?= _('Complain') ?></span></a>
                        </li>
                        <li class="{{ Helper::checkActiveMenu('admin.review') }}">
                            <a class="d-flex align-items-center" href="{{ route('admin.review') }}">
                                <i data-feather="circle"></i><span class="menu-item text-truncate"
                                                                   data-i18n=""><?= _('User Review') ?></span></a>
                        </li>
                        <li class="{{ Helper::checkActiveMenu('admin.feedback') }}">
                            <a class="d-flex align-items-center" href="{{ route('admin.feedback') }}">
                                <i data-feather="circle"></i><span class="menu-item text-truncate"
                                                                   data-i18n=""><?= _('Feedback') ?></span></a>
                        </li>
                        <li class="{{ Helper::checkActiveMenu('admin.sms_log') }}">
                            <a class="d-flex align-items-center" href="{{ route('admin.sms_log') }}">
                                <i data-feather="circle"></i><span class="menu-item text-truncate"
                                                                   data-i18n=""><?= _('SMS Log') ?></span></a>
                        </li>
                    </ul>
                </li>
                <li class=" nav-item">
                    <a class="d-flex align-items-center" href="#">
                        <i data-feather="briefcase"></i>
                        <span class="menu-title text-truncate" data-i18n="Corporate">Corporate </span>
                    </a>
                    <ul class="menu-content">
                        <li class="{{ Helper::checkActiveMenu('admin.corporate.enquiry') }}">
                            <a class="d-flex align-items-center" href="{{ route('admin.corporate.enquiry') }}">
                                <i data-feather="circle"></i><span class="menu-item text-truncate"
                                                                   data-i18n=""><?= _('Enquiry') ?></span></a>
                        </li>
                        <li
                            class="{{ Helper::checkActiveMenu('admin.corporate.company,admin.corporate.company.add,admin.corporate.company.edit,admin.corporate.company.view,admin.corporate.company.plan') }}">
                            <a class="d-flex align-items-center" href="{{ route('admin.corporate.company') }}">
                                <i data-feather="circle"></i><span class="menu-item text-truncate"
                                                                   data-i18n="Company"><?= _('Company') ?></span></a>
                        </li>
                    </ul>
                </li>
            </ul>
        <?php } ?>
        <?php if (Auth::user()->user_type_id == LAB) { ?>
            <ul class="navigation navigation-main" id="main-menu-navigation" data-menu="menu-navigation">
                <li class=" nav-item">
                    <a class="d-flex align-items-center" href="#">
                        <i data-feather="grid"></i>
                        <span class="menu-title text-truncate" data-i18n="User">Master</span></a>
                    <ul class="menu-content">
                        <li class="{{ Helper::checkActiveMenu('lab.branch,lab.add,lab.edit,lab.view') }}">
                            <a class="d-flex align-items-center" href="{{ route('lab.branch') }}">
                                <i data-feather="circle"></i><span class="menu-item text-truncate"
                                                                   data-i18n="Branch"><?= _('Manage Branch') ?></span></a>
                        </li>
                        <li class="{{ Helper::checkActiveMenu('lab.test,lab.test.add,lab.test.edit,lab.test.view') }}">
                            <a class="d-flex align-items-center" href="{{ route('lab.test') }}">
                                <i data-feather="circle"></i><span class="menu-item text-truncate"
                                                                   data-i18n="Test"><?= _('Manage Test') ?></span></a>
                        </li>
                        <!--                        <li class="{{ Helper::checkActiveMenu('lab.test.booking') }}">
                                                        <a class="d-flex align-items-center" href="{{ route('lab.test.booking') }}">
                                                            <i data-feather="circle"></i><span class="menu-item text-truncate" data-i18n="Bookings"><?= _('Book Test') ?></span></a>
                                                    </li>-->
                        <li class="{{ Helper::checkActiveMenu('lab.order,lab.order.view') }}">
                            <a class="d-flex align-items-center" href="{{ route('lab.order') }}">
                                <i data-feather="circle"></i><span class="menu-item text-truncate"
                                                                   data-i18n="Orders"><?= _('Booking Report') ?></span></a>
                        </li>
                        <li class="{{ Helper::checkActiveMenu('lab.review,lab.review.view') }}">
                            <a class="d-flex align-items-center" href="{{ route('lab.review') }}">
                                <i data-feather="circle"></i><span class="menu-item text-truncate"
                                                                   data-i18n="Reviews"><?= _('User Reviews') ?></span></a>
                        </li>
                    </ul>
                </li>
            </ul>
        <?php } ?>
        <?php if (Auth::user()->user_type_id == LAB_BRANCH) { ?>
            <ul class="navigation navigation-main" id="main-menu-navigation" data-menu="menu-navigation">
                <li class=" nav-item">
                    <a class="d-flex align-items-center" href="#">
                        <i data-feather="grid"></i>
                        <span class="menu-title text-truncate" data-i18n="User">Master</span></a>
                    <ul class="menu-content">
                        <!--                        <li class="{{ Helper::checkActiveMenu('lab.test.booking') }}">
                                                        <a class="d-flex align-items-center" href="{{ route('lab.test.booking') }}">
                                                            <i data-feather="circle"></i><span class="menu-item text-truncate" data-i18n="Bookings"><?= _('Book Test') ?></span></a>
                                                    </li>-->
                        <li class="{{ Helper::checkActiveMenu('lab.order,lab.order.view') }}">
                            <a class="d-flex align-items-center" href="{{ route('lab.order') }}">
                                <i data-feather="circle"></i><span class="menu-item text-truncate"
                                                                   data-i18n="Orders"><?= _('Booking Report') ?></span></a>
                        </li>
                    </ul>
                </li>
            </ul>
        <?php } ?>
        <?php if (Auth::user()->user_type_id == MBS_USER) { ?>
            <ul class="navigation navigation-main" id="main-menu-navigation" data-menu="menu-navigation">
                <li class=" nav-item">
                    <a class="d-flex align-items-center" href="#">
                        <i data-feather="grid"></i>
                        <span class="menu-title text-truncate" data-i18n="User">Master</span></a>
                    <ul class="menu-content">
                        <li class="{{ Helper::checkActiveMenu('mbs.branch,mbs.add,mbs.edit,mbs.view') }}">
                            <a class="d-flex align-items-center" href="{{ route('mbs.branch') }}">
                                <i data-feather="circle"></i><span class="menu-item text-truncate"
                                                                   data-i18n="Branch"><?= _('Manage Branch') ?></span></a>
                        </li>
                        <li
                            class="{{ Helper::checkActiveMenu('mbs.facility,mbs.facility.add,mbs.facility.edit,mbs.facility.view') }}">
                            <a class="d-flex align-items-center" href="{{ route('mbs.facility') }}">
                                <i data-feather="circle"></i><span class="menu-item text-truncate"
                                                                   data-i18n="Test"><?= _('Manage Facility') ?></span></a>
                        </li>
                        <li class="{{ Helper::checkActiveMenu('mbs.order,mbs.order.view') }}">
                            <a class="d-flex align-items-center" href="{{ route('mbs.order') }}">
                                <i data-feather="circle"></i><span class="menu-item text-truncate"
                                                                   data-i18n="Orders"><?= _('Booking Report') ?></span></a>
                        </li>
                        <li class="{{ Helper::checkActiveMenu('mbs.review,mbs.review.view') }}">
                            <a class="d-flex align-items-center" href="{{ route('mbs.review') }}">
                                <i data-feather="circle"></i><span class="menu-item text-truncate"
                                                                   data-i18n="Reviews"><?= _('User Reviews') ?></span></a>
                        </li>
                    </ul>
                </li>
            </ul>
        <?php } ?>
        <?php if (Auth::user()->user_type_id == MBS_BRANCH_USER) { ?>
            <ul class="navigation navigation-main" id="main-menu-navigation" data-menu="menu-navigation">
                <li class=" nav-item">
                    <a class="d-flex align-items-center" href="#">
                        <i data-feather="grid"></i>
                        <span class="menu-title text-truncate" data-i18n="User">Master</span></a>
                    <ul class="menu-content">
                        <li class="{{ Helper::checkActiveMenu('mbs.order,mbs.order.view') }}">
                            <a class="d-flex align-items-center" href="{{ route('mbs.order') }}">
                                <i data-feather="circle"></i><span class="menu-item text-truncate"
                                                                   data-i18n="Orders"><?= _('Booking Report') ?></span></a>
                        </li>
                    </ul>
                </li>
            </ul>
        <?php } ?>
        <?php if (Auth::user()->user_type_id == SBS_USER) { ?>
            <ul class="navigation navigation-main" id="main-menu-navigation" data-menu="menu-navigation">
                <li class=" nav-item">
                    <a class="d-flex align-items-center" href="#">
                        <i data-feather="grid"></i>
                        <span class="menu-title text-truncate" data-i18n="User">Master</span></a>
                    <ul class="menu-content">
                        <li class="{{ Helper::checkActiveMenu('sbs.branch,sbs.add,sbs.edit,sbs.view') }}">
                            <a class="d-flex align-items-center" href="{{ route('sbs.branch') }}">
                                <i data-feather="circle"></i><span class="menu-item text-truncate"
                                                                   data-i18n="Branch"><?= _('Manage Branch') ?></span></a>
                        </li>
                        <li
                            class="{{ Helper::checkActiveMenu('sbs.facility,sbs.facility.add,sbs.facility.edit,sbs.facility.view') }}">
                            <a class="d-flex align-items-center" href="{{ route('sbs.facility') }}">
                                <i data-feather="circle"></i><span class="menu-item text-truncate"
                                                                   data-i18n="Test"><?= _('Manage Facility') ?></span></a>
                        </li>
                        <li class="{{ Helper::checkActiveMenu('sbs.order,sbs.order.view') }}">
                            <a class="d-flex align-items-center" href="{{ route('sbs.order') }}">
                                <i data-feather="circle"></i><span class="menu-item text-truncate"
                                                                   data-i18n="Orders"><?= _('Booking Report') ?></span></a>
                        </li>
                        <li class="{{ Helper::checkActiveMenu('sbs.review,sbs.review.view') }}">
                            <a class="d-flex align-items-center" href="{{ route('sbs.review') }}">
                                <i data-feather="circle"></i><span class="menu-item text-truncate"
                                                                   data-i18n="Reviews"><?= _('User Reviews') ?></span></a>
                        </li>
                    </ul>
                </li>
            </ul>
        <?php } ?>
        <?php if (Auth::user()->user_type_id == SBS_BRANCH_USER) { ?>
            <ul class="navigation navigation-main" id="main-menu-navigation" data-menu="menu-navigation">
                <li class=" nav-item">
                    <a class="d-flex align-items-center" href="#">
                        <i data-feather="grid"></i>
                        <span class="menu-title text-truncate" data-i18n="User">Master</span></a>
                    <ul class="menu-content">
                        <li class="{{ Helper::checkActiveMenu('sbs.order,sbs.order.view') }}">
                            <a class="d-flex align-items-center" href="{{ route('sbs.order') }}">
                                <i data-feather="circle"></i><span class="menu-item text-truncate"
                                                                   data-i18n="Orders"><?= _('Booking Report') ?></span></a>
                        </li>
                    </ul>
                </li>
            </ul>
        <?php } ?>
        <?php if (Auth::user()->user_type_id == CORPORATE_USER) { ?>
            <ul class="navigation navigation-main" id="main-menu-navigation" data-menu="menu-navigation">
                <li class="{{ Helper::checkActiveMenu('corporate.dashBoard') }}">
                    <a class="d-flex align-items-center" href="{{ route('corporate.dashBoard') }}">
                        <span class="menu-item text-truncate"
                              data-i18n="DashBoard"><b><?= _('DashBoard') ?></b></span></a>
                </li>
                <li
                    class="{{ Helper::checkActiveMenu('corporate.user,corporate.user.add,corporate.user.edit,corporate.user.view,corporate.user.plan.list') }}">
                    <a class="d-flex align-items-center" href="{{ route('corporate.user') }}">
                        <span class="menu-item text-truncate" data-i18n="Employee"><b><?= _('Employee') ?></b></span></a>
                </li>
                <li
                    class="{{ Helper::checkActiveMenu('corporate.department,corporate.department.add,corporate.department.edit') }}">
                    <a class="d-flex align-items-center" href="{{ route('corporate.department') }}">
                        <span class="menu-item text-truncate"
                              data-i18n="Department"><b><?= _('Department') ?></b></span></a>
                </li>
                <li
                    class="{{ Helper::checkActiveMenu('corporate.designation,corporate.designation.add,corporate.designation.edit') }}">
                    <a class="d-flex align-items-center" href="{{ route('corporate.designation') }}">
                        <span class="menu-item text-truncate"
                              data-i18n="Designation"><b><?= _('Designation') ?></b></span></a>
                </li>
                <li class="{{ Helper::checkActiveMenu('corporate.branch,corporate.branch.add,corporate.branch.edit') }}">
                    <a class="d-flex align-items-center" href="{{ route('corporate.branch') }}">
                        <span class="menu-item text-truncate" data-i18n="branch"><b><?= _('Branch') ?></b></span></a>
                </li>
                <li class="{{ Helper::checkActiveMenu('corporate.plan') }}">
                    <a class="d-flex align-items-center" href="{{ route('corporate.plan') }}">
                        <span class="menu-item text-truncate"
                              data-i18n="branch"><b><?= _('Subscription') ?></b></span></a>
                </li>

            </ul>
        <?php } ?>
        <?php if (Auth::user()->user_type_id == PHARMACY_USER) { ?>
            <ul class="navigation navigation-main" id="main-menu-navigation" data-menu="menu-navigation">
                <li class=" nav-item">
                    <a class="d-flex align-items-center" href="#">
                        <span>
                            <?xml version="1.0" encoding="utf-8"?>
                            <!-- Generator: Adobe Illustrator 21.1.0, SVG Export Plug-In . SVG Version: 6.00 Build 0)  -->
                            <svg version="1.1" id="Layer_1" xmlns="http://www.w3.org/2000/svg"
                                 xmlns:xlink="http://www.w3.org/1999/xlink" x="0px" y="0px" viewBox="0 0 190 190"
                                 style="enable-background:new 0 0 190 190;" xml:space="preserve">
                            <style type="text/css">
                                .st0 {
                                    fill: #63626A;
                                }
                            </style>
                            <path class="st0" d="M102.3,34.1c0,2.1,0,4,0,5.9c2,0.6,4,1,5.8,1.7c11.6,4.2,19,14.7,19,27c0,22.9,0,45.8,0,68.7c0,0.6,0,1.3,0,2
                                  c-2.1,0-4,0-6.1,0c0-20.6,0-41.1,0-61.8c-35.2,0-70.2,0-105.4,0c0,24.7,0,49.4,0,74.3c24.1,0,48.3,0,72.7,0
                                  c-7.6,13.9-5.7,26.1,5.5,37.2c-0.6,0-1.2,0.1-1.7,0.1c-24.2,0-48.5,0-72.7,0c-6.1,0-10.1-3.9-10.1-10.1c0-36.9,0-73.8,0-110.7
                                  c0-13.5,9.8-25.2,23.1-27.8c0.6-0.1,1.1-0.3,1.7-0.4c0-2,0-3.9,0-6C56.7,34.1,79.4,34.1,102.3,34.1z" />
                            <path class="st0" d="M68.1,27.7c-11.1,0-22.2,0-33.3,0c-6.1,0-10-3.9-10-10.1c0-1.9,0-3.7,0-5.6c0.1-5.1,4.1-9.1,9.2-9.1
                                  c22.8,0,45.6,0,68.4,0c5.2,0,9.2,4.1,9.3,9.3c0,2,0,4,0,6c-0.1,5.5-4.1,9.5-9.6,9.5C90.7,27.8,79.4,27.7,68.1,27.7z" />
                            <path class="st0" d="M133.2,188.7c-8.5,0-17,0.6-25.3-0.2c-10.2-0.9-18-10.6-18-21c-0.1-10.6,7.6-19.9,17.8-21.5
                                  c0.6-0.1,1.3-0.3,1.9-0.3c7.8,0,15.6,0,23.6,0C133.2,160.1,133.2,174.5,133.2,188.7z" />
                            <path class="st0" d="M139.6,189.1c0-14.6,0-28.9,0-43.5c0.8,0,1.6,0,2.3,0c6.6,0,13.2-0.1,19.8,0c10.8,0.2,19.5,8.1,21.1,19.2
                                  c1.4,9.8-5,19.9-14.7,23.1c-1.6,0.5-3.3,1-4.9,1c-7.1,0.1-14.2,0.1-21.3,0.1C141.1,189.1,140.4,189.1,139.6,189.1z" />
                            <path class="st0" d="M58.8,123.9c-3.9,0-7.7,0-11.4,0c-3.1,0-4.1-1-4.1-4c0-3.6,0-7.2,0-10.9c0-2.6,1.1-3.7,3.8-3.7
                                  c3.8,0,7.6,0,11.7,0c0-3.2,0-6.2,0-9.3c0-6,0.2-6.2,6.2-6.2c1.4,0,2.8,0,4.3,0c8.5-0.1,8.3-0.3,8.2,8.3c0,2.3,0,4.6,0,7.2
                                  c3.4,0,6.8,0,10.1,0c0.7,0,1.4,0,2.1,0c2,0.1,3.2,1.2,3.3,3.3c0.1,3.9,0,7.9,0,11.8c0,2.3-1.2,3.5-3.5,3.5c-3.9,0-7.9,0-12,0
                                  c0,3.8,0,7.5,0,11.1c0,3.4-0.9,4.4-4.4,4.4c-3.5,0-7,0-10.5,0c-2.7,0-3.8-1.1-3.8-3.8C58.8,131.8,58.8,128,58.8,123.9z" />
                            </svg>

                        </span>
                        <span class="menu-title text-truncate" data-i18n="Medicines">Medicines</span></a>
                    <ul class="menu-content">
                        <li
                            class="{{ Helper::checkActiveMenu('medicine.usersPrescription,medicine.usersPrescription.view') }}">
                            <a class="d-flex align-items-center" href="{{ route('medicine.usersPrescription') }}">
                                <i data-feather="circle"></i><span class="menu-item text-truncate"
                                                                   data-i18n="Users Prescription"><?= _('Users Prescription') ?></span></a>
                        </li>

                    </ul>
                </li>
            </ul>
        <?php } ?>
    </div>
</div>
<!-- END: Main Menu-->
