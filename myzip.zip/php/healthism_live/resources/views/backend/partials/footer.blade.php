<div class="sidenav-overlay"></div>
<div class="drag-target"></div>

<!-- BEGIN: Footer-->
<footer class="footer footer-static footer-light">
    <p class="clearfix mb-0"><span class="float-md-start d-block d-md-inline-block mt-25">Copyright &copy;
            {{ date('Y') }}
            <a class="ms-25" href="https://healthismplus.com" target="_blank">Healthism Plus</a><span
                class="d-none d-sm-inline-block">, All rights Reserved</span></span></p>
</footer>
<button class="btn btn-primary btn-icon scroll-top" type="button"><i data-feather="arrow-up"></i></button>
<!-- END: Footer-->

<div id="loader">
    <div class="spinner spinner-border" role="status">
        <span class="sr-only"></span>
    </div>
</div>

<script>
    $(function() {
        let validator = $('form.needs-validation').jbvalidator({
            errorMessage: true,
            successClass: true,
        });
        $(document).on('click', '.needs-validation button[type=submit]', function() {
            let idtoTrigger = $(".is-invalid:first").parentsUntil(".content").parent().attr("id");
            $("[data-target='#" + idtoTrigger + "'").find("button").trigger("click");
            let idtoTriggerAgain = $(".is-invalid:first").parentsUntil(".content").parent().attr("id");
            $("[data-target='#" + idtoTriggerAgain + "'").find("button").trigger("click");
        });
        $(document).on('change', '#state_id', function() {
            if (this.value != '') {
                var idState = this.value;
                $("#city_id").html('');
                $.ajax({
                    url: "{{ route('fetchCity') }}",
                    type: "POST",
                    data: {
                        state_id: $(this).val(),
                        _token: '{{ csrf_token() }}'
                    },
                    dataType: 'json',
                    success: function(response) {
                        $('#city_id').html('<option value="">Select City</option>');
                        $.each(response.cities, function(key, value) {
                            $("#city_id").append(
                                `<option value="${value.id}">${value.name}</option>`
                            );
                        });
                    }
                });
            }
        });
        $(".tags-input").select2({
            tags: true,
        });
        $(".datepicker").flatpickr({
            dateFormat: "d-m-Y"
        });
        $('body').on('click', '.pagination a', function(e) {
            e.preventDefault();
            var url = $(this).attr('href');
            let params = (new URL(url)).searchParams;
            $("#page").val(params.get("page"));
            loadingOverlay("#search_form", "show");
            $.ajax({
                url: url,
                method: "post",
                data: $("#search_form").serialize()
            }).done(function(data) {
                $('#ajax_content').html(data);
                loadingOverlay("#search_form", "hide");
            }).fail(function() {
                alert('content could not be loaded.');
            });
        });
        $("body").on("submit", "#search_form", function() {
            search_criteria();
        });
        $("body").on("change", "[name=records_per_page]", function() {
            search_criteria();
        });
    });

    function search_criteria() {
        $("#page").val(1);
        loadingOverlay("#search_form", "show");
        $.ajax({
            url: $("#search_form").attr("action"),
            method: "post",
            data: $("#search_form").serialize()
        }).done(function(data) {
            $('#ajax_content').html(data);
            loadingOverlay("#search_form", "hide");
        }).fail(function() {
            alert('content could not be loaded.');
        });
    }

    function set_sort_data(field_name, orderby) {
        $("#sort_field").val(field_name);
        $("#sort_action").val(orderby);
        search_criteria();
    }

    function loadingOverlay(section, action) {
        if (action == 'show') {
            $(section).LoadingOverlay("show", {
                // background: "rgba(165, 190, 100, 0.5)"
                imageColor: "#2caa8a",
                size: 30
            });
        } else {
            $(section).LoadingOverlay("hide");
        }
        feather.replace();
        $(".select2").select2();
        $(".datepicker").flatpickr({
            dateFormat: "d-m-Y"
        });
    }
    feather.replace();
</script>
@yield('script')
