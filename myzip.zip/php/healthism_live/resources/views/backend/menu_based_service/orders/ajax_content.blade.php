<script>
    var csrf_field = "{{ csrf_token() }}";
</script>
<script src="{{ Helper::static_asset('admin-assets/js/module/common.js') }}"></script>
<div class="row f-12">
    <form class="" method="POST" action="{{ route('admin.menu_based_service.booking') }}" id="search_form" onsubmit="return false">
        {{ csrf_field() }}
        <div class="col-12">
            <div class="card">
                <div class="card-header border-bottom">
                    <h4 class="card-title">{{ __("Order List")  }}</h4>
                </div>

                <!--Search Form -->
                <div class="card-body mt-2">
                    <input type="hidden" name="page" id="page" value="{{ empty(app('request')->input('page')) ? 1 : app('request')->input('page')  }}">
                    <input type="hidden" name="sort_field" id="sort_field" value="{{ app('request')->input('sort_field') }}">
                    <input type="hidden" name="sort_action" id="sort_action" value="{{ app('request')->input('sort_action') }}">
                    <div class="row g-1 mb-md-1">
                        <div class="col-md-4">
                            <label class="form-label">Order Code</label>
                            <input type="text" class="form-control dt-input dt-full-name" placeholder="Order Code" name="order_code" value="{{app('request')->input('order_code')}}">
                        </div>
                        <div class="col-md-4">
                            <label class="form-label">MBS Name</label>
                            <input type="text" class="form-control dt-input dt-full-name" placeholder="MBS Name" name="menu_based_service_name" value="{{app('request')->input('menu_based_service_name')}}">
                        </div>
                        <div class="col-md-4">
                            <label class="form-label">Member Name</label>
                            <input type="text" class="form-control dt-input dt-full-name" placeholder="Member Name" name="patient_name" value="{{app('request')->input('patient_name')}}">
                        </div>
                        <div class="mb-1 col-md-4">
                            <label class="form-label" for="user_id"><?= _('User') ?></label>
                            <input type="text" name="user" class="form-control user_search" placeholder="<?= _('Select User') ?>"
                                   value="{{app('request')->input('user')}}"/>
                            <input type="hidden" id="user_id" name="user_id" value="{{app('request')->input('user_id')}}">
                        </div>
                        <div class="col-md-4">
                            <label class="form-label">Order Status</label>
                            <select name="status_id" id="status_id" class="select2 form-select" >
                                <option value="">ALL</option>
                                @foreach ($statusList as $row)
                                <option <?php echo request_display('status_id') == $row['id'] ? 'selected' : '' ?> value="{{ $row['id']  }}">{{ $row['name']  }}</option>
                                @endforeach
                            </select>
                        </div>
                        <div class="col-md-4">
                            <label class="form-label">Payment Status</label>
                            <select name="payment_status_id" id="payment_status_id" class="select2 form-select" >
                                <option value="">ALL</option>
                                @foreach ($paymentStatusList as $row)
                                <option <?php echo request_display('payment_status_id') == $row['id'] ? 'selected' : '' ?> value="{{ $row['id']  }}">{{ $row['name']  }}</option>
                                @endforeach
                            </select>
                        </div>
                        <div class="col-md-4">
                            <div class="col-md-5" style="float:left;margin-right:5px;">
                                <label class="form-label">Order Start Date</label>
                                <input type="text" name="start_date" class="form-control datepicker" placeholder="Start Date" value="{{ request_display('start_date') }}" />
                            </div>
                            <div class="col-md-5" style="float:left">
                                <label class="form-label">Order End Date</label>
                                <input type="text" name="end_date" class="form-control datepicker" placeholder="End Date" value="{{ request_display('end_date') }}" />
                            </div>
                        </div>
                        <div class="col-md-4 m-t-35">
                            <button type="submit" class="btn btn-primary waves-effect waves-float waves-light">Search</button>
                            <a href="{{route('admin.menu_based_service.booking')}}" class="btn btn-outline-secondary waves-effect">Reset</a>
                        </div>
                    </div>
                </div>
                <hr class="my-0">
                <div class="card-datatable">
                    <?php echo parPageRecordDropDown([5, 10, 15, 20]) ?>
                    @if(!$orders->isEmpty())
                    @php $start = $orders->firstItem(); @endphp
                    <div class="table-responsive">
                        <table class="table table-bordered table-hover">
                            <thead>
                                <tr role="row">
                                    <th>Order Details</th>
                                    <th>User Details</th>
                                    <th>Order Code</th>
                                    <th>Amount</th>
                                    <th>Status</th>
                                    <th>Created/Updated</th>
                                    <th>Actions</th>
                                </tr>
                            </thead>
                            <tbody>
                                @foreach($orders as $order)
                                <tr class="l-h-22">
                                    <td valign="top">
                                        <?php
                                        if (!empty($order->order->description_json)) {
                                            $desArr = json_decode($order->order->description_json, True);
                                            if (!empty($desArr['desc1'])) {
                                                echo '<b class="theam-color">' . $desArr['desc1'] . '</b><br>';
                                            }
                                            if (!empty($desArr['desc2'])) {
                                                echo '<span>' . $desArr['desc2'] . '</span><br>';
                                            }
                                            if (!empty($desArr['desc3'])) {
                                                echo '<span>' . $desArr['desc3'] . '</span>';
                                            }
                                        }
                                        ?>
                                    </td>
                                    <td valign="top">
                                        @if(!empty($order->user))
                                        {{ $order->user->first_name.' '.$order->user->last_name }}<br>
                                        <span class="f-11">{{$order->user->mobile}}</span><br>
                                        <span class="f-11">{{$order->user->email}}</span><br>
                                        @endif
                                    </td>
                                    <td valign="top">{{ !empty($order->order)?$order->order->order_code:''  }}</td>
                                    <td valign="top">Rs.{{ $order->amount  }}</td>
                                    <td valign="top">
                                        <span>{{ !empty($order->order)?$order->order->status->name:'' }}</span><br>
                                        @if(!empty($order->order->payment))
                                        <span>{{ $order->order->payment->status->name  }}</span>
                                        @endif
                                    </td>
                                    <td valign="top"> 
                                        <span>{{ date("d/m/Y H:i",strtotime($order->created_at)) }}</span><br>
                                        <span>{{ date("d/m/Y H:i",strtotime($order->updated_at)) }}</span>
                                    </td>
                                    <td>
                                        <div class="text-nowrap">
                                            <a title="View" href="{{  route('admin.menu_based_service.booking.view', ['id'=>$order->id] )  }}">
                                                <i data-feather="file-text" class="me-50 text-dark"></i>
                                            </a>
                                        </div>
                                    </td>
                                </tr>
                                @endforeach
                            </tbody>
                        </table>
                    </div>
                    @endif
                    <?php echo pagination($orders) ?>
                </div>
            </div>
        </div>
    </form>
</div>
@section('script')
<script type="text/javascript">
    $(document).ready(initCommon);
</script>

@endsection