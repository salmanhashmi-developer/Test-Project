@extends("backend.layouts.master")
@section('title') Order view @endsection
@section('content')
<!-- BEGIN: Content-->
<div class="app-content content f-12">
    <div class="content-wrapper p-0">
        <div class="content-body">
            @include('backend.message')
            <div class="p-b-10"> <a href="{{route('admin.menu_based_service.booking')}}"><i data-feather="arrow-left" class="me-50 text-dark"></i> Orders</a></div>
            <b class="m-l-20">Order {{$order->order->order_code}}</b>
            <p class="m-l-20"> From {{$order->user->first_name.' '.$order->user->last_name}}</p>
            <div class="card" data-select2-id="14">
                <div class="card-body py-2 my-25" data-select2-id="53">
                    <!-- header section -->
                    <!-- Modern Horizontal Wizard -->
                    <section class="modern-horizontal-wizard">
                        <div class="bs-stepper wizard-modern modern-wizard-example">
                            <div class="bs-stepper-header">
                                <div class="step" data-target="#order-modern" role="tab" id="order-modern-trigger">
                                    <button type="button" class="step-trigger">
                                        <span class="bs-stepper-box"><i data-feather="user" class="font-medium-3"></i></span>
                                        <span class="bs-stepper-label">
                                            <span class="bs-stepper-title">Order Details</span>
                                        </span>
                                    </button>
                                </div>
                                <div class="line"><i data-feather="chevron-right" class="font-medium-2"></i></div>
                                <div class="step" data-target="#test-list" role="tab" id="test-list-trigger">
                                    <button type="button" class="step-trigger">
                                        <span class="bs-stepper-box"><i data-feather="file-text" class="font-medium-3"></i></span>
                                        <span class="bs-stepper-label">
                                            <span class="bs-stepper-title">Facility List</span>
                                        </span>
                                    </button>
                                </div>
                            </div>
                            <div class="bs-stepper-content">
                                <div id="order-modern" class="content" role="tabpanel" aria-labelledby="order-modern-trigger">
                                    <?php if (!empty($order->userMember)) { ?>
                                        <div class="d-flex">
                                            <div class="row">
                                                <div class="col-md-12 header-title">
                                                    <span>Member Details</span>
                                                </div>
                                                <div class="col-md-12">
                                                    <table class="table">
                                                        <thead>
                                                            <tr>
                                                                <th>Name</th>
                                                                <th>Mobile No.</th>
                                                                <th>Email</th>
                                                            </tr>
                                                        </thead> 
                                                        <tbody>
                                                            <tr>
                                                                <td>{{$order->userMember->first_name.' '.$order->userMember->last_name}}</td>
                                                                <td>{{$order->userMember->mobile}}</td>
                                                                <td>{{$order->userMember->email}}</td>
                                                            </tr>
                                                        </tbody>
                                                    </table>
                                                </div>
                                            </div>
                                        </div>
                                        <?php } ?>
                                        <div class="d-flex">
                                            <div class="row">
                                                <div class="col-md-12 header-title">
                                                    <span>Menu Base Service Details</span>
                                                </div>
                                                <div class="col-md-12">
                                                    <table class="table">
                                                        <thead>
                                                            <tr>
                                                                <th>Name</th>
                                                                <th>Mobile No.</th>
                                                                <th>Address</th>
                                                            </tr>
                                                        </thead> 
                                                        <tbody>
                                                            <tr>
                                                                <td>{{$order->menuBasedService->name}}</td>
                                                                <td>{{$order->menuBasedService->mobile}}</td>
                                                                <td>{{$order->menuBasedService->address1.', '.$order->menuBasedService->address2.', '.$order->menuBasedService->area.', '.$order->menuBasedService->city->name.', '.$order->menuBasedService->state->name.'- '.$order->menuBasedService->pincode}}</td>
                                                            </tr>
                                                        </tbody>
                                                    </table>
                                                </div>
                                            </div>
                                        </div>
                                        <div class="d-flex">
                                            <div class="row">
                                                <div class="col-md-12 header-title">
                                                    <span>Order Status</span>
                                                </div>
                                                <div class="col-md-12">
                                                    <table class="table">
                                                        <thead>
                                                            <tr>
                                                                <th>Status</th>
                                                                <th>Created Date</th>
                                                                <th>Updated Date</th>
                                                            </tr>
                                                        </thead> 
                                                        <tbody>
                                                            <tr>
                                                                <td><span class="<?php echo $order->order->status_id == STATUS_DONE ? 'done-status' : 'other-status'; ?>">{{$order->order->status->name}}</span></td>
                                                                <td>{{ date("d/m/Y H:i",strtotime($order->order->created_at)) }}</td>
                                                                <td>{{ date("d/m/Y H:i",strtotime($order->order->updated_at)) }}</td>
                                                            </tr>
                                                        </tbody>
                                                    </table>
                                                </div>
                                            </div>
                                        </div>
                                        <div class="d-flex">
                                            <div class="row">
                                                <div class="col-md-12 header-title">
                                                    <span>Payment Status</span>
                                                </div>
                                                <div class="col-md-12">
                                                    <table class="table">
                                                        <thead>
                                                            <tr>
                                                                <th>Status</th>
                                                                <th>Payment Method</th>
                                                                <th>Created Date</th>
                                                                <th>Updated Date</th>
                                                            </tr>
                                                        </thead> 
                                                        <tbody>
                                                            <tr>
                                                                <td><span class="<?php echo $order->order->payment->status_id == STATUS_DONE ? 'done-status' : 'other-status'; ?>">{{$order->order->payment->status->name}}</span></td>
                                                                <td>{{$order->order->payment->paymentmode->name}}</td>
                                                                <td>{{ date("d/m/Y H:i",strtotime($order->order->payment->created_at)) }}</td>
                                                                <td>{{ date("d/m/Y H:i",strtotime($order->order->payment->updated_at)) }}</td>
                                                            </tr>
                                                        </tbody>
                                                    </table>
                                                </div>
                                            </div>
                                        </div>
                                        <?php if (!empty($order->order->histories)) {
                                            ?>
                                            <div class="d-flex">
                                                <div class="row">
                                                    <div class="col-md-12 header-title">
                                                        <span>Tracking Status</span>
                                                    </div>
                                                    <div class="col-md-12">
                                                        <table class="table">
                                                            <thead>
                                                                <tr>
                                                                    <th>Status</th>
                                                                    <th>Remark</th>
                                                                    <th>Created Date</th>
                                                                </tr>
                                                            </thead> 
                                                            <tbody>
                                                                <?php
                                                                foreach ($order->order->histories as $key => $value) {
                                                                    if ($value->type == 'ORDER') {
                                                                        ?>
                                                                        <tr>
                                                                            <td>{{$value->status->name}}</td>
                                                                            <td>{{$value->remark}}</td>
                                                                            <td>{{ date("d/m/Y H:i",strtotime($value->created_at)) }}</td>
                                                                        </tr>
                                                                        <?php
                                                                    }
                                                                }
                                                                ?>
                                                            </tbody>
                                                        </table>
                                                    </div>
                                                </div>
                                            </div>
                                        <?php } ?>
                                    </div>
                                    <div id="test-list" class="content" role="tabpanel" aria-labelledby="test-list-trigger">
                                        <div class="card-datatable">
                                            <?php if (!empty($order->menuBasedServiceBookingDetails)) { ?>
                                                <div class="d-flex">
                                                    <div class="row">
                                                        <div class="col-md-12">
                                                            <table class="table">
                                                                <thead>
                                                                    <tr>
                                                                        <th>Name</th>
                                                                        <th>Amount</th>
                                                                    </tr>
                                                                </thead> 
                                                                <tbody>
                                                                    <?php
                                                                    foreach ($order->menuBasedServiceBookingDetails as $value) {
                                                                        ?>
                                                                        <tr>
                                                                            <td class="f-u">{{$value->menuBasedServiceFacility->name}}</td>
                                                                            <td>Rs.{{$value->amount}}</td>
                                                                        </tr>
                                                                        <?php
                                                                    }
                                                                    ?>
                                                                </tbody>
                                                            </table>
                                                        </div>
                                                    </div>
                                                </div>
                                                <?php
                                            } else {
                                                echo 'Sorry, Test data not found.';
                                            }
                                            ?>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </section>
                    <div class="row" data-select2-id="12">
                        <div class="col-12">
                            <a href="{{route('admin.menu_based_service.booking')}}" class="btn btn-outline-secondary waves-effect">Back</a>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
@endsection

