<div class="row">
    <form class="" method="POST" action="{{ route('admin.menu_based_service.facility') }}" id="search_form"
        onsubmit="return false">
        {{ csrf_field() }}
        <div class="col-12">
            <div class="card">
                <div class="card-header border-bottom">
                    <?php
                    if (!empty($menuBasedService)) {
                        $flag = 'MBS';
                        ?>
                    <input type="hidden" name="menu_based_service_id" value="{{ $menuBasedService->id }}">
                    <h4 class="card-title">{{ $menuBasedService->name }} - Facility Master</h4>
                    <div
                        class="dt-action-buttons d-flex align-items-center justify-content-center justify-content-lg-end flex-lg-nowrap flex-wrap">
                        <div class="dt-buttons d-inline-flex">
                            <a class="dt-button add-new btn btn-primary me-1"
                                href="{{ route('admin.menu_based_service.facility.add', ['menu_based_service_id' => $menuBasedService->id]) }}">{{ __('Add New Facility') }}</a>
                            <?php if (!empty($menuBasedService->parent_id)) { ?>
                            <a class="btn btn-outline-secondary waves-effect"
                                href="{{ route('admin.menu_based_service.branch', ['menu_based_service_id' => $menuBasedService->parent_id]) }}">{{ __('Back') }}</a>
                            <?php } else { ?>
                            <a class="btn btn-outline-secondary waves-effect"
                                href="{{ route('admin.menu_based_service') }}">{{ __('Back') }}</a>
                            <?php } ?>
                        </div>
                    </div>
                    <?php
                    } else {
                        $flag = 'Globle';
                        ?>
                    <h4 class="card-title">{{ __('Menu Based Service Facility Master') }}</h4>
                    <?php } ?>
                </div>
                <!--Search Form -->
                <div class="card-body mt-2">
                    <div class="row g-1 mb-md-1">
                        <div class="col-md-3">
                            <label class="form-label">Facility Name</label>
                            <input type="text" class="form-control dt-input dt-full-name" placeholder="Facility Name"
                                name="name" value="{{ app('request')->input('name') }}">
                        </div>
                        <?php if (empty($menuBasedService)) { ?>
                        <div class="col-md-3">
                            <label class="form-label">Menu Based Service Name</label>
                            <input type="text" class="form-control dt-input dt-full-name"
                                placeholder="Menu Based Service Name" name="menu_based_service_name"
                                value="{{ app('request')->input('menu_based_service_name') }}">
                        </div>
                        <?php } ?>
                        <div class="col-md-2">
                            <label class="form-label">Type</label>
                            <select name="type" id="type" class="select2 form-select">
                                <?php $set_values = request_display('type'); ?>
                                <option value="">All</option>
                                <option <?= $set_values == 0 ? 'selected' : '' ?> value="0">Facility</option>
                                <option <?= $set_values == 1 ? 'selected' : '' ?> value="1">Package</option>
                            </select>
                        </div>
                        <div class="col-md-2">
                            <label class="form-label">Status</label>
                            <select name="status_id" id="status_id" class="select2 form-select">
                                <?php $set_values = request_display('status_id'); ?>
                                <option value="">All</option>
                                <option <?= $set_values == 1 ? 'selected' : '' ?> value="1">Active</option>
                                <option <?= $set_values == 2 ? 'selected' : '' ?> value="2">Inactive</option>
                            </select>
                        </div>

                        <div class="col-md-2">
                            <label class="form-label"></label>
                            <button type="submit"
                                class="btn btn-primary mt-2 waves-effect waves-float waves-light">Search</button>
                        </div>
                    </div>
                </div>
                <hr class="my-0">
                <div class="card-datatable">
                    <?php echo parPageRecordDropDown(); ?>
                    @if (!$facilitis->isEmpty())
                        @php $start = $facilitis->firstItem(); @endphp
                        <div class="table-responsive">

                            <table class="table table-bordered table-hover">
                                <thead>
                                    <tr role="row">
                                        <th></th>
                                        <th>Name</th>
                                        <th>Menu Based Service</th>
                                        <th>Type</th>
                                        <th>Time</th>
                                        <th>Gender</th>
                                        <th>Status</th>
                                        <th>Actions</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    @foreach ($facilitis as $facility)
                                        <tr class="f-12">
                                            <td><?= $start++ ?></td>
                                            <td valign="top">{{ $facility->name }}</td>
                                            <td valign="top">
                                                <a target="_blank"
                                                    href="{{ route('admin.menu_based_service.view', ['id' => $facility->menu_based_service_id]) }}">{{ $facility->menuBasedService->name }}
                                                    <span
                                                        style="font-size: 11px;">({{ $facility->menuBasedService->area }})</span>
                                                </a>
                                            </td>
                                            <td valign="top">
                                                {{ $facility->is_package == 1 ? 'Package' : 'Facility' }}</td>
                                            <td valign="top">{{ $facility->time }}</td>
                                            <td valign="top">{{ $facility->gender }}</td>
                                            <td valign="top">{{ $facility->status->name }}</td>
                                            <td>
                                                <div class="text-nowrap">
                                                    <a title="Edit"
                                                        href="{{ route('admin.menu_based_service.facility.edit', ['id' => $facility->id, 'flag' => $flag]) }}">
                                                        <i data-feather="edit" class="me-50 text-dark"></i>
                                                    </a>
                                                    <a title="View"
                                                        href="{{ route('admin.menu_based_service.facility.view', ['id' => $facility->id, 'flag' => $flag]) }}">
                                                        <i data-feather="file-text" class="me-50 text-dark"></i>
                                                    </a>
                                                    <a title="Delete" data-facility-name="{{ $facility->name }}"
                                                        data-facility-id="{{ $facility->id }}" data-action="delete">
                                                        <i data-feather="trash-2" class="me-50 text-danger"></i>
                                                    </a>
                                                </div>
                                            </td>
                                        </tr>
                                    @endforeach
                                </tbody>
                            </table>
                        </div>
                    @endif
                    <?php echo pagination($facilitis); ?>
                </div>
            </div>
        </div>
    </form>
</div>
@section('script')
    <script type="text/javascript">
        $(document).on("click", "a[data-action='delete']", function() {
            var name = $(this).attr("data-facility-name");
            var id = $(this).attr("data-facility-id");
            var $this = $(this);
            confirmationAlertPopup(("Do you want to delete " + name),
                "Yes, delete it !",
                function(result) {
                    if (result.isConfirmed) {
                        var param = new Object();
                        param["facility_id"] = id;
                        //console.log(param);
                        if (APP.BlockConcurrentReq(2000)) {
                            return;
                        }
                        loadingOverlay("body", "show");
                        jqueryAjax("{{ route('admin.menu_based_service.facility.delete') }}",
                            param,
                            function(
                                res) {
                                loadingOverlay("body", "hide");
                                if (res.code != 200) {
                                    Notification.show({
                                        type: "error",
                                        msg: res.message,
                                        timeout: 3000
                                    });
                                    return;
                                }
                                Notification.show({
                                    type: "success",
                                    msg: res.message,
                                    timeout: 3000
                                });
                                var $closestTr = $this.closest("tr");
                                $closestTr.hide();
                                $closestTr.next().remove();
                            }, "", "json");
                        resultAlertPopup("Deleted!", "Facility" + name +
                            " has been deleted.",
                            "success");
                    }
                });
        });
    </script>
@endsection
