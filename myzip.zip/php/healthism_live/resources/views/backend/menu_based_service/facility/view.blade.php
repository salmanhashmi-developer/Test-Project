@extends("backend.layouts.master")
@section('title') Facility View @endsection
@section('content')

<!-- BEGIN: Content-->
<div class="app-content content ">

    <div class="content-wrapper p-0">

        <div class="content-body">
            @include('backend.message')
            <div class="card" data-select2-id="14">
                <div class="card-header border-bottom">
                    <h4 class="card-title">Facility Details View</h4>
                </div>
                <div class="card-body py-2 my-25" data-select2-id="53">
                    <!-- header section -->

                    <!-- Modern Horizontal Wizard -->
                    <section class="modern-horizontal-wizard">
                        <div class="bs-stepper wizard-modern modern-wizard-example">
                            <div class="bs-stepper-header">
                                <div class="step" data-target="#account-details-modern" role="tab" id="account-details-modern-trigger">
                                    <button type="button" class="step-trigger">
                                        <span class="bs-stepper-box"><i data-feather="user" class="font-medium-3"></i></span>
                                        <span class="bs-stepper-label">
                                            <span class="bs-stepper-title">Facility Details</span>
                                        </span>
                                    </button>
                                </div>
                                <div class="line"><i data-feather="chevron-right" class="font-medium-2"></i></div>
                                <div class="step" data-target="#personal-info-modern" role="tab" id="personal-info-modern-trigger">
                                    <button type="button" class="step-trigger">
                                        <span class="bs-stepper-box"><i data-feather="file-text" class="font-medium-3"></i></span>
                                        <span class="bs-stepper-label">
                                            <span class="bs-stepper-title">Additional Details</span>
                                        </span>
                                    </button>
                                </div>

                            </div>
                            <div class="bs-stepper-content">
                                <div style="font-size: 12px;" id="account-details-modern" class="content" role="tabpanel" aria-labelledby="account-details-modern-trigger">
                                    <div class="row">
                                        <div class="mb-1 col-md-2">
                                            <span><?= _('Name') ?></span>
                                            <br>
                                            <span class="fw-bolder me-25">{{ $facility->name }}</span>
                                        </div>
                                        <div class="mb-1 col-md-2">
                                            <span><?= _('Type') ?></span><br>
                                            <span class="fw-bolder me-25">{{ $facility->is_package==1?'Package':'Facility' }}</span>
                                        </div>
                                        <div class="mb-1 col-md-2">
                                            <span><?= _('Category') ?></span><br>
                                            <span class="fw-bolder me-25">{{ $facility->category }}</span>
                                        </div>
                                        <div class="mb-1 col-md-2">
                                            <span><?= _('Status') ?></span><br>
                                            <span class="fw-bolder me-25 <?php echo $facility->status_id == 1 ? 'text-success' : 'text-danger'; ?>">{{ $facility->status->name }}</span>
                                        </div>
                                        <div class="mb-1 col-md-2">
                                            <span><?= _('Gender') ?></span><br>
                                            <span class="fw-bolder me-25">{{ $facility->gender }}</span>
                                        </div>
                                    </div>
                                    <div class="row" style="border-bottom: 1px solid #efefef;padding: 15px 0px;">
                                        <div class="mb-1 col-md-2">
                                            <span><?= _('Price') ?></span>
                                            <br>
                                            <span class="fw-bolder me-25"> Rs.{{ $facility->price }}</span>
                                        </div>
                                        <div class="mb-1 col-md-2">
                                            <span><?= _('Discount') ?></span><br>
                                            <span class="fw-bolder me-25">{{!empty($facility->discount)?$facility->discount:'0.00' }}%</span>
                                        </div>
                                        <div class="mb-1 col-md-2">
                                            <span><?= _('Time') ?></span><br>
                                            <span class="fw-bolder me-25">{{ $facility->time }}</span>
                                        </div>
                                    </div>
                                    <div class="row">
                                        <div class="col-md-7">
                                            <div class="row">
                                                <div class="mb-1 col-md-12" style="border-bottom: 1px solid #efefef;padding: 12px 0px;line-height: 2em;">
                                                    <span><?= _('Description') ?></span>
                                                    <br>
                                                    <span class="fw-bolder me-25">{{ $facility->description }}</span>
                                                </div>
                                            </div>
                                        </div>
                                        <div class="col-md-5" style="padding: 15px 18px 0px 20px;border-left: 1px solid #dfd8d8;">
                                            <div class="row">
                                                <div class="mb-1 col-md-6 mt-1">
                                                    <span><?= _('Service Provider Name') ?></span>
                                                    <br>
                                                    <span class="fw-bolder me-25">{{ $facility->menuBasedService->name }}</span>
                                                </div>
                                                <div class="mb-1 col-md-6 mt-1">
                                                    <span><?= _('Contact Person') ?></span>
                                                    <br>
                                                    <span class="fw-bolder me-25">{{ $facility->menuBasedService->contact_person? $facility->menuBasedService->contact_person:'-' }}</span>
                                                </div>
                                                <div class="mb-1 col-md-12 mt-1">
                                                    <span><?= _('Service Provider Address') ?></span>
                                                    <br>
                                                    <span class="fw-bolder me-25">
                                                        {{ $facility->menuBasedService->address1 }}, {{ $facility->menuBasedService->address2 }}, {{ $facility->menuBasedService->area }}
                                                        , {{ $facility->menuBasedService->city->name }}, {{ $facility->menuBasedService->state->name }}-, {{ $facility->menuBasedService->pincode }}
                                                    </span>
                                                </div>
                                                <div class="mb-1 col-md-6 mt-1">
                                                    <span><?= _('Phone') ?></span>
                                                    <br>
                                                    <span class="fw-bolder me-25">{{ $facility->menuBasedService->phone?$facility->menuBasedService->phone:'-' }}</span>
                                                </div>
                                                <div class="mb-1 col-md-6 mt-1">
                                                    <span><?= _('Mobile') ?></span>
                                                    <br>
                                                    <span class="fw-bolder me-25">{{ $facility->menuBasedService->mobile? $facility->menuBasedService->mobile:'-' }}</span>
                                                </div>
                                                <?php if ($facility->menu_based_serviceParent) { ?>
                                                    <div class="mb-1 col-md-12 mt-1">
                                                        <span><?= _('Note') ?></span>
                                                        <br>
                                                        <span class="fw-bolder me-25">This service provider is working under the {{ $facility->menuBasedServiceParent->name}}</span>
                                                    </div>
                                                <?php } ?>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                <div id="personal-info-modern" class="content f-12" role="tabpanel" aria-labelledby="personal-info-modern-trigger">
                                    <div>
                                        <div class="col-xl-12  b-b-10 d-flex align-items-start me-2">
                                            <b style="font-size: 15px;">Facility Details</b> <small>(Total {{$facility->facility_count}} facility)</small>
                                        </div>
                                        <?php
                                        if (!empty($facility->detail_json)) {
                                            foreach ($facility->detail_json as $key => $mainFacility) {
                                                ?>
                                                <div class="col-xl-12 p-b-10 p-t-10 b-b-10 d-flex align-items-start me-2">
                                                    <div class="row">
                                                        <div class="col-xl-12 p-b-10 me-2">
                                                            <b><?php echo $mainFacility['parent']; ?></b> 
                                                        </div>
                                                        <?php
                                                        if (!empty($mainFacility['children'])) {
                                                            foreach ($mainFacility['children'] as $key => $subFacility) {
                                                                ?>
                                                                <div class="col-xl-12 p-b-10 me-2">
                                                                    <?php echo $subFacility; ?>
                                                                </div>
                                                                <?php
                                                            }
                                                        }
                                                        ?>
                                                    </div>
                                                </div>
                                                <?php
                                            }
                                        }
                                        ?>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </section>
                    <div class="row" data-select2-id="12">
                        <div class="col-12">
                            <?php if ($flag == 'MBS') { ?>
                                <a href="{{ route('admin.menu_based_service.facility.edit', ['id'=>$facility->id,'flag'=>'MBS'] )  }}" class="btn btn-primary me-1 waves-effect waves-float waves-light" > Edit</a>
                                <a href="{{route('admin.menu_based_service.facility', ['menu_based_service_id'=>$facility->menu_based_service_id])}}" class="btn btn-outline-secondary waves-effect">Back</a>
                            <?php } else { ?>
                                <a href="{{ route('admin.menu_based_service.facility.edit', ['id'=>$facility->id,'flag'=>'Globle'] )  }}" class="btn btn-primary me-1 waves-effect waves-float waves-light" > Edit</a>
                                <a href="{{route('admin.menu_based_service.facility')}}" class="btn btn-outline-secondary waves-effect">Back</a>
                            <?php } ?>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
@endsection
