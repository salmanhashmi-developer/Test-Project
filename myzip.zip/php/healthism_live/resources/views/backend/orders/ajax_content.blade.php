<script>
    var csrf_field = "{{ csrf_token() }}";
</script>
<script src="{{ Helper::static_asset('admin-assets/js/module/common.js') }}"></script>
<div class="row">
    <form class="" method="POST" action="{{ route('admin.orders') }}" id="search_form" onsubmit="return false">
        {{ csrf_field() }}
        <div class="col-12">
            <div class="card">
                <div class="card-header border-bottom">
                    <h4 class="card-title">{{ __("Order List")  }}</h4>
                </div>

                <!--Search Form -->
                <div class="card-body mt-2">
                    <input type="hidden" name="page" id="page" value="{{ empty(app('request')->input('page')) ? 1 : app('request')->input('page')  }}">
                    <input type="hidden" name="sort_field" id="sort_field" value="{{ app('request')->input('sort_field') }}">
                    <input type="hidden" name="sort_action" id="sort_action" value="{{ app('request')->input('sort_action') }}">
                    <div class="row g-1 mb-md-1">
                        <div class="col-md-3">
                            <label class="form-label">Order Code</label>
                            <input type="text" class="form-control dt-input dt-full-name" placeholder="Order Code" name="order_code" value="{{app('request')->input('order_code')}}">
                        </div>
                        <!--                        <div class="col-md-4">
                                                    <label class="form-label">User Name:</label>
                                                    <input type="text" class="form-control dt-input dt-full-name" placeholder="{{ __('User Name') }}" name="name" value="{{app('request')->input('name')}}">
                                                </div>-->
                        <div class="col-md-3">
                            <label class="form-label" for="user_id"><?= _('User') ?></label>
                            <input type="text" name="user" class="form-control user_search" placeholder="<?= _('Select User') ?>"
                                   value="{{app('request')->input('user')}}"/>
                            <input type="hidden" id="user_id" name="user_id" value="{{app('request')->input('user_id')}}">
                        </div>
                        <div class="col-md-3">
                            <label class="form-label">Subscription</label>
                            <select name="subscription_id" id="subscription_id" class="select2 form-select" >
                                <option value="">ALL</option>
                                @foreach ($subscriptions as $row)
                                <option {{ request_display('subscription_id') == $row['id'] ?'selected' : '' }} value="{{ $row['id']  }}">{{ $row['name'] .' (' . $row['plan_type'] .')'  }}</option>
                                @endforeach
                            </select>

                        </div>
                        <div class="col-md-3">
                            <label class="form-label">Status</label>
                            <select name="status_id" id="status_id" class="select2 form-select" >
                                <option value="">ALL</option>
                                @foreach ($statusList as $row)
                                <option <?php echo request_display('status_id') == $row['id'] ? 'selected' : '' ?> value="{{ $row['id']  }}">{{ $row['name']  }}</option>
                                @endforeach
                            </select>
                        </div>
                        <div class="col-md-3">
                            <label class="form-label">Order Id</label>
                            <input type="text" class="form-control dt-input dt-full-name" placeholder="Order Id" name="order_id" value="{{app('request')->input('order_id')}}">
                        </div>
                        <div class="col-md-3">
                            <label class="form-label">Service</label>
                            <select name="service_id" id="service_id" class="select2 form-select" >
                                <option value="">ALL</option>
                                @foreach ($service as $row)
                                <option {{ request_display('service_id') == $row['id'] ?'selected' : '' }} value="{{ $row['id']  }}">{{ $row['name']  }}</option>
                                @endforeach
                            </select>
                        </div>
                        <div class="col-md-3">
                            <div style="float:left;margin-right:5px;">
                                <label class="form-label">Order Start Date</label>
                                <input type="text" name="start_date" class="form-control datepicker" placeholder="Start Date" value="{{ request_display('start_date') }}" />
                            </div>
                        </div>
                        <div class="col-md-3">
                            <div style="float:left">
                                <label class="form-label">Order End Date</label>
                                <input type="text" name="end_date" class="form-control datepicker" placeholder="End Date" value="{{ request_display('end_date') }}" />
                            </div>
                        </div>
                        <div class="col-md-4 m-t-35">
                            <label class="form-label"></label>
                            <button type="submit" class="btn btn-primary waves-effect waves-float waves-light">Search</button>
                            <a id="refresh" data-url="/admin/orders" class="btn btn-outline-secondary waves-effect">Reset</a>
                        </div>
                    </div>
                </div>
                <hr class="my-0">
                <div class="card-datatable">
                    <?php echo parPageRecordDropDown() ?>
                    @if(!$orders->isEmpty())
                    @php $start = $orders->firstItem(); @endphp
                    <div class="table-responsive">
                        <table class="table table-bordered table-hover">
                            <thead>
                                <tr role="row">
                                    <th><?php echo sort_field_display('order_details', 'ORDER DETAILS'); ?></th>
                                    <th><?php echo sort_field_display('order_code order_id', 'ORDER CODE / ORDER ID'); ?></th>
                                    <th>USER DETAILS</th>
                                    <th><?php echo sort_field_display('amount', 'AMOUNT'); ?></th>
                                    <th><?php echo sort_field_display('Status', 'STATUS'); ?></th>
                                    <th><?php echo sort_field_display('created_at', 'CREATED / UPDATED DATE'); ?></th>
                                    <th>ACTIONS</th>
                                </tr>
                            </thead>
                            <tbody>
                                @foreach($orders as $order)
                                <tr class="f-12">
                                    <td valign="top">
                                        <?php
                                        if (!empty($order->description_json)) {
                                            $descriptionArr = json_decode($order->description_json, True);
                                            if (!empty($descriptionArr['desc1'])) {
                                                echo '<b class="theam-color">' . $descriptionArr['desc1'] . '</b><br>';
                                            }
                                            if (!empty($descriptionArr['desc2'])) {
                                                echo '<span>' . $descriptionArr['desc2'] . '</span><br>';
                                            }
                                            if (!empty($descriptionArr['desc3'])) {
                                                echo '<span>' . $descriptionArr['desc3'] . '</span>';
                                            }
                                        }
                                        ?>
                                    </td>
                                    <td valign="top">
                                        {{ $order->order_code  }}
                                        </br>
                                        <span>{{ $order->id  }}</span>
                                    </td>
                                    <td valign="top">
                                        {{ $order->user->first_name.' '.$order->user->last_name }}
                                        </br>
                                        <span>{{$order->user->mobile}}</span>
                                        </br>
                                        <span>{{$order->user->email}}</span>
                                    </td>
                                    <td valign="top">{{ $order->amount  }}</td>
                                    <td valign="top">{{ $order->status->name  }}</td>
                                    <td valign="top">
                                        {{ date("d/m/Y H:i",strtotime($order->created_at)) }}
                                        </br>
                                        <span>{{ date("d/m/Y H:i",strtotime($order->updated_at)) }}</span>
                                    </td>
                                    <td>
                                        <div class="dropdown">
                                            <button type="button" class="btn btn-sm dropdown-toggle hide-arrow py-0" data-bs-toggle="dropdown">
                                                <i data-feather="more-vertical"></i>
                                            </button>
                                            <div class="dropdown-menu dropdown-menu-end">
                                                <a class="dropdown-item" href="{{  route('admin.orders.view', ['id'=>$order->id] )  }}">
                                                    <i data-feather="file-text" class="me-50"></i>
                                                    <span>View</span>
                                                </a>
                                                <?php
                                                if (!empty($order->payment)) {
                                                    if ($order->payment->payment_mode_id != OFFLINE) {
                                                        $dbtimestamp = strtotime($order->created_at);
                                                        if (time() - $dbtimestamp > 15 * 60) {
                                                            // 15 mins has passed
                                                            if (in_array($order->status_id, [STATUS_PENDING, STATUS_RETURN_FROM_PG, STATUS_SENT_ON_PG])) {
                                                                ?>
                                                                <a class="dropdown-item" href="{{  route('admin.orders.recheck', ['id'=>$order->id] )  }}">
                                                                    <i data-feather="edit-2" class="me-51"></i>
                                                                    <span>Order Recheck</span>
                                                                </a>
                                                                <?php
                                                            }
                                                        }
                                                    }
                                                }
                                                ?>
                                            </div>
                                        </div>
                                    </td>
                                </tr>
                                @endforeach
                            </tbody>
                        </table>
                    </div>
                    @endif
                    <?php echo pagination($orders) ?>
                </div>
            </div>
        </div>
    </form>
</div>
@section('script')
<script type="text/javascript">
    $(document).ready(initCommon);
</script>

@endsection