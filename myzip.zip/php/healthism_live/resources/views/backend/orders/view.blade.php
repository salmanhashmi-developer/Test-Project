@extends('backend.layouts.master')
@section('title')
    Order view
@endsection
@section('content')
    <!-- BEGIN: Content-->
    <div class="app-content content ">
        <div class="content-wrapper p-0">
            <div class="content-body">
                @include('backend.message')
                <div class="card" data-select2-id="14">
                    <div class="card-header border-bottom">
                        <h4 class="card-title">Order Details View</h4>
                    </div>
                    <div class="card-body py-2 my-25" data-select2-id="53">
                        <!-- header section -->
                        <!-- Modern Horizontal Wizard -->
                        <section class="modern-horizontal-wizard">
                            <div class="bs-stepper wizard-modern modern-wizard-example">
                                <div class="bs-stepper-header">
                                    <div class="step" data-target="#order-modern" role="tab"
                                        id="order-modern-trigger">
                                        <button type="button" class="step-trigger">
                                            <span class="bs-stepper-box"><i data-feather="user"
                                                    class="font-medium-3"></i></span>
                                            <span class="bs-stepper-label">
                                                <span class="bs-stepper-title">Order</span>
                                            </span>
                                        </button>
                                    </div>
                                    <div class="line"><i data-feather="chevron-right" class="font-medium-2"></i></div>
                                    <div class="step" data-target="#order-detail-modern" role="tab"
                                        id="order-detail-modern-trigger">
                                        <button type="button" class="step-trigger">
                                            <span class="bs-stepper-box"><i data-feather="file-text"
                                                    class="font-medium-3"></i></span>
                                            <span class="bs-stepper-label">
                                                <span class="bs-stepper-title">Order Details</span>
                                            </span>
                                        </button>
                                    </div>
                                    <div class="line"><i data-feather="chevron-right" class="font-medium-2"></i></div>
                                    <div class="step" data-target="#order-payment-modern" role="tab"
                                        id="order-payment-modern-trigger">
                                        <button type="button" class="step-trigger">
                                            <span class="bs-stepper-box"><i data-feather="file-text"
                                                    class="font-medium-3"></i></span>
                                            <span class="bs-stepper-label">
                                                <span class="bs-stepper-title">Order Payment</span>
                                            </span>
                                        </button>
                                    </div>
                                    <div class="line"><i data-feather="chevron-right" class="font-medium-2"></i></div>
                                    <div class="step" data-target="#order-charges-modern" role="tab"
                                        id="order-charges-modern-trigger">
                                        <button type="button" class="step-trigger">
                                            <span class="bs-stepper-box"><i data-feather="file-text"
                                                    class="font-medium-3"></i></span>
                                            <span class="bs-stepper-label">
                                                <span class="bs-stepper-title">Order Charges</span>
                                            </span>
                                        </button>
                                    </div>
                                    <div class="line"><i data-feather="chevron-right" class="font-medium-2"></i></div>
                                    <div class="step" data-target="#order-histories-modern" role="tab"
                                        id="order-histories-modern-trigger">
                                        <button type="button" class="step-trigger">
                                            <span class="bs-stepper-box"><i data-feather="file-text"
                                                    class="font-medium-3"></i></span>
                                            <span class="bs-stepper-label">
                                                <span class="bs-stepper-title">Order Histories</span>
                                            </span>
                                        </button>
                                    </div>
                                </div>
                                <div class="bs-stepper-content">
                                    <div id="order-modern" class="content" role="tabpanel"
                                        aria-labelledby="order-modern-trigger">
                                        <div class="info-container me-2">
                                            <ul class="list-unstyled f-12">
                                                <?php if (!empty($order->subscription->name)) { ?>
                                                <li class="mb-75 mt-2">
                                                    <div class="row">
                                                        <div class="mb-1 col-md-4">
                                                            <span><?= _('Subscription') ?>:</span>
                                                            <br>
                                                            <span
                                                                class="fw-bolder me-25">{{ $order->subscription->name }}</span>
                                                        </div>
                                                        <div class="mb-1 col-md-4">

                                                        </div>
                                                        <div class="mb-1 col-md-4">

                                                        </div>
                                                    </div>
                                                </li>
                                                <?php } ?>
                                                <li class="mb-75 mt-2">
                                                    <div class="row">
                                                        <div class="mb-1 col-md-4">
                                                            <span><?= _('Order Id') ?>:</span>
                                                            <br>
                                                            <span class="fw-bolder me-25">{{ $order->id }}</span>
                                                        </div>
                                                        <div class="mb-1 col-md-4">
                                                            <span><?= _('Order Code') ?>:</span>
                                                            <br>
                                                            <span class="fw-bolder me-25">{{ $order->order_code }}</span>
                                                        </div>
                                                        <div class="mb-1 col-md-4">
                                                            <span><?= _('Username') ?>:</span>
                                                            <br>
                                                            <span
                                                                class="fw-bolder me-25">{{ $order->user->first_name . ' ' . $order->user->last_name }}</span>
                                                        </div>
                                                    </div>
                                                </li>
                                                <li class="mb-75 mt-2">
                                                    <div class="row">
                                                        <div class="mb-1 col-md-4">
                                                            <span><?= _('Service') ?>:</span>
                                                            <br>
                                                            <span
                                                                class="fw-bolder me-25">{{ $order->service->name }}</span>
                                                        </div>
                                                        <div class="mb-1 col-md-4">
                                                            <span><?= _('Amount') ?>:</span>
                                                            <br>
                                                            <span class="fw-bolder me-25">{{ $order->amount }}</span>
                                                        </div>
                                                        <div class="mb-1 col-md-4">
                                                            <span><?= _('Charges') ?>:</span>
                                                            <br>
                                                            <span class="fw-bolder me-25">{{ $order->charges }}</span>
                                                        </div>
                                                    </div>
                                                </li>
                                                <li class="mb-75 mt-2">
                                                    <div class="row">
                                                        <div class="mb-1 col-md-4">
                                                            <span><?= _('Created At') ?>:</span>
                                                            <br>
                                                            <span
                                                                class="fw-bolder me-25">{{ date('d/m/Y H:i', strtotime($order->created_at)) }}</span>
                                                        </div>
                                                        <div class="mb-1 col-md-4">
                                                            <span><?= _('Updated At') ?>:</span>
                                                            <br>
                                                            <span
                                                                class="fw-bolder me-25">{{ date('d/m/Y H:i', strtotime($order->updated_at)) }}</span>
                                                        </div>
                                                        <div class="mb-1 col-md-4">
                                                            <span><?= _('Status') ?>:</span>
                                                            <br>
                                                            <span class="fw-bolder me-25">{{ $order->status->name }}</span>
                                                        </div>
                                                    </div>
                                                </li>
                                                <li class="mb-75 mt-2">
                                                    <div class="row">
                                                        <div class="mb-1 col-md-12">
                                                            <span><?= _('Remark') ?>:</span>
                                                            <br>
                                                            <span class="fw-bolder me-25"
                                                                style="color: <?php echo $order->description_json; ?>;">
                                                                {{ $order->remark }}
                                                            </span>
                                                        </div>
                                                    </div>
                                                </li>
                                                <li class="mb-75 mt-2">
                                                    <div class="row">
                                                        <div class="mb-1 col-md-12">
                                                            <span><?= _('Description') ?>:</span>
                                                            <br>
                                                            <span class="fw-bolder me-25"
                                                                style="color: <?php echo $order->description_json; ?>;">
                                                                {{ $order->description_json }}
                                                            </span>
                                                        </div>
                                                    </div>
                                                </li>
                                                <li class="mb-75 mt-2">
                                                    <div class="row">
                                                        <div class="mb-1 col-md-12">
                                                            <span><?= _('Gender') ?>:</span>
                                                            <br>
                                                            <span class="fw-bolder me-25"
                                                                style="color: <?php echo $order->transaction_json; ?>;">
                                                                {{ $order->transaction_json }}
                                                            </span>
                                                        </div>
                                                    </div>
                                                </li>
                                            </ul>
                                        </div>
                                    </div>
                                    <div id="order-detail-modern" class="content" role="tabpanel"
                                        aria-labelledby="order-detail-modern-trigger">
                                        <div class="d-flex">
                                            <div class="col-lg-8 col-md-8 align-items-start me-2">
                                                <div class="info-container">
                                                    @foreach ($order->detail as $row)
                                                        <ul class="list-unstyled f-12">
                                                            <li class="mb-75 mt-2">
                                                                <div class="row">
                                                                    <div class="mb-1 col-md-4">
                                                                        <span><?= _('Order Id') ?>:</span>
                                                                        <br>
                                                                        <span
                                                                            class="fw-bolder me-25">{{ $row->order_id }}</span>
                                                                    </div>
                                                                    <div class="mb-1 col-md-4">
                                                                        <span><?= _('Service') ?>:</span>
                                                                        <br>
                                                                        <span
                                                                            class="fw-bolder me-25">{{ $row->service->name }}</span>
                                                                    </div>
                                                                    <div class="mb-1 col-md-4">
                                                                        <span><?= _('Reference') ?>:</span>
                                                                        <br>
                                                                        <span
                                                                            class="fw-bolder me-25">{{ !empty($row->user) ? $row->user->first_name . ' ' . $row->user->last_name : '-' }}</span>
                                                                    </div>
                                                                </div>
                                                            </li>
                                                            <li class="mb-75 mt-2">
                                                                <div class="row">
                                                                    <div class="mb-1 col-md-4">
                                                                        <span><?= _('Wallet Amount') ?>:</span>
                                                                        <br>
                                                                        <span
                                                                            class="fw-bolder me-25">{{ $row->wallet_amount }}</span>
                                                                    </div>
                                                                    <div class="mb-1 col-md-4">
                                                                        <span><?= _('Refund Amount') ?>:</span>
                                                                        <br>
                                                                        <span
                                                                            class="fw-bolder me-25">{{ $row->refund_amount }}</span>
                                                                    </div>
                                                                    <div class="mb-1 col-md-4">
                                                                        <span><?= _('Coupon Amount') ?>:</span>
                                                                        <br>
                                                                        <span
                                                                            class="fw-bolder me-25">{{ $row->coupon_amount }}</span>
                                                                    </div>
                                                                </div>
                                                            </li>
                                                            <li class="mb-75 mt-2">
                                                                <div class="row">
                                                                    <div class="mb-1 col-md-4">
                                                                        <span><?= _('PG Amount') ?>:</span>
                                                                        <br>
                                                                        <span
                                                                            class="fw-bolder me-25">{{ $row->pg_amount }}</span>
                                                                    </div>
                                                                    <div class="mb-1 col-md-4">
                                                                        <span><?= _('Paid Amount') ?>:</span>
                                                                        <br>
                                                                        <span
                                                                            class="fw-bolder me-25">{{ $row->paid_amount }}</span>
                                                                    </div>
                                                                    <div class="mb-1 col-md-4">
                                                                        <span><?= _('Tracking') ?>:</span>
                                                                        <br>
                                                                        <span
                                                                            class="fw-bolder me-25">{{ $row->tracking_json }}</span>
                                                                    </div>
                                                                </div>
                                                            </li>
                                                            <li class="mb-75 mt-2">
                                                                <div class="row">
                                                                    <div class="mb-1 col-md-4">
                                                                        <span><?= _('Cancellation Charge') ?>:</span>
                                                                        <br>
                                                                        <span
                                                                            class="fw-bolder me-25">{{ $row->cancellation_charge }}</span>
                                                                    </div>
                                                                    <div class="mb-1 col-md-4">
                                                                        <span><?= _('Tax') ?>:</span>
                                                                        <br>
                                                                        <span
                                                                            class="fw-bolder me-25">{{ $row->tax }}</span>
                                                                    </div>
                                                                    <div class="mb-1 col-md-4">
                                                                        <span><?= _('Charges') ?>:</span>
                                                                        <br>
                                                                        <span
                                                                            class="fw-bolder me-25">{{ $row->charges }}</span>
                                                                    </div>
                                                                </div>
                                                            </li>
                                                            <li class="mb-75 mt-2">
                                                                <div class="row">
                                                                    <div class="mb-1 col-md-4">
                                                                        <span><?= _('Updated At') ?>:</span>
                                                                        <br>
                                                                        <span
                                                                            class="fw-bolder me-25">{{ $row->updated_at }}</span>
                                                                    </div>
                                                                    <div class="mb-1 col-md-4">
                                                                        <span><?= _('Created At') ?>:</span>
                                                                        <br>
                                                                        <span
                                                                            class="fw-bolder me-25">{{ $row->created_at }}</span>
                                                                    </div>
                                                                    <div class="mb-1 col-md-4">
                                                                        <span><?= _('Status') ?>:</span>
                                                                        <br>
                                                                        <span
                                                                            class="fw-bolder me-25">{{ $row->status->name }}</span>
                                                                    </div>
                                                                </div>
                                                            </li>
                                                            <li class="mb-75 mt-2">
                                                                <div class="row">
                                                                    <div class="mb-1 col-md-6">
                                                                        <span><?= _('Remark') ?>:</span>
                                                                        <br>
                                                                        <span class="fw-bolder me-25"
                                                                            style="color:<?php echo $row->remark_color_code; ?>">{{ $row->remark }}
                                                                        </span>
                                                                    </div>
                                                                    <div class="mb-1 col-md-6">
                                                                        <span><?= _('Histories') ?>:</span>
                                                                        <br>
                                                                        <span
                                                                            class="fw-bolder me-25">{{ $row->histories_json }}</span>
                                                                    </div>
                                                                </div>
                                                            </li>
                                                        </ul>
                                                    @endforeach
                                                </div>
                                            </div>
                                            <div class="col-lg-4 col-md-4 d-flex">
                                                @if (!empty($row->status_list))
                                                    <div class="border-bottom m-b-10 p-r-10" style="width: 100%">
                                                        <form class="" method="POST"
                                                            action="{{ route('admin.orders.update') }}">
                                                            {{ csrf_field() }}
                                                            <div class="col-12">
                                                                <div class="col-md-12">
                                                                    <label class="form-label">Remark</label>
                                                                    <textarea name="remark" class="form-control" cols="2" rows="2" required></textarea>
                                                                </div>
                                                                <div class="col-md-12 p-t-10">
                                                                    <label class="form-label">Status</label>
                                                                    <select name="status_id" id="status_id"
                                                                        class="select2 form-select" required="">
                                                                        <option value=""></option>
                                                                        @foreach ($row->status_list as $status)
                                                                            <option value="{{ $status['id'] }}">
                                                                                {{ $status['name'] }}</option>
                                                                        @endforeach
                                                                    </select>
                                                                </div>
                                                                <div class="col-md-12 m-t-10">
                                                                    <input type="hidden" name="order_id"
                                                                        value="{{ $row->order_id }}">
                                                                    <input type="hidden" name="order_detail_id"
                                                                        value="{{ $row->id }}">
                                                                    <button type="submit"
                                                                        class="col-md-12 btn btn-primary waves-effect waves-float waves-light">Update</button>
                                                                </div>
                                                            </div>
                                                        </form>
                                                    </div>
                                                @endif
                                            </div>
                                        </div>
                                    </div>
                                    <div id="order-payment-modern" class="content" role="tabpanel"
                                        aria-labelledby="order-payment-modern-trigger">
                                        <div class="info-container me-2">
                                            <ul class="list-unstyled f-12">
                                                @if (!empty($order->payment))
                                                    <li class="mb-75 mt-2">
                                                        <div class="row">
                                                            <div class="mb-1 col-md-3">
                                                                <span><?= _('Order Id') ?>:</span>
                                                                <br>
                                                                <span
                                                                    class="fw-bolder me-25">{{ $order->payment->order_id }}</span>
                                                            </div>
                                                            <div class="mb-1 col-md-3">
                                                                <span><?= _('Username') ?>:</span>
                                                                <br>
                                                                <span
                                                                    class="fw-bolder me-25">{{ $order->payment->user->first_name . ' ' . $order->payment->user->last_name }}</span>
                                                            </div>
                                                            <div class="mb-1 col-md-3">
                                                                <span><?= _('Payment Mode') ?>:</span>
                                                                <br>
                                                                <span
                                                                    class="fw-bolder me-25">{{ $order->payment->paymentmode->name }}</span>
                                                            </div>
                                                            <div class="mb-1 col-md-3">
                                                                <span><?= _('PG Amount') ?>:</span>
                                                                <br>
                                                                <span
                                                                    class="fw-bolder me-25">{{ $order->payment->pg_amount }}</span>
                                                            </div>
                                                        </div>
                                                    </li>
                                                    <li class="mb-75 mt-2">
                                                        <div class="row">
                                                            <div class="mb-1 col-md-3">
                                                                <span><?= _('Refund Amount') ?>:</span>
                                                                <br>
                                                                <span
                                                                    class="fw-bolder me-25">{{ $order->payment->refund_amount }}</span>
                                                            </div>
                                                            <div class="mb-1 col-md-3">
                                                                <span><?= _('PG Reference') ?>:</span>
                                                                <br>
                                                                <span
                                                                    class="fw-bolder me-25">{{ $order->payment->pg_reference_id }}</span>
                                                            </div>
                                                            <div class="mb-1 col-md-3">
                                                                <span><?= _('Status') ?>:</span>
                                                                <br>
                                                                <span
                                                                    class="fw-bolder me-25">{{ $order->payment->status->name }}</span>
                                                            </div>
                                                            <div class="mb-1 col-md-3">
                                                                <span><?= _('IP Address') ?>:</span>
                                                                <br>
                                                                <span
                                                                    class="fw-bolder me-25">{{ $order->payment->ip_address }}</span>
                                                            </div>
                                                        </div>
                                                    </li>
                                                    <li class="mb-75 mt-2">
                                                        <div class="row">

                                                            <div class="mb-1 col-md-3">
                                                                <span><?= _('Created At') ?>:</span>
                                                                <br>
                                                                <span
                                                                    class="fw-bolder me-25">{{ date('d/m/Y H:i', strtotime($order->payment->created_at)) }}</span>
                                                            </div>
                                                            <div class="mb-1 col-md-3">
                                                                <span><?= _('Updated At') ?>:</span>
                                                                <br>
                                                                <span
                                                                    class="fw-bolder me-25">{{ date('d/m/Y H:i', strtotime($order->payment->updated_at)) }}</span>
                                                            </div>
                                                            <div class="mb-1 col-md-3">
                                                                <span><?= _('Payment Sync Retry Count') ?>:</span>
                                                                <br>
                                                                <span
                                                                    class="fw-bolder me-25">{{ $order->payment->payment_sync_retry_count }}</span>
                                                            </div>
                                                            <div class="mb-1 col-md-3">

                                                            </div>
                                                        </div>
                                                    </li>
                                                    <li class="mb-75 mt-2">
                                                        <div class="row">
                                                            <div class="mb-1 col-md-12">
                                                                <span><?= _('PG Response') ?>:</span>
                                                                <br>
                                                                <span
                                                                    class="fw-bolder me-25">{{ $order->payment->pg_response }}</span>
                                                            </div>
                                                        </div>
                                                    </li>
                                                    <li class="mb-75 mt-2">
                                                        <div class="row">
                                                            <div class="mb-1 col-md-12">
                                                                <span><?= _('PG Refund Response') ?>:</span>
                                                                <br>
                                                                <span
                                                                    class="fw-bolder me-25">{{ $order->payment->pg_refund_response }}</span>
                                                            </div>
                                                        </div>
                                                    </li>
                                                @endif
                                            </ul>
                                        </div>
                                    </div>
                                    <div id="order-charges-modern" class="content" role="tabpanel"
                                        aria-labelledby="order-charges-modern-trigger">
                                        <div class="d-flex">
                                            <div class="col-xl-8 col-lg-5 col-md-5  d-flex align-items-start me-2">
                                                <div class="info-container">
                                                    @if (!empty($order->charges))
                                                        @foreach ($order->charges as $row)
                                                            <ul class="list-unstyled">
                                                                <li class="mb-75">
                                                                    <span
                                                                        class="fw-bolder me-25"><?= _('Order Id') ?>:</span>
                                                                    <span>{{ $row->order_id }} </span>
                                                                </li>

                                                                <li class="mb-75">
                                                                    <span
                                                                        class="fw-bolder me-25"><?= _('Username') ?>:</span>
                                                                    <span>{{ $row->user->first_name . ' ' . $row->user->last_name }}
                                                                    </span>
                                                                </li>
                                                                <li class="mb-75">
                                                                    <span
                                                                        class="fw-bolder me-25"><?= _('Service') ?>:</span>
                                                                    <span>{{ @$row->service->name }} </span>
                                                                </li>
                                                                <li class="mb-75">
                                                                    <span
                                                                        class="fw-bolder me-25"><?= _('Order Detail Id') ?>:</span>
                                                                    <span>{{ $row->order_detail_id }} </span>
                                                                </li>
                                                                <li class="mb-75">
                                                                    <span
                                                                        class="fw-bolder me-25"><?= _('Charge Type Id') ?>:</span>
                                                                    <span>{{ @$row->chargeType->name }} </span>
                                                                </li>
                                                                <li class="mb-75">
                                                                    <span class="fw-bolder me-25"><?= _('Name') ?>:</span>
                                                                    <span>{{ $row->name }} </span>
                                                                </li>
                                                                <li class="mb-75">
                                                                    <span
                                                                        class="fw-bolder me-25"><?= _('Amount') ?>:</span>
                                                                    <span>{{ $row->amount }} </span>
                                                                </li>
                                                                <li class="mb-75">
                                                                    <span
                                                                        class="fw-bolder me-25"><?= _('Created At') ?>:</span>
                                                                    <span>{{ date('d/m/Y H:i', strtotime($row->created_at)) }}
                                                                    </span>
                                                                </li>


                                                            </ul>
                                                        @endforeach
                                                    @endif
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                    <div id="order-histories-modern" class="content" role="tabpanel"
                                        aria-labelledby="order-histories-modern-trigger">
                                        <div class="card-datatable">

                                            <div class="table-responsive">
                                                <table class="table table-bordered table-hover">
                                                    <thead>
                                                        <tr role="row">

                                                            <th>Order Id</th>
                                                            <th>Type</th>
                                                            <th>Status</th>
                                                            <th>Remarks</th>
                                                            <th>Created At</th>
                                                            <th>Updated At</th>
                                                            <th>Updated By</th>

                                                        </tr>
                                                    </thead>
                                                    <tbody>
                                                        @if (!empty($order->histories))
                                                            @foreach ($order->histories as $row)
                                                                <tr class="f-12">

                                                                    <td valign="top">{{ $row->order_id }}</td>
                                                                    <td valign="top">{{ $row->type }}</td>
                                                                    <td valign="top">{{ $row->status->name }}</td>
                                                                    <td valign="top">{{ $row->remark }}</td>
                                                                    <td valign="top">
                                                                        {{ date('d/m/Y H:i', strtotime($row->created_at)) }}
                                                                    </td>
                                                                    <td valign="top">
                                                                        {{ date('d/m/Y H:i', strtotime($row->created_at)) }}
                                                                    </td>
                                                                    <td valign="top">{{ @$row->user->first_name }}</td>

                                                                </tr>
                                                            @endforeach
                                                        @endif

                                                    </tbody>
                                                </table>
                                            </div>




                                        </div>
                                    </div>




                                </div>

                            </div>
                        </section>
                        <!-- /Modern Horizontal Wizard -->

                        <div class="row" data-select2-id="12">
                            <div class="col-12">

                                <a href="{{ route('admin.orders') }}"
                                    class="btn btn-outline-secondary waves-effect">Back</a>
                            </div>
                        </div>


                    </div>

                </div>

            </div>
        </div>
    </div>
@endsection
