@extends("backend.layouts.master")
@section('title') Doctor List @endsection
@section('content')

<!-- BEGIN: Content-->
<div class="app-content content ">

    <div class="content-wrapper p-0">

        <div class="content-body">
            @include('backend.message')
            <div class="card" data-select2-id="14">
                <div class="card-header border-bottom">
                    <h4 class="card-title">Doctor Appointment Booking Details</h4>
                </div>
                <div class="card-body py-2 my-25" data-select2-id="53">
                    <!-- header section -->

                    <!-- Modern Horizontal Wizard -->
                    <section class="modern-horizontal-wizard m-2">
                        <div class="info-container me-2">
                            <ul class="list-unstyled f-12">
                                <li class="mb-75 mt-2">
                                    <div class="row">
                                        <div class="mb-1 col-md-4">
                                            <span><?= _('Hospital Name') ?>:</span>
                                            <br>
                                            <span class="fw-bolder me-25">{{ $doctorAppointmentBooking->hospital->name  }}<span class="f-11">({{$doctorAppointmentBooking->hospital->area}})</span></span>
                                        </div>
                                        <div class="mb-1 col-md-4">
                                            <span><?= _('Doctor Name') ?>:</span>
                                            <br>
                                            <span class="fw-bolder me-25">{{ $doctorAppointmentBooking->doctor->first_name.' '.$doctorAppointmentBooking->doctor->middle_name.' '.$doctorAppointmentBooking->doctor->last_name  }}<span class="f-11">({{$doctorAppointmentBooking->doctor->phone}})</span></span>
                                        </div>
                                        <div class="mb-1 col-md-4">
                                            <span><?= _('Book By') ?>:</span>
                                            <br>
                                            <span class="fw-bolder me-25">{{ $doctorAppointmentBooking->user->first_name  .' '.$doctorAppointmentBooking->user->last_name  }}<span class="f-11">({{$doctorAppointmentBooking->user->mobile}})</span></span>
                                        </div>
                                    </div>
                                </li>
                                <li class="mb-75 mt-2">
                                    <div class="row">
                                        <div class="mb-1 col-md-4">
                                            <span><?= _('User Patient Name') ?>:</span>
                                            <br>
                                            <span class="fw-bolder me-25">{{ $doctorAppointmentBooking->user_patient->first_name  .' '.$doctorAppointmentBooking->user_patient->last_name  }}</span>
                                        </div>
                                        <div class="mb-1 col-md-4">
                                            <span><?= _('Patient Name') ?>:</span>
                                            <br>
                                            <span class="fw-bolder me-25">{{ $doctorAppointmentBooking->patient_name }}</span></span>
                                        </div>
                                        <div class="mb-1 col-md-4">
                                            <span><?= _('Patient Mobileno') ?>:</span>
                                            <br>
                                            <span class="fw-bolder me-25">{{ $doctorAppointmentBooking->patient_mobile }}</span></span>
                                        </div>
                                    </div>
                                </li>
                                <li class="mb-75 mt-2">
                                    <div class="row">
                                        <div class="mb-1 col-md-4">
                                            <span><?= _('Order Id') ?>:</span>
                                            <br>
                                            <span class="fw-bolder me-25">{{ $doctorAppointmentBooking->order_id  }}</span>
                                        </div>
                                        <div class="mb-1 col-md-4">
                                            <span><?= _('Appointment Start - End') ?>:</span>
                                            <br>
                                            <span class="fw-bolder me-25">
                                                <?php if (!empty($doctorAppointmentBooking->appointment_start) && !empty($doctorAppointmentBooking->appointment_end)) {?>
                                                    {{ date("d/m/Y H:i",strtotime($doctorAppointmentBooking->appointment_start)).' to '. date("d/m/Y H:i",strtotime($doctorAppointmentBooking->appointment_end)) }}
                                                <?php } ?>
                                            </span>
                                        </div>
                                        <div class="mb-1 col-md-4">
                                            <span><?= _('Appointment Date Time') ?>:</span>
                                            <br>
                                            <span class="fw-bolder me-25">{{ date("d/m/Y",strtotime($doctorAppointmentBooking->appointment_date)) .' '.date("H:i",strtotime($doctorAppointmentBooking->appointment_time)) }}</span>
                                        </div>
                                    </div>
                                </li>
                                <li class="mb-75 mt-2">
                                    <div class="row">
                                        <div class="mb-1 col-md-4">
                                            <span><?= _('Amount') ?>:</span>
                                            <br>
                                            <span class="fw-bolder me-25">{{ $doctorAppointmentBooking->amount }}</span></span>
                                        </div>
                                        <div class="mb-1 col-md-4">
                                            <span><?= _('Refund Amount') ?>:</span>
                                            <br>
                                            <span class="fw-bolder me-25">{{ $doctorAppointmentBooking->refund_amount }}</span></span>
                                        </div>
                                        <div class="mb-1 col-md-4">
                                            <span><?= _('Discount') ?>:</span>
                                            <br>
                                            <span class="fw-bolder me-25">{{ $doctorAppointmentBooking->discount }}</span>
                                        </div>
                                    </div>
                                </li>
                                <li class="mb-75 mt-2">
                                    <div class="row">
                                        <div class="mb-1 col-md-4">
                                            <span><?= _('Booked By') ?>:</span>
                                            <br>
                                            <span class="fw-bolder me-25">{{ $doctorAppointmentBooking->user->first_name .' '. $doctorAppointmentBooking->user->last_name }}</span>
                                        </div>
                                        <div class="mb-1 col-md-4">
                                            <span><?= _('Is Video') ?>:</span>
                                            <br>
                                            <span class="fw-bolder me-25">{{ post_display('is_video',$doctorAppointmentBooking->is_video) == 1 ? 'Yes':'No' }}</span></span>
                                        </div>
                                        <div class="mb-1 col-md-4">
                                            <span><?= _('Status') ?>:</span>
                                            <br>
                                            <span class="fw-bolder me-25">{{ $doctorAppointmentBooking->status->name }}</span></span>
                                        </div>

                                    </div>
                                </li>
                                <li class="mb-75 mt-2">
                                    <div class="row">
                                        <div class="mb-1 col-md-4">
                                            <span><?= _('Created At') ?>:</span>
                                            <br>
                                            <span class="fw-bolder me-25">{{ date("d/m/Y H:i",strtotime($doctorAppointmentBooking->created_at )) }}</span>
                                        </div>
                                        <div class="mb-1 col-md-4">
                                            <span><?= _('Updated At') ?>:</span>
                                            <br>
                                            <span class="fw-bolder me-25">{{ date("d/m/Y H:i",strtotime($doctorAppointmentBooking->updated_at)) }}</span>
                                        </div>
                                        <div class="mb-1 col-md-4">

                                        </div>
                                    </div>
                                </li>
                            </ul>





<!--                                    <ul class="list-unstyled">
                                <li class="mb-75">
                                    <span class="fw-bolder me-25"><?= _('Doctor Hospital Slot') ?>:</span>


                                    <ul class="list-unstyled p-2"  style=" list-style-type: circle;">
                                        <li class="mb-75">
                                            <span class="fw-bolder me-25"><?= _('Day') ?>:</span>
                                            <span>
                                                <?php if (!empty($doctorAppointmentBooking->hospitalslot->day)) { ?>
                                                    {{ $doctorAppointmentBooking->hospitalslot->day }} 
                                                <?php } ?></span>
                                        </li>
                                        <li class="mb-75">
                                            <span class="fw-bolder me-25"><?= _('Date') ?>:</span>
                                            <span>
                                                <?php if (!empty($doctorAppointmentBooking->hospitalslot->date)) { ?>
                                                    {{ date("d/m/Y",strtotime($doctorAppointmentBooking->hospitalslot->date)) }} 
                                                <?php } ?></span>
                                        </li>
                                        <li class="mb-75">
                                            <span class="fw-bolder me-25"><?= _('From Time') ?>:</span>
                                            <span>{{ date("H:i",strtotime($doctorAppointmentBooking->hospitalslot->from_time)) }} </span>
                                        </li>
                                        <li class="mb-75">
                                            <span class="fw-bolder me-25"><?= _('To Time') ?>:</span>
                                            <span>{{ date("H:i",strtotime($doctorAppointmentBooking->hospitalslot->to_time)) }} </span>
                                        </li>
                                        <li class="mb-75">
                                            <span class="fw-bolder me-25"><?= _('Is Video') ?>:</span>
                                            <span>{{ post_display('is_video',$doctorAppointmentBooking->hospitalslot->is_video) == 1 ? 'Yes':'No'  }} </span>
                                        </li>
                                        <li class="mb-75">
                                            <span class="fw-bolder me-25"><?= _('Is Offline') ?>:</span>
                                            <span>{{ post_display('is_video',$doctorAppointmentBooking->hospitalslot->is_offline) == 1 ? 'Yes':'No' }} </span>
                                        </li>
                                        <li class="mb-75">
                                            <span class="fw-bolder me-25"><?= _('Status') ?>:</span>
                                            <span>{{ $doctorAppointmentBooking->hospitalslot->status->name }} </span>
                                        </li>
                                    </ul>




                                </li>
                            </ul>-->

                        </div>
                    </section>
                    <!-- /Modern Horizontal Wizard -->

                    <div class="row" data-select2-id="12">
                        <div class="col-12">
                            <a href="{{route('admin.doctor_appointment_booking')}}" class="btn btn-outline-secondary waves-effect">Back</a>
                        </div>
                    </div>


                </div>

            </div>

        </div>
    </div>
</div>
@endsection

