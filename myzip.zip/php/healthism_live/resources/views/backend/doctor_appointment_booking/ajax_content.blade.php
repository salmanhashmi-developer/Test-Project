<div class="row">
    <form class="" method="POST" action="{{ route('admin.doctor_appointment_booking') }}" id="search_form" onsubmit="return false">
        {{ csrf_field() }}
        <div class="col-12">
            <div class="card">
                <div class="card-header border-bottom">
                    <h4 class="card-title">{{ __("Doctor Appointment Booking")  }}</h4>
                </div>
                <div class="card-body mt-1">
                    <input type="hidden" name="page" id="page" value="{{ empty(app('request')->input('page')) ? 1 : app('request')->input('page')  }}">
                    <input type="hidden" name="sort_field" id="sort_field" value="{{ app('request')->input('sort_field') }}">
                    <input type="hidden" name="sort_action" id="sort_action" value="{{ app('request')->input('sort_action') }}">
                    <div class="row g-1 mb-md-1">
                        <div class="col-md-4">
                            <label class="form-label">Order Id</label>
                            <input type="text" class="form-control dt-input dt-full-name" placeholder="Order Id" name="order_id" value="{{app('request')->input('order_id')}}">
                        </div>
                        <div class="col-md-4">
                            <label class="form-label">Hospital Name</label>
                            <input type="text" class="form-control dt-input dt-full-name" placeholder="Hospital Name" name="hospital_name" value="{{app('request')->input('hospital_name')}}">
                        </div>
                        <div class="col-md-4">
                            <label class="form-label">Doctor Name</label>
                            <input type="text" class="form-control dt-input dt-full-name" placeholder="Doctor Name" name="doctor_name" value="{{app('request')->input('doctor_name')}}">
                        </div>
                    </div>
                    <div class="row g-1 mb-md-1">
                        <div class="col-md-4">
                            <label class="form-label">Patient Name</label>
                            <input type="text" class="form-control dt-input dt-full-name" placeholder="Patient Name" name="patient_name" value="{{app('request')->input('patient_name')}}">
                        </div>
                        <div class="col-md-4">
                            <label class="form-label">Mobile</label>
                            <input type="text" class="form-control dt-input" name="mobile" placeholder="Mobile No" value="{{app('request')->input('mobile')}}">
                        </div>
                        <div class="col-md-4">
                            <label class="form-label">Status:</label>
                            <select name="status_id" id="status_id" class="select2 form-select" >
                                <option value="">ALL</option>
                                @foreach ($statusList as $row)
                                <option <?php echo request_display('status_id') == $row['id'] ? 'selected' : '' ?> value="{{ $row['id']  }}">{{ $row['name']  }}</option>
                                @endforeach
                            </select>
                        </div>
                    </div>
                    <div class="row g-1">
                        <div class="col-md-12">
                            <label class="form-label">Appointment Start Date - End Sate </label>
                        </div>
                        <div class="col-md-4">
                            <div class="col-md-5" style="float:left;margin-right:5px;"> <input type="text" name="start_date" class="form-control datepicker" placeholder="Start Date" value="{{ request_display('start_date') }}" /></div>
                            <div class="col-md-5" style="float:left"> <input type="text" name="end_date" class="form-control datepicker" placeholder="End Date" value="{{ request_display('end_date') }}" /></div>
                        </div>
                        <div class="col-md-4">
                            <label class="form-label"></label>
                            <button type="submit" class="btn btn-primary waves-effect waves-float waves-light">Search</button>
                        </div>
                    </div>
                </div>
                <hr class="my-0">
                <div class="card-datatable">
                    <?php echo parPageRecordDropDown() ?>
                    @if(!$doctorAppointmentBookings->isEmpty())
                    @php $start = $doctorAppointmentBookings->firstItem(); @endphp
                    <div class="table-responsive">
                        <table class="table table-bordered table-hover">
                            <thead>
                                <tr role="row">
                                    <th><?php echo sort_field_display('order_id', 'Order ID'); ?></th>
                                    <th>Hospital</th>
                                    <th>Doctor</th>
                                    <th>Patient</th>
                                    <th><?php echo sort_field_display('appointment_date', 'Date Time'); ?></th>
                                    <th><?php echo sort_field_display('amount', 'Amount'); ?></th>
                                    <!--<th><?php echo sort_field_display('discount', 'Discount'); ?></th>-->
                                    <th><?php echo sort_field_display('Status', 'Status'); ?></th>
                                    <th>Actions</th>
                                </tr>
                            </thead>
                            <tbody>
                                @foreach($doctorAppointmentBookings as $doctorAppointmentBooking)
                                <tr class="f-12">
                                    <td valign="top">{{ $doctorAppointmentBooking->order_id  }}</td>
                                    <td valign="top">{{ $doctorAppointmentBooking->hospital->name}}
                                        <br><span class="f-11">({{$doctorAppointmentBooking->hospital->area}})</span></td>
                                    <td valign="top">
                                        {{ $doctorAppointmentBooking->doctor->first_name.' '.$doctorAppointmentBooking->doctor->last_name  }}
                                        <br><span class="f-11">{{$doctorAppointmentBooking->doctor->phone}}</span>
                                    </td>
                                    <td valign="top">
                                        {{ $doctorAppointmentBooking->patient_name  }} <br/>
                                        <span class="f-11">{{ $doctorAppointmentBooking->patient_mobile}}</span>
                                    </td>
                                    <td valign="top">{{ date("d/m/Y",strtotime($doctorAppointmentBooking->appointment_date))  }}
                                        <br>{{ date("H:i",strtotime($doctorAppointmentBooking->appointment_time))  }}</td>
                                    <td valign="top">{{ $doctorAppointmentBooking->amount  }}</td>
                                    <!--<td valign="top">{{ $doctorAppointmentBooking->discount  }}</td>-->
                                    <td valign="top">{{ $doctorAppointmentBooking->status->name  }}</td>
                                    <td>
                                        <div class="dropdown">
                                            <button type="button" class="btn btn-sm dropdown-toggle hide-arrow py-0" data-bs-toggle="dropdown">
                                                <i data-feather="more-vertical"></i>
                                            </button>
                                            <div class="dropdown-menu dropdown-menu-end">
                                                <a class="dropdown-item" href="{{  route('admin.doctor_appointment_booking.view', ['id'=>$doctorAppointmentBooking->id] )  }}">
                                                    <i data-feather="file-text" class="me-50"></i>
                                                    <span>View</span>
                                                </a>
                                            </div>
                                        </div>
                                    </td>
                                </tr>
                                @endforeach
                            </tbody>
                        </table>
                    </div>
                    @endif
                    <?php echo pagination($doctorAppointmentBookings) ?>
                </div>
            </div>
        </div>
    </form>
</div>
