<div class="row">
    <form class="" method="POST" action="{{ route('admin.subscription_based_service.branch') }}" id="search_form"
        onsubmit="return false">
        {{ csrf_field() }}
        <div class="col-12">
            <div class="card">
                <div class="card-header border-bottom">
                    <h4 class="card-title">{{ $subscriptionBasedService->name }} : Branch List</h4>
                    <div
                        class="dt-action-buttons d-flex align-items-center justify-content-center justify-content-lg-end flex-lg-nowrap flex-wrap">
                        <div class="dt-buttons d-inline-flex">
                            <a class="dt-button add-new btn btn-primary"
                                href="{{ route('admin.subscription_based_service.add', ['subscription_based_service_id' => $subscriptionBasedService->id]) }}">{{ __('Add New Branch') }}</a>
                            <a style="margin-left: 15px;" href="{{ route('admin.subscription_based_service') }}"
                                class="btn btn-outline-secondary waves-effect">Back</a>

                        </div>
                    </div>
                </div>
                <!--Search Form -->
                <div class="card-body mt-2">
                    <input type="hidden" name="page" id="page"
                        value="{{ empty(app('request')->input('page')) ? 1 : app('request')->input('page') }}">
                    <input type="hidden" name="subscription_based_service_id"
                        value="{{ $subscriptionBasedService->id }}">
                    <div class="row g-1 mb-md-1">
                        <div class="col-md-2">
                            <label class="form-label">Phone</label>
                            <input type="text" class="form-control dt-input" placeholder="Phone No" name="phone"
                                value="{{ app('request')->input('phone') }}">
                        </div>
                        <div class="col-md-2">
                            <label class="form-label">Pincode</label>
                            <input type="text" class="form-control dt-input" placeholder="Pincode" name="pincode"
                                value="{{ app('request')->input('pincode') }}">
                        </div>
                        <div class="col-md-3">
                            <label class="form-label">State</label>
                            <select name="state_id" id="state_id" class="select2 form-select">
                                <option value="">All</option>
                                <?php
                                $set_values = request_display('state_id');
                                foreach ($states as $state):
                                    ?>
                                <option value="{{ $state->id }}" <?= $state->id == $set_values ? 'selected' : '' ?>>
                                    {{ $state->name }}</option><?php
                                endforeach;
                                ?>
                            </select>
                        </div>
                        <div class="col-md-3">
                            <label class="form-label">City</label>
                            <select name="city_id" id="city_id" class="select2 form-select">
                                <option value="">All</option>
                                <?php
                                $set_values = request_display("city_id");
                                foreach ($cities as $city):
                                    ?>
                                <option value="{{ $city->id }}" {{ $city->id == $set_values ? 'selected' : '' }}>
                                    {{ $city->name }}</option><?php
                                endforeach;
                                ?>
                            </select>
                        </div>
                        <div class="col-md-2">
                            <label class="form-label"></label>
                            <button type="submit"
                                class="btn btn-primary mt-2 waves-effect waves-float waves-light">Search</button>
                        </div>
                    </div>
                </div>
                <hr class="my-0">
                <div class="card-datatable">
                    <?php echo parPageRecordDropDown(); ?>
                    @if (!$subscriptionBasedServiceBranch->isEmpty())
                        @php $start = $subscriptionBasedServiceBranch->firstItem(); @endphp
                        <div class="table-responsive">

                            <table class="table table-bordered table-hover">
                                <thead>
                                    <tr role="row">
                                        <th></th>
                                        <th><?php echo sort_field_display('name', 'Name'); ?></th>
                                        <th>Phone</th>
                                        <th><?php echo sort_field_display('Area', 'Area'); ?></th>
                                        <th><?php echo sort_field_display('Pincode', 'Pincode'); ?></th>
                                        <th>City</th>
                                        <th>State</th>
                                        <th>Actions</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    @foreach ($subscriptionBasedServiceBranch as $data)
                                        <tr>
                                            <td><?= $start++ ?></td>
                                            <td valign="top">{{ $data->name }}</td>
                                            <td valign="top">{{ $data->phone }}</td>
                                            <td valign="top">{{ $data->area }}</td>
                                            <td valign="top">{{ $data->pincode }}</td>
                                            <td valign="top">{{ $data->city->name }}</td>
                                            <td valign="top">{{ $data->state->name }}</td>
                                            <td>
                                                <div class="text-nowrap">
                                                    <a title="Subscription Based Service Details"
                                                        href="{{ route('admin.subscription_based_service.view', ['id' => $data->id]) }}">
                                                        <i data-feather="file-text" class="me-50 text-dark"></i>
                                                    </a>
                                                    <a title="Subscription Based Service Location"
                                                        href="{{ route('admin.subscription_based_service.location', ['id' => $data->id]) }}">
                                                        <i data-feather="map-pin" class="me-50 text-dark"></i>
                                                    </a>
                                                    <a title="Delete Subscription Based Service"
                                                        href="{{ route('admin.subscription_based_service.edit', ['id' => $data->id]) }}">
                                                        <i data-feather="edit" class="me-50 text-dark"></i>
                                                    </a>
                                                    <a title="Subscription Based Service Facility"
                                                        href="{{ route('admin.subscription_based_service.facility', ['subscription_based_service_id' => $data->id]) }}">
                                                        <i data-feather="package" class="me-50 text-dark"></i>
                                                    </a>
                                                    <a title="Subscription Based Service Delete"
                                                        data-subscription-based-service-name="{{ $data->name }}"
                                                        data-subscription-based-service-id="{{ $data->id }}"
                                                        data-action="delete">
                                                        <i data-feather="trash-2" class="me-50 text-danger"></i>
                                                    </a>
                                                </div>
                                            </td>
                                        </tr>
                                    @endforeach
                                </tbody>
                            </table>
                        </div>
                    @endif
                    <?php echo pagination($subscriptionBasedServiceBranch); ?>
                </div>
            </div>
        </div>
    </form>
</div>
@section('script')
    <script type="text/javascript">
        $(document).on("click", "a[data-action='delete']", function() {
             var name = $(this).attr("data-subscription-based-service-name");
            var id = $(this).attr("data-subscription-based-service-id");
            var $this = $(this);
            confirmationAlertPopup(("Do you want to delete " + name), "Yes, delete it !",
                function(result) {
                    if (result.isConfirmed) {
                        var param = new Object();
                        param["subscription_based_service_id"] = id;
                        //console.log(param);
                        if (APP.BlockConcurrentReq(2000)) {
                            return;
                        }
                        loadingOverlay("body", "show");
                        jqueryAjax("{{ route('admin.subscription_based_service.delete') }}", param,
                            function(
                                res) {
                                loadingOverlay("body", "hide");
                                if (res.code != 200) {
                                    Notification.show({
                                        type: "error",
                                        msg: res.message,
                                        timeout: 3000
                                    });
                                    return;
                                }
                                Notification.show({
                                    type: "success",
                                    msg: res.message,
                                    timeout: 3000
                                });
                                var $closestTr = $this.closest("tr");
                                $closestTr.hide();
                                $closestTr.next().remove();
                            }, "", "json");
                        resultAlertPopup("Deleted!", "Service " + name +
                            " has been deleted.",
                            "success");
                    }
                });

        });
    </script>
@endsection
