@extends("backend.layouts.master")
@section('title') Facility Edit @endsection
@section('content')
<script type="text/javascript" src="{{ Helper::static_asset('admin-assets/js/module/common.js') }}"></script>
<script type="text/javascript" src="{{ Helper::static_asset('admin-assets/js/module/subscription-base-service.js') }}"></script>
<script type="text/javascript">$(document).ready(initFacilityMaster);</script>
<!-- BEGIN: Content-->
<div class="app-content content ">

    <div class="content-wrapper p-0">

        <div class="content-body">

            <div class="card" data-select2-id="14">
                <div class="card-header border-bottom">
                    <h4 class="card-title">Edit Facility Details</h4>
                </div>
                <div class="card-body py-2 my-25" data-select2-id="53">
                    <!-- header section -->

                    <!-- form -->
                    @include('backend.message')

                    <form class="needs-validation" method="POST" action="{{route('admin.subscription_based_service.facility.update', $facility->id)}}" method="POST" enctype="multipart/form-data" novalidate>
                        {{ csrf_field() }}


                        <section class="modern-horizontal-wizard">

                            <div class="bs-stepper wizard-modern modern-wizard-example">

                                <div class="bs-stepper-header">
                                    <div class="step" data-target="#account-details-modern" role="tab"
                                         id="facility-details-modern-trigger">
                                        <button type="button" class="step-trigger">
                                            <span class="bs-stepper-box">
                                                <i data-feather="user" class="font-medium-3"></i>
                                            </span>
                                            <span class="bs-stepper-label">
                                                <span class="bs-stepper-title">Facility Details</span>
                                            </span>
                                        </button>
                                    </div>


                                    <div class="line">
                                        <i data-feather="chevron-right" class="font-medium-2"></i>
                                    </div>
                                    <div class="step" data-target="#facility-details-info" role="tab"
                                         id="facility-details-info-trigger">
                                        <button type="button" class="step-trigger">
                                            <span class="bs-stepper-box">
                                                <i data-feather="file-text" class="font-medium-3"></i>
                                            </span>
                                            <span class="bs-stepper-label">
                                                <span class="bs-stepper-title">Additional Details</span>
                                            </span>
                                        </button>
                                    </div>
                                </div>

                                <div class="bs-stepper-content">
                                    <div id="account-details-modern" class="content" role="tabpanel" aria-labelledby="facility-details-modern-trigger">
                                        <div class="content-header">
                                            <h5 class="mb-0"><?= ('Facility Details') ?></h5>
                                        </div>
                                        <input type="hidden" name="subscription_based_service_id" value="{{!empty($facility->subscriptionBasedService->id)?$facility->subscriptionBasedService->id:0}}">
                                        <input type="hidden" name="subscription_based_service_parent_id" value="{{!empty($facility->subscriptionBasedService->parent_id)?$facility->subscriptionBasedService->parent_id:0}}">
                                        <input type="hidden" name="flag" value="SBS">
                                        <div class="row">
                                            <div class="mb-1 col-md-4">
                                                <label class="form-label" for="name"><?= _('Name*') ?></label>
                                                <input type="text" name="name" id="name" class="form-control" placeholder="<?= _('Facility Name') ?>" value="<?= post_display('name', $facility->name) ?>" required/>
                                            </div>
                                            <div class="mb-1 col-md-4">
                                                <?php
                                                $genderArr = explode(',', $facility->gender);
                                                $male = $female = $other = "";
                                                foreach ($genderArr as $value) {
                                                    if ($value == 'Male') {
                                                        $male = ' selected="selected" ';
                                                    }
                                                    if ($value == 'Female') {
                                                        $female = ' selected="selected" ';
                                                    }
                                                    if ($value == 'Unisex') {
                                                        $other = ' selected="selected" ';
                                                    }
                                                }
                                                ?>
                                                <label class="form-label" for="gender"><?= _('Gender') ?></label>
                                                <select name="gender" class="form-select select2" id="gender">
                                                    <option value="Male" <?php echo $male; ?>>Male</option>
                                                    <option value="Female" <?php echo $female; ?>>Female</option>
                                                    <option value="Unisex" <?php echo $other; ?>>Unisex</option>
                                                </select>
                                            </div>
                                            <div class="mb-1 col-md-4">
                                                <label class="form-label">Status</label>
                                                <select name="status_id" id="status_id" class="select2 form-select" required>
                                                    <option value="1" {{ $facility->status_id=='1' ? "selected" : ''  }}>Active</option>
                                                    <option value="2" {{ $facility->status_id=='2' ? "selected" : ''  }}>Inactive</option>
                                                </select>
                                            </div>
                                        </div>
                                        <div class="row">
                                            <div class="mb-1 col-md-4">
                                                <label class="form-label" for="description">Description</label>
                                                <textarea name="description" id="" cols="30" rows="4" class="form-control"><?= post_display('description', $facility->description) ?></textarea>
                                            </div>
                                            <div class="mb-1 col-md-4">
                                                <label class="form-label" for="result">Result</label>
                                                <textarea name="result" id="" cols="30" rows="4" class="form-control"><?= post_display('description', $facility->result) ?></textarea>
                                            </div>
                                            <div class="mb-1 col-md-4">
                                                <label class="form-label" for="note">Note</label>
                                                <textarea name="note" id="" cols="30" rows="4" class="form-control"><?= post_display('description', $facility->note) ?></textarea>
                                            </div>
                                        </div>
                                        <div class="row">
                                            <div class="mb-1 col-md-4">
                                                <label class="form-label" for="discount"><?= _('Discount(%)') ?></label>
                                                <input type="number" name="discount" id="discount" class="form-control" value="<?= post_display('discount', $facility->discount) ?>" />
                                            </div>
                                            <div class="mb-1 col-md-4">
                                                <label class="form-label" for="price"><?= _('Price(Rs)*') ?></label>
                                                <input type="number" name="price" id="price" class="form-control" placeholder="<?= _('Price') ?>" value="<?= post_display('price', $facility->price) ?>"   required/>
                                            </div>
                                            <div class="mb-1 col-md-4">
                                                <label class="form-label" for="days"><?= _('Days*') ?></label>
                                                <input type="text" name="days" id="days" class="form-control" placeholder="<?= _('Days') ?>"  value="<?= post_display('days', $facility->days) ?>"  required/>
                                            </div>
                                        </div>
                                        <div class="row">
                                            <div class="mb-1 col-md-4">
                                                <label class="form-label" for="calories_burn"><?= _('Calories Burn') ?></label>
                                                <input type="text" name="calories_burn" id="calories_burn" class="form-control" placeholder="<?= _('Calories Burn') ?>" value="<?= post_display('calories_burn', $facility->calories_burn) ?>" />
                                            </div>
                                            <div class="mb-1 col-md-8">
                                                <label class="form-label" for="sub_category_ids"><?= _('Sub Category') ?></label>
                                                <select name="sub_category_ids[]" class="form-select select2" id="sub_category_ids" multiple>
                                                    <?php $subCategoryIdArr = explode(',', $facility->sub_category_ids); ?>
                                                    @foreach ($subCategory as $row)
                                                    <option value="{{ $row['id']  }}" <?php echo in_array($row['id'], $subCategoryIdArr)?' selected="selected" ':'';?>>{{ $row['name']  }}</option>
                                                    @endforeach
                                                </select>
                                            </div>
                                        </div>
                                        <?php if (!empty($facility->subscriptionBasedService)) { ?>
                                            <div class="row">
                                                <div class="mb-1 col-md-12 mt-1 b-b-10">
                                                    <span class="fw-bolder me-25">Subscription Based Service Details</span>
                                                </div>
                                            </div>
                                            <div class="row">
                                                <div class="mb-1 col-md-3 mt-1">
                                                    <span><?= _('Subscription Based Service Name') ?></span>
                                                    <br>
                                                    <span class="fw-bolder me-25">{{ $facility->subscriptionBasedService->name }}</span>
                                                </div>
                                                <div class="mb-1 col-md-3 mt-1">
                                                    <span><?= _('Contact Person') ?></span>
                                                    <br>
                                                    <span class="fw-bolder me-25">{{ $facility->subscriptionBasedService->contact_person? $facility->subscriptionBasedService->contact_person:'-' }}</span>
                                                </div>
                                                <div class="mb-1 col-md-3 mt-1">
                                                    <span><?= _('Phone') ?></span>
                                                    <br>
                                                    <span class="fw-bolder me-25">{{ $facility->subscriptionBasedService->phone?$facility->subscriptionBasedService->phone:'-' }}</span>
                                                </div>
                                                <div class="mb-1 col-md-3 mt-1">
                                                    <span><?= _('Mobile') ?></span>
                                                    <br>
                                                    <span class="fw-bolder me-25">{{ $facility->subscriptionBasedService->mobile? $facility->subscriptionBasedService->mobile:'-' }}</span>
                                                </div>
                                                <div class="mb-1 col-md-12 mt-1">
                                                    <span><?= _('Subscription Based Service Address') ?></span>
                                                    <br>
                                                    <span class="fw-bolder me-25">
                                                        {{ $facility->subscriptionBasedService->address1 }}, {{ $facility->subscriptionBasedService->address2 }}, {{ $facility->subscriptionBasedService->area }}
                                                        , {{ $facility->subscriptionBasedService->city->name }}, {{ $facility->subscriptionBasedService->state->name }}-, {{ $facility->subscriptionBasedService->pincode }}
                                                    </span>
                                                </div>
                                                <?php if ($facility->subscriptionBasedService->parent) { ?>
                                                    <div class="mb-1 col-md-12 mt-1">
                                                        <span><?= _('Note') ?></span>
                                                        <br>
                                                        <span class="fw-bolder me-25">This service is working under the {{ $facility->subscriptionBasedService->parent->name}}</span>
                                                    </div>
                                                <?php } ?>
                                            </div>
                                        <?php } ?>
                                    </div>
                                    <div id="facility-details-info" class="content" role="tabpanel" aria-labelledby="facility-details-modern-trigger">
                                        <div class="row">
                                            <div class="mb-1 col-md-9">
                                                <label class="form-label">More Details</label>
                                                <input data-id="title" type="text" placeholder="Facility title" value="" class="form-control"/>
                                            </div>
                                            <div class="mb-1 col-md-3">
                                                <input type="hidden" name="facility_desc_json" value="{{$facility->facility_desc_json}}" data-id="desc-json" />
                                                <a data-id="btn-add" class="btn btn-primary mt-2 me-1 waves-effect waves-float waves-light">Add</a>
                                            </div>
                                            <div class="mb-1 col-md-12">
                                                <ul class="list-group" data-id="data-list">
                                                </ul>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </section>
                        <div class="row" data-select2-id="12">
                            <div class="col-12">
                                <button type="submit" class="btn btn-primary me-1 waves-effect waves-float waves-light">Save changes</button>
                                <?php if ($flag == 'SBS') { ?>
                                    <a href="{{route('admin.subscription_based_service.facility', ['subscription_based_service_id'=>$facility->subscription_based_service_id])}}" class="btn btn-outline-secondary waves-effect">Back</a>
                                <?php } else { ?>
                                    <a href="{{route('admin.subscription_based_service.facility')}}" class="btn btn-outline-secondary waves-effect">Back</a>
                                <?php } ?>
                            </div>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>
</div>
@endsection

