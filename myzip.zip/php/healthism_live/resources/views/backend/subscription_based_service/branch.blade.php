@extends("backend.layouts.master")
@section('title') Subscription Based Service Branch List @endsection
@section('content')

    <!-- BEGIN: Content-->
    <div class="app-content content ">

        <div class="content-wrapper p-0">

            <div class="content-body" id="ajax_content">
                @include('backend.message')
                @include("backend.subscription_based_service.branch_content")
            </div>


        </div>
    </div>
@endsection
