@extends("backend.layouts.master")
@section('title') Lab Add @endsection
@section('content')

<link rel="stylesheet" type="text/css" href="{{ Helper::static_asset('admin-assets/vendors/css/pickers/pickadate/pickadate.css') }}">

<script src="{{ Helper::static_asset('admin-assets/vendors/js/pickers/pickadate/picker.js') }}"></script>
<script src="{{ Helper::static_asset('admin-assets/vendors/js/pickers/pickadate/picker.date.js') }}"></script>
<script src="{{ Helper::static_asset('admin-assets/vendors/js/pickers/pickadate/picker.time.js') }}"></script>
<script src="{{ Helper::static_asset('admin-assets/vendors/js/extensions/moment.min.js') }}"></script>
<script type="text/javascript" src="{{ Helper::static_asset('admin-assets/js/module/common.js') }}"></script>
<script type="text/javascript" src="{{ Helper::static_asset('admin-assets/js/module/lab.js') }}?1"></script>
<script type="text/javascript">$(document).ready(initAddLab);</script>

<!-- BEGIN: Content-->
<div class="app-content content ">
    <div class="content-wrapper p-0">
        <div class="content-body">
            <div class="card" data-select2-id="14">
                <div class="card-header border-bottom">

                    <h4 class="card-title">
                        <?php
                        $hideClass = "";
                        if (empty($parent_lab)) {
                            echo 'Add New Lab Details';
                            $type = LAB;
                        } else {
                            $hideClass = "d-none";
                            echo $parent_lab->name . ': Add Branch';
                            $type = LAB_BRANCH;
                        }
                        ?>
                    </h4>
                </div>
                <div class="card-body py-2 my-25" data-select2-id="53">
                    <!-- header section -->
                    <!-- form -->
                    @include('backend.message')
                    <form class="needs-validation" method="POST" action="{{route('admin.lab.store')}}" enctype="multipart/form-data" novalidate>
                        {{ csrf_field() }}
                        <section class="modern-horizontal-wizard">
                            <div class="bs-stepper wizard-modern modern-wizard-example">
                                <div class="bs-stepper-header">
                                    <div class="step" data-target="#account-details-modern" role="tab" id="service-details-modern-trigger">
                                        <button type="button" class="step-trigger">
                                            <span class="bs-stepper-box"><i data-feather="user" class="font-medium-3"></i></span>
                                            <span class="bs-stepper-label"><span class="bs-stepper-title">Lab Details</span></span>
                                        </button>
                                    </div>
                                    <div class="line">
                                        <i data-feather="chevron-right" class="font-medium-2"></i>
                                    </div>
                                    <div class="step" data-target="#service-details-info1" role="tab" id="service-details-info-trigger">
                                        <button type="button" class="step-trigger">
                                            <span class="bs-stepper-box"><i data-feather="file-text" class="font-medium-3"></i></span>
                                            <span class="bs-stepper-label"><span class="bs-stepper-title">Lab Documents</span></span>
                                        </button>
                                    </div>
                                    <div class="line">
                                        <i data-feather="chevron-right" class="font-medium-2"></i>
                                    </div>
                                    <div class="step" data-target="#lab-details-info2" role="tab" id="service-details-info-trigger">
                                        <button type="button" class="step-trigger">
                                            <span class="bs-stepper-box"><i data-feather="file-text" class="font-medium-3"></i></span>
                                            <span class="bs-stepper-label"><span class="bs-stepper-title">Lab Policy & Timing</span></span>
                                        </button>
                                    </div>
                                </div>

                                <div class="bs-stepper-content">
                                    <div id="account-details-modern" class="content" role="tabpanel" aria-labelledby="service-details-modern-trigger">
                                        <div class="content-header">
                                            <h5 class="mb-0"><?= ('Lab Details') ?></h5>
                                        </div>
                                        <div class="row">
                                            <input type="hidden" name="parent_id" value="{{!empty($parent_lab->id)?$parent_lab->id:0}}">

                                            <div class="mb-1 col-md-8">
                                                <label class="form-label" for="user_id"><?= _('User') ?></label>
                                                <input type="text" name="user" id="user_search" class="form-control" placeholder="<?= _('Select User') ?>"
                                                       value=""/>
                                                <input type="hidden" id="user_id" name="user_id" value="">
                                            </div>
                                            <div class="mb-1 col-md-4">
                                                <label class="form-label" for="contact_person"><?= _('Contact Person*') ?></label>
                                                <input type="text" name="contact_person" id="contact_person" class="form-control" placeholder="<?= _('Contact Person') ?>" value="<?= post_display('Contact Person') ?>" required/>
                                            </div>
                                        </div>
                                        <div class="row">
                                            <div class="mb-1 col-md-4">
                                                <label class="form-label" for="name"><?= _('Name*') ?></label>
                                                <input type="text" name="name" id="name" class="form-control" placeholder="<?= _('Lab Name') ?>" value="<?= post_display('name') ?>" required/>
                                            </div>
                                            <div class="mb-1 col-md-4">
                                                <label class="form-label" for="phone"><?= _('Phone') ?></label>
                                                <input type="text" name="phone" class="form-control"  placeholder="<?= _('phone') ?>" value="<?= post_display('phone') ?>" />
                                            </div>
                                            <div class="mb-1 col-md-4">
                                                <label class="form-label" for="mobile"><?= _('Mobile*') ?></label>
                                                <input type="text" name="mobile" class="form-control" pattern="[6789][0-9]{9}" maxlength="10" placeholder="<?= _('Mobile') ?>" value="<?= post_display('mobile') ?>" required/>
                                            </div>

                                        </div>
                                        <div class="row">
                                            <div class="mb-1 col-md-4">
                                                <label class="form-label" for="email"><?= _('Email') ?></label>
                                                <input type="email" name="email" class="form-control" placeholder="<?= _('Email') ?>" value="<?= post_display('email') ?>" />
                                            </div>
                                             <div class="mb-1 col-md-4">
                                                <label class="form-label" for="discount"><?= _('Discount(%)') ?></label>
                                                <input type="number" name="discount" id="discount" <?php echo $type == LAB_BRANCH ? 'disabled' : '' ?> class="form-control" placeholder="<?= _('Discount') ?>"  value="{{!empty($parent_lab->discount)?$parent_lab->discount:''}}"/>
                                            </div>
                                            <div class="mb-1 col-md-4">
                                                <label class="form-check-label mb-50" for="status"><?= __('Status') ?></label>
                                                <select name="status_id" class="form-select select2" required>
                                                    <?php $set_values = post_display('type'); ?>
                                                    @foreach(hospital_status as $key=>$val)
                                                    <option class="dropdown-item" value="<?= $key ?>" <?= $key == $set_values ? 'selected' : '' ?>><?= $val ?></option>
                                                    @endforeach
                                                </select>
                                            </div>

                                        </div>
                                        <div class="row">
                                            <div class="mb-1 col-md-4">
                                                <label class="form-check-label mb-50" for="virtual_location"><?= __('Virtual Location') ?></label>
                                                <div class="form-check form-check-success form-switch">
                                                    <input type="checkbox" name="virtual_location" class="form-check-input"  />
                                                </div>
                                            </div>
                                            <div class="mb-1 col-md-4">
                                                <label class="form-label" for="address1">Address Line 1*</label>
                                                <textarea name="address1" id="" cols="20" rows="2" class="form-control" required></textarea>
                                            </div>
                                            <div class="mb-1 col-md-4">
                                                <label class="form-label" for="address2">Address Line 2*</label>
                                                <textarea name="address2" cols="20" rows="2" class="form-control" required></textarea>
                                            </div>

                                        </div>
                                        <div class="row">
                                            <div class="mb-1 col-md-4">
                                                <label class="form-label" for="area"><?= _('Area*') ?></label>
                                                <input type="text" name="area" class="form-control" placeholder="<?= _('Area') ?>" value="<?= post_display('area') ?>" required />
                                            </div>
                                            <div class="mb-1 col-md-4">
                                                <label class="form-label" for="pincode"><?= _('Pincode*') ?></label>
                                                <input type="text" pattern="[0-9]{6}"  maxlength="6" name="pincode" class="form-control" placeholder="<?= _('Pincode') ?>" value="<?= post_display('pincode') ?>" required/>
                                            </div>
                                            <div class="mb-1 col-md-4">
                                                <label class="form-label" for="state">State*</label>
                                                <select name="state_id" id="state_id" class="select2 form-select" required>
                                                    <option value="">Select State</option>
                                                    <?php foreach ($states as $state): ?>
                                                        <option value="{{ $state->id }}">{{$state->name}}</option><?php
                                                    endforeach;
                                                    ?>
                                                </select>
                                            </div>
                                        </div>
                                        <div class="row">
                                            <div class="mb-1 col-md-4">
                                                <label for="language" class="form-label">City*</label>
                                                <select name="city_id" id="city_id" class="select2 form-select" required>
                                                    <option value="">Select City</option>
                                                </select>
                                            </div>
                                            <div class="mb-1 col-md-4">
                                                <label class="form-label" for="latitude"><?= _('Latitude*') ?></label>
                                                <input type="text" name="latitude" id="latitude" data-v-message="Invalid latitude" maxlength="12" pattern="^(\+|-)?(?:90(?:(?:\.0{1,9})?)|(?:[0-9]|[1-8][0-9])(?:(?:\.[0-9]{1,9})?))$" class="form-control" placeholder="<?= _('Latitude') ?>" value="<?= post_display('latitude') ?>" required/>
                                                <span id='latitude-error' class="error"></span>
                                            </div>
                                            <div class="mb-1 col-md-4">
                                                <label class="form-label" for="longitude"><?= _('Longitude*') ?></label>
                                                <input type="text" name="longitude" id="longitude" maxlength="12" data-v-message="Invalid longitude" pattern="^(\+|-)?(?:180(?:(?:\.0{1,9})?)|(?:[0-9]|[1-9][0-9]|1[0-7][0-9])(?:(?:\.[0-9]{1,9})?))$" class="form-control" placeholder="<?= _('Longitude') ?>" value="<?= post_display('longitude') ?>" required/>
                                                <span id='longitude-error' class="error"></span>
                                            </div>
                                        </div>
                                        <div class="row">
                                            <div class="mb-1 mt-1 col-md-8">
                                                <label class="form-label" for="description"><?= _('Description*') ?></label>
                                                <textarea name="description" class="form-control" cols="5" rows="5" required></textarea>
                                            </div>
                                            <div class="mb-1 col-md-4">
                                                <label class="form-label" for="registration_council"><?= _('Upload Profile Pic') ?></label>
                                                <div data-provides="fileupload" class="fileupload fileupload-new p-t-10">
                                                    <div style="width: 120px; height: 120px;" class="fileupload-new thumbnail">
                                                        <?php $src = '/admin-assets/images/icons/file-icons/no_document.png'; ?>
                                                        <img alt="" src="<?php echo $src; ?>">
                                                    </div>
                                                    <div style="max-width: 120px; max-height: 120px; line-height: 20px;" class="fileupload-preview fileupload-exists thumbnail"></div>
                                                    <div>
                                                        <span class="btn btn-file" style="padding: 10px 0px 0px 0px;">
                                                            <span class="btn btn-primary fileupload-new">Select image</span>
                                                            <span class="btn btn-primary fileupload-exists">Change</span>
                                                            <input data-file-profile="true" type="file" accept="image/*" name="photo">
                                                        </span>
                                                        <a href="javascript:void(0)" class="btn btn-outline-secondary mt-1 waves-effect" data-remove-profile="true">Remove</a>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    </div>

                                    <div id="service-details-info1" class="content" role="tabpanel" aria-labelledby="service-details-modern-trigger">
                                        <div class="row">
                                            <div class="col-12">
                                                <label class="form-label" for="images_list"><?= _('Lab Gallery Images') ?></label>
                                                <div class="dropzone-area dropzone" id="id_dropzone" style="border-radius: 10px;">
                                                    <input type="file" name="gallery_images[]" style="display: none">
                                                </div>
                                                <select name="images_list[]" id="images_list" multiple style="display: none"></select>
                                            </div>
                                        </div>


                                        <div class="row m-t-10 <?php echo $hideClass; ?>">
                                            <div class="col-md-6 mb-1">
                                                <label class="form-label" for="pancard_number"><?= _('PAN No') ?></label>
                                                <input type="text" name="pancard_number" class="form-control" placeholder="<?= _('PAN No') ?>" value="<?= post_display('pancard_number') ?>" />
                                            </div>
                                            <div class="col-md-6 mb-1">
                                                <label class="form-label" for="gst_number"><?= _('GST No') ?></label>
                                                <input type="text" name="gst_number" class="form-control" placeholder="<?= _('GST No') ?>" value="<?= post_display('gst_number') ?>" />
                                            </div>
                                        </div>

                                        <div class="row <?php echo $hideClass; ?>">
                                            <div class="col-md-6">
                                                <label class="form-label" for="pan_card_document"><?= _('PAN Card Document') ?></label>
                                                <div data-provides="fileupload" class="fileupload fileupload-new p-t-10">
                                                    <div style="width: 120px; height: 120px;" class="fileupload-new thumbnail">
                                                        <?php $src = '/admin-assets/images/icons/file-icons/no_document.png'; ?>
                                                        <img alt="" src="<?php echo $src; ?>">
                                                    </div>
                                                    <div style="max-width: 120px; max-height: 120px; line-height: 20px;" class="fileupload-preview fileupload-exists thumbnail"></div>
                                                    <div>
                                                        <span class="btn btn-file" style="padding: 10px 0px 0px 0px;">
                                                            <span class="btn btn-primary fileupload-new">Select document</span>
                                                            <span class="btn btn-primary fileupload-exists">Change</span>
                                                            <input type="file" name="pancard_document">
                                                        </span>
                                                    </div>
                                                </div>
                                            </div>
                                            <div class="col-md-6">
                                                <label class="form-label" for="gst_certificate"><?= _('GST Certificate') ?></label>
                                                <div data-provides="fileupload" class="fileupload fileupload-new p-t-10">
                                                    <div style="width: 120px; height: 120px;" class="fileupload-new thumbnail">
                                                        <?php $src = '/admin-assets/images/icons/file-icons/no_document.png'; ?>
                                                        <img alt="" src="<?php echo $src; ?>">
                                                    </div>
                                                    <div style="max-width: 120px; max-height: 120px; line-height: 20px;" class="fileupload-preview fileupload-exists thumbnail"></div>
                                                    <div>
                                                        <span class="btn btn-file" style="padding: 10px 0px 0px 0px;">
                                                            <span class="btn btn-primary fileupload-new">Select document</span>
                                                            <span class="btn btn-primary fileupload-exists">Change</span>
                                                            <input type="file" name="gst_certificate" />
                                                        </span>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>

                                        <div class="row <?php echo $hideClass; ?>">
                                            <div class="mb-1 col-md-6">
                                                <label class="form-label" for="bank_account_number"><?= _('Bank Account Number') ?></label>
                                                <input type="number" name="bank_account_number" class="form-control" placeholder="<?= _('Bank Account Number') ?>" value="<?= post_display('bank_account_number') ?>" />
                                            </div>
                                            <div class="mb-1 col-md-6">
                                                <label class="form-label" for="bank_account_name"><?= _('Bank Account Name') ?></label>
                                                <input type="text" name="bank_account_name" class="form-control" placeholder="<?= _('Bank Account Name') ?>" value="<?= post_display('bank_account_name') ?>" />
                                            </div>
                                        </div>

                                        <div class="row <?php echo $hideClass; ?>">
                                            <div class="mb-1 col-md-6">
                                                <label class="form-label" for="bank_name"><?= _('Bank Name') ?></label>
                                                <input type="text" name="bank_name" class="form-control" placeholder="<?= _('Bank Name') ?>" value="<?= post_display('bank_name') ?>" />
                                            </div>
                                            <div class="mb-1 col-md-6">
                                                <label class="form-label" for="bank_ifsc_code"><?= _('IFSC Code') ?></label>
                                                <input type="text" name="bank_ifsc_code" class="form-control" placeholder="<?= _('IFSC Code') ?>" value="<?= post_display('bank_ifsc_code') ?>" />
                                            </div>
                                        </div>
                                        <div class="row <?php echo $hideClass; ?>">
                                            <div class="col-md-6">
                                                <label class="form-label" for="nabl_document"><?= _('NABL Document') ?></label>
                                                <div data-provides="fileupload" class="fileupload fileupload-new p-t-10">
                                                    <div style="width: 120px; height: 120px;" class="fileupload-new thumbnail">
                                                        <?php $src = '/admin-assets/images/icons/file-icons/no_document.png'; ?>
                                                        <img alt="" src="<?php echo $src; ?>">
                                                    </div>
                                                    <div style="max-width: 120px; max-height: 120px; line-height: 20px;" class="fileupload-preview fileupload-exists thumbnail"></div>
                                                    <div>
                                                        <span class="btn btn-file" style="padding: 10px 0px 0px 0px;">
                                                            <span class="btn btn-primary fileupload-new">Select document</span>
                                                            <span class="btn btn-primary fileupload-exists">Change</span>
                                                            <input type="file" name="nabl_document">
                                                        </span>
                                                    </div>
                                                </div>
                                            </div>
                                            <div class="col-md-6">
                                                <label class="form-label" for="mou_document"><?= _('MOU Certificate') ?></label>
                                                <div data-provides="fileupload" class="fileupload fileupload-new p-t-10">
                                                    <div style="width: 120px; height: 120px;" class="fileupload-new thumbnail">
                                                        <?php $src = '/admin-assets/images/icons/file-icons/no_document.png'; ?>
                                                        <img alt="" src="<?php echo $src; ?>">
                                                    </div>
                                                    <div style="max-width: 120px; max-height: 120px; line-height: 20px;" class="fileupload-preview fileupload-exists thumbnail"></div>
                                                    <div>
                                                        <span class="btn btn-file" style="padding: 10px 0px 0px 0px;">
                                                            <span class="btn btn-primary fileupload-new">Select document</span>
                                                            <span class="btn btn-primary fileupload-exists">Change</span>
                                                            <input type="file" name="mou_document" />
                                                        </span>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    </div>

                                    <div id="lab-details-info2" class="content" role="tabpanel" aria-labelledby="service-details-modern-trigger">
                                        <div class="row">
                                            <div class="col-12"><div class="border-bottom"><b>Visit Time</b></div></div>
                                        </div>
                                        <div class="row">
                                            <div class="mt-1 mb-1 col-12"><div id="error-alert" class="error"></div></div>
                                            <div class="mb-1 col-md-12">
                                                <label class="form-label" for="days"><?= _('Days') ?></label>
                                                <select name="days[]" class="form-select select2" id="days" multiple>
                                                    @foreach($day_list as $row)
                                                    <option value="<?= $row ?>" ><?= $row ?></option>
                                                    @endforeach
                                                </select>
                                            </div>
                                            <div class="mb-1 col-md-3">
                                                <label class="form-label">Start Time</label>
                                                <input id="start_time" type="text" value="10:00 AM" class="form-control time-picker"/>
                                            </div>
                                            <div class="mb-1 col-md-3">
                                                <label class="form-label">End Time</label>
                                                <input id="end_time" type="text" value="01:00 PM" class="form-control time-picker"/>
                                            </div>
                                            <div class="mb-1 col-md-3">
                                                <input type="hidden" name="slot_data_obj" id="day-time"/>
                                                <a id="add-time" class="btn btn-primary mt-2 me-1 waves-effect waves-float waves-light">Add</a>
                                            </div>
                                            <div class="col-12"><h5 class="fw-bolder border-bottom pb-50 pt-50 mb-1">Slot Details</h5></div>
                                            <div id="time-data">
                                                <div class="row">
                                                    <div class="col-lg-3 col-md-4 col-sm-12">
                                                        <div class="faq-navigation d-flex justify-content-between flex-column mb-2 mb-md-0">
                                                            <ul class="nav nav-pills nav-left flex-column" role="tablist">
                                                                <li class="nav-item">
                                                                    <a class="nav-link active" data-key="Monday" data-bs-toggle="pill" href="#slot-monday" aria-expanded="true" role="tab" aria-selected="true">
                                                                        <span class="fw-bold">Monday</span>
                                                                    </a>
                                                                </li>
                                                                <li class="nav-item">
                                                                    <a class="nav-link" data-key="Tuesday" data-bs-toggle="pill" href="#slot-tuesday" aria-expanded="false" role="tab" aria-selected="false">
                                                                        <span class="fw-bold">Tuesday</span>
                                                                    </a>
                                                                </li>
                                                                <li class="nav-item">
                                                                    <a class="nav-link" data-key="Wednesday" data-bs-toggle="pill" href="#slot-wednesday" aria-expanded="false" role="tab" aria-selected="false">
                                                                        <span class="fw-bold">Wednesday</span>
                                                                    </a>
                                                                </li>
                                                                <li class="nav-item">
                                                                    <a class="nav-link" data-key="Thursday" data-bs-toggle="pill" href="#slot-thursday" aria-expanded="false" role="tab" aria-selected="false">
                                                                        <span class="fw-bold">Thursday</span>
                                                                    </a>
                                                                </li>
                                                                <li class="nav-item">
                                                                    <a class="nav-link" data-key="Friday" data-bs-toggle="pill" href="#slot-friday" aria-expanded="false" role="tab" aria-selected="false">
                                                                        <span class="fw-bold">Friday</span>
                                                                    </a>
                                                                </li>
                                                                <li class="nav-item">
                                                                    <a class="nav-link" data-key="Saturday" data-bs-toggle="pill" href="#slot-saturday" aria-expanded="false" role="tab" aria-selected="false">
                                                                        <span class="fw-bold">Saturday</span>
                                                                    </a>
                                                                </li>
                                                                <li class="nav-item">
                                                                    <a class="nav-link" data-key="Sunday"  data-bs-toggle="pill" href="#slot-sunday" aria-expanded="false" role="tab" aria-selected="false">
                                                                        <span class="fw-bold">Sunday</span>
                                                                    </a>
                                                                </li>
                                                            </ul>
                                                        </div>
                                                    </div>
                                                    <div class="col-lg-9 col-md-8 col-sm-12">
                                                        <!-- pill tabs tab content -->
                                                        <div class="tab-content">
                                                            <div role="tabpanel" data-tab="Monday" class="tab-pane active" id="slot-monday" aria-labelledby="slot-monday" aria-expanded="true">
                                                                <div class="table-responsive">
                                                                    <table class="table">
                                                                        <thead>
                                                                            <tr><th class="text-center" colspan="5">Monday Slot</th></tr>
                                                                            <tr><th>Start Time</th><th>End Time</th><th>Actions</th></tr>
                                                                        </thead>
                                                                        <tbody>
                                                                            <!-- <tr><td><span class="fw-bold">10:00 AM</span></td><td><span class="fw-bold">10:00 PM</span></td><td>Yes</td><td>No</td><td><a data-action="delete" class="badge rounded-pill badge-light-danger me-1" href="#">\<svg xmlns="http://www.w3.org/2000/svg" width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="feather feather-trash me-50"><polyline points="3 6 5 6 21 6"></polyline><path d="M19 6v14a2 2 0 0 1-2 2H7a2 2 0 0 1-2-2V6m3 0V4a2 2 0 0 1 2-2h4a2 2 0 0 1 2 2v2"></path></svg><span>Delete</span></a></td></tr>-->
                                                                        </tbody>
                                                                    </table>
                                                                </div>
                                                            </div>
                                                            <div class="tab-pane" data-tab="Tuesday" id="slot-tuesday" role="tabpanel" aria-labelledby="slot-tuesday" aria-expanded="false">
                                                                <div class="table-responsive">
                                                                    <table class="table">
                                                                        <thead>
                                                                            <tr><th class="text-center" colspan="5">Tuesday Slot</th></tr>
                                                                            <tr><th>Start Time</th><th>End Time</th><th>Actions</th></tr>
                                                                        </thead>
                                                                        <tbody></tbody>
                                                                    </table>
                                                                </div>
                                                            </div>
                                                            <div class="tab-pane" data-tab="Wednesday" id="slot-wednesday" role="tabpanel" aria-labelledby="slot-wednesday" aria-expanded="false">
                                                                <div class="table-responsive">
                                                                    <table class="table">
                                                                        <thead>
                                                                            <tr><th class="text-center" colspan="5">Wednesday Slot</th></tr>
                                                                            <tr><th>Start Time</th><th>End Time</th><th>Actions</th></tr>
                                                                        </thead>
                                                                        <tbody></tbody>
                                                                    </table>
                                                                </div>
                                                            </div>
                                                            <div class="tab-pane" data-tab="Thursday" id="slot-thursday" role="tabpanel" aria-labelledby="slot-thursday" aria-expanded="false">
                                                                <div class="table-responsive">
                                                                    <table class="table">
                                                                        <thead>
                                                                            <tr><th class="text-center" colspan="5">Thursday Slot</th></tr>
                                                                            <tr><th>Start Time</th><th>End Time</th><th>Actions</th></tr>
                                                                        </thead>
                                                                        <tbody></tbody>
                                                                    </table>
                                                                </div>
                                                            </div>
                                                            <div class="tab-pane" data-tab="Friday" id="slot-friday" role="tabpanel" aria-labelledby="slot-friday" aria-expanded="false">
                                                                <div class="table-responsive">
                                                                    <table class="table">
                                                                        <thead>
                                                                            <tr><th class="text-center" colspan="5">Friday Slot</th></tr>
                                                                            <tr><th>Start Time</th><th>End Time</th><th>Actions</th></tr>
                                                                        </thead>
                                                                        <tbody></tbody>
                                                                    </table>
                                                                </div>
                                                            </div>
                                                            <div class="tab-pane" data-tab="Saturday" id="slot-saturday" role="tabpanel" aria-labelledby="slot-saturday" aria-expanded="false">
                                                                <div class="table-responsive">
                                                                    <table class="table">
                                                                        <thead>
                                                                            <tr><th class="text-center" colspan="5">Saturday Slot</th></tr>
                                                                            <tr><th>Start Time</th><th>End Time</th><th>Actions</th></tr>
                                                                        </thead>
                                                                        <tbody></tbody>
                                                                    </table>
                                                                </div>
                                                            </div>
                                                            <div class="tab-pane" data-tab="Sunday" id="slot-sunday" role="tabpanel" aria-labelledby="slot-sunday" aria-expanded="false">
                                                                <div class="table-responsive">
                                                                    <table class="table">
                                                                        <thead>
                                                                            <tr><th class="text-center" colspan="5">Sunday Slot</th></tr>
                                                                            <tr><th>Start Time</th><th>End Time</th><th>Actions</th></tr>
                                                                        </thead>
                                                                        <tbody></tbody>
                                                                    </table>
                                                                </div>
                                                            </div>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>

                                        <div class="row <?php echo $hideClass; ?>">
                                            <div class="border-bottom p-b-10 m-b-10"><b>Cancellation Policy</b></div>
                                            <div class="mb-1 col-md-4">
                                                <label class="form-check-label mb-50" for="cash_booking_allowed"><?= __('Cash Booking Allowed') ?></label>
                                                <div class="form-check form-check-success form-switch">
                                                    <input type="checkbox" name="cash_booking_allowed"  class="form-check-input"  />
                                                </div>
                                            </div>
                                            <div class="mb-1 col-md-4">
                                                <label class="form-check-label mb-50" for="cancellation_allowed"><?= __('Cancellation Allowed') ?></label>
                                                <div class="form-check form-check-success form-switch">
                                                    <input type="checkbox" name="cancellation_allowed" class="form-check-input"  />
                                                </div>
                                            </div>
                                        </div>

                                        <div class="row <?php echo $hideClass; ?>">
                                            <!-- Cancel Policy  -->
                                            <div class="repeater_fields col-sm-12">
                                                <div data-repeater-list="cancel_policy">
                                                    <div data-repeater-item>
                                                        <div class="row align-content-center">
                                                            <div class="col-md-11 col-10">
                                                                <div class="mb-1">
                                                                    <input name="cancel_policy" id="" class="form-control" />
                                                                </div>
                                                            </div>

                                                            <div class="col-md-1 col-2">
                                                                <div class="m-t-10">
                                                                    <a data-action="delete" data-repeater-delete class="badge rounded-pill badge-light-danger me-1" href="#">
                                                                        <svg xmlns="http://www.w3.org/2000/svg" width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="feather feather-trash me-50"><polyline points="3 6 5 6 21 6"></polyline><path d="M19 6v14a2 2 0 0 1-2 2H7a2 2 0 0 1-2-2V6m3 0V4a2 2 0 0 1 2-2h4a2 2 0 0 1 2 2v2"></path></svg>
                                                                        <span>Delete</span>
                                                                    </a>
                                                                </div>
                                                            </div>
                                                        </div>
                                                    </div>
                                                </div>
                                                <div class="row">
                                                    <div class="col-12">
                                                        <button class="btn btn-icon btn-primary" type="button" data-repeater-create>
                                                            <i data-feather="plus" class="me-25"></i>
                                                            <span>Add New</span>
                                                        </button>
                                                    </div>
                                                </div>
                                            </div>
                                            <!-- Cancel Policy  -->
                                            <!-- Cancel Policy Settings -->
                                            <div class="repeater_fields col-sm-12">
                                                <div data-repeater-list="cancel_policy_setting">
                                                    <div class="border-bottom p-b-10 m-b-10 m-t-35"><b>Cancellation Policy Setting</b></div>
                                                    <div data-repeater-item>
                                                        <div class="row align-content-center">
                                                            <div class="col-md-3 col-5">
                                                                <div class="mb-1">
                                                                    <label class="form-label" for="hours"><?= __('Hours') ?></label>
                                                                    <input type="number" name="hours" class="form-control">
                                                                </div>
                                                            </div>
                                                            <div class="col-md-3 col-5">
                                                                <div class="mb-1">
                                                                    <label class="form-label" for="charge"><?= __('Charge') ?></label>
                                                                    <input type="number" name="charge" class="form-control">
                                                                </div>
                                                            </div>
                                                            <div class="col-md-2 col-2">
                                                                <div class="m-t-35">
                                                                    <a data-action="delete" data-repeater-delete class="badge rounded-pill badge-light-danger me-1" href="#">
                                                                        <svg xmlns="http://www.w3.org/2000/svg" width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="feather feather-trash me-50"><polyline points="3 6 5 6 21 6"></polyline><path d="M19 6v14a2 2 0 0 1-2 2H7a2 2 0 0 1-2-2V6m3 0V4a2 2 0 0 1 2-2h4a2 2 0 0 1 2 2v2"></path></svg>
                                                                        <span>Delete</span>
                                                                    </a>
                                                                </div>
                                                            </div>
                                                        </div>
                                                    </div>
                                                </div>
                                                <div class="row">
                                                    <div class="col-12">
                                                        <button class="btn btn-icon btn-primary" type="button" data-repeater-create>
                                                            <i data-feather="plus" class="me-25"></i>
                                                            <span>Add New</span>
                                                        </button>
                                                    </div>
                                                </div>

                                            </div>
                                            <!-- Cancel Policy Settings Ends -->
                                        </div>
                                    </div>
                                </div>
                            </div>

                        </section>

                        <div class="row" data-select2-id="12">
                            <div class="col-12">
                                <button type="submit" class="btn btn-primary me-1 waves-effect waves-float waves-light">Save changes</button>
                                <?php if (!empty($parent_lab)) { ?>
                                    <a  href="{{route('admin.lab.branch', ['lab_id'=>$parent_lab->id] )}}" class="btn btn-outline-secondary waves-effect"> Back</a>
                                <?php } else { ?>
                                    <a href="{{route('admin.lab')}}" class="btn btn-outline-secondary waves-effect">Back</a>
                                <?php } ?>
                            </div>
                        </div>
                    </form>
                    <!--/ form -->
                </div>
            </div>
        </div>
    </div>
</div>
@endsection
@section('script')
<script src="https://cdnjs.cloudflare.com/ajax/libs/jqueryui/1.13.2/jquery-ui.min.js"></script>
<script>
    $(document).ready(function () {
    $("#user_search").autocomplete({
    source: function (request, response) {
    $.ajax({
    url: "{{route('admin.lab.user_select')}}",
            type: 'GET',
            dataType: "json",
            data: {
            search: request.term,
                    type:"{{$type}}",
                    '_token': "{{ csrf_token() }}"
            },
            success: function (data) {
            response(data);
            }
    });
    },
            select: function (event, ui) {
            $('#user_search').val(ui.item.label);
            $('#user_id').val(ui.item.id);
            console.log(ui.item);
            return false;
            }
    });
    });
    $(document).ready(function () {
    $(".repeater_fields").repeater();
    $('.dropzone').sortable({
    items: '.dz-preview',
            cursor: 'move',
            opacity: 0.5,
            containment: '.dropzone',
            distance: 20,
            tolerance: 'pointer',
            stop: function () {
            var imageName = [];
            $('#images_list').find('option').remove();
            $('.dropzone .dz-preview .dz-filename [data-dz-name]').each(function (count, el) {
            imageName.push(el.innerHTML);
            $("#images_list").append(`<option value="${el.innerHTML}" selected>${el.innerHTML}</option>`);
            });
            }
    });
    });
    Dropzone.autoDiscover = false;
    $("#id_dropzone").dropzone({
    acceptedFiles: "image/*",
            maxFiles: 10,
            addRemoveLinks: true,
            method: "post",
            url: "<?= route("admin.lab.gallery_images", 0) ?>",
            success: function (file, response) {
            $("#images_list").append(`<option value="${response}" selected>${response}</option>`);
            var fileuploded = file.previewElement.querySelector("[data-dz-name]");
            fileuploded.innerHTML = response;
            },
            sending: function (file, xhr, formData) {
            formData.append("_token", "{{ csrf_token() }}");
            },
            removedfile: function (file) {
            var fileuploded = file.previewElement.querySelector("[data-dz-name]");
            var fileName = fileuploded.innerHTML;
            $("#images_list").find(`[value="${fileName}"]`).remove();
            console.log(fileName);
            file.previewElement.remove();
            $.ajax({
            type: 'POST',
                    url: "<?= route("admin.lab.gallery_images_delete", 0) ?>",
                    data: {name: fileName, request: 'remove', '_token': "{{ csrf_token() }}"},
                    sucess: function (data) {
                    file.previewElement.remove();
                    }
            });
            },
    });

</script>
@endsection
