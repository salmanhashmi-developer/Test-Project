<div class="row">
    <form class="" method="POST" action="{{ route('admin.lab.branch') }}" id="search_form" onsubmit="return false">
        {{ csrf_field() }}
        <div class="col-12">
            <div class="card">
                <div class="card-header border-bottom">
                    <h4 class="card-title">{{ $lab->name }} : Branch List</h4>
                    <div
                        class="dt-action-buttons d-flex align-items-center justify-content-center justify-content-lg-end flex-lg-nowrap flex-wrap">
                        <div class="dt-buttons d-inline-flex">
                            <a class="dt-button add-new btn btn-primary"
                                href="{{ route('admin.lab.add', ['lab_id' => $lab->id]) }}">{{ __('Add New Branch') }}</a>
                            <a class="btn btn-outline-secondary waves-effect m-l-20"
                                href="{{ route('admin.lab') }}">{{ __('Back') }}</a>
                        </div>
                    </div>
                </div>
                <!--Search Form -->
                <div class="card-body mt-2">
                    <input type="hidden" name="page" id="page"
                        value="{{ empty(app('request')->input('page')) ? 1 : app('request')->input('page') }}">
                    <input type="hidden" name="lab_id" value="{{ $lab->id }}">
                    <div class="row g-1 mb-md-1">
                        <div class="col-md-2">
                            <label class="form-label">Phone</label>
                            <input type="text" class="form-control dt-input" name="phone"
                                value="{{ app('request')->input('phone') }}">
                        </div>
                        <div class="col-md-2">
                            <label class="form-label">Pincode</label>
                            <input type="text" class="form-control dt-input" name="pincode"
                                value="{{ app('request')->input('pincode') }}">
                        </div>
                        <div class="col-md-3">
                            <label class="form-label">State</label>
                            <select name="state_id" id="state_id" class="select2 form-select">
                                <option value="">All</option>
                                <?php
                                $set_values = request_display('state_id');
                                foreach ($states as $state):
                                    ?>
                                <option value="{{ $state->id }}" <?= $state->id == $set_values ? 'selected' : '' ?>>
                                    {{ $state->name }}</option><?php
                                endforeach;
                                ?>
                            </select>
                        </div>
                        <div class="col-md-3">
                            <label class="form-label">City</label>
                            <select name="city_id" id="city_id" class="select2 form-select">
                                <option value="">All</option>
                                <?php
                                $set_values = request_display("city_id");
                                foreach ($cities as $city):
                                    ?>
                                <option value="{{ $city->id }}" {{ $city->id == $set_values ? 'selected' : '' }}>
                                    {{ $city->name }}</option><?php
                                endforeach;
                                ?>
                            </select>
                        </div>
                        <div class="col-md-2">
                            <label class="form-label"></label>
                            <button type="submit"
                                class="btn btn-primary mt-2 waves-effect waves-float waves-light">Search</button>
                        </div>
                    </div>
                </div>
                <hr class="my-0">
                <div class="card-datatable">
                    <?php echo parPageRecordDropDown(); ?>
                    @if (!$lab_branch->isEmpty())
                        @php $start = $lab_branch->firstItem(); @endphp
                        <div class="table-responsive">

                            <table class="table table-bordered table-hover">
                                <thead>
                                    <tr role="row">
                                        <th></th>
                                        <th><?php echo sort_field_display('name', 'Name'); ?></th>
                                        <th>Phone</th>
                                        <th><?php echo sort_field_display('Area', 'Area'); ?></th>
                                        <th><?php echo sort_field_display('Pincode', 'Pincode'); ?></th>
                                        <th>City</th>
                                        <th>State</th>
                                        <th>Actions</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    @foreach ($lab_branch as $data)
                                        <tr>
                                            <td><?= $start++ ?></td>
                                            <td valign="top">{{ $data->name }}</td>
                                            <td valign="top">{{ $data->phone }}</td>
                                            <td valign="top">{{ $data->area }}</td>
                                            <td valign="top">{{ $data->pincode }}</td>
                                            <td valign="top">{{ $data->city->name }}</td>
                                            <td valign="top">{{ $data->state->name }}</td>
                                            <td>
                                                <div class="text-nowrap">
                                                    <a title="Lab Details"
                                                        href="{{ route('admin.lab.view', ['id' => $data->id]) }}">
                                                        <i data-feather="file-text" class="me-50 text-dark"></i>
                                                    </a>
                                                    <a title="Lab Location"
                                                        href="{{ route('admin.lab.location', ['id' => $data->id]) }}">
                                                        <i data-feather="map-pin" class="me-50 text-dark"></i>
                                                    </a>
                                                    <a title="Lab Slot"
                                                        href="{{ route('admin.lab.slot', ['id' => $data->id]) }}">
                                                        <i data-feather="layers" class="me-50 text-dark"></i>
                                                    </a>
                                                    <a title="Delete Lab"
                                                        href="{{ route('admin.lab.edit', ['id' => $data->id]) }}">
                                                        <i data-feather="edit" class="me-50 text-dark"></i>
                                                    </a>
                                                    <a title="Lab Test"
                                                        href="{{ route('admin.lab.test', ['lab_id' => $data->id]) }}">
                                                        <i data-feather="thermometer" class="me-50 text-dark"></i>
                                                    </a>
                                                    <a title="Lab Delete" data-lab-name="{{ $data->name }}"
                                                        data-lab-id="{{ $data->id }}" data-action="delete">
                                                        <i data-feather="trash-2" class="me-50 text-danger"></i>
                                                    </a>
                                                </div>
                                            </td>
                                        </tr>
                                    @endforeach
                                </tbody>
                            </table>
                        </div>
                    @endif
                    <?php echo pagination($lab_branch); ?>
                </div>
            </div>
        </div>
    </form>
</div>
@section('script')
    <script type="text/javascript">
        $(document).on("click", "a[data-action='delete']", function() {
            var name = $(this).attr("data-lab-name");
            var id = $(this).attr("data-lab-id");
            var $this = $(this);
            confirmationAlertPopup(("Do you want to delete " + name), "Yes, delete it !",
                function(result) {
                    if (result.isConfirmed) {
                        var param = new Object();
                        param["lab_id"] = id;
                        //console.log(param);
                        if (APP.BlockConcurrentReq(2000)) {
                            return;
                        }
                        loadingOverlay("body", "show");
                        jqueryAjax("{{ route('admin.lab.delete') }}", param, function(res) {
                            loadingOverlay("body", "hide");
                            if (res.code != 200) {
                                Notification.show({
                                    type: "error",
                                    msg: res.message,
                                    timeout: 3000
                                });
                                return;
                            }
                            Notification.show({
                                type: "success",
                                msg: res.message,
                                timeout: 3000
                            });
                            var $closestTr = $this.closest("tr");
                            $closestTr.hide();
                            $closestTr.next().remove();
                        }, "", "json");
                        resultAlertPopup("Deleted!", "Lab " + name +
                            " has been deleted.",
                            "success");
                    }
                });
        });
    </script>
@endsection
