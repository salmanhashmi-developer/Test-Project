<!DOCTYPE html>
<html class="loading" lang="en" data-textdirection="ltr">
<!-- BEGIN: Head-->

<head>
    <meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width,initial-scale=1.0,user-scalable=0,minimal-ui">
    <title>@yield('title')</title>


    <link rel="apple-touch-icon" href="{{ Helper::static_asset('admin-assets/images/ico/apple-icon-120.png') }}">
    <link rel="shortcut icon" type="image/x-icon"
        href="{{ Helper::static_asset('admin-assets/images/ico/favicon.ico') }}">
    <!--<link href="https://fonts.googleapis.com/css2?family=Montserrat:ital,wght@0,300;0,400;0,500;0,600;1,400;1,500;1,600" rel="stylesheet">-->
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700&display=swap" rel="stylesheet">
    <!-- BEGIN: Vendor CSS-->
    <link rel="stylesheet" type="text/css"
        href="{{ Helper::static_asset('admin-assets/vendors/css/vendors.min.css') }}">
    <link rel="stylesheet" type="text/css"
        href="{{ Helper::static_asset('admin-assets/vendors/css/forms/select/select2.min.css') }}">
    <link rel="stylesheet" type="text/css"
        href="{{ Helper::static_asset('admin-assets/vendors/css/tables/datatable/dataTables.bootstrap5.min.css') }}">
    <link rel="stylesheet" type="text/css"
        href="{{ Helper::static_asset('admin-assets/vendors/css/tables/datatable/responsive.bootstrap5.min.css') }}">
    <link rel="stylesheet" type="text/css"
        href="{{ Helper::static_asset('admin-assets/vendors/css/tables/datatable/buttons.bootstrap5.min.css') }}">
    <link rel="stylesheet" type="text/css"
        href="{{ Helper::static_asset('admin-assets/vendors/css/tables/datatable/rowGroup.bootstrap5.min.css') }}">
    <!-- END: Vendor CSS-->

    <!-- BEGIN: Theme CSS-->
    <link rel="stylesheet" type="text/css" href="{{ Helper::static_asset('admin-assets/css/bootstrap.css') }}">
    <link rel="stylesheet" type="text/css" href="{{ Helper::static_asset('admin-assets/css/bootstrap-extended.css') }}">
    <link rel="stylesheet" type="text/css" href="{{ Helper::static_asset('admin-assets/css/colors.css') }}">
    <link rel="stylesheet" type="text/css" href="{{ Helper::static_asset('admin-assets/css/components.css') }}">
    <link rel="stylesheet" type="text/css"
        href="{{ Helper::static_asset('admin-assets/css/themes/dark-layout.css') }}">
    <link rel="stylesheet" type="text/css"
        href="{{ Helper::static_asset('admin-assets/css/themes/bordered-layout.css') }}">
    <link rel="stylesheet" type="text/css"
        href="{{ Helper::static_asset('admin-assets/css/themes/semi-dark-layout.css') }}">

    <!-- BEGIN: Page CSS-->
    <link rel="stylesheet" type="text/css"
        href="{{ Helper::static_asset('admin-assets/css/core/menu/menu-types/vertical-menu.css') }}">
    <link rel="stylesheet" type="text/css"
        href="{{ Helper::static_asset('admin-assets/css/plugins/forms/form-validation.css') }}">
    <!-- END: Page CSS-->


    <!-- BEGIN: Custom Admin CSS-->
    <link rel="stylesheet" type="text/css"
        href="{{ Helper::static_asset('admin-assets/css/admin_custom_style.css') }}">
    <!-- END: Page CSS-->
    <!-- BEGIN: Vendor JS-->
    <script src="{{ Helper::static_asset('admin-assets/vendors/js/vendors.min.js') }}"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/jquery-loading-overlay/2.1.7/loadingoverlay.min.js"
        integrity="sha512-hktawXAt9BdIaDoaO9DlLp6LYhbHMi5A36LcXQeHgVKUH6kJMOQsAtIw2kmQ9RERDpnSTlafajo6USh9JUXckw=="
        crossorigin="anonymous" referrerpolicy="no-referrer"></script>
    <!-- BEGIN Vendor JS-->

    <!-- BEGIN: Page Vendor JS-->
    <script src="{{ Helper::static_asset('admin-assets/vendors/js/forms/select/select2.full.min.js') }}"></script>
    <!-- END: Page Vendor JS-->
    <!-- BEGIN: Theme JS-->
    <script src="{{ Helper::static_asset('admin-assets/vendors/js/forms/wizard/bs-stepper.min.js') }}"></script>
    <script src="{{ Helper::static_asset('admin-assets/vendors/js/file-uploaders/dropzone.min.js') }}"></script>
    <script src="{{ Helper::static_asset('admin-assets/vendors/js/file-uploaders/bootstrap-fileupload.js') }}"></script>
    <script src="{{ Helper::static_asset('admin-assets/js/scripts/forms/form-wizard.js') }}"></script>
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/flatpickr/dist/flatpickr.min.css">
    <script src="https://cdn.jsdelivr.net/npm/flatpickr"></script>
    <link rel="stylesheet" href="{{ Helper::static_asset('admin-assets/css/plugins/forms/form-wizard.css') }}">
    <link rel="stylesheet"
        href="{{ Helper::static_asset('admin-assets/vendors/css/forms/wizard/bs-stepper.min.css') }}">
    <link rel="stylesheet"
        href="{{ Helper::static_asset('admin-assets/vendors/css/file-uploaders/bootstrap-fileupload.css') }}">
    <link rel="stylesheet"
        href="{{ Helper::static_asset('admin-assets/vendors/css/file-uploaders/dropzone.min.css') }}">


    <script src="https://cdnjs.cloudflare.com/ajax/libs/feather-icons/4.29.0/feather.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/@emretulek/jbvalidator"></script>
    <script src="https://code.jquery.com/ui/1.13.2/jquery-ui.min.js"></script>
    <link rel="stylesheet" href="https://code.jquery.com/ui/1.13.2/themes/cupertino/jquery-ui.css">
    <script src="{{ Helper::static_asset('admin-assets/vendors/js/forms/repeater/jquery.repeater.min.js') }}"></script>
    <script src="{{ asset('admin-assets/js/sweetalert.js') }}"></script>
    <!-- END: Theme JS-->

</head>
<!-- END: Head-->

<!-- BEGIN: Body-->

<body class="vertical-layout vertical-menu-modern  navbar-floating footer-static  " data-open="click"
    data-menu="vertical-menu-modern" data-col="">

    @include('backend.partials.header')

    @include('backend.partials.navbar')

    @yield('content')

    @include('backend.partials.footer')

    <script src="{{ Helper::static_asset('admin-assets/js/core/app-menu.js') }}"></script>
    <script src="{{ Helper::static_asset('admin-assets/js/core/app.js') }}"></script>

    <!-- BEGIN: Page JS-->
    <script src="{{ Helper::static_asset('admin-assets/js/scripts/pages/app-user-list.js') }}"></script>
    <!-- END: Page JS-->

</body>
<!-- END: Body-->

</html>
