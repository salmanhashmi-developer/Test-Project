@extends("backend.layouts.master")
@section('title') Hospital View @endsection
@section('content')

<!-- BEGIN: Content-->
<div class="app-content content ">

    <div class="content-wrapper p-0">

        <div class="content-body">
            @include('backend.message')
            <div class="card" data-select2-id="14">
                <div class="card-header border-bottom">
                    <h4 class="card-title">Hospital Details View</h4>
                </div>
                <div class="card-body py-2 my-25" data-select2-id="53">
                    <!-- header section -->

                    <!-- Modern Horizontal Wizard -->
                    <section class="modern-horizontal-wizard">
                        <div class="bs-stepper wizard-modern modern-wizard-example">
                            <div class="bs-stepper-header">
                                <div class="step" data-target="#account-details-modern" role="tab" id="account-details-modern-trigger">
                                    <button type="button" class="step-trigger">
                                        <span class="bs-stepper-box"><i data-feather="user" class="font-medium-3"></i></span>
                                        <span class="bs-stepper-label">
                                            <span class="bs-stepper-title">Hospital Details</span>
                                        </span>
                                    </button>
                                </div>
                                <div class="line"><i data-feather="chevron-right" class="font-medium-2"></i></div>
                                <div class="step" data-target="#personal-info-modern" role="tab" id="personal-info-modern-trigger">
                                    <button type="button" class="step-trigger">
                                        <span class="bs-stepper-box"><i data-feather="file-text" class="font-medium-3"></i></span>
                                        <span class="bs-stepper-label">
                                            <span class="bs-stepper-title">Additional Details</span>
                                        </span>
                                    </button>
                                </div>
                                <div class="line"><i data-feather="chevron-right" class="font-medium-2"></i></div>
                                <div class="step" data-target="#hospital-gallery-modern" role="tab" id="hospital-gallery-modern-trigger">
                                    <button type="button" class="step-trigger">
                                        <span class="bs-stepper-box"><i data-feather="user" class="font-medium-3"></i></span>
                                        <span class="bs-stepper-label">
                                            <span class="bs-stepper-title">Hospital Gallery</span>
                                        </span>
                                    </button>
                                </div>
                            </div>
                            <div class="bs-stepper-content">
                                <div id="account-details-modern" class="content" role="tabpanel" aria-labelledby="account-details-modern-trigger">


                                    <div class="d-flex">
                                        <div class="col-xl-8 col-lg-8 col-md-8 align-items-start me-2">
                                            <div class="info-container">
                                                <ul class="list-unstyled f-12">
                                                    <li class="mb-75 mt-2">
                                                        <div class="row">
                                                            <div class="mb-1 col-md-4">
                                                                <span><?= _('Name') ?></span>
                                                                <br>
                                                                <span class="fw-bolder me-25">{{ $hospital->name }}</span>
                                                            </div>
                                                            <div class="mb-1 col-md-4">
                                                                <span><?= _('Address 1') ?>:</span>
                                                                <br>
                                                                <span class="fw-bolder me-25">{{ $hospital->address1  }}</span>
                                                            </div>
                                                            <div class="mb-1 col-md-4">
                                                                <span><?= _('Addresss 2') ?>:</span>
                                                                <br>
                                                                <span class="fw-bolder me-25">{{ $hospital->address2  }}</span>
                                                            </div>
                                                        </div>
                                                    </li>
                                                    <li class="mb-75 mt-2">
                                                        <div class="row">
                                                            <div class="mb-1 col-md-4">
                                                                <span><?= _('Phone No') ?>:</span>
                                                                <br>
                                                                <span class="fw-bolder me-25">{{ $hospital->phone }}</span>
                                                            </div>
                                                            <div class="mb-1 col-md-4">
                                                                <span><?= _('Area') ?>:</span>
                                                                <br>
                                                                <span class="fw-bolder me-25">{{ $hospital->area }}</span>
                                                            </div>
                                                            <div class="mb-1 col-md-4">
                                                                <span><?= _('Pincode') ?>:</span>
                                                                <br>
                                                                <span class="fw-bolder me-25">{{ $hospital->pincode }}</span>
                                                            </div>
                                                        </div>
                                                    </li>
                                                    <li class="mb-75 mt-2">
                                                        <div class="row">                                                        
                                                            <div class="mb-1 col-md-4">
                                                                <span><?= _('Latitude') ?>:</span>
                                                                <br>
                                                                <span class="fw-bolder me-25">{{ $hospital->latitude }}</span>
                                                            </div>
                                                            <div class="mb-1 col-md-4">
                                                                <span><?= _('Longitude') ?>:</span>
                                                                <br>
                                                                <span class="fw-bolder me-25">{{ $hospital->longitude }}</span>
                                                            </div>
                                                            <div class="mb-1 col-md-4">
                                                                <span><?= _('City') ?>:</span>
                                                                <br>
                                                                <span class="fw-bolder me-25">{{ $hospital->city->name  }}</span>
                                                            </div>
                                                        </div>
                                                    </li>
                                                    <li class="mt-2">
                                                        <div class="row">                                                        
                                                            <div class="mb-1 col-md-4">
                                                                <span><?= _('Cancellation Allowed') ?>:</span>
                                                                <br>
                                                                <span class="fw-bolder me-25">{{ post_display('cancellation_allowed',$hospital->cancellation_allowed) == 1 ? 'Yes':'No' }}</span>
                                                            </div>
                                                            <div class="mb-1 col-md-4">
                                                                <span><?= _('Status') ?>:</span>
                                                                <br>
                                                                <span class="fw-bolder me-25">{{ $hospital->status->name  }}</span>
                                                            </div>
                                                            <div class="mb-1 col-md-4">
                                                                <span><?= _('Cancel Policy') ?>:</span>
                                                                <br>
                                                                <span class="fw-bolder me-25">
                                                                    <ul style="list-style-type: decimal;text-align:justify;" class="p-1">
                                                                        <?php
                                                                        if (!empty($hospital->cancel_policy)) {
                                                                            foreach (json_decode($hospital->cancel_policy, true) as $row) {
                                                                                echo '<li>' . $row . '</li>';
                                                                            }
                                                                        }
                                                                        ?>
                                                                    </ul>
                                                                </span>
                                                            </div>
                                                        </div>
                                                    </li>
                                                    <li class="mb-75">
                                                        <div class="row">                                                        
                                                            <div class="mb-1 col-md-4">
                                                                <span><?= _('State') ?>:</span>
                                                                <br>
                                                                <span class="fw-bolder me-25">{{ $hospital->state->name  }}</span>
                                                            </div>
                                                            <div class="mb-1 col-md-4">
                                                                <span><?= _('Cash Booking Allowed') ?>:</span>
                                                                <br>
                                                                <span class="fw-bolder me-25">{{ post_display('cash_booking_allowed',$hospital->cash_booking_allowed) == 1 ? 'Yes':'No'  }}</span>
                                                            </div>
                                                            <div class="mb-1 col-md-4">
                                                                
                                                            </div>
                                                        </div>
                                                    </li>
                                                </ul>

                                            </div>
                                        </div>
                                        <div class="col-xl-4 col-lg-4 col-md-4  d-flex align-items-start me-2">

                                            <div class="info-container">
                                                <ul class="list-unstyled">
                                                    <li class="mb-75">
                                                        <div class="user-avatar-section">
                                                            <div class="d-flex align-items-center flex-column">
                                                                <?php $src = !empty($hospital->photo) != '' ? '/image/hospital/' . $hospital->photo : '/admin-assets/images/icons/file-icons/no_document.png'; ?>
                                                                <a href="<?php echo $src; ?>" class="" target="_blank">
                                                                    <img class="img-fluid rounded mt-1 mb-3" height="110" width="110" alt="" src="<?php echo $src; ?>"  alt="User avatar" />
                                                                </a>

                                                            </div>
                                                        </div>
                                                    </li>
                                                    <li class="mb-75">
                                                        <span class="fw-bolder me-25"><?= _('Cancel Policy Settingancel Policy') ?>:</span>
                                                        <ul style="list-style-type: decimal;text-align:justify;" class="p-1">

                                                            <?php
                                                            if (!empty($hospital->cancel_policy_setting)) {
                                                                foreach (json_decode($hospital->cancel_policy_setting, true) as $row) {
                                                                    echo '<li> Rs. ' . $row['charge'] . ' for  ' . $row['hours'] . ' Hours   </li>';
                                                                }
                                                            }
                                                            ?>
                                                        </ul>
                                                    </li>
                                                </ul>
                                            </div>
                                        </div>
                                    </div>


                                </div>

                                <div id="personal-info-modern" class="content" role="tabpanel" aria-labelledby="personal-info-modern-trigger">
                                            <div class="info-container">
                                                
                                                <ul class="list-unstyled f-12">
                                                    <li class="mb-75 mt-2">
                                                        <div class="row">
                                                            <div class="mb-1 col-md-4">
                                                                <span><?= _('PAN NO') ?></span>
                                                                <br>
                                                                <span class="fw-bolder me-25">{{ $hospital->hospital_details->pancard_number }}</span>
                                                            </div>
                                                            <div class="mb-1 col-md-4">
                                                                <span><?= _('PAN Card Document') ?>:</span>
                                                                <br>
                                                                <span class="fw-bolder me-25"> <?php $src = !empty($hospital->hospital_details->pancard_document) != '' ? '/image/hospital/' . $hospital->hospital_details->pancard_document : '/admin-assets/images/icons/file-icons/no_document.png'; ?>
                                                                    <a href="<?php echo $src; ?>" class="" target="_blank">View Document</a>  </span>
                                                            </div>
                                                            <div class="mb-1 col-md-4">
                                                                <span><?= _('GST No') ?>:</span>
                                                                <br>
                                                                <span class="fw-bolder me-25">{{ $hospital->hospital_details->gst_number  }}</span>
                                                            </div>
                                                        </div>
                                                    </li>
                                                    <li class="mb-75 mt-2">
                                                        <div class="row">
                                                            <div class="mb-1 col-md-4">
                                                                <span><?= _('GST Certificate') ?>:</span>
                                                                <br>
                                                                <span class="fw-bolder me-25"> <?php $src = !empty($hospital->hospital_details->gst_certificate) != '' ? '/image/hospital/' . $hospital->hospital_details->gst_certificate : '/admin-assets/images/icons/file-icons/no_document.png'; ?>
                                                                    <a href="<?php echo $src; ?>" class="" target="_blank">View Document</a>  
                                                                </span>
                                                            </div>
                                                            <div class="mb-1 col-md-4">
                                                                <span><?= _('Bank Account Number') ?></span>
                                                                <br>
                                                                <span class="fw-bolder me-25">{{ $hospital->hospital_details->bank_account_number }}</span>
                                                            </div>
                                                            <div class="mb-1 col-md-4">
                                                                <span><?= _('Bank Account Name') ?></span>
                                                                <br>
                                                                <span class="fw-bolder me-25">{{ $hospital->hospital_details->bank_account_name }}</span>
                                                            </div>
                                                        </div>
                                                    </li>
                                                    <li class="mb-75 mt-2">
                                                        <div class="row">                                                        
                                                            <div class="mb-1 col-md-4">
                                                                <span><?= _('Bank Name') ?>:</span>
                                                                <br>
                                                                <span class="fw-bolder me-25">{{ $hospital->hospital_details->bank_name }}</span>
                                                            </div>
                                                            <div class="mb-1 col-md-4">
                                                                <span><?= _('IFSC Code') ?>:</span>
                                                                <br>
                                                                <span class="fw-bolder me-25">{{ $hospital->hospital_details->bank_ifsc_code }}</span>
                                                            </div>
                                                            <div class="mb-1 col-md-4">
                                                                
                                                            </div>
                                                        </div>
                                                    </li>
                                                </ul>

                                            </div>
                                        <!--												<div class="col-xl-5 col-lg-3 col-md-3  d-flex align-items-start me-2">
                                                                                                                                                        <div class="info-container">
                                                                                                                                                                        <ul class="list-unstyled">
                                        
                                                                                                                                                                        </ul>
                                        
                                                                                                                                                        </div>
                                                                                                                                         </div>
                                        -->
                                </div>
                                <div id="hospital-gallery-modern" class="content" role="tabpanel" aria-labelledby="hospital-gallery-modern-trigger">
                                    <?php //echo "<pre>";print_r($images);?>

                                    <div class="cws-content">
                                        <div class="row blog-list-wrapper">
                                            <?php
                                            if (!empty($images)) {
                                                foreach ($images as $row) {
                                                    ?>
                                                    <div class="col-md-4">
                                                        <div class=" border mt-1 ml-1 mr-1 mb-2 text-center">
                                                            <article class="card">
                                                                <?php $src = '/image/hospital_gallery/' . $row['name']; ?>
                                                                <a href="<?php echo $src; ?>" class="" target="_blank">
                                                                    <img src="<?php echo $src; ?>" alt="" class="card-img-top">
                                                                </a>
                                                            </article>
                                                        </div>
                                                    </div> 
                                                    <?php
                                                }
                                            }
                                            ?>

                                        </div>
                                    </div>


                                </div>
                            </div>

                        </div>
                    </section>
                    <!-- /Modern Horizontal Wizard -->

                    <div class="row" data-select2-id="12">
                        <div class="col-12">
                            <a href="{{ route('admin.hospital.edit', ['id'=>$hospital->id] )  }}" class="btn btn-primary me-1 waves-effect waves-float waves-light" > Edit</a>
                            <a href="{{route('admin.hospital')}}" class="btn btn-outline-secondary waves-effect">Back</a>
                        </div>
                    </div>


                </div>

            </div>

        </div>
    </div>
</div>
@endsection
