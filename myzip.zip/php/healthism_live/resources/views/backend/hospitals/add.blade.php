@extends("backend.layouts.master")
@section('title') Hospital Add @endsection
@section('content')

<!-- BEGIN: Content-->
<div class="app-content content ">

    <div class="content-wrapper p-0">

        <div class="content-body">

            <div class="card" data-select2-id="14">
                <div class="card-header border-bottom">
                    <h4 class="card-title">Add New Hospital Details</h4>
                </div>
                <div class="card-body py-2 my-25" data-select2-id="53">
                    <!-- header section -->

                    <!-- form -->
                    @include('backend.message')

                    <form class="needs-validation" method="POST" action="{{route('admin.hospital.store')}}" method="POST" enctype="multipart/form-data" novalidate>
                        {{ csrf_field() }}
                        <section class="modern-horizontal-wizard">

                            <div class="bs-stepper wizard-modern modern-wizard-example">

                                <div class="bs-stepper-header">
                                    <div class="step" data-target="#account-details-modern" role="tab" id="hospital-details-modern-trigger">
                                        <button type="button" class="step-trigger">
                                            <span class="bs-stepper-box">
                                                <i data-feather="user" class="font-medium-3"></i>
                                            </span>
                                            <span class="bs-stepper-label">
                                                <span class="bs-stepper-title">Hospital Details</span>
                                            </span>
                                        </button>
                                    </div>


                                    <div class="line">
                                        <i data-feather="chevron-right" class="font-medium-2"></i>
                                    </div>
                                    <div class="step" data-target="#hostpital-details-info" role="tab" id="hostpital-details-info-trigger">
                                        <button type="button" class="step-trigger">
                                            <span class="bs-stepper-box">
                                                <i data-feather="file-text" class="font-medium-3"></i>
                                            </span>
                                            <span class="bs-stepper-label">
                                                <span class="bs-stepper-title">Hospital Additional Details</span>
                                            </span>
                                        </button>
                                    </div>
                                </div>

                                <div class="bs-stepper-content">
                                    <div id="account-details-modern" class="content" role="tabpanel" aria-labelledby="hospital-details-modern-trigger">
                                        <div class="content-header">
                                            <h5 class="mb-0"><?= ('Hospital Details') ?></h5>
                                        </div>
                                        <div class="row">
                                            <div class="mb-1 col-md-6">
                                                <div class="mb-1 col-md-12">
                                                    <label class="form-label" for="name"><?= _('Name') ?></label>
                                                    <input type="text" name="name" id="name" class="form-control" placeholder="<?= _('Hospital Name') ?>" value="<?= post_display('name') ?>" required/>
                                                </div>
                                                <div class="mb-1 col-md-12">
                                                    <label class="form-label" for="phone"><?= _('Phone') ?></label>
                                                    <input type="text" name="phone" class="form-control" pattern="[0-9]+" placeholder="<?= _('phone') ?>" value="<?= post_display('phone') ?>" required/>
                                                </div>
                                                <div class="mb-1 col-md-12">
                                                    <label class="form-label" for="type"><?= _('Type') ?></label>
                                                    <select name="type" class="form-select select2" required>
                                                        <option value=""></option>
                                                        <?php
                                                        $set_values = post_display('type');
                                                        ?>
                                                        @foreach($type as $row)
                                                        <option value="<?= $row ?>" <?= $row == $set_values ? 'selected' : '' ?>><?= $row ?></option>
                                                        @endforeach

                                                    </select>
                                                </div>
                                            </div>
                                            <div class="mb-1 col-md-6">
                                                <label class="form-label" for="registration_council"><?= _('Upload Profile Pic') ?></label>
                                                <div data-provides="fileupload" class="fileupload fileupload-new">
                                                    <div style="width: 200px; height: 150px;" class="fileupload-new thumbnail">
                                                        <?php $src = '/admin-assets/images/icons/file-icons/no_document.png'; ?>
                                                        <img alt="" src="<?php echo $src; ?>">
                                                    </div>
                                                    <div style="max-width: 200px; max-height: 150px; line-height: 20px;" class="fileupload-preview fileupload-exists thumbnail"></div>
                                                    <div>
                                                        <span class="btn btn-file" style="padding: 10px 0px 0px 0px;">
                                                            <span class="btn btn-primary fileupload-new">Select image</span>
                                                            <span class="btn btn-primary fileupload-exists">Change</span>
                                                            <input data-file-profile="true" type="file" accept="image/*" name="photo">
                                                        </span>
                                                        <a href="javascript:void(0)" class="btn btn-outline-secondary mt-1 waves-effect" data-remove-profile="true">Remove</a>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                        <div class="row">
                                            <div class="mb-1 col-md-6">
                                                <label class="form-label" for="address1">Address 1</label>
                                                <textarea name="address1" id="" cols="30" rows="2" class="form-control" required></textarea>
                                            </div>
                                            <div class="mb-1 col-md-6">
                                                <label class="form-label" for="address2">Address 2</label>
                                                <textarea name="address2" cols="30" rows="2" class="form-control" required></textarea>
                                            </div>
                                        </div>
                                        <div class="row">
                                            <div class="mb-1 col-md-4">
                                                <label class="form-label" for="area"><?= _('Area') ?></label>
                                                <input type="text" name="area" class="form-control" placeholder="<?= _('Area') ?>" value="<?= post_display('area') ?>" required />
                                            </div>
                                            <div class="mb-1 col-md-4">
                                                <label class="form-label" for="pincode"><?= _('Pincode') ?></label>
                                                <input type="text" name="pincode" class="form-control" placeholder="<?= _('Pincode') ?>" value="<?= post_display('pincode') ?>" required/>
                                            </div>
                                            <div class="mb-1 col-md-4">
                                                <label class="form-label" for="state">State</label>
                                                <select name="state_id" id="state_id" class="select2 form-select" required>
                                                    <option value="">Select State</option>
                                                    <?php foreach ($states as $state): ?>
                                                        <option value="{{ $state->id }}">{{$state->name}}</option><?php
                                                    endforeach;
                                                    ?>
                                                </select>
                                            </div>
                                        </div>
                                        <div class="row">
                                            <div class="mb-1 col-md-4">
                                                <label for="language" class="form-label">City</label>
                                                <select name="city_id" id="city_id" class="select2 form-select" required>
                                                    <option value="">Select City</option>
                                                </select>
                                            </div>
                                            <div class="mb-1 col-md-4">
                                                <label class="form-label" for="latitude"><?= _('Latitude') ?></label>
                                                <input type="text" name="latitude" class="form-control" data-v-message="Invalid latitude" maxlength="12" pattern="^(\+|-)?(?:90(?:(?:\.0{1,9})?)|(?:[0-9]|[1-8][0-9])(?:(?:\.[0-9]{1,9})?))$" placeholder="<?= _('Latitude') ?>" value="<?= post_display('latitude') ?>" required />
                                            </div>
                                            <div class="mb-1 col-md-4">
                                                <label class="form-label" for="longitude"><?= _('Longitude') ?></label>
                                                <input type="text" name="longitude" class="form-control" maxlength="12" data-v-message="Invalid longitude" pattern="^(\+|-)?(?:180(?:(?:\.0{1,9})?)|(?:[0-9]|[1-9][0-9]|1[0-7][0-9])(?:(?:\.[0-9]{1,9})?))$" placeholder="<?= _('Longitude') ?>" value="<?= post_display('longitude') ?>" required />
                                            </div>

                                        </div>
                                        <div class="row">

                                            <div class="mb-1 col-md-4">
                                                <label class="form-check-label mb-50" for="status"><?= __('Status') ?></label>

                                                <select name="status_id" class="form-select select2">
                                                    <?php
                                                    $set_values = post_display('type');
                                                    ?>
                                                    @foreach(hospital_status as $key=>$val)
                                                    <option class="dropdown-item" value="<?= $key ?>" <?= $key == $set_values ? 'selected' : '' ?>><?= $val ?></option>
                                                    @endforeach

                                                </select>
                                            </div>
                                            <div class="mb-1 col-md-4">
                                                <label class="form-check-label mb-50" for="cash_booking_allowed"><?= __('Cash Booking Allowed') ?></label>
                                                <div class="form-check form-check-success form-switch">
                                                    <input type="checkbox" name="cash_booking_allowed"  class="form-check-input"  />
                                                </div>
                                            </div>
                                            <div class="mb-1 col-md-4">
                                                <label class="form-check-label mb-50" for="cancellation_allowed"><?= __('Cancellation Allowed') ?></label>
                                                <div class="form-check form-check-success form-switch">
                                                    <input type="checkbox" name="cancellation_allowed" class="form-check-input"  />
                                                </div>
                                            </div>
                                        </div>

                                        <div class="row">
                                            <!-- Cancel Policy  -->
                                            <div class="repeater_fields col-sm-12">

                                                <div data-repeater-list="cancel_policy">
                                                    <div class="border-bottom m-b-10"><b>Cancellation Policy</b></div>
                                                    <div data-repeater-item>
                                                        <div class="row d-flex align-items-end">
                                                            <div class="col-md-11 col-12">
                                                                <div class="mb-1">
                                                                    <textarea name="" id="" cols="30" rows="1" class="form-control"></textarea>
                                                                </div>
                                                            </div>

                                                            <div class="col-md-1 col-12 mb-50">
                                                                <div class="mb-1">
                                                                    <button class="btn btn-outline-danger text-nowrap px-1" data-repeater-delete type="button">
                                                                        <i title="Delete" data-feather="x" class="me-25"></i>
                                                                    </button>
                                                                </div>
                                                            </div>
                                                        </div>
                                                    </div>

                                                </div>
                                                <div class="row">
                                                    <div class="col-12">
                                                        <button class="btn btn-icon btn-primary" type="button" data-repeater-create>
                                                            <i data-feather="plus" class="me-25"></i>
                                                            <span>Add New</span>
                                                        </button>
                                                    </div>
                                                </div>

                                            </div>
                                            <!-- Cancel Policy  -->

                                            <!-- Cancel Policy Settings -->

                                            <div class="repeater_fields col-sm-12">
                                                <div data-repeater-list="cancel_policy_setting">
                                                    <div class="border-bottom m-b-10 m-t-10"><b>Cancellation Policy Setting</b></div>
                                                    <div data-repeater-item>
                                                        <div class="row d-flex align-items-end">
                                                            <div class="col-md-3 col-5">
                                                                <div class="mb-1">
                                                                    <label class="form-label" for="itemname"><?= __('Hours') ?></label>
                                                                    <input type="text" name="hours" class="form-control">
                                                                </div>
                                                            </div>
                                                            <div class="col-md-3 col-5">
                                                                <div class="mb-1">
                                                                    <label class="form-label" for="itemname"><?= __('Charge') ?></label>
                                                                    <input type="text" name="charge" class="form-control">
                                                                </div>
                                                            </div>
                                                            <div class="col-md-2 col-2">
                                                                <div class="">
                                                                    <button class="btn btn-outline-danger text-nowrap px-1 m-t-m-50" data-repeater-delete type="button">
                                                                        <i title="Delete" data-feather="x" class="me-25"></i>
                                                                    </button>
                                                                </div>
                                                            </div>
                                                        </div>
                                                    </div>
                                                </div>
                                                <div class="row">
                                                    <div class="col-12">
                                                        <button class="btn btn-icon btn-primary" type="button" data-repeater-create>
                                                            <i data-feather="plus" class="me-25"></i>
                                                            <span>Add New</span>
                                                        </button>
                                                    </div>
                                                </div>

                                            </div>


                                            <!-- Cancel Policy Settings Ends -->




                                        </div>

                                    </div>

                                    <div id="hostpital-details-info" class="content" role="tabpanel" aria-labelledby="hospital-details-modern-trigger">
                                        <div class="row">
                                            <label class="form-label"
                                                   for="images_list"><?= _('Hospital Gallery Images') ?></label>

                                            <div class="dropzone-area dropzone" id="id_dropzone">

                                                <input type="file" name="gallery_images[]" style="display: none">

                                            </div>
                                            <select name="images_list[]" id="images_list" multiple style="display: none"></select>
                                        </div>


                                        <div class="row">
                                            <div class="mb-1 col-md-6">
                                                <label class="form-label"
                                                       for="pancard_number"><?= _('PAN No') ?></label>
                                                <input type="text" name="pancard_number"
                                                       class="form-control"
                                                       placeholder="<?= _('PAN No') ?>"
                                                       value="<?= post_display('pancard_number') ?>" />
                                            </div>
                                            <div class="mb-1 col-md-6">
                                                <label class="form-label"
                                                       for="gst_number"><?= _('GST No') ?></label>
                                                <input type="text" name="gst_number"
                                                       class="form-control"
                                                       placeholder="<?= _('GST No') ?>"
                                                       value="<?= post_display('gst_number') ?>"/>
                                            </div>

                                        </div>

                                        <div class="row">

                                            <div class="mb-1 col-md-6">
                                                <label class="form-label"
                                                       for="pan_card_document"><?= _('PAN Card Document') ?></label>

                                                <div data-provides="fileupload"
                                                     class="fileupload fileupload-new">

                                                    <div style="width: 200px; height: 150px;"
                                                         class="fileupload-new thumbnail">
                                                             <?php $src = '/admin-assets/images/icons/file-icons/no_document.png'; ?>
                                                        <img alt="" src="<?php echo $src; ?>">
                                                    </div>

                                                    <div
                                                        style="max-width: 200px; max-height: 150px; line-height: 20px;"
                                                        class="fileupload-preview fileupload-exists thumbnail"></div>

                                                    <div>
                                                        <span class="btn btn-file"><span
                                                                class="fileupload-new">Select document</span>
                                                            <span class="fileupload-exists">Change</span>
                                                            <input type="file"
                                                                   name="pancard_document"></span>
                                                    </div>
                                                </div>


                                            </div>

                                            <div class="mb-1 col-md-6">
                                                <label class="form-label"
                                                       for="gst_certificate"><?= _('GST Certificate') ?></label>

                                                <div data-provides="fileupload"
                                                     class="fileupload fileupload-new">

                                                    <div style="width: 200px; height: 150px;"
                                                         class="fileupload-new thumbnail">
                                                             <?php $src = '/admin-assets/images/icons/file-icons/no_document.png'; ?>
                                                        <img alt="" src="<?php echo $src; ?>">
                                                    </div>

                                                    <div
                                                        style="max-width: 200px; max-height: 150px; line-height: 20px;"
                                                        class="fileupload-preview fileupload-exists thumbnail"></div>

                                                    <div>
                                                        <span class="btn btn-file"><span
                                                                class="fileupload-new">Select document</span>
                                                            <span class="fileupload-exists">Change</span>
                                                            <input type="file"
                                                                   name="gst_certificate"></span>
                                                    </div>
                                                </div>


                                            </div>

                                        </div>
                                        <div class="row">
                                            <div class="mb-1 col-md-6">
                                                <label class="form-label"
                                                       for="bank_account_number"><?= _('Bank Account Number') ?></label>
                                                <input type="text" name="bank_account_number"
                                                       class="form-control"
                                                       placeholder="<?= _('Bank Account Number') ?>"
                                                       value="<?= post_display('bank_account_number') ?>"/>
                                            </div>
                                            <div class="mb-1 col-md-6">
                                                <label class="form-label"
                                                       for="bank_account_name"><?= _('Bank Account Name') ?></label>
                                                <input type="text" name="bank_account_name"
                                                       class="form-control"
                                                       placeholder="<?= _('Bank Account Name') ?>"
                                                       value="<?= post_display('bank_account_name') ?>"/>
                                            </div>

                                        </div>
                                        <div class="row">
                                            <div class="mb-1 col-md-6">
                                                <label class="form-label"
                                                       for="bank_account_number"><?= _('Bank Name') ?></label>
                                                <input type="text" name="bank_name"
                                                       class="form-control"
                                                       placeholder="<?= _('Bank Account Number') ?>"
                                                       value="<?= post_display('bank_name') ?>"/>
                                            </div>
                                            <div class="mb-1 col-md-6">
                                                <label class="form-label"
                                                       for="bank_ifsc_code"><?= _('IFSC Code') ?></label>
                                                <input type="text" name="bank_ifsc_code"
                                                       class="form-control"
                                                       placeholder="<?= _('IFSC Code') ?>"
                                                       value="<?= post_display('bank_ifsc_code') ?>"/>
                                            </div>

                                        </div>

                                    </div>
                                </div>
                            </div>

                        </section>

                        <div class="row" data-select2-id="12">
                            <div class="col-12">
                                <button type="submit" class="btn btn-primary mt-1 me-1 waves-effect waves-float waves-light">Save changes</button>
                                <a class="btn btn-outline-secondary mt-1 waves-effect" href="{{ route("admin.hospital") }}">Back</a>
                            </div>
                        </div>
                    </form>
                    <!--/ form -->
                </div>
            </div>

        </div>


    </div>
</div>
@endsection
@section('script')
<script src="https://cdnjs.cloudflare.com/ajax/libs/jqueryui/1.13.2/jquery-ui.min.js"></script>
<script>
    $(document).ready(function () {
        $(".repeater_fields").repeater();

        $('.dropzone').sortable({
            items: '.dz-preview',
            cursor: 'move',
            opacity: 0.5,
            containment: '.dropzone',
            distance: 20,
            tolerance: 'pointer',
            stop: function () {
                var imageName = [];
                $('#images_list').find('option').remove();
                $('.dropzone .dz-preview .dz-filename [data-dz-name]').each(function (count, el) {
                    imageName.push(el.innerHTML);
                    $("#images_list").append(`<option value="${el.innerHTML}" selected>${el.innerHTML}</option>`);
                });

            }
        });
    });
    Dropzone.autoDiscover = false;
    $("#id_dropzone").dropzone({
        acceptedFiles: "image/*",
        maxFiles: 10,
        addRemoveLinks: true,
        method: "post",
        url: "<?= route("admin.hospital.gallery_images", 0) ?>",
        success: function (file, response) {
            $("#images_list").append(`<option value="${response}" selected>${response}</option>`);
            var fileuploded = file.previewElement.querySelector("[data-dz-name]");
            fileuploded.innerHTML = response;

        },
        sending: function (file, xhr, formData) {
            formData.append("_token", "{{ csrf_token() }}");
        },
        removedfile: function (file) {
            var fileuploded = file.previewElement.querySelector("[data-dz-name]");

            var fileName = fileuploded.innerHTML;


            $("#images_list").find(`[value="${fileName}"]`).remove();
            console.log(fileName);
            file.previewElement.remove();
            $.ajax({
                type: 'POST',
                url: "<?= route("admin.hospital.gallery_images_delete", 0) ?>",
                data: {name: fileName, request: 'remove', '_token': "{{ csrf_token() }}"},
                sucess: function (data) {
                    file.previewElement.remove();
                }
            });
        },
    });

</script>
@endsection
