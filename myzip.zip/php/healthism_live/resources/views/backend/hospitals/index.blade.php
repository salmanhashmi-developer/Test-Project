@extends("backend.layouts.master")
@section('title') Hospital List @endsection
@section('content')

    <!-- BEGIN: Content-->
    <div class="app-content content ">

        <div class="content-wrapper p-0">

            <div class="content-body" id="ajax_content">
                @include('backend.message')
                @include("backend.hospitals.ajax_content")
            </div>


        </div>
    </div>
@endsection
