<div class="row">
    <form class="" method="POST" action="{{ route('admin.doctor.hospital.mapping') }}" id="search_form" onsubmit="return false">
        {{ csrf_field() }}
        <div class="col-12">
            <div class="card">
                <div class="card-header border-bottom">
                    <h4 class="card-title">{{ __("Doctor Hospital Mapping")  }}</h4>
                    <div
                        class="dt-action-buttons d-flex align-items-center justify-content-center justify-content-lg-end flex-lg-nowrap flex-wrap">
                        <div class="dt-buttons d-inline-flex">
                            <a class="dt-button add-new btn btn-primary" href="{{ route('admin.doctor.hospital.mapping.add')}}">{{ __("Add New Mapping")  }}</a>
                        </div>
                    </div>
                </div>
                <!--Search Form -->
                <div class="card-body mt-2">
                    <input type="hidden" name="page" id="page" value="{{ empty(app('request')->input('page')) ? 1 : app('request')->input('page')  }}">
                    <input type="hidden" name="sort_field" id="sort_field" value="{{ app('request')->input('sort_field') }}">
                    <input type="hidden" name="sort_action" id="sort_action" value="{{ app('request')->input('sort_action') }}">
                    <div class="row g-1 mb-md-1">
                        <div class="col-md-4">
                            <label class="form-label">Doctor</label>
                            <input type="text" class="form-control dt-input dt-full-name" placeholder="Doctor Name" name="doctor_name" value="{{app('request')->input('doctor_name')}}">
                        </div>
                        <div class="col-md-4">
                            <label class="form-label">Hospital</label>
                            <input type="text" class="form-control dt-input dt-full-name" placeholder="Hospital Name" name="hospital_name" value="{{app('request')->input('hospital_name')}}">
                        </div>
                        <div class="col-md-4">
                            <label class="form-label"></label>
                            <button type="submit" class="btn btn-primary mt-2 waves-effect waves-float waves-light">Search</button>
                        </div>
                    </div>
                </div>
                <hr class="my-0">
                <div class="card-datatable">
                    <?php echo parPageRecordDropDown() ?>
                    @if(!$mapping->isEmpty())
                    @php $start = $mapping->firstItem(); @endphp
                    <div class="table-responsive">
                        <table class="table table-bordered table-hover">
                            <thead>
                                <tr role="row">
                                    <th>No</th>
                                    <th><?php echo sort_field_display('hospital_id', 'Hospital'); ?></th>
                                    <th><?php echo sort_field_display('doctor_id', 'Doctor'); ?></th>
                                    <th>Fees</th>
                                    <th>Discount</th>
                                    <th title="Video Consultation">Video Cons.</th>
                                    <th>Slot Type</th>
                                    <th>Action</th>
                                </tr>
                            </thead>
                            <tbody>
                                @foreach($mapping as $mappingData)
                                <tr class="f-12">
                                    <td><?= $start++; ?></td>
                                    <td valign="top">
                                        {{!empty($mappingData->hospital)?$mappingData->hospital->name:'-'}}<br>
                                        <span class="f-11">({{!empty($mappingData->hospital->area)?$mappingData->hospital->area:'-' }})</span>
                                    </td>
                                    <td valign="top">{{ $mappingData->doctor->first_name .' '.$mappingData->doctor->last_name  }}
                                        <br><span class="f-11">{{ $mappingData->doctor->phone}}</span>
                                    </td>
                                    <td valign="top">{{ $mappingData->fees}}</td>
                                    <td valign="top">{{ $mappingData->discount}}</td>
                                    <td valign="top">{{ $mappingData->video_consultation_available==1?'YES':'NO'}}</td>
                                    <td valign="top">{{ $mappingData->slot_type}}</td>
                                    <td>
                                        <div class="dropdown">
                                            <button type="button" class="btn btn-sm dropdown-toggle hide-arrow py-0" data-bs-toggle="dropdown">
                                                <i data-feather="more-vertical"></i>
                                            </button>
                                            <div class="dropdown-menu dropdown-menu-end">
                                                <a class="dropdown-item" href="{{  route('admin.doctor.hospital.mapping.view', ['id'=>$mappingData->id] )  }}">
                                                    <i data-feather="file-text" class="me-50"></i>
                                                    <span>View</span>
                                                </a>
                                                <a class="dropdown-item" href="{{  route('admin.doctor.hospital.slot', ['id'=>$mappingData->id] )  }}">
                                                    <i data-feather="grid" class="me-50"></i>
                                                    <span>Slot</span>
                                                </a>
                                                <a class="dropdown-item" href="{{  route('admin.doctor.hospital.mapping.edit', ['id'=>$mappingData->id] )  }}">
                                                    <i data-feather="edit-2" class="me-50"></i>
                                                    <span>Edit</span>
                                                </a>
                                            </div>
                                        </div>
                                    </td>
                                </tr>
                                @endforeach
                            </tbody>
                        </table>
                    </div>
                    @endif
                    <?php echo pagination($mapping) ?>
                </div>
            </div>
        </div>
    </form>
</div>
