@extends("backend.layouts.master")
@section('title') Doctor Hospital Mapping @endsection
@section('content')
<!-- BEGIN: Content-->
<!-- Vendor files -->
<script>
    var csrf_field = "{{ csrf_token() }}";
</script>
<script src="{{ Helper::static_asset('admin-assets/vendors/js/pickers/pickadate/picker.js') }}"></script>
<script src="{{ Helper::static_asset('admin-assets/vendors/js/pickers/pickadate/picker.date.js') }}"></script>
<script src="{{ Helper::static_asset('admin-assets/vendors/js/pickers/pickadate/picker.time.js') }}"></script>
<script src="{{ Helper::static_asset('admin-assets/vendors/js/extensions/moment.min.js') }}"></script>
<script src="{{ Helper::static_asset('admin-assets/js/module/doctor-hospital-slot.js') }}"></script>

<!-- Template files -->
<link rel="stylesheet" type="text/css" href="{{ Helper::static_asset('admin-assets/vendors/css/pickers/pickadate/pickadate.css') }}">
<div class="app-content content" id="add_edit_slot">
    <div class="content-wrapper p-0">
        <div class="content-body">
            <div class="card" data-select2-id="14">
                <div class="card-header border-bottom">
                    <h4 class="card-title">Doctor Hospital Slot </h4>
                </div>
                <div class="card-body py-2 my-25" data-select2-id="53">
                    @include('backend.message')

                    <form class="needs-validation" method="POST" action="{{route('admin.doctor.hospital.slot.store')}}" method="POST" enctype="multipart/form-data" novalidate>
                        {{ csrf_field() }}
                        <section class="modern-horizontal-wizard">
                            <div>
                                <div class="row">
                                    <div class="mb-1 col-md-12"><div id="error-alert" class="error"></div></div>
                                </div>
                                <div class="row">
                                    <div class="mb-1 col-md-2">
                                        <label class="form-label">Start Time</label>
                                        <input id="start_time" value="10:00" type="text" class="form-control time-picker"/>
                                    </div>
                                    <div class="mb-1 col-md-2">
                                        <label class="form-label">End Time</label>
                                        <input id="end_time" value="13:00" type="text" class="form-control time-picker"/>
                                    </div>
                                    <div class="mb-1 col-md-2">
                                        <label class="form-label">Interval</label>
                                        <input id="interval_time" value="00:30" type="text" class="form-control time-picker"/>
                                    </div>
                                    <div class="mb-1 col-md-2">
                                        <label class="form-check-label mb-50" for="offline_available">Offline Available</label>
                                        <div class="form-check form-check-success form-switch">
                                            <input type="checkbox" checked="true" name="offline_available" class="form-check-input"/>
                                        </div>
                                    </div>
                                    <div class="mb-1 col-md-2">
                                        <label class="form-check-label mb-50" for="video_available">Video Available</label>
                                        <div class="form-check form-check-success form-switch">
                                            <input type="checkbox" name="video_available" class="form-check-input"/>
                                        </div>
                                    </div>
                                    <div class="mb-1 col-md-2">
                                        <a id="add-time" class="btn btn-primary btn-block mt-2 me-1 waves-effect waves-float waves-light">Add</a>
                                    </div>
                                </div>
                            </div>
                            <h5 class="fw-bolder border-bottom pb-50 pt-50 mb-1">Slot Details</h5>
                                <!-- vertical tab pill -->
                                <div class="row">
                                    <div class="col-lg-3 col-md-4 col-sm-12">
                                        <div class="faq-navigation d-flex justify-content-between flex-column mb-2 mb-md-0">
                                            <ul class="nav nav-pills nav-left flex-column" role="tablist">
                                                <li class="nav-item">
                                                    <a class="nav-link active" data-key="Mon" data-bs-toggle="pill" href="#slot-monday" aria-expanded="true" role="tab" aria-selected="true">
                                                        <span class="fw-bold">Monday</span>
                                                    </a>
                                                </li>
                                                <li class="nav-item">
                                                    <a class="nav-link" data-key="Tue" data-bs-toggle="pill" href="#slot-tuesday" aria-expanded="false" role="tab" aria-selected="false">
                                                        <span class="fw-bold">Tuesday</span>
                                                    </a>
                                                </li>
                                                <li class="nav-item">
                                                    <a class="nav-link" data-key="Wed" data-bs-toggle="pill" href="#slot-wednesday" aria-expanded="false" role="tab" aria-selected="false">
                                                        <span class="fw-bold">Wednesday</span>
                                                    </a>
                                                </li>
                                                <li class="nav-item">
                                                    <a class="nav-link" data-key="Thu" data-bs-toggle="pill" href="#slot-thursday" aria-expanded="false" role="tab" aria-selected="false">
                                                        <span class="fw-bold">Thursday</span>
                                                    </a>
                                                </li>
                                                <li class="nav-item">
                                                    <a class="nav-link" data-key="Fri" data-bs-toggle="pill" href="#slot-friday" aria-expanded="false" role="tab" aria-selected="false">
                                                        <span class="fw-bold">Friday</span>
                                                    </a>
                                                </li>
                                                <li class="nav-item">
                                                    <a class="nav-link" data-key="Sat" data-bs-toggle="pill" href="#slot-saturday" aria-expanded="false" role="tab" aria-selected="false">
                                                        <span class="fw-bold">Saturday</span>
                                                    </a>
                                                </li>
                                                <li class="nav-item">
                                                    <a class="nav-link" data-key="Sun"  data-bs-toggle="pill" href="#slot-sunday" aria-expanded="false" role="tab" aria-selected="false">
                                                        <span class="fw-bold">Sunday</span>
                                                    </a>
                                                </li>
                                            </ul>
                                        </div>
                                    </div>

                                    <div class="col-lg-9 col-md-8 col-sm-12">
                                        <!-- pill tabs tab content -->
                                        <div class="tab-content">
                                            <div role="tabpanel" data-tab="Mon" class="tab-pane active" id="slot-monday" aria-labelledby="slot-monday" aria-expanded="true">
                                                <div class="table-responsive">
                                                    <table class="table">
                                                        <thead>
                                                            <tr><th class="text-center" colspan="5">Monday Slot</th></tr>
                                                            <tr><th>Start Time</th><th>End Time</th><th>Is Offline</th><th>Is Video</th><th>Actions</th></tr>
                                                        </thead>
                                                        <tbody>
<!--                                                            <tr>
                                                                <td><span class="fw-bold">10:00 AM</span></td>
                                                                <td><span class="fw-bold">10:00 PM</span></td>
                                                                <td>Yes</td>
                                                                <td>No</td>
                                                                <td>
                                                                    <a data-action="delete" class="badge rounded-pill badge-light-danger me-1" href="#">
                                                                        <svg xmlns="http://www.w3.org/2000/svg" width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="feather feather-trash me-50"><polyline points="3 6 5 6 21 6"></polyline><path d="M19 6v14a2 2 0 0 1-2 2H7a2 2 0 0 1-2-2V6m3 0V4a2 2 0 0 1 2-2h4a2 2 0 0 1 2 2v2"></path></svg>
                                                                        <span>Delete</span>
                                                                    </a>
                                                                </td>
                                                            </tr>-->
                                                        </tbody>
                                                    </table>
                                                </div>
                                            </div>
                                            <div class="tab-pane" data-tab="Tue" id="slot-tuesday" role="tabpanel" aria-labelledby="slot-tuesday" aria-expanded="false">
                                                <div class="table-responsive">
                                                    <table class="table">
                                                        <thead>
                                                            <tr><th class="text-center" colspan="5">Tuesday Slot</th></tr>
                                                            <tr><th>Start Time</th><th>End Time</th><th>Is Offline</th><th>Is Video</th><th>Actions</th></tr>
                                                        </thead>
                                                        <tbody></tbody>
                                                    </table>
                                                </div>
                                            </div>
                                            <div class="tab-pane" data-tab="Wed" id="slot-wednesday" role="tabpanel" aria-labelledby="slot-wednesday" aria-expanded="false">
                                                <div class="table-responsive">
                                                    <table class="table">
                                                        <thead>
                                                            <tr><th class="text-center" colspan="5">Wednesday Slot</th></tr>
                                                            <tr><th>Start Time</th><th>End Time</th><th>Is Offline</th><th>Is Video</th><th>Actions</th></tr>
                                                        </thead>
                                                        <tbody></tbody>
                                                    </table>
                                                </div>
                                            </div>
                                            <div class="tab-pane" data-tab="Thu" id="slot-thursday" role="tabpanel" aria-labelledby="slot-thursday" aria-expanded="false">
                                                <div class="table-responsive">
                                                    <table class="table">
                                                        <thead>
                                                            <tr><th class="text-center" colspan="5">Thursday Slot</th></tr>
                                                            <tr><th>Start Time</th><th>End Time</th><th>Is Offline</th><th>Is Video</th><th>Actions</th></tr>
                                                        </thead>
                                                        <tbody></tbody>
                                                    </table>
                                                </div>
                                            </div>
                                            <div class="tab-pane" data-tab="Fri" id="slot-friday" role="tabpanel" aria-labelledby="slot-friday" aria-expanded="false">
                                                <div class="table-responsive">
                                                    <table class="table">
                                                        <thead>
                                                            <tr><th class="text-center" colspan="5">Friday Slot</th></tr>
                                                            <tr><th>Start Time</th><th>End Time</th><th>Is Offline</th><th>Is Video</th><th>Actions</th></tr>
                                                        </thead>
                                                        <tbody></tbody>
                                                    </table>
                                                </div>
                                            </div>
                                            <div class="tab-pane" data-tab="Sat" id="slot-saturday" role="tabpanel" aria-labelledby="slot-saturday" aria-expanded="false">
                                                <div class="table-responsive">
                                                    <table class="table">
                                                        <thead>
                                                            <tr><th class="text-center" colspan="5">Saturday Slot</th></tr>
                                                            <tr><th>Start Time</th><th>End Time</th><th>Is Offline</th><th>Is Video</th><th>Actions</th></tr>
                                                        </thead>
                                                        <tbody></tbody>
                                                    </table>
                                                </div>
                                            </div>
                                            <div class="tab-pane" data-tab="Sun" id="slot-sunday" role="tabpanel" aria-labelledby="slot-sunday" aria-expanded="false">
                                                <div class="table-responsive">
                                                    <table class="table">
                                                        <thead>
                                                            <tr><th class="text-center" colspan="5">Sunday Slot</th></tr>
                                                            <tr><th>Start Time</th><th>End Time</th><th>Is Offline</th><th>Is Video</th><th>Actions</th></tr>
                                                        </thead>
                                                        <tbody></tbody>
                                                    </table>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                        </section>
                        <section form-data-section="">
                            <input type="hidden" name="hospital_id" value="<?= $mapping->hospital_id ?>" />
                            <input type="hidden" name="doctor_id" value="<?= $mapping->doctor_id ?>" />
                            <input type="hidden" name="slot_data_obj" value='<?= $mapping->slot ?>' />
                            <input type="hidden" name="delete_slot_data_obj" value='' />
                        </section>

                        <div class="row" data-select2-id="12">
                            <div class="col-12 text-end">
                                <input type="hidden" name="dayTime" id="day-time"/>
                                <button type="submit" class="btn btn-primary mt-1 me-1 waves-effect waves-float waves-light">Save changes</button>
                                <a class="btn btn-outline-secondary mt-1 waves-effect" href="{{ route('admin.doctor.hospital.mapping') }}">Back</a>
                            </div>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>
</div>
@endsection
@section('script')
<script type="text/javascript">
    $(document).ready(initDoctorHospitalSlot);
</script>

@endsection
