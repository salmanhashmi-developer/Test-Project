@extends("backend.layouts.master")
@section('title') Doctor Hospital Mapping @endsection
@section('content')

<!-- BEGIN: Content-->
<div class="app-content content ">

    <div class="content-wrapper p-0">

        <div class="content-body">
            @include('backend.message')
            <div class="card" data-select2-id="14">
                <div class="card-header border-bottom">
                    <h4 class="card-title">Doctor Hospital Mapping Detail</h4>
                </div>
                <div class="card-body py-2 my-25" data-select2-id="53">
                    <!-- header section -->

                    <!-- Modern Horizontal Wizard -->
                    <section class="modern-horizontal-wizard">
                        <div class="bs-stepper wizard-modern modern-wizard-example">
                            <div class="bs-stepper-content">
                                <div class="" role="tabpanel" aria-labelledby="account-details-modern-trigger">
                                    <div class="d-flex">
                                        <div class="col-xl-4 col-lg-4 col-md-4  d-flex align-items-start me-2">
                                            <div class="info-container">
                                                <ul class="list-unstyled">
                                                    <li class="mb-75">
                                                        <div class="border-bottom m-b-10 f-17"><b>Doctor Detail</b></div>
                                                    </li>
                                                    <li class="mb-75 f-14">
                                                        <span class="fw-bolder me-25">Name :</span>
                                                        <span>{{ $mapping->doctor->first_name  }} {{ $mapping->doctor->last_name  }}</span>
                                                    </li>
                                                    <li class="mb-75 f-14">
                                                        <span class="fw-bolder me-25">Phone :</span>
                                                        <span>{{ $mapping->doctor->phone}}</span>
                                                    </li>
                                                    <li class="mb-75 f-14">
                                                        <span class="fw-bolder me-25"> Specialization :</span>
                                                        <span>{{ $mapping->doctor->specialization}}</span>
                                                    </li>

                                                </ul>

                                            </div>
                                        </div>
                                        <div class="col-xl-4 col-lg-4 col-md-4  d-flex align-items-start me-2">
                                            <div class="info-container">
                                                <ul class="list-unstyled">
                                                    <li class="mb-75">
                                                        <div class="border-bottom m-b-10 f-17"><b>Hospital Detail</b></div>
                                                    </li>
                                                    <li class="mb-75 f-14">
                                                        <span class="fw-bolder me-25">Name :</span>
                                                        <span>{{ $mapping->hospital->name  }}</span>
                                                    </li>
                                                    <li class="mb-75 f-14">
                                                        <span class="fw-bolder me-25">Area :</span>
                                                        <span>{{ $mapping->hospital->area}}</span>
                                                    </li>
                                                    <li class="mb-75 f-14">
                                                        <span class="fw-bolder me-25"> Type :</span>
                                                        <span>{{ $mapping->hospital->type}}</span>
                                                    </li>

                                                </ul>

                                            </div>
                                        </div>
                                        <div class="col-xl-4 col-lg-4 col-md-4  d-flex align-items-start me-2">
                                            <div class="info-container">
                                                <ul class="list-unstyled">
                                                    <li class="mb-75">
                                                        <div class="border-bottom m-b-10 f-17"><b>Mapping Detail</b></div>
                                                    </li>
                                                    <li class="mb-75 f-14">
                                                        <span class="fw-bolder me-25">Fees :</span>
                                                        <span>{{ $mapping->fees  }}</span>
                                                    </li>
                                                    <li class="mb-75 f-14">
                                                        <span class="fw-bolder me-25">Discount :</span>
                                                        <span>{{ $mapping->discount}}</span>
                                                    </li>
                                                    <li class="mb-75 f-14">
                                                        <span class="fw-bolder me-25">Slot Type :</span>
                                                        <span>{{ $mapping->slot_type}}</span>
                                                    </li>
                                                    <li class="mb-75 f-14">
                                                        <span class="fw-bolder me-25">Video Consultation Available :</span>
                                                        <span>{{ $mapping->video_consultation_available}}</span>
                                                    </li>
                                                </ul>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                <div class="m-t-35" role="tabpanel" aria-labelledby="account-details-modern-trigger">
                                    <div class="border-bottom m-b-10 f-17"><b>Visit Time Detail</b></div>
                                    <div class="d-flex">
                                        <div class="col-xl-12 col-lg-12 col-md-12  d-flex align-items-start me-2">
                                            <div class="info-container m-t-10">
                                                <?php
                                                if (!empty($mapping->timing_json)) {
                                                    $timingArr = json_decode($mapping->timing_json, true);
                                                    if (!empty($timingArr)) {
                                                        $html = '<table class="table table-bordered table-hover f-14">';
                                                        foreach ($timingArr as $value) {
                                                            if (!empty($value['times'])) {
                                                                foreach ($value['times'] as $timing) {
                                                                    $html .= "<tr>";
                                                                    $html .= "<td>" . $value['day'] . "</td>";
                                                                    $html .= "<td>" . $timing['start_time'] . ' - ' . $timing['end_time'] . "</td>";
                                                                    $html .= "</tr>";
                                                                }
                                                            }
                                                        }
                                                        $html .= "</table>";
                                                        echo $html;
                                                    }
                                                } else {
                                                    echo "Visit Time Not Available";
                                                }
                                                ?>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </section>
                    <!-- /Modern Horizontal Wizard -->
                    <div class="row" data-select2-id="12">
                        <div class="col-12">
                            <a href="{{ route('admin.doctor.hospital.mapping.edit', ['id'=>$mapping->id] )  }}" class="btn btn-primary me-1 waves-effect waves-float waves-light" > Edit</a>
                            <a href="{{route('admin.doctor.hospital.mapping')}}" class="btn btn-outline-secondary waves-effect">Back</a>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
@endsection

