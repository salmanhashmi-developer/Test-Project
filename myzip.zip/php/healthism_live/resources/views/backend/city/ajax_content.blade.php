
<div class="row">
    <form class="" method="POST" action="{{ route('admin.city') }}" id="search_form" onsubmit="return false">
        {{ csrf_field() }}
        <div class="col-12">
            <div class="card">
                <div class="card-header border-bottom">
                    <h4 class="card-title">{{ __("City List")  }}</h4>
                    <div class="dt-action-buttons d-flex align-items-center justify-content-center justify-content-lg-end flex-lg-nowrap flex-wrap">
                        <div class="dt-buttons d-inline-flex">
                            <a class="dt-button add-new btn btn-primary" href="{{ route('admin.city.add')  }}">{{ __("Add New City")  }}</a> 
                        </div>
                    </div>
                </div>
                <!--Search Form -->
                <div class="card-body mt-2">
                    <input type="hidden" name="page" id="page" value="{{ empty(app('request')->input('page')) ? 1 : app('request')->input('page')  }}">
                    <div class="row g-1 mb-md-1">
                        <div class="col-md-4">
                            <label class="form-label">Name</label>
                            <input type="text" class="form-control dt-input dt-full-name" placeholder="Name" name="name" value="{{app('request')->input('name')}}">
                        </div>
                        <div class="col-md-4">
                            <label class="form-label">State</label>
                            <select name="state_id" class="select2 form-select form-control">
                                <option value="">Select State</option>
                                <?php foreach ($stateList as $state): ?>
                                    <option value="{{ $state->id }}" {{ app('request')->input('state_id') == $state->id ? "selected" : ''  }}>{{$state->name}}</option><?php
                                endforeach;
                                ?>
                            </select>
                        </div>
                        <div class="col-md-4">
                            <label class="form-label"></label>
                            <button type="submit" class="btn btn-primary mt-2 waves-effect waves-float waves-light">Search</button>
                        </div>
                    </div>
                </div>
                <hr class="my-0">
                <div class="card-datatable">
                    <?php echo parPageRecordDropDown() ?>
                    @if(!$cityList->isEmpty())
                    @php $start = $cityList->firstItem(); @endphp
                    <div class="table-responsive">

                        <table class="table table-bordered table-hover">
                            <thead>
                                <tr role="row">
                                    <th>No.</th>
                                    <th>Name</th>
                                    <th>State</th>
                                    <th>Actions</th>
                                </tr>
                            </thead>
                            <tbody>
                                @foreach($cityList as $city)
                                <tr class="f-12">
                                    <td><?= $start++; ?></td>
                                    <td valign="top">{{ $city->name }}</td>
                                    <td valign="top">{{ $city->state->name}}</td>
                                    <td>
                                        <div class="text-nowrap">
                                            <a title="Edit" href="{{  route('admin.city.edit', ['id'=>$city->id] )  }}">
                                                <i data-feather="edit" class="me-50 text-dark"></i>
                                            </a>
                                        </div>
                                    </td>
                                </tr>
                                @endforeach
                            </tbody>
                        </table>
                    </div>
                    @endif
                    <?php echo pagination($cityList) ?>
                </div>
            </div>
        </div>
    </form>

</div>
