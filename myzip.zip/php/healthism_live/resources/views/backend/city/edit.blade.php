@extends("backend.layouts.master")
@section('title') City Edit @endsection
@section('content')

<!-- BEGIN: Content-->
<div class="app-content content ">

    <div class="content-wrapper p-0">

        <div class="content-body">

            <div class="card" data-select2-id="14">
                <div class="card-header border-bottom">
                    <h4 class="card-title">City Details Edit</h4>
                </div>
                <div class="card-body py-2 my-25" data-select2-id="53">
                    <!-- header section -->

                    <!-- form -->
                    @include('backend.message')

                    <form class="needs-validation" method="POST" action="{{route('admin.city.update', $city->id)}}" method="POST" enctype="multipart/form-data" novalidate>
                        {{ csrf_field() }}

                        <div class="row" data-select2-id="12">
                            <div class="col-12 col-sm-12 mb-1">
                                <label class="form-label" for="name"><?= _('Name') ?></label>
                                <input type="text" name="name" class="form-control" placeholder="<?= _('Name') ?>" value="{{ post_display('name',$city->name)  }}" required/>
                            </div>
                            <div class="col-12 col-sm-12 mb-1">
                                <label class="form-label" for="state_id">State</label>
                                <select class="form-control select2" name="state_id" required/>
                                    <?php
                                    $setValues = $city->state_id;
                                    ?>
                                    @foreach($stateList as $state)
                                    <option value="<?= $state->id ?>" <?=  $state->id == $setValues ? 'selected' : '' ?>><?=  $state->name ?></option>
                                    @endforeach
                                </select>

                            </div>
                            <div class="col-12">
                                <button type="submit" class="btn btn-primary mt-1 me-1 waves-effect waves-float waves-light">Save changes</button>
                                <a class="btn btn-outline-secondary mt-1 waves-effect" href="{{ route('admin.city') }}">Back</a>
                            </div>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>
</div>
@endsection
