@extends("backend.layouts.master")
@section('title') Upload Test Report @endsection
@section('content')
<!-- BEGIN: Content-->
<div class="app-content content f-12">
    <div class="content-wrapper p-0">
        <div class="content-body">
            @include('backend.message')
            <div class="p-b-10"> <a href="{{route('admin.lab.booking.view', ['id'=>$order->id])}}"><i data-feather="arrow-left" class="me-50 text-dark"></i>Show Order Details</a></div>
            <b class="m-l-20">Order {{$order->order->order_code}}</b>
            <p class="m-l-20"> From {{$order->user->first_name.' '.$order->user->last_name}}</p>
            <div class="card" data-select2-id="14">
                <form class="needs-validation" method="POST" action="{{route('admin.lab.file.upload')}}" method="POST" enctype="multipart/form-data" novalidate>
                    {{ csrf_field() }}
                    <div class="card-body py-2 my-25" data-select2-id="53">
                        <!-- header section -->
                        <!-- Modern Horizontal Wizard -->
                        <section class="modern-horizontal-wizard">
                            <div class="bs-stepper wizard-modern modern-wizard-example">
                                <div class="row">
                                    <div id="order-modern">
                                        <div class="d-flex">
                                            <div class="row">
                                                <div class="col-md-12 header-title">
                                                    <span>Patient Details</span>
                                                </div>
                                                <div class="col-md-12">
                                                    <table class="table">
                                                        <thead>
                                                            <tr>
                                                                <th>Name</th>
                                                                <th>Mobile No.</th>
                                                                <th>Email</th>
                                                            </tr>
                                                        </thead> 
                                                        <tbody>
                                                            <tr>
                                                                <td>{{$order->user_patient->first_name.' '.$order->user_patient->last_name}}</td>
                                                                <td>{{$order->user_patient->mobile}}</td>
                                                                <td>{{$order->user_patient->email}}</td>
                                                            </tr>
                                                        </tbody>
                                                    </table>
                                                </div>
                                            </div>
                                        </div>
                                        <input type="hidden" name="image_prifix" value="LA-">
                                        <input type="hidden" name="service_ref_id" value="{{$order->lab_id}}">
                                        <input type="hidden" name="ref_id" value="{{$order->id}}">
                                        <input type="hidden" name="user_id" value="{{$order->user_id}}">
                                        <input type="hidden" name="service_id" value="{{SERVICE_LAB_REPORT}}">
                                        <div class="d-flex">
                                            <div class="row">
                                                <div class="col-md-12 header-title">
                                                    <span>Lab Details</span>
                                                </div>
                                                <div class="col-md-12">
                                                    <table class="table">
                                                        <thead>
                                                            <tr>
                                                                <th>Lab Name</th>
                                                                <th>Mobile No.</th>
                                                                <th>Address</th>
                                                            </tr>
                                                        </thead> 
                                                        <tbody>
                                                            <tr>
                                                                <td>{{$order->lab->name}}</td>
                                                                <td>{{$order->lab->mobile}}</td>
                                                                <td>{{$order->lab->address1.', '.$order->lab->address2.', '.$order->lab->area.', '.$order->lab->city->name.', '.$order->lab->state->name.'- '.$order->lab->pincode}}</td>
                                                            </tr>
                                                        </tbody>
                                                    </table>
                                                </div>
                                            </div>
                                        </div>
                                        <?php if (!empty($order->labBookingDetail)) { ?>
                                            <div class="d-flex">
                                                <div class="row">
                                                    <div class="col-md-12 header-title">
                                                        <span>Test List</span>
                                                    </div>
                                                    <div class="col-md-12">
                                                        <table class="table">
                                                            <thead>
                                                                <tr>
                                                                    <th>Name</th>
                                                                    <th>Amount</th>
                                                                </tr>
                                                            </thead> 
                                                            <tbody>
                                                                <?php
                                                                foreach ($order->labBookingDetail as $value) {
                                                                    ?>
                                                                    <tr>
                                                                        <td class="f-u">{{$value->test->name}}</td>
                                                                        <td>Rs.{{$value->amount}}</td>
                                                                    </tr>
                                                                    <?php
                                                                }
                                                                ?>
                                                            </tbody>
                                                        </table>
                                                    </div>
                                                </div>
                                            </div>
                                            <?php
                                        } else {
                                            echo 'Sorry, Test data not found.';
                                        }
                                        ?>
                                        <div class="d-flex">
                                            <div class="row">
                                                <div class="col-md-12 header-title">
                                                    <span>Upload Test Reports</span>
                                                </div>
                                                <div class="col-md-12">
                                                    <input type="file" placeholder="Upload Multiple File" class="form-control" name="new_file[]" multiple />
                                                </div>
                                            </div>
                                        </div>
                                        <?php if (!empty($files)) { ?>
                                            <div class="row">
                                                <?php foreach ($files as $file) { ?>
                                                    <div class="col-md-2 mt-1">
                                                        <a target="_blank" href="{{$file['file']}}">
                                                            <img src="/admin-assets/images/icons/pdf.png" alt="">
                                                            <p>{{$file['original_file_name']}}</p>
                                                            <a href="{{route('admin.lab.file.delete', ['id'=>$file['id'],'service_id'=>SERVICE_LAB_REPORT,'ref_id'=>$order->id])}}" class="btn btn-primary waves-effect">Delete</a>
                                                        </a>
                                                    </div>
                                                <?php } ?>
                                            </div>
                                        <?php } ?>
                                    </div>
                                </div>
                            </div>
                        </section>
                        <div class="row" data-select2-id="12">
                            <div class="col-12">
                                <button type="submit" class="btn btn-primary me-1 waves-effect waves-float waves-light">Save</button>
                                <a href="{{route('admin.lab.booking.view', ['id'=>$order->id])}}" class="btn btn-outline-secondary waves-effect">Back</a>
                            </div>
                        </div>
                    </div>
                </form>
            </div>
        </div>
    </div>
</div>
@endsection



