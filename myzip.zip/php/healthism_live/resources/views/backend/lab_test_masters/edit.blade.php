@extends("backend.layouts.master")
@section('title') Test Edit @endsection
@section('content')
<script type="text/javascript" src="{{ Helper::static_asset('admin-assets/js/module/common.js') }}"></script>
<script type="text/javascript" src="{{ Helper::static_asset('admin-assets/js/module/lab.js') }}"></script>
<script type="text/javascript">$(document).ready(initTestMaster);</script>

<!-- BEGIN: Content-->
<div class="app-content content ">

    <div class="content-wrapper p-0">

        <div class="content-body">

            <div class="card" data-select2-id="14">
                <div class="card-header border-bottom">
                    <h4 class="card-title">Test Details Edit</h4>
                </div>
                <div class="card-body py-2 my-25" data-select2-id="53">
                    <!-- header section -->

                    <!-- form -->
                    @include('backend.message')

                    <form class="needs-validation" method="POST" action="{{route('admin.test.update', $test->id)}}" method="POST" enctype="multipart/form-data" novalidate>
                        {{ csrf_field() }}


                        <section class="modern-horizontal-wizard">

                            <div class="bs-stepper wizard-modern modern-wizard-example">

                                <div class="bs-stepper-header">
                                    <div class="step" data-target="#account-details-modern" role="tab"
                                         id="test-details-modern-trigger">
                                        <button type="button" class="step-trigger">
                                            <span class="bs-stepper-box">
                                                <i data-feather="user" class="font-medium-3"></i>
                                            </span>
                                            <span class="bs-stepper-label">
                                                <span class="bs-stepper-title">Test Details</span>
                                            </span>
                                        </button>
                                    </div>


                                    <div class="line">
                                        <i data-feather="chevron-right" class="font-medium-2"></i>
                                    </div>
                                    <div class="step" data-target="#test-details-info" role="tab"
                                         id="test-details-info-trigger">
                                        <button type="button" class="step-trigger">
                                            <span class="bs-stepper-box">
                                                <i data-feather="file-text" class="font-medium-3"></i>
                                            </span>
                                            <span class="bs-stepper-label">
                                                <span class="bs-stepper-title">Additional Details</span>
                                            </span>
                                        </button>
                                    </div>
                                </div>

                                <div class="bs-stepper-content">
                                    <div id="account-details-modern" class="content" role="tabpanel" aria-labelledby="test-details-modern-trigger">
                                        <div class="content-header">
                                            <h5 class="mb-0"><?= ('Test Details') ?></h5>
                                        </div>
                                        <div class="row">
                                            <div class="mb-1 col-md-4">
                                                <label class="form-label" for="name"><?= _('Name*') ?></label>
                                                <input type="text" name="name" id="name" class="form-control" placeholder="<?= _('Test Name') ?>" value="<?= post_display('name', $test->name) ?>" required/>
                                            </div>
                                            <div class="mb-1 col-md-4">
                                                <?php
                                                $genderArr = explode(',', $test->gender);
                                                $male = $female = $other = "";
                                                foreach ($genderArr as $value) {
                                                    if ($value == 'Male') {
                                                        $male = ' selected="selected" ';
                                                    }
                                                    if ($value == 'Female') {
                                                        $female = ' selected="selected" ';
                                                    }
                                                    if ($value == 'Other') {
                                                        $other = ' selected="selected" ';
                                                    }
                                                }
                                                ?>
                                                <label class="form-label" for="gender"><?= _('Gender') ?></label>
                                                <select name="gender[]" class="form-select select2" id="gender" multiple>
                                                    <option value="Male" <?php echo $male; ?>>Male</option>
                                                    <option value="Female" <?php echo $female; ?>>Female</option>
                                                    <option value="Other" <?php echo $other; ?>>Other</option>
                                                </select>
                                            </div>
                                        </div>
                                        <div class="row">
                                            <div class="mb-1 col-md-4">
                                                <label class="form-label" for="alias_name"><?= _('Alias Name') ?></label>
                                                <input type="text" name="alias_name" id="alias_name" class="form-control" placeholder="<?= _('Alias Name') ?>" value="<?= post_display('alias_name', $test->alias_name) ?>"/>
                                            </div>
                                            <div class="mb-1 col-md-4">
                                                <label class="form-label" for="body_part"><?= _('Body Part') ?></label>
                                                <input type="text" name="body_part" id="body_part" class="form-control" placeholder="<?= _('Body Part') ?>" value="<?= post_display('body_part', $test->body_part) ?>"/>
                                            </div>
                                            <div class="mb-1 col-md-4">
                                                <label class="form-label" for="disease_name"><?= _('Disease Name') ?></label>
                                                <input type="text" name="disease_name" id="disease_name" class="form-control" placeholder="<?= _('Disease Name') ?>" value="<?= post_display('disease_name', $test->disease_name) ?>"/>
                                            </div>

                                        </div>
                                        <div class="row">
                                            <div class="mb-1 col-md-4">
                                                <label class="form-label" for="description">Description</label>
                                                <textarea name="description" id="" cols="30" rows="4" class="form-control"><?= post_display('description', $test->description) ?></textarea>
                                            </div>
                                            <div class="mb-1 col-md-4">
                                                <label class="form-label" for="requirement">Sample Type</label>
                                                <textarea name="requirement" cols="30" rows="4" class="form-control"><?= post_display('requirement', $test->requirement) ?></textarea>
                                            </div>
                                            <div class="mb-1 col-md-4">
                                                <label class="form-label" for="preparation">Preparation</label>
                                                <textarea name="preparation" cols="30" rows="4" class="form-control"><?= post_display('preparation', $test->preparation) ?></textarea>
                                            </div>
                                        </div>
                                        <div class="row">
                                            <div class="mb-1 col-md-4">
                                                <label class="form-check-label mb-50" for="is_package"><?= __('Is Package') ?></label>
                                                <div class="form-check form-check-success form-switch">
                                                    <input type="checkbox" name="is_package" class="form-check-input" <?= post_display('is_package', $test->is_package) == 1 ? 'checked' : '' ?> />
                                                </div>
                                            </div>
                                            <div class="mb-1 col-md-4">
                                                <label class="form-label">Package Category</label>
                                                <select name="package_category" id="package_category" class="select2 form-select">
                                                    <option value="" {{ $test->package_category=='' ? "selected" : ''  }}>Select Category</option>
                                                    <option value="Silver" {{ $test->package_category=='Silver' ? "selected" : ''  }}>Silver</option>
                                                    <option value="Gold" {{ $test->package_category=='Gold' ? "selected" : ''  }}>Gold</option>
                                                    <option value="Diamond" {{ $test->package_category=='Diamond' ? "selected" : ''  }}>Diamond</option>
                                                </select>
                                            </div>
                                            <div class="mb-1 col-md-4">
                                                <label class="form-label">Status</label>
                                                <select name="status_id" id="status_id" class="select2 form-select" required>
                                                    <option value="1" {{ $test->status_id=='1' ? "selected" : ''  }}>Active</option>
                                                    <option value="2" {{ $test->status_id=='2' ? "selected" : ''  }}>Inactive</option>
                                                </select>
                                            </div>
                                        </div>
                                    </div>
                                    <div id="test-details-info" class="content" role="tabpanel" aria-labelledby="test-details-modern-trigger">
                                        <div class="row">
                                            <div class="col-md-12">
                                                <label class="form-label" for="test_count"><?= _('Total Test Count') ?></label>
                                                <input type="number" name="test_count" id="test_count" class="form-control" placeholder="<?= _('Test Count') ?>" value="<?= post_display('test_count', $test->test_count) ?>"/>
                                            </div>
                                            <div class="mt-1 mb-1 col-12"><div id="error-alert" class="error"></div></div>
                                            <div class="col-md-9">
                                                <label class="form-label" for="test_id">Test title</label>
                                                <input data-id="title" type="text" placeholder="Test title" value="" class="form-control test_search"/>
                                            </div>
                                            <div class="mb-1 col-md-3">
                                                <input type="hidden" name="test_desc_json" value="{{$test->test_desc_json}}" data-id="desc-json" />
                                                <a data-id="btn-add" class="btn btn-primary mt-2 me-1 waves-effect waves-float waves-light">Add</a>
                                            </div>
                                            <div class="mb-1 col-md-12">
                                                <ul class="list-group" data-id="data-list">
                                                </ul>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </section>
                        <div class="row" data-select2-id="12">
                            <div class="col-12">
                                <button type="submit" class="btn btn-primary me-1 waves-effect waves-float waves-light">Save changes</button>
                                <a class="btn btn-outline-secondary waves-effect" href="{{ route('admin.test') }}">Back</a>
                            </div>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>
</div>
@endsection

