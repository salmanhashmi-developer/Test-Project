<section class="modern-horizontal-wizard">
    <div>
        <div class="row">
            <div class="col-md-8">
                <div class="row">
                    <div class="mb-2 col-md-4">
                        <span><?= _('Name') ?></span>
                        <br>
                        <span class="fw-bolder me-25">{{ $test->name }}</span>
                    </div>
                    <div class="mb-2 col-md-4">
                        <span><?= _('Type') ?></span><br>
                        <span class="fw-bolder me-25">{{ $test->is_package==1?'Package':'Test' }}</span>
                    </div>
                    <div class="mb-2 col-md-4">
                        <span><?= _('Category') ?></span><br>
                        <span class="fw-bolder me-25">{{ $test->package_category }}</span>
                    </div>
                    <div class="mb-1 col-md-4">
                        <span><?= _('Status') ?></span><br>
                        <span class="fw-bolder me-25 <?php echo $test->status_id == 1 ? 'text-success' : 'text-danger'; ?>">{{ $test->status->name }}</span>
                    </div>
                    <div class="mb-1 col-md-4">
                        <span><?= _('Gender') ?></span><br>
                        <span class="fw-bolder me-25">{{ $test->gender }}</span>
                    </div>
                </div>
                <div class="row" style="border-bottom: 1px solid #efefef;padding: 15px 0px;">
                    <div class="mb-1 col-md-4">
                        <span><?= _('Alias Name') ?></span>
                        <br>
                        <span class="fw-bolder me-25">{{ $test->alias_name }}</span>
                    </div>
                    <div class="mb-1 col-md-4">
                        <span><?= _('Body Part') ?></span>
                        <br>
                        <span class="fw-bolder me-25">{{ $test->body_part }}</span>
                    </div>
                    <div class="mb-1 col-md-4">
                        <span><?= _('Disease Name') ?></span>
                        <br>
                        <span class="fw-bolder me-25">{{ $test->disease_name }}</span>
                    </div>
                </div>
                <div class="row" style="border-bottom: 1px solid #efefef;padding: 12px 0px;line-height: 2em;">
                    <div class="mb-1 col-md-12">
                        <span><?= _('Description') ?></span>
                        <br>
                        <span class="fw-bolder me-25">{{ $test->description }}</span>
                    </div>
                </div>
                <div class="row" style="border-bottom: 1px solid #efefef;padding: 12px 0px;line-height: 2em;">
                    <div class="mb-1 col-md-12">
                        <span><?= _('Requirement') ?></span>
                        <br>
                        <span class="fw-bolder me-25">{{ $test->requirement }}</span>
                    </div>
                </div>
                <div class="row" style="border-bottom: 1px solid #efefef;padding: 12px 0px;line-height: 2em;">
                    <div class="mb-1 col-md-12">
                        <span><?= _('Preparation') ?></span>
                        <br>
                        <span class="fw-bolder me-25">{{ $test->preparation }}</span>
                    </div>
                </div>
            </div>
            <div class="col-md-4 b-l-10">
                <div class="row b-b-10 d-flex align-items-start">
                    <b style="font-size: 15px;">Test Details</b> <small>(Total {{$test->test_count}} test)</small>
                </div>
                <?php
                if (!empty($test->test_json)) {
                    foreach ($test->test_json as $key => $mainTest) {
                        ?>
                        <div class="col-xl-12 p-b-10 p-t-10 b-b-10 d-flex align-items-start">
                            <div class="row">
                                <div class="col-xl-12 p-b-10">
                                    <b><?php echo $mainTest['parent']; ?></b> 
                                </div>
                                <?php
                                if (!empty($mainTest['children'])) {
                                    foreach ($mainTest['children'] as $key => $subTest) {
                                        ?>
                                        <div class="col-xl-12 p-b-10">
                                            <?php echo $subTest; ?>
                                        </div>
                                        <?php
                                    }
                                }
                                ?>
                            </div>
                        </div>
                        <?php
                    }
                }
                ?>
            </div>
            <div class="col-12 text-center mt-2">
                <a id="copy-test" class="btn btn-primary me-1 mt-2">Copy</a>
                <button class="btn btn-outline-secondary mt-2" data-bs-dismiss="modal" aria-label="Close">Close</button>
            </div>
        </div>
    </div>

</section>

