@extends('backend.layouts.master')
@section('title')
    Order view
@endsection
@section('content')
    <script>
        var csrf_field = "{{ csrf_token() }}";
    </script>
    <script type="text/javascript" src="{{ Helper::static_asset('admin-assets/js/module/common.js') }}"></script>
    <script type="text/javascript" src="{{ Helper::static_asset('admin-assets/js/module/lab-booking.js') }}"></script>
    <script type="text/javascript">
        $(document).ready(initBookingLab);
    </script>
    <div class="app-content content f-12">
        <div class="content-wrapper p-0">
            <div class="content-body">
                @include('backend.message')
                <div data-select2-id="14">
                    <div data-select2-id="53">
                        <section>
                            <div class="bs-stepper wizard-modern modern-wizard-example" id="stepper">
                                <div class="bs-stepper-header">
                                    <div class="step" data-target="#direct-call" role="tab" id="direct-call-trigger">
                                        <button type="button" class="step-trigger">
                                            <!--<span class="bs-stepper-box"><i data-feather="user" class="font-medium-3"></i></span>-->
                                            <span class="bs-stepper-label">
                                                <span class="bs-stepper-title">Direct To Call</span>
                                            </span>
                                        </button>
                                    </div>
                                    <div class="line" style="padding: 5px 1px 1px 10px;"><i data-feather="chevron-right"
                                            class="font-medium-2"></i></div>
                                    <div class="step" data-target="#lab-details" role="tab" id="lab-details-trigger">
                                        <button type="button" class="step-trigger">
                                            <!--<span class="bs-stepper-box"><i data-feather="file-text" class="font-medium-3"></i></span>-->
                                            <span class="bs-stepper-label">
                                                <span class="bs-stepper-title">Lab Details</span>
                                            </span>
                                        </button>
                                    </div>
                                    <div class="line" style="padding: 5px 1px 1px 10px;"><i data-feather="chevron-right"
                                            class="font-medium-2"></i></div>
                                    <div class="step" data-target="#select-test" role="tab" id="select-test-trigger">
                                        <button type="button" class="step-trigger">
                                            <!--<span class="bs-stepper-box"><i data-feather="file-text" class="font-medium-3"></i></span>-->
                                            <span class="bs-stepper-label">
                                                <span class="bs-stepper-title">Select Test</span>
                                            </span>
                                        </button>
                                    </div>
                                    <div class="line" style="padding: 5px 1px 1px 10px;"><i data-feather="chevron-right"
                                            class="font-medium-2"></i></div>
                                    <div class="step" data-target="#select-collection" role="tab"
                                        id="select-collection-trigger">
                                        <button type="button" class="step-trigger">
                                            <!--<span class="bs-stepper-box"><i data-feather="file-text" class="font-medium-3"></i></span>-->
                                            <span class="bs-stepper-label">
                                                <span class="bs-stepper-title">Select Collection & Details</span>
                                            </span>
                                        </button>
                                    </div>
                                    <?php if (!empty($directCall)) { ?>
                                    <div class="line" style="padding: 5px 1px 1px 10px;"><i data-feather="chevron-right"
                                            class="font-medium-2"></i></div>
                                    <div class="step" data-target="#select-patient" role="tab"
                                        id="select-patient-trigger">
                                        <button type="button" class="step-trigger">
                                            <!--<span class="bs-stepper-box"><i data-feather="file-text" class="font-medium-3"></i></span>-->
                                            <span class="bs-stepper-label">
                                                <span class="bs-stepper-title">Select Patient</span>
                                            </span>
                                        </button>
                                    </div>
                                    <?php } ?>
                                    <div class="line" style="padding: 5px 1px 1px 10px;"><i data-feather="chevron-right"
                                            class="font-medium-2"></i></div>
                                    <div class="step" data-target="#select-address" role="tab"
                                        id="select-address-trigger">
                                        <button type="button" class="step-trigger">
                                            <!--<span class="bs-stepper-box"><i data-feather="file-text" class="font-medium-3"></i></span>-->
                                            <span class="bs-stepper-label">
                                                <span class="bs-stepper-title">Select Address</span>
                                            </span>
                                        </button>
                                    </div>

                                    <div class="line" style="padding: 5px 1px 1px 10px;"><i data-feather="chevron-right"
                                            class="font-medium-2"></i></div>
                                    <div class="step" data-target="#order-details" role="tab"
                                        id="order-details-trigger">
                                        <button type="button" class="step-trigger">
                                            <!--<span class="bs-stepper-box"><i data-feather="file-text" class="font-medium-3"></i></span>-->
                                            <span class="bs-stepper-label">
                                                <span class="bs-stepper-title">Order Details</span>
                                            </span>
                                        </button>
                                    </div>
                                    <div class="line" style="padding: 5px 1px 1px 10px;"><i
                                            data-feather="chevron-right" class="font-medium-2"></i></div>
                                    <div class="step" data-target="#order-status" role="tab"
                                        id="order-status-trigger">
                                        <button type="button" class="step-trigger">
                                            <!--<span class="bs-stepper-box"><i data-feather="file-text" class="font-medium-3"></i></span>-->
                                            <span class="bs-stepper-label">
                                                <span class="bs-stepper-title">Order Status</span>
                                            </span>
                                        </button>
                                    </div>
                                </div>
                                <div class="bs-stepper-content">
                                    <div id="direct-call" class="content" role="tabpanel"
                                        aria-labelledby="direct-call-trigger">
                                        <?php if (!empty($directCall)) { ?>
                                        <div class="card" data-select2-id="14">
                                            <div class="card-body" data-select2-id="53">
                                                <div>
                                                    <h4>{{ __('Direct To Call') }}</h4>
                                                </div>
                                                <form class="" method="POST"
                                                    action="{{ route('admin.lab.direct.call') }}">
                                                    {{ csrf_field() }}
                                                    <div class="row g-1 mb-md-1">
                                                        <div class="col-md-3">
                                                            <label class="form-label"
                                                                for="user_id"><?= _('User') ?></label>
                                                            <input type="text" name="user"
                                                                class="form-control user_search"
                                                                placeholder="<?= _('Enter Name / Email / Mobile No.') ?>"
                                                                value="{{ app('request')->input('user') }}" />
                                                            <input type="hidden" id="user_id" name="user_id"
                                                                value="{{ app('request')->input('user_id') }}">
                                                        </div>
                                                        <div class="col-md-1 m-t-35 text-center">
                                                            <label class="form-label">OR</label>
                                                        </div>
                                                        <div class="col-md-3">
                                                            <label class="form-label">Card No.</label>
                                                            <input type="text"
                                                                class="form-control dt-input dt-full-name"
                                                                placeholder="HealthismPlus Card No." name="card_no"
                                                                value="{{ app('request')->input('card_no') }}">
                                                        </div>
                                                        <div class="col-md-3 m-t-35">
                                                            <label class="form-label"></label>
                                                            <button type="submit"
                                                                class="btn btn-primary waves-effect waves-float waves-light">Search</button>
                                                            <a href="{{ route('admin.lab.direct.call') }}"
                                                                class="btn btn-outline-secondary waves-effect">Reset</a>
                                                        </div>
                                                        <div class="col-md-2 m-t-35">
                                                        </div>
                                                    </div>
                                                    <?php if (!empty($errorMsg)) { ?>
                                                    <div class="row g-1 mb-md-1">
                                                        <div class="col-md-2 m-t-35">
                                                            {{ $errorMsg }}
                                                        </div>
                                                    </div>
                                                    <?php } ?>
                                                </form>
                                            </div>
                                        </div>
                                        <?php } ?>
                                        <div class="card" data-select2-id="14">
                                            <?php if (!empty($user)) { ?>
                                            <div class="card-body" data-select2-id="53">
                                                <div class="b-b-10">
                                                    <h4>{{ __('User Details') }}</h4>
                                                </div>
                                                <input type="hidden" name="h_user_id" id="h_user_id"
                                                    value="{{ $user->id }}">
                                                <input type="hidden" name="user_patient_id" id="user_patient_id"
                                                    value="{{ !empty($userPatient) ? $userPatient->id : '' }}">
                                                <input type="hidden" name="upload_files_id" id="upload_files_id"
                                                    value="{{ !empty($uploadFiles) ? $uploadFiles->id : 0 }}">
                                                <div class="row mt-2">
                                                    <div class="mb-1 col-md-3">
                                                        <span><?= _('First Name') ?></span>
                                                        <br>
                                                        <span class="fw-bolder me-25">{{ $user->first_name }}</span>
                                                    </div>
                                                    <div class="mb-1 col-md-3">
                                                        <span><?= _('Last Name') ?></span>
                                                        <br>
                                                        <span class="fw-bolder me-25">{{ $user->last_name }}</span>
                                                    </div>
                                                    <div class="mb-1 col-md-3">
                                                        <span><?= _('Mobile No') ?></span>
                                                        <br>
                                                        <span class="fw-bolder me-25">{{ $user->mobile }}</span>
                                                    </div>
                                                    <div class="mb-1 col-md-3">
                                                        <span><?= _('Email Id') ?></span>
                                                        <br>
                                                        <span class="fw-bolder me-25">{{ $user->email }}</span>
                                                    </div>

                                                </div>
                                                <div class="row mt-2">
                                                    <div class="mb-1 col-md-3">
                                                        <span><?= _('Status') ?></span>
                                                        <br>
                                                        <span
                                                            class="fw-bolder me-25 <?php echo $user->status_id == STATUS_ACTIVE ? 'theam-color' : 'text-danger'; ?>">{{ $user->status->name }}</span>
                                                    </div>
                                                    <div class="mb-1 col-md-3">
                                                        <span><?= _('Healthism Plus Id') ?></span>
                                                        <br>
                                                        <span
                                                            class="fw-bolder me-25 theam-color">{{ !empty($userSubsciption->card_no) ? $userSubsciption->card_no : 'Plan is not available' }}</span>
                                                    </div>
                                                    <div class="mb-1 col-md-3">
                                                        <span><?= _('Plan Expiry Date') ?></span>
                                                        <br>
                                                        <span
                                                            class="fw-bolder me-25">{{ !empty($userSubsciption->expiry_date) ? date('d/m/Y', strtotime($userSubsciption->expiry_date)) : '-' }}</span>
                                                    </div>
                                                    <div class="mb-1 col-md-3">
                                                        <span><?= _('Plan Status') ?></span>
                                                        <br>
                                                        <span class="fw-bolder me-25">
                                                            <?php
                                                            if (!empty($userSubsciption)) {
                                                                if ($userSubsciption->status_id == STATUS_ACTIVE) {
                                                                    if ($userSubsciption->expire == 1) {
                                                                        echo '<b class="text-danger">Inactive</b>';
                                                                    } else {
                                                                        echo '<b class="theam-color">Active</b>';
                                                                    }
                                                                } else {
                                                                    echo '<b class="text-danger">Inactive</b>';
                                                                }
                                                            }
                                                            ?>
                                                        </span>
                                                    </div>
                                                </div>
                                                <?php if (!empty($userPatient)) { ?>
                                                <div class="mt-2 b-b-10">
                                                    <h4>{{ __('Patient Details') }}</h4>
                                                </div>
                                                <div class="row mt-2">
                                                    <div class="mb-1 col-md-2">
                                                        <span><?= _('Name') ?></span>
                                                        <br>
                                                        <span
                                                            class="fw-bolder me-25">{{ $userPatient->first_name . ' ' . $userPatient->last_name }}</span>
                                                    </div>
                                                    <div class="mb-1 col-md-2">
                                                        <span><?= _('Mobile') ?></span>
                                                        <br>
                                                        <span class="fw-bolder me-25">{{ $userPatient->mobile }}</span>
                                                    </div>

                                                    <div class="mb-1 col-md-2">
                                                        <span><?= _('Birth Date') ?>:</span>
                                                        <br>
                                                        <span
                                                            class="fw-bolder me-25">{{ !empty($userPatient->dob) ? date('d/M/Y', strtotime($userPatient->dob)) : '-' }}</span>
                                                    </div>
                                                    <div class="mb-1 col-md-2">
                                                        <span><?= _('Blood Group') ?>:</span>
                                                        <br>
                                                        <span
                                                            class="fw-bolder me-25">{{ $userPatient->blood_group }}</span>
                                                    </div>
                                                    <div class="mb-1 col-md-3">
                                                        <span><?= _('Email') ?>:</span>
                                                        <br>
                                                        <span class="fw-bolder me-25">{{ $userPatient->email }}</span>
                                                    </div>
                                                </div>
                                                <?php } ?>
                                                <?php if (!empty($uploadFiles)) { ?>
                                                <div class="mt-2 b-b-10">
                                                    <h4>{{ __('Uploded Prescription ') }}</h4>
                                                </div>
                                                <div class="row mt-2">
                                                    <?php
                                                        if (!empty($uploadFiles->file_json)) {
                                                            foreach ($uploadFiles->file_json as $file) {
                                                                ?>
                                                    <div class="mb-1 col-md-1">
                                                        <a target="_blank" href="{{ $file }}">
                                                            <img src="/admin-assets/images/icons/pdf.png" alt="">
                                                        </a>
                                                    </div>
                                                    <?php
                                                            }
                                                        }
                                                        ?>
                                                </div>
                                                <?php } ?>
                                                <div class="row mt-2">

                                                    <div class="mb-1 col-md-3">
                                                        <?php
                                                        $bookingId = !empty($uploadFiles) ? $uploadFiles->ref_id : 0;
                                                        if (!empty($bookingId)) {
                                                            ?>
                                                        <a title="View" target="_blank" class="btn btn-primary w-100"
                                                            href="{{ route('admin.lab.booking.view', ['id' => $bookingId]) }}">
                                                            Show Booking
                                                        </a>
                                                        <?php } else {
                                                            ?>
                                                        <?php
                                                        $Continue = 1;
                                                        if (empty($userSubsciption)) {
                                                            $Continue = 0;
                                                        } else {
                                                            if ($userSubsciption->status_id != STATUS_ACTIVE) {
                                                                $Continue = 0;
                                                            } else {
                                                                if ($userSubsciption->expire == 1) {
                                                                    $Continue = 0;
                                                                }
                                                            }
                                                        }
                                                        ?>
                                                        <?php if ($Continue == 1) { ?>
                                                        <button type="button" id="select-user"
                                                            data-stepper-action="next"
                                                            class="btn btn-primary w-100">Continue</button>
                                                        <?php }
                                                            ?>
                                                        <?php } ?>
                                                    </div>
                                                    <div class="mb-1 col-md-9">
                                                    </div>
                                                </div>
                                            </div>
                                            <?php } ?>
                                        </div>
                                    </div>
                                    <div id="lab-details" class="content" role="tabpanel"
                                        aria-labelledby="lab-details-trigger">
                                        <div class="card" data-select2-id="14">
                                            <div class="card-body" data-select2-id="53">
                                                <div>
                                                    <h4 class="card-title">{{ __('Search Lab') }}</h4>
                                                </div>
                                                <div class="row g-1 mb-md-1">
                                                    <div class="col-md-3">
                                                        <label class="form-label">Lab Name</label>
                                                        <input type="text" class="form-control dt-input dt-full-name"
                                                            placeholder="Lab Name" name="name"
                                                            value="{{ app('request')->input('name') }}">
                                                    </div>
                                                    <!--                                                <div class="col-md-3">
                                                                                                            <label class="form-label">Area , City</label>
                                                                                                            <input type="text" class="form-control dt-input dt-full-name" placeholder="Search Area , City" name="area" value="{{ app('request')->input('area') }}">
                                                                                                        </div>-->
                                                    <div class="col-md-3">
                                                        <label class="form-label">Pincode</label>
                                                        <input type="number" class="form-control dt-input"
                                                            id="pincode-val" placeholder="Pincode" name="pincode"
                                                            value="{{ app('request')->input('pincode') }}">
                                                    </div>
                                                    <div class="col-md-6 m-t-35">
                                                        <button type="submit" id="search-lab"
                                                            class="btn btn-primary waves-effect waves-float waves-light">Search</button>
                                                        <button type="submit" id="search-lab-reset"
                                                            class="btn btn-outline-secondary waves-effect">Reset</button>
                                                        <button type="button" data-stepper-action="previous"
                                                            class="btn btn-outline-primary waves-effect waves-float waves-light">Previous
                                                            Step</button>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                        <div class="m-1" data-select2-id="14">
                                            <section id="card-content-types">

                                            </section>
                                        </div>
                                    </div>
                                    <div id="select-test" class="content" role="tabpanel"
                                        aria-labelledby="select-test-trigger">
                                        <div class="card" data-select2-id="14">
                                            <div class="card-header border-bottom">
                                                <h4 class="card-title">{{ __('Select Test') }}</h4>
                                            </div>
                                        </div>
                                        <div class="card" data-select2-id="14">
                                            <section id="card-content-types">
                                                <div class="row">
                                                    <div class="col-lg-8">
                                                        <div class="card m-b-10">
                                                            <div>
                                                                <div class="row m-l-10 m-t-10">
                                                                    <div class="col-md-4 col-sm-12">
                                                                        <div>
                                                                            <input type="text" id="test-name"
                                                                                class="form-control" name="name"
                                                                                placeholder="Search Test Name" />
                                                                        </div>
                                                                    </div>
                                                                    <div class="col-md-5 col-sm-12">
                                                                        <div class="mt-1">
                                                                            <div class="form-check form-check-inline">
                                                                                <input class="form-check-input"
                                                                                    type="radio" name="type"
                                                                                    id="inlineRadio1" value="PACKAGE" />
                                                                                <label class="form-check-label"
                                                                                    for="inlineRadio1">Package</label>
                                                                            </div>
                                                                            <div class="form-check form-check-inline">
                                                                                <input class="form-check-input"
                                                                                    type="radio" name="type"
                                                                                    id="inlineRadio2" value="TEST"
                                                                                    checked />
                                                                                <label class="form-check-label"
                                                                                    for="inlineRadio2">Test</label>
                                                                            </div>
                                                                        </div>
                                                                    </div>
                                                                    <div class="col-md-3 col-sm-12">
                                                                        <button id="search-test"
                                                                            class="btn btn-primary waves-effect waves-float waves-light">Search</button>
                                                                    </div>
                                                                </div>
                                                            </div>
                                                        </div>
                                                        <div class="p-t-10">
                                                            <table class="m-t-5 table table-bordered table-hover">
                                                                <thead>
                                                                    <tr role="row">
                                                                        <th>TEST</th>
                                                                        <th>TYPE</th>
                                                                        <th>TOTAL<br /> TEST</th>
                                                                        <th>PRICE</th>
                                                                        <th>HEALTHISM+<br /> PRICE</th>
                                                                        <th>ACTIONS</th>
                                                                    </tr>
                                                                </thead>
                                                                <tbody id="test-table-data">

                                                                </tbody>
                                                            </table>
                                                        </div>
                                                    </div>
                                                    <div class="col-lg-4">
                                                        <div class="customer-card p-t-10">
                                                            <div class="card p-t-10">
                                                                <div class="b-b-10"><b style="font-size: 15px;">Cart
                                                                        Details</b></div>
                                                                <div class="lab-info mt-1"></div>
                                                                <div class="actions mt-2 mb-1">
                                                                    <section id="card-content-types">
                                                                        <div class="row cart-data">
                                                                        </div>
                                                                    </section>
                                                                </div>
                                                                <div class="actions">
                                                                    <button type="button" data-stepper-action="next"
                                                                        class="btn btn-outline-secondary">Next
                                                                        Step</button>
                                                                    <button type="button" data-stepper-action="previous"
                                                                        class="btn btn-outline-dark">Previous Step</button>
                                                                </div>
                                                            </div>
                                                        </div>
                                                    </div>
                                                </div>
                                            </section>
                                        </div>
                                    </div>
                                    <div id="select-collection" class="content" role="tabpanel"
                                        aria-labelledby="select-collection-trigger">
                                        <div class="card" data-select2-id="14">
                                            <div class="card-header border-bottom">
                                                <h4 class="card-title">{{ __('Select Collection') }}</h4>
                                            </div>
                                        </div>
                                        <div class="card" data-select2-id="14">
                                            <section id="card-content-types">
                                                <div class="row m-2">
                                                    <div class="col-lg-8">
                                                        <form id="checkout-address" class="list-view product-checkout">
                                                            <div class="row">
                                                                <div class="col-md-4 col-sm-12 m-10">
                                                                    <div>
                                                                        <label class="form-label">Collection</label>
                                                                        <select name="collection" id="collection"
                                                                            class="select2 form-select">
                                                                            <option value="">Select Type</option>
                                                                            <option value="2">Home Collection</option>
                                                                            <option value="1">At Lab</option>
                                                                        </select>
                                                                    </div>
                                                                </div>
                                                            </div>
                                                        </form>
                                                        <div class="row m-md-1" id="lab-slot">

                                                        </div>
                                                    </div>
                                                    <div class="col-lg-4">
                                                        <div class="customer-card p-t-10">
                                                            <div class="card p-t-10">
                                                                <div class="b-b-10"><b style="font-size: 15px;">Cart
                                                                        Details</b></div>
                                                                <div class="lab-info mt-1"></div>
                                                                <div class="slot-info mt-1"><b>Slot date & time :</b> -
                                                                </div>
                                                                <div class="actions mt-2 mb-1">
                                                                    <section id="card-content-types">
                                                                        <div class="row cart-data">
                                                                        </div>
                                                                    </section>
                                                                </div>
                                                                <div class="actions">
                                                                    <button type="button" data-stepper-action="next"
                                                                        class="btn btn-outline-secondary">Next
                                                                        Step</button>
                                                                    <button type="button" data-stepper-action="previous"
                                                                        class="btn btn-outline-dark">Previous Step</button>
                                                                </div>
                                                            </div>
                                                        </div>
                                                    </div>
                                                </div>
                                            </section>
                                        </div>
                                    </div>
                                    <div id="select-patient" class="content" role="tabpanel"
                                        aria-labelledby="select-patient-trigger">
                                        <div class="card" data-select2-id="14">
                                            <div class="card-header border-bottom">
                                                <h4 class="card-title">{{ __('Select Patient') }}</h4>
                                                <button type="button" class="btn btn-primary me-1"
                                                    data-bs-toggle="modal" data-bs-target="#addPatientModal">Add
                                                    Patient</button>
                                            </div>
                                        </div>
                                        <div class="card" data-select2-id="14">
                                            <section id="card-content-types">
                                                <div class="row">
                                                    <div class="col-md-8 col-lg-8">
                                                        <div class="row patient-list">
                                                            <?php
                                                        if (!empty($patient)) {
                                                            foreach ($patient as $value) {
                                                                ?>
                                                            <div id="patient-<?php echo $value['id']; ?>"
                                                                class="col-md-4 col-lg-4 mr-1 ml-1 booking-patient">
                                                                <p class="b-b-10"><b><?php echo $value['relation']; ?></b></p>
                                                                <p><?php echo $value['first_name'] . ' ' . $value['last_name']; ?></p>
                                                                <p><?php echo $value['mobile']; ?><br><?php echo $value['email']; ?>.</p>
                                                                <p>
                                                                    <?php $patientdata = $value['first_name'] . ' ' . $value['last_name'] . '(' . $value['mobile'] . ')'; ?>
                                                                    <a style="color: #2caa8a;font-weight: 600;"
                                                                        data-patient-id="<?php echo $value['id']; ?>"
                                                                        data-patient="<?php echo $patientdata; ?>"
                                                                        data-action="select-patient">SELECT PATIENT</a>
                                                                </p>
                                                            </div>
                                                            <?php
                                                            }
                                                        }
                                                        ?>
                                                        </div>
                                                    </div>
                                                    <div class="col-md-4 col-lg-4">
                                                        <div class="customer-card p-t-10">
                                                            <div class="card p-t-10">
                                                                <div class="b-b-10"><b style="font-size: 15px;">Cart
                                                                        Details</b></div>
                                                                <div class="lab-info mt-1"></div>
                                                                <div class="slot-info mt-1"><b>Slot date & time :</b> -
                                                                </div>
                                                                <div class="Patient-info mt-1"></div>
                                                                <div class="actions mt-2 mb-1">
                                                                    <section id="card-content-types">
                                                                        <div class="row cart-data">
                                                                        </div>
                                                                    </section>
                                                                </div>
                                                                <div class="actions">
                                                                    <button type="button" data-stepper-action="next"
                                                                        class="btn btn-outline-secondary">Next
                                                                        Step</button>
                                                                    <button type="button" data-stepper-action="previous"
                                                                        class="btn btn-outline-dark">Previous Step</button>
                                                                </div>
                                                            </div>
                                                        </div>
                                                    </div>
                                                </div>
                                            </section>
                                        </div>
                                    </div>
                                    <div id="select-address" class="content" role="tabpanel"
                                        aria-labelledby="select-address-trigger">
                                        <div class="card" data-select2-id="14">
                                            <div class="card-header border-bottom">
                                                <h4 class="card-title">{{ __('Select Address') }}</h4>
                                                <button type="button" class="btn btn-primary me-1"
                                                    data-bs-toggle="modal" data-bs-target="#addAddressModal">Add
                                                    Address</button>
                                            </div>
                                        </div>
                                        <div class="card" data-select2-id="14">
                                            <section id="card-content-types">
                                                <div class="row m-2">
                                                    <div class="col-lg-8">
                                                        <div class="row address-list">
                                                            <?php
                                                        if (!empty($address)) {
                                                            foreach ($address as $value) {
                                                                ?>
                                                            <div id="address-<?php echo $value['id']; ?>"
                                                                class="col-md-4 col-lg-4 mr-1 ml-1 booking-address">
                                                                <p class="b-b-10"><b><?php echo $value['type']; ?></b></p>
                                                                <p><?php echo $value['address_1']; ?>,</p>
                                                                <p><?php echo $value['address_2']; ?>,</p>
                                                                <p><?php echo $value['city']; ?>,<?php echo $value['state']; ?>.</p>
                                                                <p><?php echo $value['pincode']; ?></p>
                                                                <p>
                                                                    <a style="color: #2caa8a;font-weight: 600;"
                                                                        data-address="<?php echo $value['address_1'] . ',' . $value['address_2'] . ',' . $value['city'] . ',' . $value['state'] . '.-' . $value['pincode']; ?>"
                                                                        data-address-id="<?php echo $value['id']; ?>"
                                                                        data-action="select-address">SELECT ADDRESS</a>
                                                                </p>
                                                            </div>
                                                            <?php
                                                            }
                                                        }
                                                        ?>
                                                        </div>
                                                    </div>
                                                    <div class="col-lg-4">
                                                        <div class="customer-card p-t-10">
                                                            <div class="card p-t-10">
                                                                <div class="b-b-10"><b style="font-size: 15px;">Cart
                                                                        Details</b></div>
                                                                <div class="lab-info mt-1"></div>
                                                                <div class="Patient-info mt-1"></div>
                                                                <div class="slot-info mt-1"><b>Slot date & time : </b>-
                                                                </div>
                                                                <div class="address-info b-b-10 mt-1">
                                                                    <b>Home Address : </b>
                                                                    <p>-</p>
                                                                </div>
                                                                <div class="actions mt-2 mb-1">
                                                                    <section id="card-content-types">
                                                                        <div class="row cart-data">
                                                                        </div>
                                                                    </section>
                                                                </div>
                                                                <div class="actions">
                                                                    <button type="button" data-stepper-action="next"
                                                                        class="btn btn-outline-secondary">Next
                                                                        Step</button>
                                                                    <button type="button" data-stepper-action="previous"
                                                                        class="btn btn-outline-dark">Previous Step</button>
                                                                </div>
                                                            </div>
                                                        </div>
                                                    </div>
                                                </div>
                                            </section>
                                        </div>
                                    </div>
                                    <div id="order-details" class="content" role="tabpanel"
                                        aria-labelledby="order-details-trigger">
                                        <div class="card" data-select2-id="14">
                                            <div class="card-header border-bottom">
                                                <h4 class="card-title">{{ __('Order Details') }}</h4>
                                            </div>
                                        </div>
                                        <div class="card" data-select2-id="14">
                                            <?php if (!empty($user)) { ?>
                                            <section id="card-content-types">
                                                <div class="row m-2">
                                                    <div class="col-lg-7">
                                                        <div class="card">
                                                            <div class="b-b-10">
                                                                <h4>{{ __('User Details') }}</h4>
                                                            </div>
                                                            <div class="row mt-2">
                                                                <div class="mb-1 col-md-4">
                                                                    <span><?= _(' Name') ?></span>
                                                                    <br>
                                                                    <span class="fw-bolder me-25">{{ $user->first_name }}
                                                                        {{ $user->last_name }}</span>
                                                                </div>

                                                                <div class="mb-1 col-md-4">
                                                                    <span><?= _('Mobile No') ?></span>
                                                                    <br>
                                                                    <span
                                                                        class="fw-bolder me-25">{{ $user->mobile }}</span>
                                                                </div>
                                                                <div class="mb-1 col-md-4">
                                                                    <span><?= _('Email Id') ?></span>
                                                                    <br>
                                                                    <span
                                                                        class="fw-bolder me-25">{{ $user->email }}</span>
                                                                </div>

                                                            </div>
                                                            <div class="row mt-2">
                                                                <div class="mb-1 col-md-4">
                                                                    <span><?= _('Status') ?></span>
                                                                    <br>
                                                                    <span
                                                                        class="fw-bolder me-25 <?php echo $user->status_id == STATUS_ACTIVE ? 'theam-color' : 'text-danger'; ?>">{{ $user->status->name }}</span>
                                                                </div>
                                                                <div class="mb-1 col-md-4">
                                                                    <span><?= _('Healthism Plus Id') ?></span>
                                                                    <br>
                                                                    <span
                                                                        class="fw-bolder me-25 theam-color">{{ !empty($userSubsciption->card_no) ? $userSubsciption->card_no : '<span class="text-danger">Plan is not available</span>' }}</span>
                                                                </div>
                                                                <div class="mb-1 col-md-4">
                                                                    <span><?= _('Plan Expiry Date') ?></span>
                                                                    <br>
                                                                    <span
                                                                        class="fw-bolder me-25">{{ !empty($userSubsciption->expiry_date) ? date('d/m/Y', strtotime($userSubsciption->expiry_date)) : '-' }}</span>
                                                                </div>
                                                            </div>
                                                            <?php if (!empty($userPatient)) { ?>
                                                            <div class="mt-2 b-b-10">
                                                                <h4>{{ __('Patient Details') }}</h4>
                                                            </div>
                                                            <div class="row mt-2">
                                                                <div class="mb-1 col-md-4">
                                                                    <span><?= _('Name') ?></span>
                                                                    <br>
                                                                    <span
                                                                        class="fw-bolder me-25">{{ $userPatient->first_name . ' ' . $userPatient->last_name }}<b
                                                                            class="theam-color">({{ $userPatient->blood_group }})</b></span>
                                                                </div>
                                                                <div class="mb-1 col-md-4">
                                                                    <span><?= _('Mobile') ?></span>
                                                                    <br>
                                                                    <span
                                                                        class="fw-bolder me-25">{{ $userPatient->mobile }}</span>
                                                                </div>
                                                                <div class="mb-1 col-md-4">
                                                                    <span><?= _('Email') ?>:</span>
                                                                    <br>
                                                                    <span
                                                                        class="fw-bolder me-25">{{ $userPatient->email }}</span>
                                                                </div>
                                                            </div>
                                                            <div class="row mt-2">
                                                                <div class="mb-1 col-md-4">
                                                                    <span><?= _('Birth Date') ?>:</span>
                                                                    <br>
                                                                    <span
                                                                        class="fw-bolder me-25">{{ !empty($userPatient->dob) ? date('d/M/Y', strtotime($userPatient->dob)) : '-' }}</span>
                                                                </div>
                                                                <div class="mb-1 col-md-4">
                                                                    <span><?= _('Relation') ?>:</span>
                                                                    <br>
                                                                    <span
                                                                        class="fw-bolder me-25">{{ $userPatient->relation }}</span>
                                                                </div>
                                                                <div class="mb-1 col-md-4">
                                                                    <span><?= _('Gender') ?>:</span>
                                                                    <br>
                                                                    <span
                                                                        class="fw-bolder me-25">{{ $userPatient->gender }}</span>
                                                                </div>

                                                            </div>
                                                            <?php } ?>
                                                        </div>
                                                    </div>
                                                    <div class="col-lg-5">
                                                        <div class="customer-card p-t-10">
                                                            <div class="card p-t-10">
                                                                <div class="b-b-10"><b style="font-size: 15px;">Cart
                                                                        Details</b></div>
                                                                <div class="lab-info mt-1"></div>
                                                                <div class="Patient-info mt-1"></div>
                                                                <div class="slot-info mt-1"><b>Slot date & time :</b> -
                                                                </div>
                                                                <div class="address-info b-b-10 mt-1">
                                                                    <b>Home Address : </b>
                                                                    <p>-</p>
                                                                </div>
                                                                <div class="actions mt-2 mb-1">
                                                                    <section id="card-content-types">
                                                                        <div class="row cart-data b-b-10"></div>
                                                                        <div class="row cart-calculation mt-1"></div>
                                                                    </section>
                                                                </div>
                                                                <div class="actions" id="payment-method">
                                                                    <button type="button"
                                                                        class="btn btn-primary payment-page">Next
                                                                        Step</button>
                                                                    <button type="button" data-stepper-action="previous"
                                                                        class="btn btn-outline-secondary">Previous
                                                                        Step</button>
                                                                </div>
                                                            </div>
                                                        </div>
                                                    </div>
                                                </div>
                                            </section>
                                            <?php } ?>
                                        </div>
                                    </div>
                                    <div id="order-status" class="content" role="tabpanel"
                                        aria-labelledby="order-status-trigger">
                                        <div class="row">
                                            <div class="col-md-12">
                                                <div class="col-md-4 offset-4 p-t-25">
                                                    <div class="text-center">
                                                        <img src="/admin-assets/images/icons/payments/done.png"
                                                            alt="">
                                                        <h4 class=" p-t-25">Your Order is complete!</h4>
                                                        <p>You will receive a confirmation mail with order details</p>
                                                    </div>
                                                    <table class="table" id="order-status-table"
                                                        style="border: 1px solid #f6f6f6;">

                                                    </table>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="row" data-select2-id="12">
                                        <div class="col-12">
                                            <a href="{{ route('admin.lab.booked.test') }}"
                                                class="btn btn-outline-secondary waves-effect">Go To Home</a>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </section>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <div class="modal fade" id="addPatientModal" tabindex="-1" aria-labelledby="addPatientTitle" aria-hidden="true">
        <div class="modal-dialog modal-dialog-centered modal-lg">
            <div class="modal-content">
                <div class="modal-header bg-transparent">
                    <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                </div>
                <div class="modal-body pb-3 px-sm-4 mx-50">
                    <h1 class="address-title text-center mb-1" id="changeStatusTitle">Add Patient</h1>
                    <form class="row gy-1 gx-2">
                        {{ csrf_field() }}
                        <input type="hidden" name="user_id" id="user_id"
                            value="{{ !empty($user->id) ? $user->id : '' }}">
                        <div class="row g-1 mb-md-1">
                            <div class="col-md-6">
                                <label class="form-label">First Name*</label>
                                <input type="text" class="form-control dt-input dt-full-name" placeholder="First Name"
                                    name="first_name" value="">
                            </div>
                            <div class="col-md-6">
                                <label class="form-label">Last Name*</label>
                                <input type="text" class="form-control dt-input dt-full-name" placeholder="Last Name"
                                    name="last_name" value="">
                            </div>
                        </div>
                        <div class="row g-1 mb-md-1">
                            <div class="col-md-6">
                                <label class="form-label">Mobile No*</label>
                                <input type="text" class="form-control dt-input dt-full-name" placeholder="Mobile No"
                                    name="mobile" value="">
                            </div>
                            <div class="col-md-6">
                                <label class="form-label">Email Id</label>
                                <input type="text" class="form-control dt-input dt-full-name" placeholder="Email Id"
                                    name="email" value="">
                            </div>
                        </div>
                        <div class="row g-1 mb-md-1">
                            <div class="col-md-4">
                                <label class="form-label">Relationship</label>
                                <select name="relation" id="relation" class="select2 form-select">
                                    <?php foreach (RELATIONSHIP as $value) { ?>
                                    <option value="{{ $value }}">{{ $value }}</option>
                                    <?php } ?>
                                </select>
                            </div>
                            <div class="col-md-4">
                                <label class="form-label">Birth Date</label>
                                <input type="text" name="dob" class="form-control datepicker"
                                    placeholder="<?= _('DOB') ?>" />
                            </div>
                            <div class="col-md-4">
                                <label class="form-label">Blood Group</label>
                                <select name="blood_group" id="blood_group" class="select2 form-select">
                                    <?php foreach (BLOOD_GROUP as $value) { ?>
                                    <option value="{{ $value }}">{{ $value }}</option>
                                    <?php } ?>
                                </select>
                            </div>
                        </div>
                        <div class="row g-1 mb-md-1">
                            <div class="col-md-12">
                                <label class="form-label">Gender</label>
                                <select name="gender" id="gender" class="select2 form-select">
                                    <option value="Male">Male</option>
                                    <option value="Female">Female</option>
                                    <option value="Other">Other</option>

                                </select>
                            </div>
                        </div>
                        <div class="row g-1 mb-md-1">
                            <div class="text-end">
                                <button type="reset" class="btn btn-outline-secondary" data-bs-dismiss="modal"
                                    aria-label="Close">Discard</button>
                                <a id="add-patient" class="btn btn-primary waves-effect waves-float waves-light">Add
                                    Patient</a>
                            </div>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>
    <div class="modal fade" id="addAddressModal" tabindex="-1" aria-labelledby="addAddressTitle" aria-hidden="true">
        <div class="modal-dialog modal-dialog-centered modal-lg">
            <div class="modal-content">
                <div class="modal-header bg-transparent">
                    <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                </div>
                <div class="modal-body pb-3 px-sm-4 mx-50">
                    <h1 class="address-title text-center mb-1" id="changeStatusTitle">Add Address</h1>
                    <form class="row gy-1 gx-2">
                        {{ csrf_field() }}
                        <input type="hidden" name="user_id" id="user_id"
                            value="{{ !empty($user->id) ? $user->id : '' }}">
                        <div class="row g-1 mb-md-1">
                            <div class="col-md-12">
                                <label class="form-label">House / Flat / Block No.*</label>
                                <input type="text" class="form-control dt-input dt-full-name"
                                    placeholder="House / Flat / Block No.*" name="address_1" required>
                            </div>
                        </div>
                        <div class="row g-1 mb-md-1">
                            <div class="col-md-12">
                                <label class="form-label">Apartment / Road / Area*</label>
                                <input type="text" class="form-control dt-input dt-full-name"
                                    placeholder="Apartment / Road / Area" name="address_2" required>
                            </div>
                        </div>
                        <div class="row g-1 mb-md-1">
                            <div class="col-md-4">
                                <label class="form-label">Pincode*</label>
                                <input type="number" class="form-control dt-input" id="pincode-val"
                                    placeholder="Pincode" name="pincode" required>
                            </div>
                            <div class="col-md-4">
                                <label class="form-label">State*</label>
                                <select name="state_id" id="state_id" class="select2 form-select" required>
                                    <option value="">Select State</option>
                                    <?php foreach ($states as $state): ?>
                                    <option value="{{ $state->id }}">{{ $state->name }}</option><?php
                                endforeach;
                                ?>
                                </select>
                            </div>
                            <div class="col-md-4">
                                <label class="form-label">City*</label>
                                <select name="city_id" id="city_id" class="select2 form-select" required>
                                    <option value="">Select City</option>
                                </select>
                            </div>
                        </div>
                        <div class="row g-1 mb-md-1">
                            <div class="col-md-12">
                                <label class="form-label">Select Type</label>
                                <select name="type" id="type" class="select2 form-select" required>
                                    <option value="">Select Type</option>
                                    <option value="Home">Home</option>
                                    <option value="Work">Work</option>
                                    <option value="Other">Other</option>
                                </select>
                            </div>
                        </div>
                        <div class="row g-1 mb-md-1">
                            <div class="text-end">
                                <button type="reset" class="btn btn-outline-secondary" data-bs-dismiss="modal"
                                    aria-label="Close">Discard</button>
                                <a id="add-address" class="btn btn-primary waves-effect waves-float waves-light">Add
                                    Address</a>
                            </div>
                        </div>

                    </form>
                </div>
            </div>
        </div>
    </div>
@endsection
@section('script')
    <script type="text/javascript">
        $(document).ready(initCommon);
    </script>
@endsection
