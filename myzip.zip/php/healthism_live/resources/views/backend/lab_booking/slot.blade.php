<?php
if (!empty($result)) {
    foreach ($result as $value) {
        ?>
        <div class="col-md-12" style="border-bottom: 1px solid;padding: 10px 25px 10px 25px;">
            <span style="font-size: 13px;font-weight: 600;color: #2caa8a;">
                <?php
                echo date("d/m/Y", strtotime($value['date'])) . '-' . $value['day'] . 'day';
                ?>
            </span>
        </div>
        <?php
        foreach ($value['slot'] as $slot) {
            $from = $value['date'] . ' ' . $slot['from_time'];
            $to = $value['date'] . ' ' . $slot['to_time'];
            ?>
            <div class="col-md-3 mt-1">
                <a data-slot-id="{{ $slot['id']  }}" data-slot-date="{{ $value['date']  }}" data-slot="{{ date('d/m/Y',strtotime($from)) }} - {{$value['day']}}day At {{ date('h:i A',strtotime($from)) }}" data-action="select-slot" class="slot-data">
                    <span style="padding: 5px;background: aliceblue;">{{ date("h:i A",strtotime($from)) }}-{{ date("h:i A",strtotime($to)) }}</span>
                </a>
            </div>
        <?php } ?>

        <?php
    }
}
?>