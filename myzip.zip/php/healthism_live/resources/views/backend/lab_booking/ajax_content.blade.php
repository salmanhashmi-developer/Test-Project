<script>
    var csrf_field = "{{ csrf_token() }}";
</script>
<script src="{{ Helper::static_asset('admin-assets/js/module/common.js') }}"></script>
<div class="row f-12">
    <form class="" method="POST" action="{{ route('admin.lab.booked.test') }}" id="search_form" onsubmit="return false">
        {{ csrf_field() }}
        <div class="col-12">
            <div class="card">
                <div class="card-header border-bottom">
                    <h4 class="card-title">{{ __("Lab Booking")  }}</h4>
                </div>

                <!--Search Form -->
                <div class="card-body mt-2">
                    <div class="row g-1 mb-md-1">
                        <div class="col-md-4">
                            <label class="form-label">User First Name</label>
                            <input type="text" class="form-control dt-input dt-full-name" placeholder="User Name" name="user_name" value="{{app('request')->input('user_name')}}">
                        </div>
                        <div class="col-md-4">
                            <label class="form-label">User Mobile</label>
                            <input type="number" class="form-control dt-input dt-full-name" placeholder="User Mobile" name="user_mobile" value="{{app('request')->input('user_mobile')}}">
                        </div>
                        <div class="col-md-4">
                            <label class="form-label">Patient First Name</label>
                            <input type="text" class="form-control dt-input dt-full-name" placeholder="Patient Name" name="patient_name" value="{{app('request')->input('patient_name')}}">
                        </div>
                        <div class="col-md-4">
                            <label class="form-label">Status</label>
                            <select name="status_id" class="select2 form-select form-control">
                                <option value="-1">All</option>
                                <?php foreach ($statusList as $status): ?>
                                    <option value="{{ $status['id'] }}" {{ $statusId == $status['id'] ? "selected" : ''  }}>{{$status['name']}}</option><?php
                                endforeach;
                                ?>
                            </select>
                        </div>
                        <div class="col-md-4">
                            <div class="col-md-5" style="float:left;margin-right:5px;">
                                <label class="form-label">Start Date</label>
                                <input type="text" name="start_date" class="form-control datepicker" placeholder="Start Date" value="{{ request_display('start_date') }}" />
                            </div>
                            <div class="col-md-5" style="float:left">
                                <label class="form-label">End Date</label>
                                <input type="text" name="end_date" class="form-control datepicker" placeholder="End Date" value="{{ request_display('end_date') }}" />
                            </div>
                        </div>
                        <div class="col-md-4 m-t-35">
                            <button type="submit" class="btn btn-primary waves-effect waves-float waves-light">Search</button>
                            <a href="{{route('admin.lab.booked.test')}}" class="btn btn-outline-secondary waves-effect">Reset</a>
                            <a href="{{  route('admin.lab.direct.call')  }}" class="btn btn-outline-primary waves-effect waves-float waves-light">Direct Call</a>
                        </div>
                    </div>
                </div>
                <hr class="my-0">
                <div class="card-datatable">
                    <?php echo parPageRecordDropDown([5, 10, 15, 20]) ?>
                    @if(!$userUpload->isEmpty())
                    @php $start = $userUpload->firstItem(); @endphp
                    <div class="table-responsive">
                        <table class="table table-bordered table-hover">
                            <thead>
                                <tr role="row">
                                    <th>File</th>
                                    <th>User</th>
                                    <th>Patient</th>
                                    <th>Status</th>
                                    <th>Created</th>
                                    <th>Actions</th>
                                </tr>
                            </thead>
                            <tbody>
                                @foreach($userUpload as $fileData)
                                <tr class="l-h-22">
                                    <td valign="top">
                                        <?php echo count($fileData->file_json) . ' Files'; ?>
                                    </td>
                                    <td valign="top">
                                        @if(!empty($fileData->user))
                                        {{ $fileData->user->first_name.' '.$fileData->user->last_name }}<br>
                                        <span class="f-11">{{$fileData->user->mobile}}</span> - 
                                        <span class="f-11">{{$fileData->user->email}}</span>
                                        @endif
                                    </td>
                                    <td valign="top">
                                        @if(!empty($fileData->userPatient))
                                        {{ $fileData->userPatient->first_name.' '.$fileData->userPatient->last_name }}(<span class="f-11 theam-color">{{$fileData->userPatient->blood_group}}</span>)<br>
                                        <span class="f-11">{{$fileData->userPatient->mobile}}</span> -
                                        <span class="f-11">{{$fileData->userPatient->email}}</span><br>
                                        <span class="f-11">Birth Date : {{!empty($fileData->userPatient->dob)? date("d/M/Y",strtotime($fileData->userPatient->dob)):'-' }}</span>
                                        @endif
                                    </td>
                                    <td valign="top">
                                        <span>{{ $fileData->status->name }}</span>
                                    </td>
                                    <td valign="top"> 
                                        <span>{{ date("d/m/Y H:i",strtotime($fileData->created_at)) }}</span>
                                    </td>
                                    <td>
                                        <div class="text-nowrap">
                                            <a title="View" href="{{  route('admin.lab.booked.test.view', ['id'=>$fileData->id] )  }}">
                                                <i data-feather="file-text" class="me-50 text-dark"></i>
                                            </a>
                                        </div>
                                    </td>
                                </tr>
                                @endforeach
                            </tbody>
                        </table>
                    </div>
                    @endif
                    <?php echo pagination($userUpload) ?>
                </div>
            </div>
        </div>
    </form>
</div>
@section('script')
<script type="text/javascript">
    $(document).ready(initCommon);
</script>
@endsection