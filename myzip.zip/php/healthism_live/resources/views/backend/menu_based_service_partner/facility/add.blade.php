@extends("backend.layouts.master")
@section('title') Menu Based Service Facility Add @endsection
@section('content')
<script type="text/javascript" src="{{ Helper::static_asset('admin-assets/js/module/common.js') }}"></script>
<script type="text/javascript" src="{{ Helper::static_asset('admin-assets/js/module/menu-base-service.js') }}"></script>
<script type="text/javascript">$(document).ready(initFacilityMaster);</script>
<div class="app-content content">
    <div class="content-wrapper p-0">
        <div class="content-body">
            <div class="card" data-select2-id="14">
                <div class="card-header border-bottom">
                    <h4 class="card-title">Add New Menu Based Service Facility</h4>
                </div>
                <div class="card-body" data-select2-id="53">
                    @include('backend.message')
                    <form class="needs-validation" method="POST" action="{{route('mbs.facility.store')}}" method="POST" enctype="multipart/form-data" novalidate>
                        {{ csrf_field() }}
                        <section class="modern-horizontal-wizard">

                            <div class="bs-stepper wizard-modern modern-wizard-example">

                                <div class="bs-stepper-header">
                                    <div class="step" data-target="#account-details-modern" role="tab" id="facility-details-modern-trigger">
                                        <button type="button" class="step-trigger">
                                            <span class="bs-stepper-box">
                                                <i data-feather="user" class="font-medium-3"></i>
                                            </span>
                                            <span class="bs-stepper-label">
                                                <span class="bs-stepper-title">Facility Details</span>
                                            </span>
                                        </button>
                                    </div>
                                    <div class="line">
                                        <i data-feather="chevron-right" class="font-medium-2"></i>
                                    </div>
                                    <div class="step" data-target="#facility-details-info" role="tab" id="facility-details-info-trigger">
                                        <button type="button" class="step-trigger">
                                            <span class="bs-stepper-box">
                                                <i data-feather="file-text" class="font-medium-3"></i>
                                            </span>
                                            <span class="bs-stepper-label">
                                                <span class="bs-stepper-title">Facility Additional Details</span>
                                            </span>
                                        </button>
                                    </div>
                                </div>

                                <div class="bs-stepper-content">
                                    <div id="account-details-modern" class="content" role="tabpanel" aria-labelledby="facility-details-modern-trigger">
                                        <div class="content-header">
                                            <h5 class="mb-0"><?= ('Facility Details') ?></h5>
                                        </div>
                                        <div class="row">
                                            <input type="hidden" name="menu_based_service_id" value="{{!empty($menuBasedService->id)?$menuBasedService->id:0}}">
                                            <input type="hidden" name="menu_based_service_parent_id" value="{{!empty($menuBasedService->parent_id)?$menuBasedService->parent_id:0}}">
                                            <input type="hidden" name="flag" value="MBS">
                                            <div class="mb-1 col-md-4">
                                                <label class="form-label" for="name"><?= _('Name*') ?></label>
                                                <input type="text" name="name" id="name" class="form-control" placeholder="<?= _('Facility Name') ?>" value="<?= post_display('name') ?>" required/>
                                            </div>
                                            <div class="mb-1 col-md-4">
                                                <label class="form-label" for="gender"><?= _('Gender') ?></label>
                                                <select name="gender" class="form-select select2" id="gender">
                                                    <option value="" >Select Gender</option>
                                                    <option value="Male" >Male</option>
                                                    <option value="Female" >Female</option>
                                                    <option value="Unisex" >Unisex</option>
                                                </select>
                                            </div>
                                            <div class="mb-1 col-md-4">
                                                <label class="form-label">Status</label>
                                                <select name="status_id" id="status_id" class="select2 form-select" required>
                                                    <option value="1">Active</option>
                                                    <option value="2">Inactive</option>
                                                </select>
                                            </div>

                                        </div>
                                        <div class="row">
                                            <div class="mb-1 col-md-4">
                                                <label class="form-label" for="description">Description</label>
                                                <textarea name="description" id="" cols="30" rows="4" class="form-control"></textarea>
                                            </div>
                                            <div class="mb-1 col-md-4">
                                                <label class="form-label" for="discount"><?= _('Discount(%)') ?></label>
                                                <input type="number" name="discount" id="discount" class="form-control" value="{{!empty($menuBasedService->discount)?$menuBasedService->discount:''}}" disabled/>
                                                <input type="hidden" name="discount" id="discount" class="form-control" value="{{!empty($menuBasedService->discount)?$menuBasedService->discount:''}}"/>
                                            </div>
                                            <div class="mb-1 col-md-4">
                                                <label class="form-label" for="price"><?= _('Price(Rs)*') ?></label>
                                                <input type="number" name="price" id="price" class="form-control" placeholder="<?= _('Price') ?>"  required/>
                                            </div>
                                        </div>
                                        <div class="row">
                                            <div class="mb-1 col-md-4">
                                                <label class="form-check-label mb-50" for="is_package"><?= __('Is Package') ?></label>
                                                <div class="form-check form-check-success form-switch">
                                                    <input type="checkbox" id="is_package" name="is_package" class="form-check-input"  />
                                                </div>
                                            </div>
                                            <div class="mb-1 col-md-4">
                                                <label class="form-label">Category</label>
                                               <select name="package_category" id="package_category" class="select2 form-select" >
                                                    <option value="">Select Category</option>
                                                    @foreach ($categoryArr as $row)
                                                    <option value="{{ $row }}">{{ $row }}</option>
                                                    @endforeach
                                                </select>
                                            </div>
                                            <div class="mb-1 col-md-4">
                                                <label class="form-label" for="time"><?= _('Time') ?></label>
                                                <input type="text" name="time" id="time" class="form-control" placeholder="<?= _('Time') ?>"  />
                                            </div>

                                        </div>
                                        <?php if (!empty($menuBasedService)) { ?>
                                            <div class="row">
                                                <div class="mb-1 col-md-12 mt-1 b-b-10">
                                                    <span class="fw-bolder me-25">Menu Based Service Details</span>
                                                </div>
                                            </div>
                                            <div class="row">
                                                <div class="mb-1 col-md-3 mt-1">
                                                    <span><?= _('Menu Based Service Name') ?></span>
                                                    <br>
                                                    <span class="fw-bolder me-25">{{ $menuBasedService->name }}</span>
                                                </div>
                                                <div class="mb-1 col-md-3 mt-1">
                                                    <span><?= _('Contact Person') ?></span>
                                                    <br>
                                                    <span class="fw-bolder me-25">{{ $menuBasedService->contact_person? $menuBasedService->contact_person:'-' }}</span>
                                                </div>
                                                <div class="mb-1 col-md-3 mt-1">
                                                    <span><?= _('Phone') ?></span>
                                                    <br>
                                                    <span class="fw-bolder me-25">{{ $menuBasedService->phone?$menuBasedService->phone:'-' }}</span>
                                                </div>
                                                <div class="mb-1 col-md-3 mt-1">
                                                    <span><?= _('Mobile') ?></span>
                                                    <br>
                                                    <span class="fw-bolder me-25">{{ $menuBasedService->mobile? $menuBasedService->mobile:'-' }}</span>
                                                </div>
                                                <div class="mb-1 col-md-12 mt-1">
                                                    <span><?= _('Menu Based Service Address') ?></span>
                                                    <br>
                                                    <span class="fw-bolder me-25">
                                                        {{ $menuBasedService->address1 }}, {{ $menuBasedService->address2 }}, {{ $menuBasedService->area }}
                                                        , {{ $menuBasedService->city->name }}, {{ $menuBasedService->state->name }}-, {{ $menuBasedService->pincode }}
                                                    </span>
                                                </div>
                                                <?php if ($menuBasedService->parent) { ?>
                                                    <div class="mb-1 col-md-12 mt-1">
                                                        <span><?= _('Note') ?></span>
                                                        <br>
                                                        <span class="fw-bolder me-25">This service is working under the {{ $menuBasedService->parent->name}}</span>
                                                    </div>
                                                <?php } ?>
                                            </div>
                                        <?php } ?>
                                    </div>
                                    <div id="facility-details-info" class="content" role="tabpanel" aria-labelledby="facility-details-modern-trigger">
                                        <div class="row">
                                            <div class="col-md-6">
                                                <label class="form-label" for="facility_count"><?= _('Total Facility Count') ?></label>
                                                <input type="number" name="facility_count" id="facility_count" class="form-control" placeholder="<?= _('Facility Count') ?>" value="<?= post_display('facility_count') ?>"/>
                                            </div>
                                            <div class="mt-1 mb-1 col-12"><div id="error-alert" class="error"></div></div>
                                            <div class="mb-1 col-md-9">
                                                <label class="form-label">Facility title</label>
                                                <input data-id="title" type="text" placeholder="Facility Title" value="" class="form-control"/>
                                            </div>
                                            <div class="mb-1 col-md-3">
                                                <input type="hidden" name="facility_desc_json" data-id="desc-json" />
                                                <a data-id="btn-add" class="btn btn-primary mt-2 me-1 waves-effect waves-float waves-light">Add</a>
                                            </div>
                                            <div class="mb-1 col-md-12">
                                                <ul class="list-group" data-id="data-list">
                                                </ul>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </section>
                        <div class="row" data-select2-id="12">
                            <div class="col-12">
                                <button type="submit" class="btn btn-primary me-1 waves-effect waves-float waves-light">Save changes</button>
                                <a href="{{route('mbs.facility', ['menu_based_service_id'=>$menuBasedService->id])}}" class="btn btn-outline-secondary waves-effect">Back</a>
                            </div>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>
</div>
<!-- add new address modal -->
<div class="modal fade" id="showFacilityData" tabindex="-1" aria-labelledby="changeStatusTitle" aria-hidden="true">
    <div class="modal-dialog modal-dialog-centered modal-lg">
        <div class="modal-content">
            <div class="modal-header bg-transparent">
                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
            </div>
            <div class="modal-body px-sm-4 mx-50 f-12">

            </div>
        </div>
    </div>
</div>
<!-- / add new address modal -->
@endsection
