@extends("backend.layouts.master")
@section('title') Reschedule @endsection
@section('content')
<script type="text/javascript" src="{{ Helper::static_asset('admin-assets/js/module/menu-base-service-partner.js') }}"></script>
<script type="text/javascript">$(document).ready(initRescheduleMBSOrder);</script>
<!-- BEGIN: Content-->
<div class="app-content content f-12">
    <div class="content-wrapper p-0">
        <div class="content-body">
            @include('backend.message')
            <div class="p-b-10"> <a href="{{route('mbs.order.view', ['id'=>$order->id])}}"><i data-feather="arrow-left" class="me-50 text-dark"></i>Show Order Details</a></div>
            <b class="m-l-20">Order {{$order->order->order_code}}</b>
            <p class="m-l-20"> From {{$order->user->first_name.' '.$order->user->last_name}}</p>
            <div class="card" data-select2-id="14">
                <form class="needs-validation" method="POST" action="" method="POST" enctype="multipart/form-data" novalidate>
                    {{ csrf_field() }}
                    <div class="card-body py-2 my-25" data-select2-id="53">
                        <section class="modern-horizontal-wizard">
                            <div class="bs-stepper wizard-modern modern-wizard-example">
                                <div class="row">
                                    <div class="col-md-5" id="order-modern">
                                        <div class="d-flex">
                                            <div class="row">
                                                <div class="col-md-12 header-title">
                                                    <span>Member Details</span>
                                                </div>
                                                <div class="col-md-12">
                                                    <table class="table">
                                                        <thead>
                                                            <tr>
                                                                <th>Name</th>
                                                                <th>Mobile No.</th>
                                                                <th>Email</th>
                                                            </tr>
                                                        </thead> 
                                                        <tbody>
                                                            <tr>
                                                                <td>{{$order->userMember->first_name.' '.$order->userMember->last_name}}</td>
                                                                <td>{{$order->userMember->mobile}}</td>
                                                                <td>{{$order->userMember->email}}</td>
                                                            </tr>
                                                        </tbody>
                                                    </table>
                                                </div>
                                            </div>
                                        </div>
                                        <div class="d-flex">
                                            <div class="row">
                                                <div class="col-md-12 header-title">
                                                    <span>Slot Data</span>
                                                </div>
                                                <div class="col-md-12">
                                                    <table class="table">
                                                        <thead>
                                                            <tr>
                                                                <th>Slot Date</th>
                                                                <th>Slot Time</th>
                                                                <th>Provider</th>
                                                            </tr>
                                                        </thead> 
                                                        <tbody>
                                                            <tr>
                                                                <td>{{ date("d/m/Y",strtotime($order->appointment_date)) }}</td>
                                                                <td>{{ date("h:i A",strtotime($order->appointment_time)) }}</td>
                                                                <td>{{$order->menuBasedService->name}}({{$order->menuBasedService->area}})</td>
                                                            </tr>
                                                        </tbody>
                                                    </table>
                                                </div>
                                            </div>
                                        </div>
                                        <?php if (!empty($order->menuBasedServiceBookingDetails)) { ?>
                                            <div class="d-flex">
                                                <div class="row">
                                                    <div class="col-md-12 header-title">
                                                        <span>Facility List</span>
                                                    </div>
                                                    <div class="col-md-12">
                                                        <table class="table">
                                                            <thead>
                                                                <tr>
                                                                    <th>Name</th>
                                                                    <th>Amount</th>
                                                                </tr>
                                                            </thead> 
                                                            <tbody>
                                                                <?php
                                                                foreach ($order->menuBasedServiceBookingDetails as $value) {
                                                                    ?>
                                                                    <tr>
                                                                        <td class="f-u">{{$value->menuBasedServiceFacility->name}}</td>
                                                                        <td>Rs.{{$value->amount}}</td>
                                                                    </tr>
                                                                    <?php
                                                                }
                                                                ?>
                                                            </tbody>
                                                        </table>
                                                    </div>
                                                </div>
                                            </div>
                                            <div class="text-success text-bold" style="padding: 10px;font-size: 14px;background: #e1ffe2;display: none;"></div>
                                            <div class="text-danger text-bold" style="padding: 10px;font-size: 14px;background: #ffe7e6;display: none;"></div>
                                            <?php
                                        } else {
                                            echo 'Sorry, Test data not found.';
                                        }
                                        ?>

                                    </div>
                                    <div class="col-md-7" style="height: 650px;overflow: auto;">
                                        <?php
                                        if (!empty($weekOfdays)) {
                                            foreach ($weekOfdays as $value) {
                                                ?>
                                                <div class="row">
                                                    <div class="col-md-12 mt-3" style="border-bottom: 1px solid;padding: 10px 10px 10px 10px;">
                                                        <span style="font-size: 13px;font-weight: 600;color: #2caa8a;">{{ date("d/m/Y",strtotime($value['date'])) }} - {{$value['day']}}</span>
                                                    </div>
                                                    <?php
                                                    foreach ($value['slot'] as $slot) {
                                                        $from = $value['date'] . ' ' . $slot['from_time'];
                                                        $to = $value['date'] . ' ' . $slot['to_time'];
                                                        ?>
                                                        <div class="col-md-4 mt-1">
                                                            <a data-booking-id="{{ $order->id  }}" data-date="{{ $value['date']  }}" data-slot-id="{{ $slot['id']  }}" data-action="reschedule">
                                                                <span style="padding: 5px;background: aliceblue;">{{ date("h:i A",strtotime($from)) }}-{{ date("h:i A",strtotime($to)) }}</span>
                                                            </a>
                                                        </div>
                                                    <?php } ?>
                                                </div>
                                                <?php
                                            }
                                        }
                                        ?>
                                    </div>
                                </div>
                            </div>
                        </section>
                    </div>
                </form>
            </div>
        </div>
    </div>
</div>
@endsection



