@extends("backend.layouts.master")
@section('title') User Review @endsection
@section('content')

<!-- BEGIN: Content-->
<div class="app-content content ">
    <div class="content-wrapper p-0">
        <div class="content-body" id="ajax_content">
            @include('backend.message')
            @include("backend.menu_based_service_partner.user_review.ajax_content")
        </div>
    </div>
</div>
@endsection
