@extends("backend.layouts.master")
@section('title') Subscription Based Service View @endsection
@section('content')

<script type="text/javascript" src="{{ Helper::static_asset('admin-assets/js/module/subscription-base-service-partner.js') }}?0.1"></script>
<script type="text/javascript">$(document).ready(initAddSBSPartnerLocation);</script>

<!-- BEGIN: Content-->
<div class="app-content content ">

    <div class="content-wrapper p-0">

        <div class="content-body">
            @include('backend.message')
            <div class="card" data-select2-id="14">
                <div class="card-header border-bottom">
                    <h4 class="card-title">UPLOAD MULTIPLE LOCATION - {{$subscriptionBasedService['name']}}</h4>
                    <div class="dt-action-buttons d-flex align-items-center justify-content-center justify-content-lg-end flex-lg-nowrap flex-wrap">
                        <div class="dt-buttons d-inline-flex">
                                <a  href="{{route('sbs.branch', ['subscription_based_service_id'=>$subscriptionBasedService['parent_id']] )}}" class="btn btn-outline-secondary waves-effect"> Back</a>
                        </div>
                    </div>
                </div>
                <div class="card-body py-2 my-25" data-select2-id="53">
                    <div class="row">
                        <div class="repeater_fields col-sm-12">
                            <form class="" method="POST" action="{{ route('sbs.location.import') }}" enctype="multipart/form-data" novalidate>
                                {{ csrf_field() }}
                                <div class="row g-1">
                                    <div class="col-md-8">
                                        <label for="formFile" class="form-label">Select Excel File</label>
                                        <input class="form-control" name="file" type="file"  required/>
                                    </div>
                                    <div class="col-md-4">
                                        <input type="hidden" name="name" value="{{$subscriptionBasedService['name']}}" />
                                        <input type="hidden" name="subscription_based_service_id" value="{{$subscriptionBasedService['id']}}" />
                                        <input type="hidden" name="subscription_based_service_parent_id" value="{{$subscriptionBasedService['parent_id']}}" />
                                        <input type="hidden" name="category_id" value="{{$subscriptionBasedService['category_id']}}" />
                                        <label class="form-label"></label>
                                        <button type="submit" class="btn btn-primary mt-2 waves-effect waves-float waves-light">Upload</button>
                                    </div>
                                </div>
                            </form>
                            @if(!empty($errorResult))
                            <div class="mt-2">
                                <div class="table-responsive">
                                    <table class="table table-bordered table-hover">
                                        <thead>
                                            <tr role="row">
                                                <th style="width: 10%;">Import Id</th>
                                                <th>Error</th>

                                            </tr>
                                        </thead>
                                        <tbody>
                                            @foreach($errorResult as $er)
                                            <tr>
                                                <td valign="top">{{ $er['import_data_id'] }}</td>
                                                <td valign="top">{{ $er['error']  }}</td>
                                            </tr>
                                            @endforeach
                                        </tbody>
                                    </table>
                                </div>
                            </div>
                            @endif
                        </div>
                    </div>
                </div>
            </div>
            <div class="card" data-select2-id="14">
                <div class="card-header border-bottom">
                    <h4 class="card-title">LOCATION LIST - {{$subscriptionBasedService['name']}}</h4>
                </div>
                <div class="card-body py-2 my-25" data-select2-id="53" id="add-multiple-location">
                    <div class="row">
                        <div class="repeater_fields col-sm-12">
                            <form class="needs-validation" novalidate>
                                <div class="row align-content-center mb-1">
                                    <div class="col-3">
                                        <label class="form-label" for="pincode"><?= _('Pincode') ?></label>
                                        <input type="text" pattern="[0-9]{6}" name="pincode" maxlength="6" class="form-control" placeholder="<?= _('Pincode') ?>" value="" />
                                    </div>
                                    <div class="col-3">
                                        <label class="form-label" for="latitude"><?= _('Latitude') ?></label>
                                        <input type="text" name="latitude" data-v-message="Invalid latitude" maxlength="12" pattern="^(\+|-)?(?:90(?:(?:\.0{1,9})?)|(?:[0-9]|[1-8][0-9])(?:(?:\.[0-9]{1,9})?))$" class="form-control" placeholder="<?= _('Latitude') ?>" value="" />
                                    </div>
                                    <div class="col-3">
                                        <label class="form-label" for="longitude"><?= _('Longitude') ?></label>
                                        <input type="text" name="longitude" maxlength="12" data-v-message="Invalid longitude" pattern="^(\+|-)?(?:180(?:(?:\.0{1,9})?)|(?:[0-9]|[1-9][0-9]|1[0-7][0-9])(?:(?:\.[0-9]{1,9})?))$" class="form-control" placeholder="<?= _('Longitude') ?>" value="" />
                                    </div>
                                    <div class="col-md-3">
                                        <input type="hidden" name="name" value="{{$subscriptionBasedService['name']}}" />
                                        <input type="hidden" name="city_id" value="" />
                                        <input type="hidden" name="state_id" value="" />
                                        <input type="hidden" name="category_id" value="{{$subscriptionBasedService['category_id']}}" />
                                        <input type="hidden" name="subscription_based_service_id" value="{{$subscriptionBasedService['id']}}" />
                                        <input type="hidden" name="subscription_based_service_parent_id" value="{{$subscriptionBasedService['parent_id']}}" />
                                        <a id="add-location" class="btn btn-primary mt-2 me-1 waves-effect waves-float waves-light">Add Location</a>
                                    </div>
                                </div>
                            </form>

                            <div class="mt-2" data-location-list="add">
                                <div class="table-responsive">
                                    <table class="table">
                                        <thead>
                                            <tr><th>Pin code</th><th>Latitude</th><th>Longitude</th><th>Actions</th></tr>
                                        </thead>
                                        <tbody>
                                            <?php if (!empty($location)) { ?>
                                                <?php foreach ($location as $value) { ?>
                                                    <tr>
                                                        <td>{{$value['pincode']}}</td><td>{{$value['latitude']}}</td><td>{{$value['longitude']}}</td>
                                                        <td><a data-action="delete" data-delete-id="{{$value['id']}}" class="badge rounded-pill badge-light-danger me-1" href="#"><svg xmlns="http://www.w3.org/2000/svg" width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="feather feather-trash me-50"><polyline points="3 6 5 6 21 6"></polyline><path d="M19 6v14a2 2 0 0 1-2 2H7a2 2 0 0 1-2-2V6m3 0V4a2 2 0 0 1 2-2h4a2 2 0 0 1 2 2v2"></path></svg><span>Delete</span></a></td>
                                                    </tr>
                                                <?php } ?>
                                            <?php } ?>
                                        </tbody>
                                    </table>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        @endsection
