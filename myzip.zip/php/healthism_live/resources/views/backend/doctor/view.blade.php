@extends("backend.layouts.master")
@section('title') Doctor List @endsection
@section('content')

<!-- BEGIN: Content-->
<div class="app-content content ">

    <div class="content-wrapper p-0">

        <div class="content-body">
            @include('backend.message')
            <div class="card" data-select2-id="14">
                <div class="card-header border-bottom">
                    <h4 class="card-title">Doctor Details View</h4>
                </div>
                <div class="card-body py-2 my-25" data-select2-id="53">
                    <!-- header section -->

                    <!-- Modern Horizontal Wizard -->
                    <section class="modern-horizontal-wizard">
                        <div class="bs-stepper wizard-modern modern-wizard-example">
                            <div class="bs-stepper-header">
                                <div class="step" data-target="#account-details-modern" role="tab" id="account-details-modern-trigger">
                                    <button type="button" class="step-trigger">
                                        <span class="bs-stepper-box"><i data-feather="user" class="font-medium-3"></i></span>
                                        <span class="bs-stepper-label">
                                            <span class="bs-stepper-title">Doctor Personal Details</span>
                                        </span>
                                    </button>
                                </div>
                                <div class="line"><i data-feather="chevron-right" class="font-medium-2"></i></div>
                                <div class="step" data-target="#personal-info-modern" role="tab" id="personal-info-modern-trigger">
                                    <button type="button" class="step-trigger">
                                        <span class="bs-stepper-box"><i data-feather="file-text" class="font-medium-3"></i></span>
                                        <span class="bs-stepper-label">
                                            <span class="bs-stepper-title">Doctor Additional Details</span>
                                        </span>
                                    </button>
                                </div>
                            </div>
                            <div class="bs-stepper-content">
                                <div id="account-details-modern" class="content" role="tabpanel" aria-labelledby="account-details-modern-trigger">
                                    <div class="d-flex">
                                        <div class="col-xl-8 col-lg-8 col-md-8 align-items-start me-2">
                                            <div class="info-container">
                                                <ul class="list-unstyled f-12">
                                                    <li class="mb-75 mt-2">
                                                        <div class="row">
                                                            <div class="mb-1 col-md-4">
                                                                <span><?= _('Doctor UserName') ?></span>
                                                                <br>
                                                                <span class="fw-bolder me-25">
                                                                    @if($doctor->user)
                                                                    <span>{{ $doctor->user->first_name }}  {{ $doctor->user->last_name }}</span>
                                                                    @endif
                                                                </span>
                                                            </div>
                                                            <div class="mb-1 col-md-4">
                                                                <span><?= _('Phone') ?>:</span>
                                                                <br>
                                                                <span class="fw-bolder me-25">{{ $doctor->phone }}</span>
                                                            </div>
                                                            <div class="mb-1 col-md-4">
                                                                <span><?= _('Status') ?>:</span>
                                                                <br>
                                                                <span class="fw-bolder me-25">{{ $doctor->status->name }}</span>
                                                            </div>
                                                        </div>
                                                    </li>
                                                    <li class="mb-75 mt-2">
                                                        <div class="row">
                                                            <div class="mb-1 col-md-4">
                                                                <span><?= _('First Name') ?>:</span>
                                                                <br>
                                                                <span class="fw-bolder me-25">{{ $doctor->first_name }}</span>
                                                            </div>
                                                            <div class="mb-1 col-md-4">
                                                                <span><?= _('Middle Name') ?>:</span>
                                                                <br>
                                                                <span class="fw-bolder me-25">{{ $doctor->middle_name  }}</span>
                                                            </div>
                                                            <div class="mb-1 col-md-4">
                                                                <span><?= _('Last Name') ?>:</span>
                                                                <br>
                                                                <span class="fw-bolder me-25">{{ $doctor->last_name  }}</span>
                                                            </div>
                                                        </div>
                                                    </li>
                                                    <li class="mb-75 mt-2">
                                                        <div class="row">
                                                            <div class="mb-1 col-md-4">
                                                                <span><?= _('Email Id') ?>:</span>
                                                                <br>
                                                                <span class="fw-bolder me-25">{{ $doctor->email }}</span>
                                                            </div>
                                                            <div class="mb-1 col-md-4">
                                                                <span><?= _('Sub Category') ?>:</span>
                                                                <br>
                                                                <span class="fw-bolder me-25">
                                                                    <?php
                                                                    $sub_category_id = explode(",", trim($doctor->sub_category_id, ","));
                                                                    $cat = array();
                                                                    foreach ($categories as $row) {
                                                                        if (in_array($row['id'], $sub_category_id)) {
                                                                            array_push($cat, $row['name']);
                                                                        }
                                                                    }
                                                                    echo implode(" , ", $cat);
                                                                    ?>
                                                                </span>
                                                            </div>
                                                            <div class="mb-1 col-md-4">
                                                                <span><?= _('Specialization') ?>:</span>
                                                                <br>
                                                                <span class="fw-bolder me-25">{{ $doctor->specialization  }}</span>
                                                            </div>
                                                        </div>
                                                    </li>
                                                    <li class="mb-75 mt-2">
                                                        <div class="row">                                                        
                                                            <div class="mb-1 col-md-4">
                                                                <span><?= _('Gender') ?>:</span>
                                                                <br>
                                                                <span class="fw-bolder me-25">{{ $doctor->gender }}</span>
                                                            </div>
                                                            <div class="mb-1 col-md-4">
                                                                <span><?= _('Experience') ?>:</span>
                                                                <br>
                                                                <span class="fw-bolder me-25">{{ $doctor->experience  }}</span>
                                                            </div>
                                                            <div class="mb-1 col-md-4">
                                                                
                                                            </div>
                                                        </div>
                                                    </li>
                                                    <li class="mb-75 mt-2">
                                                        <div class="row">                                                        
                                                            <div class="mb-1 col-md-12">
                                                                <span><?= _('Short Description') ?>:</span>
                                                                <br>
                                                                <span class="fw-bolder me-25">{{ $doctor->short_desc }}</span>
                                                            </div>
                                                        </div>
                                                    </li>
                                                </ul>
                                            </div>
                                        </div>
                                        <div class="col-xl-4 col-lg-4 col-md-4  d-flex align-items-start me-2">
                                            <div class="user-avatar-section">
                                                <div class="d-flex align-items-center flex-column">
                                                    <?php $src = !empty($doctor->photo) != '' ? '/image/doctor_profile/' . $doctor->photo : '/admin-assets/images/icons/file-icons/no_document.png'; ?>
                                                    <a href="<?php echo $src; ?>" class="" target="_blank">
                                                        <img class="img-fluid rounded mt-1 mb-3" height="110" width="110" alt="" src="<?php echo $src; ?>"  alt="" />
                                                    </a>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>

                                <div id="personal-info-modern" class="content" role="tabpanel" aria-labelledby="personal-info-modern-trigger">
                                    <div class="d-flex">
                                        <div class="col-xl-12 col-lg-12 col-md-12 align-items-start me-2">
                                            <div class="info-container">
                                                <ul class="list-unstyled f-12">
                                                    <li class="mb-75 mt-2">
                                                        <div class="row">
                                                            <div class="mb-1 col-md-4">
                                                                <span><?= _('Description') ?>:</span>
                                                                <br>
                                                                <span class="fw-bolder me-25">{{ $doctor->doctor_details->description }}</span>
                                                            </div>
                                                            <div class="mb-1 col-md-4">
                                                                <span><?= _('Registration Number') ?>:</span>
                                                                <br>
                                                                <span class="fw-bolder me-25">{{ $doctor->doctor_details->registration_number  }}</span>
                                                            </div>
                                                            <div class="mb-1 col-md-4">
                                                                <span><?= _('Registration Council') ?>:</span>
                                                                <br>
                                                                <span class="fw-bolder me-25">{{ $doctor->doctor_details->registration_council  }}</span>
                                                            </div>
                                                        </div>
                                                    </li>
                                                    <li class="mb-75 mt-2">
                                                        <div class="row">
                                                            <div class="mb-1 col-md-4">
                                                                <span><?= _('Registration Date') ?>:</span>
                                                                <br>
                                                                <span class="fw-bolder me-25"><?= !empty($doctor->doctor_details->registration_date) ? post_display('registration_date', date("d-m-Y", strtotime($doctor->doctor_details->registration_date))) : '' ?></span>
                                                            </div>
                                                            <div class="mb-1 col-md-4">
                                                                <span><?= _('Registration Proof') ?>:</span>
                                                                <br>
                                                                <span class="fw-bolder me-25"><?php $src = !empty($doctor->doctor_details->registration_proof) != '' ? '/image/doctor_mix/' . $doctor->doctor_details->registration_proof : '/admin-assets/images/icons/file-icons/no_document.png'; ?>
                                                                    <a href="<?php echo $src; ?>" class="" target="_blank">View Document</a></span>
                                                            </div>
                                                            <div class="mb-1 col-md-4">
                                                                <span><?= _('Last Degree Obtained') ?>:</span>
                                                                <br>
                                                                <span class="fw-bolder me-25">{{$doctor->doctor_details->last_degree_obtained  }}</span>
                                                            </div>
                                                        </div>
                                                    </li>
                                                    <li class="mb-75 mt-2">
                                                        <div class="row">
                                                            <div class="mb-1 col-md-4">
                                                                <span><?= _('Date Completion') ?>:</span>
                                                                <br>
                                                                <span class="fw-bolder me-25"><?=
                                                                    !empty($doctor->doctor_details->date_of_completion) ? post_display('date_of_completion', date("d-m-Y", strtotime($doctor->doctor_details->date_of_completion))) :''?></span>
                                                            </div>
                                                            <div class="mb-1 col-md-4">
                                                                <span><?= _('College/Institute Name') ?>:</span>
                                                                <br>
                                                                <span class="fw-bolder me-25">{{$doctor->doctor_details->college_institute_name  }}</span>
                                                            </div>
                                                            <div class="mb-1 col-md-4">
                                                                <span><?= _('Qualification Certificates') ?>:</span>
                                                                <br>
                                                                <span class="fw-bolder me-25">
                                                                    <?php $src = !empty($doctor->doctor_details->qualification_certificates) != '' ? '/image/doctor_mix/' . $doctor->doctor_details->qualification_certificates : '/admin-assets/images/icons/file-icons/no_document.png'; ?>
                                                                    <a href="<?php echo $src; ?>" class="" target="_blank">View Document</a>
                                                                </span>
                                                            </div>
                                                        </div>
                                                    </li>
                                                    <li class="mb-75 mt-2">
                                                        <div class="row">
                                                            <div class="mb-1 col-md-12">
                                                                <span><?= _('Services') ?>:</span>
                                                                <br>
                                                                <span class="fw-bolder me-25">
                                                                    <?php
                                                                    if ($doctor->doctor_details->service_json != 'NULL' && !empty($doctor->doctor_details->service_json)):
                                                                        echo $doctor->doctor_details->service_json;
                                                                    endif;
                                                                    ?>
                                                                </span>
                                                            </div>
                                                        </div>
                                                    </li>
                                                    <li class="mb-75 mt-2">
                                                        <div class="row">
                                                            <div class="mb-1 col-md-12">
                                                                <span><?= _('Specialization') ?>:</span>
                                                                <br>
                                                                <span class="fw-bolder me-25">
                                                                    <?php
                                                                    if ($doctor->doctor_details->specialization_json != 'NULL' && !empty($doctor->doctor_details->specialization_json)):
                                                                        echo $doctor->doctor_details->specialization_json;
                                                                    endif;
                                                                    ?>
                                                                </span>
                                                            </div>
                                                        </div>
                                                    </li>
                                                    <li class="mb-75 mt-2">
                                                        <div class="row">
                                                            <div class="mb-1 col-md-12">
                                                                <span><?= _('Education') ?>:</span>
                                                                <br>
                                                                <span class="fw-bolder me-25">
                                                                    <?php
                                                                    if ($doctor->doctor_details->education_json != 'NULL' && !empty($doctor->doctor_details->education_json)):
                                                                        echo $doctor->doctor_details->education_json;
                                                                    endif;
                                                                    ?>
                                                                </span>
                                                            </div>
                                                        </div>
                                                    </li>
                                                    <li class="mb-75 mt-2">
                                                        <div class="row">
                                                            <div class="mb-1 col-md-12">
                                                                <span><?= _('Membership') ?>:</span>
                                                                <br>
                                                                <span class="fw-bolder me-25">
                                                                    <?php
                                                                    if ($doctor->doctor_details->membership_json != 'NULL' && !empty($doctor->doctor_details->membership_json)):
                                                                        echo $doctor->doctor_details->membership_json;
                                                                    endif;
                                                                    ?>
                                                                </span>
                                                            </div>
                                                        </div>
                                                    </li>
                                                    <li class="mb-75 mt-2">
                                                        <div class="row">
                                                            <div class="mb-1 col-md-12">
                                                                <span><?= _('Experience') ?>:</span>
                                                                <br>
                                                                <span class="fw-bolder me-25">
                                                                    <?php
                                                                    if ($doctor->doctor_details->experience_json != 'NULL' && !empty($doctor->doctor_details->experience_json)):
                                                                        echo $doctor->doctor_details->experience_json;
                                                                    endif;
                                                                    ?>
                                                                </span>
                                                            </div>
                                                        </div>
                                                    </li>
                                                    <li class="mb-75 mt-2">
                                                        <div class="row">
                                                            <div class="mb-1 col-md-12">
                                                                <span><?= _('Registration') ?>:</span>
                                                                <br>
                                                                <span class="fw-bolder me-25">
                                                                    <?php
                                                                    if ($doctor->doctor_details->registration_json != 'NULL' && !empty($doctor->doctor_details->registration_json)):
                                                                        echo $doctor->doctor_details->registration_json;
                                                                    endif;
                                                                    ?>
                                                                </span>
                                                            </div>
                                                        </div>
                                                    </li>
                                                    <li class="mb-75 mt-2">
                                                        <div class="row">
                                                            <div class="mb-1 col-md-3">
                                                                <span><?= _('Aadhar No') ?>:</span>
                                                                <br>
                                                                <span class="fw-bolder me-25">{{ $doctor->doctor_details->aadhar_card_no }}</span>
                                                            </div>
                                                            <div class="mb-1 col-md-3">
                                                                <span><?= _('Aadhar Card Document') ?>:</span>
                                                                <br>
                                                                <span class="fw-bolder me-25"> 
                                                                    <?php $src = !empty($doctor->doctor_details->aadhar_card_document) != '' ? '/image/doctor_mix/' . $doctor->doctor_details->aadhar_card_document : '/admin-assets/images/icons/file-icons/no_document.png'; ?>
                                                                    <a href="<?php echo $src; ?>" class="" target="_blank">View Document</a>
                                                                </span>
                                                            </div>
                                                            <div class="mb-1 col-md-3">
                                                                <span><?= _('PAN No') ?>:</span>
                                                                <br>
                                                                <span class="fw-bolder me-25">{{ $doctor->doctor_details->pan_card_no }}</span>
                                                            </div>
                                                            <div class="mb-1 col-md-3">
                                                                <span><?= _('PAN Card Document') ?>:</span>
                                                                <br>
                                                                <span class="fw-bolder me-25">
                                                                    <?php $src = !empty($doctor->doctor_details->pan_card_document) != '' ? '/image/doctor_mix/' . $doctor->doctor_details->pan_card_document : '/admin-assets/images/icons/file-icons/no_document.png'; ?>
                                                                    <a href="<?php echo $src; ?>" class="" target="_blank">View Document</a>
                                                                </span>
                                                            </div>
                                                        </div>
                                                    </li>
                                                </ul>
                                            </div>
                                        </div>
                                        <!--												<div class="col-xl-5 col-lg-3 col-md-3  d-flex align-items-start me-2">
                                                                                                                                                        <div class="info-container">
                                                                                                                                                                        <ul class="list-unstyled">
                                        
                                                                                                                                                                        </ul>
                                        
                                                                                                                                                        </div>
                                                                                                                                         </div>
                                        -->


                                    </div>
                                </div>
                            </div>

                        </div>
                    </section>
                    <!-- /Modern Horizontal Wizard -->

                    <div class="row" data-select2-id="12">
                        <div class="col-12">
                            <a href="{{ route('admin.doctor.edit', ['id'=>$doctor->id] )  }}" class="btn btn-primary me-1 waves-effect waves-float waves-light" > Edit</a>
                            <a href="{{route('admin.doctor')}}" class="btn btn-outline-secondary waves-effect">Back</a>
                        </div>
                    </div>


                </div>

            </div>

        </div>
    </div>
</div>
@endsection

