@extends("backend.layouts.master")
@section('title') Doctor Edit @endsection
@section('content')
<!-- BEGIN: Content-->
<div class="app-content content ">
    <div class="content-wrapper p-0">
        <div class="content-body">
            <div class="card" data-select2-id="14">
                <div class="card-header border-bottom">
                    <h4 class="card-title">Add New Doctor Details </h4>
                </div>
                <div class="card-body py-2 my-25" data-select2-id="53">
                    <!-- header section -->
                    <!-- form -->
                    @include('backend.message')
                    <form class="needs-validation" method="POST" action="{{route('admin.doctor.store')}}" method="POST" enctype="multipart/form-data" novalidate>
                        {{ csrf_field() }}
                        <!-- Modern Horizontal Wizard -->
                        <section class="modern-horizontal-wizard">
                            <div class="bs-stepper wizard-modern modern-wizard-example">
                                <div class="bs-stepper-header">
                                    <div class="step" data-target="#account-details-modern" role="tab"
                                         id="account-details-modern-trigger">
                                        <button type="button" class="step-trigger">
                                            <span class="bs-stepper-box">
                                                <i data-feather="user" class="font-medium-3"></i>
                                            </span>
                                            <span class="bs-stepper-label">
                                                <span class="bs-stepper-title">Doctor Personal Details</span>
                                            </span>
                                        </button>
                                    </div>
                                    <div class="line">
                                        <i data-feather="chevron-right" class="font-medium-2"></i>
                                    </div>
                                    <div class="step" data-target="#personal-info-modern" role="tab"
                                         id="personal-info-modern-trigger">
                                        <button type="button" class="step-trigger">
                                            <span class="bs-stepper-box">
                                                <i data-feather="file-text" class="font-medium-3"></i>
                                            </span>
                                            <span class="bs-stepper-label">
                                                <span class="bs-stepper-title">Doctor Additional Details</span>
                                            </span>
                                        </button>
                                    </div>
                                </div>
                                <div class="bs-stepper-content">
                                    <div id="account-details-modern" class="content" role="tabpanel" aria-labelledby="account-details-modern-trigger">
                                        <div class="content-header">
                                            <h5 class="mb-0">Doctor Details</h5>
                                            <small class="text-muted">Enter Doctor Details.</small>
                                        </div>
                                        <div class="row">
                                            <div class="mb-1 col-md-8">
                                                <label class="form-label" for="user_id"><?= _('User') ?></label>
                                                <input type="text" name="user" id="user_search" class="form-control" placeholder="<?= _('Select User') ?>"
                                                       value="" required/>
                                                <input type="hidden" id="user_id" name="user_id" value="">

                                            </div>
                                        </div>

                                        <div class="row">
                                            <div class="mb-1 col-md-4">
                                                <label class="form-label" for="first_name"><?= _('First Name') ?></label>
                                                <input type="text" name="first_name" id="first_name" class="form-control" placeholder="<?= _('First Name') ?>" required />
                                            </div>
                                            <div class="mb-1 col-md-4">
                                                <label class="form-label" for="middle_name"><?= _('Middle Name') ?></label>
                                                <input type="text" name="middle_name" id="middle_name" class="form-control" placeholder="<?= _('Middle Name') ?>"  />
                                            </div>
                                            <div class="mb-1 col-md-4">
                                                <label class="form-label" for="last_name"><?= _('Last Name') ?></label>
                                                <input type="text" name="last_name" id="last_name" class="form-control" placeholder="<?= _('Last Name') ?>" required/>
                                            </div>
                                        </div>
                                        <div class="row">
                                            <div class="mb-1 col-md-4">
                                                <label class="form-label" for="first_name"><?= _('Phone') ?></label>
                                                <input type="text" name="phone" class="form-control" placeholder="<?= _('Phone') ?>" pattern="[0-9]+" />
                                            </div>
                                            <div class="mb-1 col-md-4">
                                                <label class="form-label" for="first_name"><?= _('Email') ?></label>
                                                <input type="email" name="email" class="form-control" placeholder="<?= _('Email') ?>" required/>
                                            </div>
                                            <div class="mb-1 col-md-4">
                                                <label class="form-label" for="gender"><?= _('Gender') ?></label>
                                                <select name="gender" class="form-select select2" required>
                                                    <option value=""></option>
                                                    <?php
                                                    $set_values = post_display('gender');
                                                    ?>
                                                    @foreach($gender as $row)
                                                    <option value="<?= $row ?>" <?= $row == $set_values ? 'selected' : '' ?>><?= $row ?></option>
                                                    @endforeach

                                                </select>
                                            </div>
                                        </div>
                                        <div class="row">
                                            <div class="mb-1 col-md-6">
                                                <label class="form-label" for="first_name"><?= _('Specialization') ?></label>
                                                <select name="specialization" class="form-select select2" required>
                                                    @foreach($specialization as $row)
                                                    <option value="<?= $row ?>" ><?= $row ?></option>
                                                    @endforeach

                                                </select>
                                            </div>
                                            <div class="mb-1 col-md-6">
                                                <label class="form-label" for="first_name"><?= _('Category') ?></label>
                                                <select name="sub_category_id[]" class="form-select select2" multiple required>
                                                    @foreach($categories as $row)
                                                    <option value="<?= $row['id'] ?>" ><?= $row['name'] ?></option>
                                                    @endforeach

                                                </select>
                                            </div>
                                        </div>
                                        <div class="row">
                                            <div class="mb-1 col-md-6">
                                                <label class="form-label" for="short_desc"><?= _('Short Description (Max - 100 Char)') ?></label>
                                                <textarea name="short_desc" maxlength="100" class="form-control" cols="5" rows="3" required></textarea>
                                            </div>
                                            <div class="mb-1 col-md-6">
                                                <label class="form-label" for="short_desc"><?= _('Upload Profile Pic') ?></label>
                                                <div data-provides="fileupload" class="fileupload fileupload-new">
                                                    <div style="width: 150px; height: 100px;" class="fileupload-new thumbnail">
                                                        <?php $src = '/admin-assets/images/icons/file-icons/no_document.png'; ?>
                                                        <img alt="" src="<?php echo $src; ?>">
                                                    </div>
                                                    <div style="max-width: 150px; max-height: 100px; line-height: 20px;" class="fileupload-preview fileupload-exists thumbnail"></div>
                                                    <div>
                                                        <span class="btn btn-file" style="padding: 10px 0px 0px 0px;">
                                                            <span class="btn btn-primary fileupload-new">Select image</span>
                                                            <span class="btn btn-primary fileupload-exists">Change</span>
                                                            <input data-file-profile="true" type="file" accept="image/*" name="photo">
                                                        </span>
                                                        <a href="javascript:void(0)" class="btn btn-outline-secondary mt-1 waves-effect" data-remove-profile="true">Remove</a>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                        <div class="row">
                                            <div class="mb-1 col-md-3">
                                                <label class="form-label" for="experience"><?= _('Experience') ?></label>
                                                <input type="text" name="experience" class="form-control" pattern="[0-9]+([\.,][0-9]+)?" title="<?= _('Only Allow Decimal number ex 5.6') ?>"  placeholder="<?= _('Experience') ?>" required/>
                                            </div>
                                            <div class="mb-1 col-md-3">
                                                <label class="form-label mb-50" for="status"><?= __('Status') ?></label>

                                                <select name="status_id" class="form-select select2">
                                                    <?php
                                                    $set_values = post_display('status_id');
                                                    ?>
                                                    @foreach(doctor_status as $key=>$val)
                                                    <option class="dropdown-item" value="<?= $key ?>" <?= $key == $set_values ? 'selected' : '' ?>><?= $val ?></option>
                                                    @endforeach
                                                </select>
                                            </div>
                                        </div>
                                    </div>
                                    <div id="personal-info-modern" class="content" role="tabpanel" aria-labelledby="personal-info-modern-trigger">
                                        <div class="row">
                                            <div class="mb-1 col-md-12 border-bottom pb-1">
                                                <label class="form-label" for="description"><?= _('Description') ?></label>
                                                <textarea name="description" class="form-control" cols="5" rows="5"></textarea>
                                            </div>
                                        </div>
                                        <div class="row border-bottom">
                                            <div class="mb-1 col-md-6">
                                                <div class="mb-1 col-md-12">
                                                    <label class="form-label" for="registration_number"><?= _('Registration Number') ?></label>
                                                    <input type="text" name="registration_number" class="form-control" placeholder="<?= _('Registration Number') ?>"  />
                                                </div>
                                                <div class="mb-1 col-md-12">
                                                    <label class="form-label" for="registration_council"><?= _('Registration Council') ?></label>
                                                    <select name="registration_council" class="form-select select2">
                                                        <option value=""></option>
                                                        <?php
                                                        $set_values = post_display('registration_council');
                                                        ?>
                                                        @foreach($registration_council as $row)
                                                        @if(!empty($row)):
                                                        <option value="<?= $row ?>" <?= $row == $set_values ? 'selected' : '' ?>><?= $row ?></option>
                                                        @endif
                                                        @endforeach
                                                    </select>
                                                </div>
                                                <div class="mb-1 col-md-12">
                                                    <label class="form-label" for="registration_date"><?= _('Registration Date') ?></label>
                                                    <input type="text" name="registration_date" class="form-control datepicker" placeholder="<?= _('Registration Date') ?>" />
                                                </div>
                                            </div>
                                            <div class="mb-1 col-md-6">
                                                <label class="form-label" for="registration_council"><?= _('Registration Proof') ?></label>
                                                <div data-provides="fileupload" class="fileupload fileupload-new">
                                                    <div style="width: 200px; height: 150px;" class="fileupload-new thumbnail">
                                                        <?php $src = '/admin-assets/images/icons/file-icons/no_document.png'; ?>
                                                        <img alt="" src="<?php echo $src; ?>">
                                                    </div>
                                                    <div style="max-width: 200px; max-height: 150px; line-height: 20px;" class="fileupload-preview fileupload-exists thumbnail"></div>
                                                    <div>
                                                        <span class="btn btn-file"><span class="fileupload-new">Select document</span>
                                                            <span class="fileupload-exists">Change</span>
                                                            <input type="file" name="registration_proof"></span>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                        <div class="row border-bottom p-t-10">
                                            <div class="mb-1 col-md-6">
                                                <div class="mb-1 col-md-12">
                                                    <label class="form-label" for="last_degree_obtained"><?= _('Last Degree Obtained') ?></label>
                                                    <input type="text" name="last_degree_obtained" class="form-control" placeholder="<?= _('Last Degree Obtained') ?>"  />
                                                </div>
                                                <div class="mb-1 col-md-12">
                                                    <label class="form-label" for="college_institute_name"><?= _('College/Institute Name') ?></label>
                                                    <input type="text" name="college_institute_name" class="form-control" placeholder="<?= _('College/Institute Name') ?>"  />
                                                </div>
                                                <div class="mb-1 col-md-12">
                                                    <label class="form-label" for="date_of_completion"><?= _('Date Completion') ?></label>
                                                    <input type="text" name="date_of_completion" class="form-control datepicker" placeholder="<?= _('Date Completion') ?>" />
                                                </div>
                                            </div>
                                            <div class="mb-1 col-md-6">
                                                <label class="form-label" for="registration_council"><?= _('Qualification Certificates') ?></label>
                                                <div data-provides="fileupload" class="fileupload fileupload-new">
                                                    <div style="width: 200px; height: 150px;" class="fileupload-new thumbnail">
                                                        <?php $src = '/admin-assets/images/icons/file-icons/no_document.png'; ?>
                                                        <img alt="" src="<?php echo $src; ?>">
                                                    </div>
                                                    <div style="max-width: 200px; max-height: 150px; line-height: 20px;" class="fileupload-preview fileupload-exists thumbnail"></div>
                                                    <div>
                                                        <span class="btn btn-file">
                                                            <span class="fileupload-new">Select document</span>
                                                            <span class="fileupload-exists">Change</span>
                                                            <input type="file" name="qualification_certificates">
                                                        </span>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                        <div class="row border-bottom p-t-10">
                                            <div class="mb-1 col-md-6">
                                                <div class="mb-1 col-md-12">
                                                    <label class="form-label"
                                                           for="aadhar_card_document"><?= _('Aadhar Card Document') ?></label>
                                                    <div data-provides="fileupload" class="fileupload fileupload-new">
                                                        <div style="width: 200px; height: 150px;" class="fileupload-new thumbnail">
                                                            <?php $src = '/admin-assets/images/icons/file-icons/no_document.png'; ?>
                                                            <img alt="" src="<?php echo $src; ?>">
                                                        </div>
                                                        <div style="max-width: 200px; max-height: 150px; line-height: 20px;" class="fileupload-preview fileupload-exists thumbnail"></div>
                                                        <div>
                                                            <span class="btn btn-file">
                                                                <span class="fileupload-new">Select document</span>
                                                                <span class="fileupload-exists">Change</span>
                                                                <input type="file" name="aadhar_card_document">
                                                            </span>
                                                        </div>
                                                    </div>
                                                </div>
                                                <div class="mb-1 col-md-12">
                                                    <label class="form-label" for="aadhar_card_no"><?= _('Aadhar No') ?></label>
                                                    <input type="text" name="aadhar_card_no" class="form-control" placeholder="<?= _('Aadhar No') ?>"/>
                                                </div>
                                            </div>
                                            <div class="mb-1 col-md-6">
                                                <div class="mb-1 col-md-12">
                                                    <label class="form-label" for="pan_card_document"><?= _('PAN Card Document') ?></label>
                                                    <div data-provides="fileupload" class="fileupload fileupload-new">
                                                        <div style="width: 200px; height: 150px;" class="fileupload-new thumbnail">
                                                            <?php $src = '/admin-assets/images/icons/file-icons/no_document.png'; ?>
                                                            <img alt="" src="<?php echo $src; ?>">
                                                        </div>
                                                        <div style="max-width: 200px; max-height: 150px; line-height: 20px;" class="fileupload-preview fileupload-exists thumbnail"></div>
                                                        <div>
                                                            <span class="btn btn-file">
                                                                <span class="fileupload-new">Select document</span>
                                                                <span class="fileupload-exists">Change</span>
                                                                <input type="file" name="pan_card_document">
                                                            </span>
                                                        </div>
                                                    </div>
                                                </div>
                                                <div class="mb-1 col-md-12">
                                                    <label class="form-label" for="pan_card_no"><?= _('PAN No') ?></label>
                                                    <input type="text" name="pan_card_no" class="form-control" placeholder="<?= _('PAN No') ?>"/>
                                                </div>
                                            </div>
                                        </div>
                                        <div class="row p-t-10">
                                            <div class="mb-1 col-md-12">
                                                <label class="form-label" for="services"><?= _('Services') ?></label>
                                                <select name="services[]" class="form-control tags-input" multiple="multiple">
                                                </select>
                                                <label class="form-label" for="specialization_json"><?= _('Specialization') ?></label>
                                                <select name="specialization_json[]" class="form-control tags-input" multiple="multiple">
                                                </select>
                                            </div>
                                            <div class="mb-1 col-md-12">
                                                <label class="form-label"
                                                       for="education"><?= _('Education') ?></label>
                                                <select name="education[]" class="form-control tags-input" multiple="multiple">
                                                </select>
                                                <label class="form-label"
                                                       for="membership"><?= _('Membership') ?></label>
                                                <select name="membership[]" class="form-control tags-input" multiple="multiple">
                                                </select>
                                            </div>
                                            <div class="mb-1 col-md-12">
                                                <label class="form-label"
                                                       for="experience"><?= _('Experience') ?></label>
                                                <select name="experience_json[]" class="form-control tags-input" multiple="multiple">
                                                </select>
                                                <label class="form-label"
                                                       for="registration"><?= _('Registration') ?></label>
                                                <select name="registration[]" class="form-control tags-input" multiple="multiple">
                                                </select>
                                            </div>
                                        </div>
                                    </div>
                                    </section>
                                    <!-- /Modern Horizontal Wizard -->
                                    <div class="row" data-select2-id="12">
                                        <div class="col-12">
                                            <button type="submit" class="btn btn-primary mt-1 me-1 waves-effect waves-float waves-light">Save changes</button>
                                            <a class="btn btn-outline-secondary mt-1 waves-effect" href="{{ route("admin.doctor") }}">Back</a>
                                        </div>
                                    </div>
                                    </form>
                                    <!--/ form -->
                                </div>
                            </div>
                            </div>
                            </div>
                            </div>
                            @endsection
                            @section('script')
                            <script>
                                $(document).ready(function () {
                                    $("#user_search").autocomplete({
                                        source: function (request, response) {
                                            $.ajax({
                                                url: "{{route('admin.doctor.user_select')}}",
                                                type: 'GET',
                                                dataType: "json",
                                                data: {
                                                    search: request.term,
                                                    '_token': "{{ csrf_token() }}",
                                                },
                                                success: function (data) {
                                                    response(data);
                                                }
                                            });
                                        },
                                        select: function (event, ui) {
                                            $('#user_search').val(ui.item.label);
                                            $('#user_id').val(ui.item.id);
                                            console.log(ui.item);
                                            return false;
                                        }
                                    });

                                });
                            </script>
                            @endsection
