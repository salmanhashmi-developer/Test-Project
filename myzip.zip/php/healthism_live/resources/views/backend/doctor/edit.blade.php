@extends("backend.layouts.master")
@section('title') Doctor Edit @endsection
@section('content')

<!-- BEGIN: Content-->
<div class="app-content content ">

    <div class="content-wrapper p-0">

        <div class="content-body">

            <div class="card" data-select2-id="14">
                <div class="card-header border-bottom">
                    <h4 class="card-title">Doctor Details Edit</h4>
                </div>
                <div class="card-body py-2 my-25" data-select2-id="53">
                    <!-- header section -->

                    <!-- form -->
                    @include('backend.message')

                    <form class="needs-validation" method="POST" action="{{route('admin.doctor.update', $doctor->id)}}" method="POST" enctype="multipart/form-data" novalidate>
                        {{ csrf_field() }}


                        <!-- Modern Horizontal Wizard -->
                        <section class="modern-horizontal-wizard">
                            <div class="bs-stepper wizard-modern modern-wizard-example">
                                <div class="bs-stepper-header">
                                    <div class="step" data-target="#account-details-modern" role="tab"
                                         id="account-details-modern-trigger">
                                        <button type="button" class="step-trigger">
                                            <span class="bs-stepper-box">
                                                <i data-feather="user" class="font-medium-3"></i>
                                            </span>
                                            <span class="bs-stepper-label">
                                                <span class="bs-stepper-title">Doctor Personal Details</span>
                                            </span>
                                        </button>
                                    </div>
                                    <div class="line">
                                        <i data-feather="chevron-right" class="font-medium-2"></i>
                                    </div>
                                    <div class="step" data-target="#personal-info-modern" role="tab"
                                         id="personal-info-modern-trigger">
                                        <button type="button" class="step-trigger">
                                            <span class="bs-stepper-box">
                                                <i data-feather="file-text" class="font-medium-3"></i>
                                            </span>
                                            <span class="bs-stepper-label">
                                                <span class="bs-stepper-title">Doctor Additional Details</span>
                                            </span>
                                        </button>
                                    </div>
                                </div>
                                <div class="bs-stepper-content">
                                    <div id="account-details-modern" class="content" role="tabpanel" aria-labelledby="account-details-modern-trigger">
                                        <div class="content-header">
                                            <h5 class="mb-0">Doctor Details</h5>
                                            <small class="text-muted">Enter Doctor Details.</small>
                                        </div>
                                        <div class="row">
                                            <div class="mb-1 col-md-6">
                                                <label class="form-label" for="user_id"><?= _('User') ?></label>
                                                <input type="text" name="user" id="user_search" class="form-control" placeholder="<?= _('Select User') ?>"
                                                       value="<?= !empty($doctor->user) ? post_display('user', "{$doctor->user->first_name} {$doctor->user->last_name}") : '' ?>" required/>
                                                <input type="hidden" id="user_id" name="user_id" value="<?= !empty($doctor->user) ? $doctor->user->id : '' ?>">

                                            </div>
                                        </div>
                                        <div class="row">
                                            <div class="mb-1 col-md-4">
                                                <label class="form-label" for="first_name"><?= _('First Name') ?></label>
                                                <input type="text" name="first_name" id="first_name" class="form-control" placeholder="<?= _('First Name') ?>" value="<?= post_display('first_name', $doctor->first_name) ?>" required/>
                                            </div>
                                            <div class="mb-1 col-md-4">
                                                <label class="form-label" for="middle_name"><?= _('Middle Name') ?></label>
                                                <input type="text" name="middle_name" id="middle_name" class="form-control" placeholder="<?= _('Middle Name') ?>" value="<?= post_display('middle_name', $doctor->middle_name) ?>" />
                                            </div>
                                            <div class="mb-1 col-md-4">
                                                <label class="form-label" for="last_name"><?= _('Last Name') ?></label>
                                                <input type="text" name="last_name" id="last_name" class="form-control" placeholder="<?= _('Last Name') ?>" value="<?= post_display('last_name', $doctor->last_name) ?>" required/>
                                            </div>
                                        </div>
                                        <div class="row">
                                            <div class="mb-1 col-md-4">
                                                <label class="form-label" for="first_name"><?= _('Phone') ?></label>
                                                <input type="text" name="phone" class="form-control" placeholder="<?= _('Phone') ?>" value="<?= post_display('phone', $doctor->phone) ?>" pattern="[0-9]+" required/>
                                            </div>
                                            <div class="mb-1 col-md-6">
                                                <label class="form-label" for="first_name"><?= _('Email') ?></label>
                                                <input type="email" name="email" class="form-control" placeholder="<?= _('Email') ?>" value="<?= post_display('email', $doctor->email) ?>" required/>
                                            </div>
                                            <div class="mb-1 col-md-2">
                                                <label class="form-label" for="gender"><?= _('Gender') ?></label>
                                                <select name="gender" class="form-select select2" required>
                                                    <option value=""></option>
                                                    <?php
                                                    $set_values = post_display('gender', $doctor->gender);
                                                    ?>
                                                    @foreach($gender as $row)
                                                    <option value="<?= $row ?>" <?= $row == $set_values ? 'selected' : '' ?>><?= $row ?></option>
                                                    @endforeach

                                                </select>
                                            </div>


                                        </div>
                                        <div class="row">
                                            <div class="mb-1 col-md-6">
                                                <label class="form-label" for="first_name"><?= _('Specialization') ?></label>
                                                <select name="specialization" class="form-select select2" required>
                                                    <?php
                                                    $set_values = post_display('specialization', $doctor->specialization);
                                                    ?>
                                                    @foreach($specialization as $row)
                                                    <option value="<?= $row ?>" <?= $row == $set_values ? 'selected' : '' ?>><?= $row ?></option>
                                                    @endforeach

                                                </select>
                                            </div>
                                            <div class="mb-1 col-md-6">
                                                <label class="form-label" for="first_name"><?= _('Category') ?></label>
                                                <select name="sub_category_id[]" class="form-select select2" multiple required>
                                                    <?php
                                                    $set_values = explode(",", $doctor->sub_category_id);
                                                    ?>
                                                    @foreach($categories as $row)
                                                    <option value="<?= $row['id'] ?>" <?= in_array($row['id'], $set_values) ? 'selected' : '' ?>><?= $row['name'] ?></option>
                                                    @endforeach

                                                </select>
                                            </div>
                                        </div>
                                        <div class="row">


                                            <div class="mb-1 col-md-6">
                                                <label class="form-label" for="short_desc"><?= _('Short Description (Max - 100 Char)') ?></label>
                                                <textarea name="short_desc" maxlength="100" class="form-control" cols="5" rows="5" required><?= post_display('short_desc', $doctor->short_desc) ?></textarea>
                                            </div>

                                            <div class="mb-1 col-md-6">
                                                <label class="form-label" for="short_desc"><?= _('Change Profile Pic') ?></label>

                                                <div data-provides="fileupload" class="fileupload fileupload-new">

                                                    <div style="width: 150px; height: 100px;" class="fileupload-new thumbnail">
                                                        <?php $src = !empty($doctor->photo) != '' ? '/image/doctor_profile/' . $doctor->photo : '/admin-assets/images/icons/file-icons/no_document.png'; ?>
                                                        <img alt="" src="<?php echo $src; ?>">
                                                    </div>

                                                    <div style="max-width: 150px; max-height: 100px; line-height: 20px;" class="fileupload-preview fileupload-exists thumbnail"></div>

                                                    <div>
                                                        <span class="btn btn-file" style="padding: 10px 0px 0px 0px;">
                                                            <span class="btn btn-primary fileupload-new">Select image</span>
                                                            <span class="btn btn-primary fileupload-exists">Change</span>
                                                            <input type="file" accept="image/*" name="photo">
                                                        </span>
                                                        <?php if (!empty($doctor->photo)) { ?>
                                                            <a class="btn btn-outline-secondary mt-1 waves-effect" href="{{  route('admin.doctor.remove.profile', ['id'=>$doctor->id] )  }}">Remove</a>
                                                        <?php } ?>
                                                    </div>
                                                </div>
                                            </div>


                                        </div>
                                        <div class="row">
                                            <div class="mb-1 col-md-3">
                                                <label class="form-label" for="experience"><?= _('Experience') ?></label>
                                                <input type="text" name="experience" class="form-control"  pattern="[0-9]+([\.,][0-9]+)?" title="<?= _('Only Allow Decimal number ex 5.6') ?>" placeholder="<?= _('Experience') ?>" required value="<?= post_display('experience', $doctor->experience); ?>"/>
                                            </div>

                                            <div class="mb-1 col-md-3">
                                                <label class="form-check-label mb-50" for="status"><?= __('Status') ?></label>

                                                <select name="status_id" class="form-select select2">
                                                    <?php
                                                    $set_values = post_display('status_id', $doctor->status_id);
                                                    ?>
                                                    @foreach(doctor_status as $key=>$val)
                                                    <option class="dropdown-item" value="<?= $key ?>" <?= $key == $set_values ? 'selected' : '' ?>><?= $val ?></option>
                                                    @endforeach

                                                </select>
                                            </div>
                                        </div>

                                    </div>

                                    <div id="personal-info-modern" class="content" role="tabpanel" aria-labelledby="personal-info-modern-trigger">
                                        <div class="row">
                                            <div class="mb-1 col-md-12 border-bottom pb-1">
                                                <label class="form-label" for="description"><?= _('Description') ?></label>
                                                <textarea name="description" class="form-control" cols="5" rows="5"><?= post_display('description', $doctor->doctor_details->description) ?></textarea>
                                            </div>
                                        </div>
                                        <div class="row border-bottom">
                                            <div class="mb-1 col-md-6">
                                                <div class="mb-1 col-md-12">
                                                    <label class="form-label" for="registration_number"><?= _('Registration Number') ?></label>
                                                    <input type="text" name="registration_number" class="form-control" placeholder="<?= _('Registration Number') ?>" value="<?= post_display('registration_number', $doctor->doctor_details->registration_number) ?>" />
                                                </div>
                                                <div class="mb-1 col-md-12">
                                                    <label class="form-label" for="registration_council"><?= _('Registration Council') ?></label>
                                                    <select name="registration_council" class="form-select select2">
                                                        <option value=""></option>
                                                        <?php
                                                        $set_values = post_display('registration_council', $doctor->doctor_details->registration_council);
                                                        ?>
                                                        @foreach($registration_council as $row)
                                                        @if(!empty($row)):
                                                        <option value="<?= $row ?>" <?= $row == $set_values ? 'selected' : '' ?>><?= $row ?></option>
                                                        @endif
                                                        @endforeach
                                                    </select>
                                                </div>
                                                <div class="mb-1 col-md-12">
                                                    <label class="form-label" for="registration_date"><?= _('Registration Date') ?></label>
                                                    <input type="text" name="registration_date"
                                                           class="form-control datepicker"
                                                           placeholder="<?= _('Registration Date') ?>"
                                                           value="<?=
                                                           !empty($doctor->doctor_details->registration_date) ? post_display('registration_date', date("d-m-Y", strtotime($doctor->doctor_details->registration_date))) : ''
                                                           ?>"/>
                                                </div>
                                            </div>
                                            <div class="mb-1 col-md-6">
                                                <label class="form-label" for="registration_council"><?= _('Registration Proof') ?></label>
                                                <div data-provides="fileupload" class="fileupload fileupload-new">
                                                    <div style="width: 200px; height: 150px;" class="fileupload-new thumbnail">
                                                        <?php $src = !empty($doctor->doctor_details->registration_proof) != '' ? '/image/doctor_mix/' . $doctor->doctor_details->registration_proof : '/admin-assets/images/icons/file-icons/no_document.png'; ?>
                                                        <img alt="" src="<?php echo $src; ?>">
                                                    </div>

                                                    <div style="max-width: 200px; max-height: 150px; line-height: 20px;" class="fileupload-preview fileupload-exists thumbnail"></div>

                                                    <div>
                                                        <span class="btn btn-file"><span class="fileupload-new">Select document</span>
                                                            <span class="fileupload-exists">Change</span>
                                                            <input type="file" name="registration_proof"></span>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                        <div class="row border-bottom p-t-10">
                                            <div class="mb-1 col-md-6">
                                                <div class="mb-1 col-md-12">
                                                    <label class="form-label" for="last_degree_obtained"><?= _('Last Degree Obtained') ?></label>
                                                    <input type="text" name="last_degree_obtained" class="form-control" placeholder="<?= _('Last Degree Obtained') ?>" value="<?= post_display('last_degree_obtained', $doctor->doctor_details->last_degree_obtained) ?>" />
                                                </div>
                                                <div class="mb-1 col-md-12">
                                                    <label class="form-label" for="college_institute_name"><?= _('College/Institute Name') ?></label>
                                                    <input type="text" name="college_institute_name" class="form-control" placeholder="<?= _('College/Institute Name') ?>" value="<?= post_display('college_institute_name', $doctor->doctor_details->college_institute_name) ?>" />
                                                </div>
                                                <div class="mb-1 col-md-12">
                                                    <label class="form-label" for="date_of_completion"><?= _('Date Completion') ?></label>
                                                    <input type="text" name="date_of_completion" class="form-control datepicker" placeholder="<?= _('Date Completion') ?>"
                                                           value="<?=
                                                           !empty($doctor->doctor_details->date_of_completion) ? post_display('date_of_completion', date("d-m-Y", strtotime($doctor->doctor_details->date_of_completion))) :
                                                                   ''
                                                           ?>" />
                                                </div>
                                            </div>
                                            <div class="mb-1 col-md-6">
                                                <label class="form-label"
                                                       for="registration_council"><?= _('Qualification Certificates') ?></label>

                                                <div data-provides="fileupload"
                                                     class="fileupload fileupload-new">

                                                    <div style="width: 200px; height: 150px;"
                                                         class="fileupload-new thumbnail">
                                                             <?php $src = !empty($doctor->doctor_details->qualification_certificates) != '' ? '/image/doctor_mix/' . $doctor->doctor_details->qualification_certificates : '/admin-assets/images/icons/file-icons/no_document.png'; ?>
                                                        <img alt="" src="<?php echo $src; ?>">
                                                    </div>
                                                    <div
                                                        style="max-width: 200px; max-height: 150px; line-height: 20px;"
                                                        class="fileupload-preview fileupload-exists thumbnail"></div>

                                                    <div>
                                                        <span class="btn btn-file"><span
                                                                class="fileupload-new">Select document</span>
                                                            <span class="fileupload-exists">Change</span>
                                                            <input type="file"
                                                                   name="qualification_certificates"></span>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                        <div class="row border-bottom p-t-10">
                                            <div class="mb-1 col-md-6">
                                                <div class="mb-1 col-md-12">
                                                    <label class="form-label" for="aadhar_card_document"><?= _('Aadhar Card Document') ?></label>
                                                    <div data-provides="fileupload" class="fileupload fileupload-new">
                                                        <div style="width: 200px; height: 150px;"
                                                             class="fileupload-new thumbnail">
                                                                 <?php $src = !empty($doctor->doctor_details->aadhar_card_document) != '' ? '/image/doctor_mix/' . $doctor->doctor_details->aadhar_card_document : '/admin-assets/images/icons/file-icons/no_document.png'; ?>
                                                            <img alt="" src="<?php echo $src; ?>">
                                                        </div>
                                                        <div
                                                            style="max-width: 200px; max-height: 150px; line-height: 20px;"
                                                            class="fileupload-preview fileupload-exists thumbnail"></div>
                                                        <div>
                                                            <span class="btn btn-file"><span
                                                                    class="fileupload-new">Select document</span>
                                                                <span class="fileupload-exists">Change</span>
                                                                <input type="file"
                                                                       name="aadhar_card_document"></span>
                                                        </div>
                                                    </div>
                                                </div>
                                                <div class="mb-1 col-md-12">
                                                    <label class="form-label"
                                                           for="aadhar_card_no"><?= _('Aadhar No') ?></label>
                                                    <input type="text" name="aadhar_card_no"
                                                           class="form-control"
                                                           placeholder="<?= _('Aadhar No') ?>"
                                                           value="<?= post_display('aadhar_card_no', $doctor->doctor_details->aadhar_card_no) ?>"/>
                                                </div>
                                            </div>
                                            <div class="mb-1 col-md-6">
                                                <div class="mb-1 col-md-6">
                                                    <label class="form-label"
                                                           for="pan_card_document"><?= _('PAN Card Document') ?></label>
                                                    <div data-provides="fileupload"
                                                         class="fileupload fileupload-new">
                                                        <div style="width: 200px; height: 150px;"
                                                             class="fileupload-new thumbnail">
                                                                 <?php $src = !empty($doctor->doctor_details->pan_card_document) != '' ? '/image/doctor_mix/' . $doctor->doctor_details->pan_card_document : '/admin-assets/images/icons/file-icons/no_document.png'; ?>
                                                            <img alt="" src="<?php echo $src; ?>">
                                                        </div>
                                                        <div  style="max-width: 200px; max-height: 150px; line-height: 20px;"
                                                              class="fileupload-preview fileupload-exists thumbnail"></div>
                                                        <div>
                                                            <span class="btn btn-file"><span
                                                                    class="fileupload-new">Select document</span>
                                                                <span class="fileupload-exists">Change</span>
                                                                <input type="file" name="pan_card_document"></span>
                                                        </div>
                                                    </div>
                                                </div>
                                                <div class="mb-1 col-md-6">
                                                    <label class="form-label"
                                                           for="pan_card_no"><?= _('PAN No') ?></label>
                                                    <input type="text" name="pan_card_no"
                                                           class="form-control"
                                                           placeholder="<?= _('PAN No') ?>"
                                                           value="<?= post_display('pan_card_no', $doctor->doctor_details->pan_card_no)
                                                                 ?>"/>
                                                </div>
                                            </div>
                                        </div>
                                        <div class="row">
                                            <div class="mb-1 col-md-12">
                                                <label class="form-label"
                                                       for="services"><?= _('Services') ?></label>
                                                <select name="services[]" class="form-control tags-input" multiple="multiple">
                                                    <?php
                                                    if (!empty($doctor->doctor_details->service_json)):
                                                        $array = json_decode($doctor->doctor_details->service_json, true);
                                                        if (!empty($array)) {
                                                            foreach ($array as $row) {
                                                                ?>
                                                                <option value="<?= $row ?>" selected><?= $row ?></option>
                                                                <?php
                                                            }
                                                        }
                                                    endif;
                                                    ?>
                                                </select>
                                                <label class="form-label"
                                                       for="specialization_json"><?= _('Specialization') ?></label>
                                                <select name="specialization_json[]" class="form-control tags-input" multiple="multiple">
                                                    <?php
                                                    if (!empty($doctor->doctor_details->specialization_json)):
                                                        $array = json_decode($doctor->doctor_details->specialization_json, true);
                                                        if (!empty($array)) {
                                                            foreach ($array as $row) {
                                                                ?>
                                                                <option value="<?= $row ?>" selected><?= $row ?></option>
                                                                <?php
                                                            }
                                                        }
                                                    endif;
                                                    ?>
                                                </select>
                                            </div>
                                        </div>
                                        <div class="mb-1 col-md-12">
                                            <label class="form-label"
                                                   for="education"><?= _('Education') ?></label>
                                            <select name="education[]" class="form-control tags-input" multiple="multiple">
                                                <?php
                                                if (!empty($doctor->doctor_details->education_json)):
                                                    $array = json_decode($doctor->doctor_details->education_json, true);
                                                    if (!empty($array)) {
                                                        foreach ($array as $row) {
                                                            ?>
                                                            <option value="<?= $row ?>" selected><?= $row ?></option>
                                                            <?php
                                                        }
                                                    }
                                                endif;
                                                ?>
                                            </select>
                                            <label class="form-label"
                                                   for="membership"><?= _('Membership') ?></label>
                                            <select name="membership[]" class="form-control tags-input" multiple="multiple">
                                                <?php
                                                if (!empty($doctor->doctor_details->membership_json)):
                                                    $array = json_decode($doctor->doctor_details->membership_json, true);
                                                    if (!empty($array)) {
                                                        foreach ($array as $row) {
                                                            ?>
                                                            <option value="<?= $row ?>" selected><?= $row ?></option>
                                                            <?php
                                                        }
                                                    }
                                                endif;
                                                ?>
                                            </select>
                                        </div>
                                        <div class="mb-1 col-md-12">
                                            <label class="form-label"
                                                   for="experience"><?= _('Experience') ?></label>
                                            <select name="experience_json[]" class="form-control tags-input" multiple="multiple">
                                                <?php
                                                if (!empty($doctor->doctor_details->experience_json)):
                                                    $array = json_decode($doctor->doctor_details->experience_json, true);
                                                    if (!empty($array)) {
                                                        foreach ($array as $row) {
                                                            ?>
                                                            <option value="<?= $row ?>" selected><?= $row ?></option>
                                                            <?php
                                                        }
                                                    }
                                                endif;
                                                ?>
                                            </select>
                                            <label class="form-label"
                                                   for="registration"><?= _('Registration') ?></label>
                                            <select name="registration[]" class="form-control tags-input" multiple="multiple">
                                                <?php
                                                if (!empty($doctor->doctor_details->registration_json)):
                                                    $array = json_decode($doctor->doctor_details->registration_json, true);
                                                    if (!empty($array)) {
                                                        foreach ($array as $row) {
                                                            ?>
                                                            <option value="<?= $row ?>" selected><?= $row ?></option>
                                                            <?php
                                                        }
                                                    }
                                                endif;
                                                ?>
                                            </select>
                                        </div>
                                    </div>
                                    </section>
                                    <!-- /Modern Horizontal Wizard -->
                                    <div class="row" data-select2-id="12">
                                        <div class="col-12">
                                            <button type="submit" class="btn btn-primary mt-1 me-1 waves-effect waves-float waves-light">Save changes</button>
                                            <a class="btn btn-outline-secondary mt-1 waves-effect" href="{{ route("admin.doctor") }}">Back</a>
                                        </div>
                                    </div>
                                    </form>
                                    <!--/ form -->
                                </div>
                            </div>

                            </div>


                            </div>
                            </div>
                            @endsection
                            @section('script')
                            <script>
                                $(document).ready(function () {
                                    $("#user_search").autocomplete({
                                        source: function (request, response) {
                                            $.ajax({
                                                url: "{{route('admin.doctor.user_select')}}",
                                                type: 'GET',
                                                dataType: "json",
                                                data: {
                                                    search: request.term,
                                                    '_token': "{{ csrf_token() }}",
                                                },
                                                success: function (data) {
                                                    response(data);
                                                }
                                            });
                                        },
                                        select: function (event, ui) {
                                            $('#user_search').val(ui.item.label);
                                            $('#user_id').val(ui.item.id);
                                            console.log(ui.item);
                                            return false;
                                        }
                                    });

                                });
                            </script>
                            @endsection
