<div class="row">
    <form class="" method="POST" action="{{ route('admin.doctor') }}" id="search_form" onsubmit="return false">
        {{ csrf_field() }}
        <div class="col-12">
            <div class="card">
                <div class="card-header border-bottom">
                    <h4 class="card-title">{{ __('Doctor List') }}</h4>
                    <div
                        class="dt-action-buttons d-flex align-items-center justify-content-center justify-content-lg-end flex-lg-nowrap flex-wrap">
                        <div class="dt-buttons d-inline-flex">
                            <a class="dt-button add-new btn btn-primary"
                               href="{{ route('admin.doctor.add') }}">{{ __('Add New Doctor') }}</a>
                        </div>
                    </div>
                </div>
                <!--Search Form -->
                <div class="card-body mt-2">
                    <input type="hidden" name="page" id="page"
                           value="{{ empty(app('request')->input('page')) ? 1 : app('request')->input('page') }}">
                    <input type="hidden" name="sort_field" id="sort_field"
                           value="{{ app('request')->input('sort_field') }}">
                    <input type="hidden" name="sort_action" id="sort_action"
                           value="{{ app('request')->input('sort_action') }}">
                    <div class="row g-1 mb-md-1">
                        <div class="col-md-4">
                            <label class="form-label">Name</label>
                            <input type="text" class="form-control dt-input dt-full-name" placeholder="Doctor Name"
                                   name="name" value="{{ app('request')->input('name') }}">
                        </div>
                        <div class="col-md-4">
                            <label class="form-label">Phone</label>
                            <input type="text" class="form-control dt-input" placeholder="Phone No" name="phone"
                                   value="{{ app('request')->input('phone') }}">
                        </div>
                        <div class="col-md-4">
                            <label class="form-label">Email</label>
                            <input type="text" class="form-control dt-input" placeholder="Email" name="email"
                                   value="{{ app('request')->input('email') }}">
                        </div>
                    </div>
                    <div class="row g-1">
                        <div class="col-md-4">
                            <label class="form-label">Specialization</label>
                            <select name="specialization" class="form-select select2">
                                <option value="">All</option>
                                <?php
                                $set_values = request_display('specialization');
                                ?>
                                @foreach ($specialization as $row)
                                <option value="<?= $row ?>" <?= $row == $set_values ? 'selected' : '' ?>><?= $row ?>
                                </option>
                                @endforeach
                            </select>
                        </div>
                        <div class="col-md-4">
                            <label class="form-label">Gender</label>
                            <select name="gender" class="form-select select2">
                                <option value="">All</option>
                                <?php
                                $set_values = request_display('gender');
                                ?>
                                @foreach ($gender as $row)
                                <option value="<?= $row ?>" <?= $row == $set_values ? 'selected' : '' ?>><?= $row ?>
                                </option>
                                @endforeach
                            </select>
                        </div>
                        <div class="col-md-4">
                            <label class="form-label"></label>
                            <button type="submit"
                                    class="btn btn-primary mt-2 waves-effect waves-float waves-light">Search</button>
                        </div>
                    </div>
                </div>
                <hr class="my-0">
                <div class="card-datatable">
                    <?php echo parPageRecordDropDown(); ?>
                    @if (!$doctors->isEmpty())
                    @php $start = $doctors->firstItem(); @endphp
                    <div class="table-responsive">
                        <table class="table table-bordered table-hover">
                            <thead>
                                <tr role="row">
                                    <th></th>
                                    <th><?php echo sort_field_display('name', 'Name'); ?></th>
                                    <th>Phone</th>
                                    <th>Email</th>
                                    <th><?php echo sort_field_display('Specialization', 'Specialization'); ?></th>
                                    <th><?php echo sort_field_display('Gender', 'Gender'); ?></th>
                                    <th>Actions</th>
                                </tr>
                            </thead>
                            <tbody>
                                @foreach ($doctors as $doctor)
                                <tr class="f-12">
                                    <td><?= $start++ ?></td>
                                    <td valign="top">
                                        {{ $doctor->first_name . ' ' . $doctor->last_name }}
                                        @if ($doctor->code)
                                        <span style="font-size: 12px;">Code : <b>{{$doctor->code}}</b></span>
                                        @endif
                                    </td>
                                    <td valign="top">{{ $doctor->phone }}</td>
                                    <td valign="top">{{ $doctor->email }}</td>
                                    <td valign="top">{{ $doctor->specialization }}</td>
                                    <td valign="top">{{ $doctor->gender }}</td>
                                    <td>
                                        <div class="text-nowrap">
                                            <a title="View"
                                               href="{{ route('admin.doctor.view', ['id' => $doctor->id]) }}">
                                                <i data-feather="file-text" class="me-50 text-dark"></i>
                                            </a>
                                            <a title="Edit"
                                               href="{{ route('admin.doctor.edit', ['id' => $doctor->id]) }}">
                                                <i data-feather="edit" class="me-50 text-dark"></i>
                                            </a>
                                            <a title="Delete"
                                               data-doctor-name="{{ $doctor->first_name . ' ' . $doctor->last_name }}"
                                               data-doctor-id="{{ $doctor->id }}" data-action="delete">
                                                <i data-feather="trash-2" class="me-50 text-danger"></i>
                                            </a>
                                        </div>
                                    </td>
                                </tr>
                                @endforeach
                            </tbody>
                        </table>
                    </div>
                    @endif
                    <?php echo pagination($doctors); ?>
                </div>
            </div>
        </div>
    </form>
</div>
@section('script')
<script type="text/javascript">
    $(document).on("click", "a[data-action='delete']", function () {
        var name = $(this).attr("data-doctor-name");
        var id = $(this).attr("data-doctor-id");
        var $this = $(this);
        confirmationAlertPopup(("Do you want to delete " + name), "Yes, delete it !", function (result) {
            if (result.isConfirmed) {
                var param = new Object();
                param["doctor_id"] = id;
                if (APP.BlockConcurrentReq(2000)) {
                    return;
                }

                loadingOverlay("body", "show");
                jqueryAjax("/admin/doctor/delete", param, function (res) {
                    loadingOverlay("body", "hide");
                    if (res.code != 200) {
                        resultAlertPopup("Error!", res.message, "error");
                        return;
                    }
                    resultAlertPopup("Deleted!", "Doctor " + name + " has been deleted.",
                            "success");

                    var $closestTr = $this.closest("tr");
                    $closestTr.hide();
                    $closestTr.next().remove();
                }, "", "json");
            }
        });
    });
</script>
@endsection
