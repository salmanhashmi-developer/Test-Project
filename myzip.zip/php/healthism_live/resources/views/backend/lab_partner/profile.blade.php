@extends("backend.layouts.master")
@section('title') My Profile @endsection
@section('content')
<div class="app-content content ">
    <div class="content-wrapper p-0">
        <div class="content-body">
            @include('backend.message')
            <div class="card" data-select2-id="14">
                <div class="card-body py-2 my-25" data-select2-id="53">
                    <section class="modern-horizontal-wizard">
                        <div class="bs-stepper wizard-modern modern-wizard-example">
                            <div class="bs-stepper-header">
                                <div class="step" data-target="#account-details-modern" role="tab" id="account-details-modern-trigger">
                                    <button type="button" class="step-trigger">
                                        <span class="bs-stepper-box"><i data-feather="user" class="font-medium-3"></i></span>
                                        <span class="bs-stepper-label">
                                            <span class="bs-stepper-title">Lab Details</span>
                                        </span>
                                    </button>
                                </div>
                                <div class="line"><i data-feather="chevron-right" class="font-medium-2"></i></div>
                                <div class="step" data-target="#personal-info-modern" role="tab" id="personal-info-modern-trigger">
                                    <button type="button" class="step-trigger">
                                        <span class="bs-stepper-box"><i data-feather="file-text" class="font-medium-3"></i></span>
                                        <span class="bs-stepper-label">
                                            <span class="bs-stepper-title">Additional Details</span>
                                        </span>
                                    </button>
                                </div>
                                <div class="line"><i data-feather="chevron-right" class="font-medium-2"></i></div>
                                <div class="step" data-target="#service-gallery-modern" role="tab" id="service-gallery-modern-trigger">
                                    <button type="button" class="step-trigger">
                                        <span class="bs-stepper-box"><i data-feather="user" class="font-medium-3"></i></span>
                                        <span class="bs-stepper-label">
                                            <span class="bs-stepper-title">Service Gallery</span>
                                        </span>
                                    </button>
                                </div>
                            </div>
                            <div class="bs-stepper-content" style="font-size: 12px;">
                                <div  id="account-details-modern" class="content" role="tabpanel" aria-labelledby="account-details-modern-trigger">
                                    <div class="row">
                                        <div class="mb-1 col-md-2">
                                            <span><?= _('Name') ?></span>
                                            <br>
                                            <span class="fw-bolder me-25">{{ $lab->name }}</span>
                                        </div>
                                        <div class="mb-1 col-md-2">
                                            <span><?= _('Contact Person') ?>:</span>
                                            <br>
                                            <span class="fw-bolder me-25">{{ $lab->contact_person }}</span>
                                        </div>
                                        <div class="mb-1 col-md-2">
                                            <span><?= _('Phone No') ?>:</span>
                                            <br>
                                            <span class="fw-bolder me-25">{{ $lab->phone}}</span>
                                        </div>
                                        <div class="mb-1 col-md-2">
                                            <span><?= _('Mobile') ?>:</span>
                                            <br>
                                            <span class="fw-bolder me-25">{{ $lab->mobile  }}</span>
                                        </div>
                                        <div class="mb-1 col-md-3">
                                            <span><?= _('User') ?>:</span>
                                            <br>
                                            <?php if (!empty($lab->user)) { ?>
                                                <span class="fw-bolder me-25">{{ $lab->user->first_name.' '. $lab->user->last_name }}
                                                    ({{$lab->user->mobile}})</span>
                                            <?php } ?>
                                        </div>
                                    </div>
                                    <div class="row mt-2">
                                        <div class="col-md-9">
                                            <div class="row mt-2">
                                                <div class="mb-1 col-md-12">
                                                    <span><?= _('Address') ?>:</span>
                                                    <br>
                                                    <span class="fw-bolder me-25">{{ $lab->address1 }}, {{ $lab->address2 }}, {{ $lab->area }}
                                                        , {{ $lab->city->name }}, {{ $lab->state->name }}-, {{ $lab->pincode }}</span>
                                                </div>
                                            </div>
                                            <div class="row  mt-2">
                                                <div class="mb-1 col-md-3">
                                                    <span><?= _('Discount') ?>:</span>
                                                    <br>
                                                    <span class="fw-bolder me-25">{{ $lab->discount?$lab->discount:'0.00'  }} %</span>
                                                </div>
                                                <div class="mb-1 col-md-3">
                                                    <span><?= _('Latitude') ?>:</span><br>
                                                    <span class="fw-bolder me-25">{{ $lab->latitude  }}</span>
                                                </div>
                                                <div class="mb-1 col-md-3">
                                                    <span><?= _('Longitude') ?>:</span><br>
                                                    <span class="fw-bolder me-25">{{ $lab->longitude  }}</span>
                                                </div>
                                                <div class="mb-1 col-md-3">
                                                    <span><?= _('Status') ?>:</span><br>
                                                    <span class="fw-bolder me-25">{{ $lab->status->name  }}</span>
                                                </div>
                                            </div>
                                            <div class="row  mt-2">
                                                <div class="mb-1 col-md-3">
                                                    <span><?= _('Virtual Location') ?>:</span><br>
                                                    <span class="fw-bolder me-25">{{ $lab->virtual_location=="1"?'YES':"NO"  }}</span>
                                                </div>
                                                <div class="mb-1 col-md-3">
                                                    <span><?= _('Cash Booking Allowed') ?>:</span><br>
                                                    <span class="fw-bolder me-25">{{ post_display('cash_booking_allowed',$lab->cash_booking_allowed) == 1 ? 'Yes':'No' }}</span>

                                                </div>
                                                <div class="mb-1 col-md-3">
                                                    <span><?= _('Cancellation Allowed') ?>:</span><br>
                                                    <span class="fw-bolder me-25">{{ post_display('cancellation_allowed',$lab->cancellation_allowed) == 1 ? 'Yes':'No'  }}</span>
                                                </div>
                                            </div>
                                        </div>
                                        <div class="col-md-3">
                                            <div class="user-avatar-section">
                                                <div class="d-flex align-items-center flex-column">
                                                    <?php $src = !empty($lab->photo) != '' ? $lab->photo : '/admin-assets/images/icons/file-icons/no_document.png'; ?>
                                                    <a href="<?php echo $src; ?>" class="" target="_blank">
                                                        <img class="img-fluid rounded mt-1 mb-3" height="110" width="110" alt="" src="<?php echo $src; ?>"  alt="User avatar" />
                                                    </a>

                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                <div id="personal-info-modern" class="content" role="tabpanel" aria-labelledby="personal-info-modern-trigger">
                                    <div class="row">
                                        <?php if ($lab->parent_id == 0) { ?>
                                            <div class="mb-1 col-md-6">
                                                <div class="row mt-2">
                                                    <div class="mb-1 col-md-6">
                                                        <span><?= _('PAN No') ?></span>
                                                        <br>
                                                        <span class="fw-bolder me-25">{{ $lab->lab_details->pancard_number  }}</span>
                                                    </div>
                                                    <div class="mb-1 col-md-6">
                                                        <span><?= _('PAN Card') ?></span>
                                                        <br>
                                                        <span class="fw-bolder me-25"><?php $src = !empty($lab->lab_details->pancard_document) != '' ? $lab->lab_details->pancard_document : '/admin-assets/images/icons/file-icons/no_document.png'; ?>
                                                            <a href="<?php echo $src; ?>" class="" target="_blank">View Document</a>
                                                        </span>
                                                    </div>
                                                </div>
                                                <div class="row mt-2">
                                                    <div class="mb-1 col-md-6">
                                                        <span><?= _('GST No') ?></span>
                                                        <br>
                                                        <span class="fw-bolder me-25">{{ $lab->lab_details->gst_number  }}</span>
                                                    </div>
                                                    <div class="mb-1 col-md-6">
                                                        <span><?= _('GST Certificate') ?></span>
                                                        <br>
                                                        <span class="fw-bolder me-25"><?php $src = !empty($lab->lab_details->gst_certificate) != '' ? $lab->lab_details->gst_certificate : '/admin-assets/images/icons/file-icons/no_document.png'; ?>
                                                            <a href="<?php echo $src; ?>" class="" target="_blank">View Document</a>
                                                        </span>
                                                    </div>
                                                </div>
                                                <div class="row mt-2">
                                                    <div class="mb-1 col-md-6">
                                                        <span><?= _('Bank Account Number') ?></span>
                                                        <br>
                                                        <span class="fw-bolder me-25">{{ $lab->lab_details->bank_account_number  }}</span>
                                                    </div>
                                                    <div class="mb-1 col-md-6">
                                                        <span><?= _('Bank Account Name') ?></span>
                                                        <br>
                                                        <span class="fw-bolder me-25">{{ $lab->lab_details->bank_account_name  }}</span>
                                                    </div>
                                                </div>
                                                <div class="row mt-2">
                                                    <div class="mb-1 col-md-6">
                                                        <span><?= _('Bank Name') ?></span>
                                                        <br>
                                                        <span class="fw-bolder me-25">{{ $lab->lab_details->bank_name  }}</span>
                                                    </div>
                                                    <div class="mb-1 col-md-6">
                                                        <span><?= _('IFSC Code') ?></span>
                                                        <br>
                                                        <span class="fw-bolder me-25">{{ $lab->lab_details->bank_ifsc_code  }}</span>
                                                    </div>
                                                </div>
                                                <div class="row mt-2">
                                                    <div class="mb-1 col-md-6">
                                                        <span><?= _('MOU Document') ?></span>
                                                        <br>
                                                        <span class="fw-bolder me-25">
                                                            <?php $src = !empty($lab->lab_details->mou_document) != '' ? $lab->lab_details->mou_document : '/admin-assets/images/icons/file-icons/no_document.png'; ?>
                                                            <a href="<?php echo $src; ?>" class="" target="_blank">View Document</a> 
                                                        </span>
                                                    </div>
                                                    <div class="mb-1 col-md-6">
                                                        <span><?= _('NABL Document') ?></span>
                                                        <br>
                                                        <span class="fw-bolder me-25">
                                                            <?php $src = !empty($lab->lab_details->nabl_document) != '' ? $lab->lab_details->nabl_document : '/admin-assets/images/icons/file-icons/no_document.png'; ?>
                                                            <a href="<?php echo $src; ?>" class="" target="_blank">View Document</a>
                                                        </span>
                                                    </div>
                                                </div>
                                                <div class="row mt-2">
                                                    <div class="col-md-12">
                                                        <span class="fw-bolder me-25"><?= _('Cancel Policy') ?>:</span>
                                                        <ul style="list-style-type: decimal;text-align:justify;" class="p-1">
                                                            <?php
                                                            if (!empty($lab->cancel_policy)) {
                                                                foreach ($lab->cancel_policy as $row) {
                                                                    echo '<li class="mb-75">' . $row . '</li>';
                                                                }
                                                            }
                                                            ?>
                                                        </ul>
                                                    </div>
                                                </div>
                                                <div class="row">
                                                    <div class="col-md-12">
                                                        <span class="fw-bolder me-25"><?= _('Cancel Policy Setting') ?>:</span>
                                                        <ul style="list-style-type: decimal;text-align:justify;" class="p-1">
                                                            <?php
                                                            if (!empty($lab->cancel_policy_setting)) {
                                                                foreach ($lab->cancel_policy_setting as $row) {
                                                                    echo '<li class="mb-75"> ' . $row['charge'] . '% for  ' . $row['hours'] . ' Hours   </li>';
                                                                }
                                                            }
                                                            ?>
                                                        </ul>
                                                    </div>
                                                </div>
                                            </div>
                                            <?php } ?>
                                            <div class="mb-1 col-md-6">
                                                <div class="info-container">
                                                    <div class="border-bottom m-b-10 f-17"><b>Visit Time Detail</b></div>
                                                    <div class="row">
                                                        <?php
                                                        if (!empty($lab->lab_details->timing_json)) {
                                                            $timingArr = $lab->lab_details->timing_json;
                                                            if (!empty($timingArr)) {
                                                                $html = "";
                                                                foreach ($timingArr as $value) {
                                                                    if (!empty($value['times'])) {
                                                                        foreach ($value['times'] as $timing) {
                                                                            $html .= "<div style='padding: 15px;border: 1px solid #e6e7e7;' class='col-md-4'>";
                                                                            $html .= "<div style='color: #2caa8a;font-size: 14px;'>" . $value['day'] . "</div>";
                                                                            $html .= "<div>" . $timing['start_time'] . ' - ' . $timing['end_time'] . "</div>";
                                                                            $html .= "</div>";
                                                                        }
                                                                    }
                                                                }
                                                                echo $html;
                                                            }
                                                        } else {
                                                            echo "Visit Time Not Available";
                                                        }
                                                        ?>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                    <div id="service-gallery-modern" class="content" role="tabpanel" aria-labelledby="service-gallery-modern-trigger">
                                        <div class="cws-content">
                                            <div class="row blog-list-wrapper">
                                                <?php
                                                if (!empty($images)) {
                                                    foreach ($images as $row) {
                                                        ?>
                                                        <div class="col-md-4">
                                                            <div class=" border mt-1 ml-1 mr-1 mb-2 text-center">
                                                                <article class="card">
                                                                    <a href="<?php echo $row ?>" class="" target="_blank">
                                                                        <img src="<?php echo $row ?>" alt="" class="card-img-top">
                                                                    </a>
                                                                </article>
                                                            </div>
                                                        </div> 
                                                        <?php
                                                    }
                                                }
                                                ?>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </section>
                </div>
            </div>
        </div>
    </div>
</div>
@endsection
