<div class="row">
    <form class="" method="POST" action="{{ route('lab.test') }}" id="search_form" onsubmit="return false">
        {{ csrf_field() }}
        <div class="col-12">
            <div class="card">
                <div class="card-header border-bottom">
                    <input type="hidden" name="lab_id" value="{{ $lab->id }}">
                    <h4 class="card-title">{{ $lab->name }} - Test Master</h4>
                    <div
                        class="dt-action-buttons d-flex align-items-center justify-content-center justify-content-lg-end flex-lg-nowrap flex-wrap">
                        <div class="dt-buttons d-inline-flex">
                            <a class="dt-button add-new btn btn-primary me-1"
                                href="{{ route('lab.test.add', ['lab_id' => $lab->id]) }}">{{ __('Add New Lab Test') }}</a>
                            <a href="{{ route('lab.branch') }}" class="btn btn-outline-secondary waves-effect"> Back</a>
                        </div>
                    </div>
                </div>
                <!--Search Form -->
                <div class="card-body mt-2">
                    <div class="row g-1 mb-md-1">
                        <div class="col-md-3">
                            <label class="form-label">Test Name</label>
                            <input type="text" class="form-control dt-input dt-full-name" placeholder="Lab Test Name"
                                name="name" value="{{ app('request')->input('name') }}">
                        </div>
                        <div class="col-md-2">
                            <label class="form-label">Type</label>
                            <select name="type" id="type" class="select2 form-select">
                                <?php $set_values = request_display('type'); ?>
                                <option value="">All</option>
                                <option <?= $set_values == 0 ? 'selected' : '' ?> value="0">Test</option>
                                <option <?= $set_values == 1 ? 'selected' : '' ?> value="1">Package</option>
                            </select>
                        </div>
                        <div class="col-md-2">
                            <label class="form-label">Status</label>
                            <select name="status_id" id="status_id" class="select2 form-select">
                                <?php $set_values = request_display('status_id'); ?>
                                <option value="">All</option>
                                <option <?= $set_values == 1 ? 'selected' : '' ?> value="1">Active</option>
                                <option <?= $set_values == 2 ? 'selected' : '' ?> value="2">Inactive</option>
                            </select>
                        </div>

                        <div class="col-md-2">
                            <label class="form-label"></label>
                            <button type="submit"
                                class="btn btn-primary mt-2 waves-effect waves-float waves-light">Search</button>
                        </div>
                    </div>
                </div>
                <hr class="my-0">
                <div class="card-datatable">
                    <?php echo parPageRecordDropDown(); ?>
                    @if (!$tests->isEmpty())
                        @php $start = $tests->firstItem(); @endphp
                        <div class="table-responsive">

                            <table class="table table-bordered table-hover">
                                <thead>
                                    <tr role="row">
                                        <th></th>
                                        <th>Name</th>
                                        <!--<th>Lab</th>-->
                                        <th>Type</th>
                                        <th>Count</th>
                                        <th>Gender</th>
                                        <th>Status</th>
                                        <th>Actions</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    @foreach ($tests as $test)
                                        <tr class="f-12">
                                            <td><?= $start++ ?></td>
                                            <td valign="top">{{ $test->name }}</td>
                                            <!--                                    <td valign="top">
                                        <a target="_blank" href="{{ route('lab.view', ['id' => $test->lab_id]) }}">{{ $test->lab->name }}
                                            <span style="font-size: 11px;">({{ $test->lab->area }})</span>
                                        </a>
                                    </td>-->
                                            <td valign="top">{{ $test->is_package == 1 ? 'Package' : 'Test' }}</td>
                                            <td valign="top">{{ $test->test_count }}</td>
                                            <td valign="top">{{ $test->gender }}</td>
                                            <td valign="top">{{ $test->status->name }}</td>
                                            <td>
                                                <div class="text-nowrap">
                                                    <a title="View"
                                                        href="{{ route('lab.test.view', ['id' => $test->id]) }}">
                                                        <i data-feather="file-text" class="me-50 text-dark"></i>
                                                    </a>
                                                    <a title="Edit"
                                                        href="{{ route('lab.test.edit', ['id' => $test->id]) }}">
                                                        <i data-feather="edit" class="me-50 text-dark"></i>
                                                    </a>
                                                    <a title="Delete" data-test-name="{{ $test->name }}"
                                                        data-test-id="{{ $test->id }}" data-action="delete">
                                                        <i data-feather="trash-2" class="me-50 text-danger"></i>
                                                    </a>
                                                </div>
                                            </td>
                                        </tr>
                                    @endforeach
                                </tbody>
                            </table>
                        </div>
                    @endif
                    <?php echo pagination($tests); ?>
                </div>
            </div>
        </div>
    </form>
</div>
@section('script')
    <script type="text/javascript">
        $(document).on("click", "a[data-action='delete']", function() {
            var name = $(this).attr("data-test-name");
            var id = $(this).attr("data-test-id");
            var $this = $(this);
            confirmationAlertPopup(("Do you want to delete " + name),
                "Yes, delete it !",
                function(result) {
                    if (result.isConfirmed) {
                        var param = new Object();
                        param["test_id"] = id;
                        //console.log(param);
                        if (APP.BlockConcurrentReq(2000)) {
                            return;
                        }
                        loadingOverlay("body", "show");
                        jqueryAjax("{{ route('lab.test.delete') }}", param, function(res) {
                            loadingOverlay("body", "hide");
                            if (res.code != 200) {
                                Notification.show({
                                    type: "error",
                                    msg: res.message,
                                    timeout: 3000
                                });
                                return;
                            }
                            Notification.show({
                                type: "success",
                                msg: res.message,
                                timeout: 3000
                            });
                            var $closestTr = $this.closest("tr");
                            $closestTr.hide();
                            $closestTr.next().remove();
                        }, "", "json");
                        resultAlertPopup("Deleted!", "Test " + name +
                            " has been deleted.",
                            "success");
                    }
                });
        });
    </script>
@endsection
