@extends("backend.layouts.master")
@section('title') Lab Test Add @endsection
@section('content')
<script type="text/javascript" src="{{ Helper::static_asset('admin-assets/js/module/common.js') }}"></script>
<script type="text/javascript" src="{{ Helper::static_asset('admin-assets/js/module/lab.js') }}"></script>
<script type="text/javascript">$(document).ready(initTestMaster);</script>
<div class="app-content content ">
    <div class="content-wrapper p-0">
        <div class="content-body">
            <div class="card" data-select2-id="14">
                <div class="card-header border-bottom">
                    <h4 class="card-title">Add New Lab Test</h4>
                </div>
                <div class="card-body py-2 my-25" data-select2-id="53">
                    @include('backend.message')
                    <form class="needs-validation" method="POST" action="{{route('lab.test.store')}}" method="POST" enctype="multipart/form-data" novalidate>
                        {{ csrf_field() }}
                        <section class="modern-horizontal-wizard">
                            <div class="bs-stepper wizard-modern modern-wizard-example">
                                <div class="bs-stepper-header">
                                    <div class="step" data-target="#account-details-modern" role="tab" id="test-details-modern-trigger">
                                        <button type="button" class="step-trigger">
                                            <span class="bs-stepper-box">
                                                <i data-feather="user" class="font-medium-3"></i>
                                            </span>
                                            <span class="bs-stepper-label">
                                                <span class="bs-stepper-title">Test Details</span>
                                            </span>
                                        </button>
                                    </div>
                                    <div class="line">
                                        <i data-feather="chevron-right" class="font-medium-2"></i>
                                    </div>
                                    <div class="step" data-target="#test-details-info" role="tab" id="test-details-info-trigger">
                                        <button type="button" class="step-trigger">
                                            <span class="bs-stepper-box">
                                                <i data-feather="file-text" class="font-medium-3"></i>
                                            </span>
                                            <span class="bs-stepper-label">
                                                <span class="bs-stepper-title">Test Additional Details</span>
                                            </span>
                                        </button>
                                    </div>
                                </div>
                               <div class="bs-stepper-content">
                                    <div id="account-details-modern" class="content" role="tabpanel" aria-labelledby="test-details-modern-trigger">
                                        <div class="content-header">
                                            <h5 class="mb-0"><?= ('Test Details') ?></h5>
                                        </div>
                                        <div class="row">
                                            <input type="hidden" name="lab_id" value="{{!empty($lab->id)?$lab->id:0}}">
                                            <input type="hidden" name="lab_parent_id" value="{{!empty($lab->parent_id)?$lab->parent_id:0}}">
                                            <input type="hidden" name="flag" value="Lab">
                                            <div class="mb-1 col-md-4">
                                                <label class="form-label" for="name"><?= _('Name*') ?></label>
                                                <input type="text" name="name" id="name" class="form-control" placeholder="<?= _('Test Name') ?>" value="<?= post_display('name') ?>" required/>
                                            </div>
                                            <div class="mb-1 col-md-4">
                                                <label class="form-label" for="gender"><?= _('Gender') ?></label>
                                                <select name="gender[]" class="form-select select2" id="gender" multiple>
                                                    <option value="Male" >Male</option>
                                                    <option value="Female" >Female</option>
                                                    <option value="Other" >Other</option>
                                                </select>
                                            </div>
                                            <div class="mb-1 col-md-4">
                                                <label class="form-label">Status</label>
                                                <select name="status_id" id="status_id" class="select2 form-select" required>
                                                    <option value="1">Active</option>
                                                    <option value="2">Inactive</option>
                                                </select>
                                            </div>

                                        </div>
                                        <div class="row">
                                            <div class="mb-1 col-md-4">
                                                <label class="form-label" for="alias_name"><?= _('Alias Name') ?></label>
                                                <input type="text" name="alias_name" id="alias_name" class="form-control" placeholder="<?= _('Alias Name') ?>" value="<?= post_display('alias_name') ?>"/>
                                            </div>
                                            <div class="mb-1 col-md-4">
                                                <label class="form-label" for="body_part"><?= _('Body Part') ?></label>
                                                <input type="text" name="body_part" id="body_part" class="form-control" placeholder="<?= _('Body Part') ?>" value="<?= post_display('body_part') ?>"/>
                                            </div>
                                            <div class="mb-1 col-md-4">
                                                <label class="form-label" for="disease_name"><?= _('Disease Name') ?></label>
                                                <input type="text" name="disease_name" id="disease_name" class="form-control" placeholder="<?= _('Disease Name') ?>" value="<?= post_display('disease_name') ?>"/>
                                            </div>

                                        </div>
                                        <div class="row">
                                            <div class="mb-1 col-md-4">
                                                <label class="form-label" for="description">Description</label>
                                                <textarea name="description" id="" cols="30" rows="4" class="form-control"></textarea>
                                            </div>
                                            <div class="mb-1 col-md-4">
                                                <label class="form-label" for="requirement">Sample Type</label>
                                                <textarea name="requirement" cols="30" rows="4" class="form-control"></textarea>
                                            </div>
                                            <div class="mb-1 col-md-4">
                                                <label class="form-label" for="preparation">Preparation</label>
                                                <textarea name="preparation" cols="30" rows="4" class="form-control"></textarea>
                                            </div>
                                        </div>
                                        <div class="row">
                                            <div class="mb-1 col-md-4">
                                                <label class="form-check-label mb-50" for="is_package"><?= __('Is Package') ?></label>
                                                <div class="form-check form-check-success form-switch">
                                                    <input type="checkbox" name="is_package" class="form-check-input"  />
                                                </div>
                                            </div>
                                            <div class="mb-1 col-md-4">
                                                <label class="form-label">Package Category</label>
                                                <select name="package_category" id="package_category" class="select2 form-select" >
                                                    <option value="" selected>Select Category</option>
                                                    <option value="Silver">Silver</option>
                                                    <option value="Gold">Gold</option>
                                                    <option value="Diamond">Diamond</option>
                                                </select>
                                            </div>
                                            <div class="mb-1 col-md-4">
                                                <label class="form-label" for="e_report_hours"><?= _('E - Report Hours') ?></label>
                                                <input type="number" name="e_report_hours" id="e_report_hours" class="form-control" placeholder="<?= _('E - Report Hours') ?>"  />
                                            </div>

                                        </div>
                                        <div class="row">
                                            <div class="mb-1 col-md-4">
                                                <label class="form-check-label mb-50" for="home_collection"><?= __('Home Collection') ?></label>
                                                <div class="form-check form-check-success form-switch">
                                                    <input type="checkbox" name="home_collection" class="form-check-input"  />
                                                </div>
                                            </div>
                                           <div class="mb-1 col-md-4 d-none">
                                                <label class="form-label" for="discount"><?= _('Discount(%)') ?></label>
                                                <input type="number" name="discount" id="discount" class="form-control" placeholder="<?= _('Discount') ?>"  value="{{!empty($lab->discount)?$lab->discount:''}}" />
                                            </div>
                                            <div class="mb-1 col-md-4">
                                                <label class="form-label" for="price"><?= _('Price(Rs)*') ?></label>
                                                <input type="number" name="price" id="price" class="form-control" placeholder="<?= _('Price') ?>"  required/>
                                            </div>

                                        </div>
                                        <?php if (!empty($lab)) { ?>
                                            <div class="row">
                                                <div class="mb-1 col-md-12 mt-1 b-b-10">
                                                    <span class="fw-bolder me-25">Lab Details</span>
                                                </div>
                                            </div>
                                            <div class="row">
                                                <div class="mb-1 col-md-3 mt-1">
                                                    <span><?= _('Lab Name') ?></span>
                                                    <br>
                                                    <span class="fw-bolder me-25">{{ $lab->name }}</span>
                                                </div>
                                                <div class="mb-1 col-md-3 mt-1">
                                                    <span><?= _('Contact Person') ?></span>
                                                    <br>
                                                    <span class="fw-bolder me-25">{{ $lab->contact_person? $lab->contact_person:'-' }}</span>
                                                </div>
                                                <div class="mb-1 col-md-3 mt-1">
                                                    <span><?= _('Phone') ?></span>
                                                    <br>
                                                    <span class="fw-bolder me-25">{{ $lab->phone?$lab->phone:'-' }}</span>
                                                </div>
                                                <div class="mb-1 col-md-3 mt-1">
                                                    <span><?= _('Mobile') ?></span>
                                                    <br>
                                                    <span class="fw-bolder me-25">{{ $lab->mobile? $lab->mobile:'-' }}</span>
                                                </div>
                                                <div class="mb-1 col-md-12 mt-1">
                                                    <span><?= _('Lab Address') ?></span>
                                                    <br>
                                                    <span class="fw-bolder me-25">
                                                        {{ $lab->address1 }}, {{ $lab->address2 }}, {{ $lab->area }}
                                                        , {{ $lab->city->name }}, {{ $lab->state->name }}-, {{ $lab->pincode }}
                                                    </span>
                                                </div>
                                                <?php if ($lab->parent) { ?>
                                                    <div class="mb-1 col-md-12 mt-1">
                                                        <span><?= _('Note') ?></span>
                                                        <br>
                                                        <span class="fw-bolder me-25">This lab is working under the {{ $lab->parent->name}}</span>
                                                    </div>
                                                <?php } ?>
                                            </div>
                                        <?php } ?>
                                    </div>
                                    <div id="test-details-info" class="content" role="tabpanel" aria-labelledby="test-details-modern-trigger">
                                        <div class="row">
                                            <div class="col-md-6">
                                                <label class="form-label" for="test_count"><?= _('Total Test Count') ?></label>
                                                <input type="number" name="test_count" id="test_count" class="form-control" placeholder="<?= _('Test Count') ?>" value="<?= post_display('test_count') ?>"/>
                                            </div>
                                            <div class="mt-1 mb-1 col-12"><div id="error-alert" class="error"></div></div>
                                            <div class="mb-1 col-md-9">
                                                <label class="form-label">Test title</label>
                                                <input data-id="title" type="text" placeholder="Test title" value="" class="form-control"/>
                                            </div>
                                            <div class="mb-1 col-md-3">
                                                <input type="hidden" name="test_desc_json" data-id="desc-json" />
                                                <a data-id="btn-add" class="btn btn-primary mt-2 me-1 waves-effect waves-float waves-light">Add</a>
                                            </div>
                                            <div class="mb-1 col-md-12">
                                                <ul class="list-group" data-id="data-list">
                                                </ul>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </section>
                        <div class="row" data-select2-id="12">
                            <div class="col-12">
                                <button type="submit" class="btn btn-primary me-1 waves-effect waves-float waves-light">Save changes</button>
                                <a href="{{route('lab.test',['lab_id'=>$lab->id])}}" class="btn btn-outline-secondary waves-effect">Back</a>
                            </div>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>
</div>
@endsection
