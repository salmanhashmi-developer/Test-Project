@extends("backend.layouts.master")
@section('title') Upload Test Report @endsection
@section('content')
<script type="text/javascript" src="{{ Helper::static_asset('admin-assets/js/module/lab-partner.js') }}"></script>
<script type="text/javascript">$(document).ready(initCancelLabOrder);</script>
<!-- BEGIN: Content-->
<div class="app-content content f-12">
    <div class="content-wrapper p-0">
        <div class="content-body">
            @include('backend.message')
            <div class="p-b-10"> <a href="{{route('lab.order.view', ['id'=>$order->id])}}"><i data-feather="arrow-left" class="me-50 text-dark"></i>Show Order Details</a></div>
            <b class="m-l-20">Order {{$order->order->order_code}}</b>
            <p class="m-l-20"> From {{$order->user->first_name.' '.$order->user->last_name}}</p>
            <div class="card" data-select2-id="14">
                <form class="needs-validation" method="POST" action="{{route('lab.file.upload')}}" method="POST" enctype="multipart/form-data" novalidate>
                    {{ csrf_field() }}
                    <div class="card-body py-2 my-25" data-select2-id="53">
                        <section class="modern-horizontal-wizard">
                            <div class="bs-stepper wizard-modern modern-wizard-example">
                                <div class="row">
                                    <div class="col-md-8">
                                        <div id="order-modern">
                                            <div class="d-flex">
                                                <div class="row">
                                                    <div class="col-md-12 header-title">
                                                        <span>Patient Details</span>
                                                    </div>
                                                    <div class="col-md-12">
                                                        <table class="table">
                                                            <thead>
                                                                <tr>
                                                                    <th>Name</th>
                                                                    <th>Mobile No.</th>
                                                                    <th>Email</th>
                                                                </tr>
                                                            </thead> 
                                                            <tbody>
                                                                <tr>
                                                                    <td>{{$order->user_patient->first_name.' '.$order->user_patient->last_name}}</td>
                                                                    <td>{{$order->user_patient->mobile}}</td>
                                                                    <td>{{$order->user_patient->email}}</td>
                                                                </tr>
                                                            </tbody>
                                                        </table>
                                                    </div>
                                                </div>
                                            </div>
                                            <?php
                                            if ($order->is_home_collection == 1) {
                                                $address = !empty($order->address) ? $order->address : '';
                                                ?>
                                                <div class="d-flex">
                                                    <div class="row">
                                                        <div class="col-md-12 header-title">
                                                            <span>Home Collection Address & Slot</span>
                                                        </div>
                                                        <div class="col-md-12">
                                                            <table class="table">
                                                                <thead>
                                                                    <tr>
                                                                        <th>Slot Date</th>
                                                                        <th>Slot Time</th>
                                                                        <th>Home Collection Address</th>
                                                                    </tr>
                                                                </thead> 
                                                                <tbody>
                                                                    <tr>
                                                                        <td>{{ date("d/m/Y",strtotime($order->appointment_date)) }}</td>
                                                                        <td>{{$order->appointment_time}}</td>
                                                                        <td>
                                                                            <?php
                                                                            if (!empty($address)) {
                                                                                echo $address['address_1'] . ', ' . $address['address_2'] . ', ' . $address['city'] . ', ' . $address['state'] . '-' . $address['pincode'] . ' (' . $address['type'] . ')';
                                                                            }
                                                                            ?>
                                                                        </td>
                                                                    </tr>
                                                                </tbody>
                                                            </table>
                                                        </div>
                                                    </div>
                                                </div>
                                            <?php } else { ?>
                                                <div class="d-flex">
                                                    <div class="row">
                                                        <div class="col-md-12 header-title">
                                                            <span>Slot Data</span>
                                                        </div>
                                                        <div class="col-md-12">
                                                            <table class="table">
                                                                <thead>
                                                                    <tr>
                                                                        <th>Slot Date</th>
                                                                        <th>Slot Time</th>
                                                                        <th>Lab</th>
                                                                    </tr>
                                                                </thead> 
                                                                <tbody>
                                                                    <tr>
                                                                        <td>{{ date("d/m/Y",strtotime($order->appointment_date)) }}</td>
                                                                        <td>{{ date("h:i A",strtotime($order->appointment_time)) }}</td>
                                                                        <td>{{$order->lab->name}} ({{$order->lab->area}})</td>
                                                                    </tr>
                                                                </tbody>
                                                            </table>
                                                        </div>
                                                    </div>
                                                </div>
                                            <?php } ?>
                                            <?php if (!empty($order->labBookingDetail)) { ?>
                                                <div class="d-flex">
                                                    <div class="row">
                                                        <div class="col-md-12 header-title">
                                                            <span>Test List</span>
                                                        </div>
                                                        <div class="col-md-12">
                                                            <table class="table">
                                                                <thead>
                                                                    <tr>
                                                                        <th>Name</th>
                                                                        <th>Amount</th>
                                                                    </tr>
                                                                </thead> 
                                                                <tbody>
                                                                    <?php
                                                                    foreach ($order->labBookingDetail as $value) {
                                                                        ?>
                                                                        <tr>
                                                                            <td class="f-u">{{$value->test->name}}</td>
                                                                            <td>Rs.{{$value->amount}}</td>
                                                                        </tr>
                                                                        <?php
                                                                    }
                                                                    ?>
                                                                </tbody>
                                                            </table>
                                                        </div>
                                                    </div>
                                                </div>
                                                <?php
                                            } else {
                                                echo 'Sorry, Test data not found.';
                                            }
                                            ?>

                                        </div>
                                    </div>
                                    <div class="col-md-4" style="height: 300px;overflow: auto;">
                                        <div class="row">
                                            <div class="mb-1 col-md-12">
                                                <table class="table">
                                                    <thead>
                                                        <tr> <th colspan="2"> cancellation Reason</th></tr>
                                                    </thead>
                                                    <tbody>
                                                        <?php foreach ($reasones as $key => $value) { ?>
                                                            <tr>
                                                                <td> <input type="radio" name="reason" value="<?php echo $value; ?>" <?php echo $key == 0 ? 'checked' : ''; ?>></td>
                                                                <td><?php echo $value; ?></td>
                                                            </tr>
                                                        <?php } ?> 
                                                    </tbody>
                                                </table>
                                                <div class="text-success text-bold" style="padding: 10px;font-size: 14px;background: #e1ffe2;display: none;"></div>
                                                <div class="text-danger text-bold" style="padding: 10px;font-size: 14px;background: #ffe7e6;display: none;"></div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </section>
                        <div class="row" data-select2-id="12">
                            <div class="col-12">
                                <a data-booking-id="{{$order->id}}" data-action="calcel" class="btn btn-primary me-1 waves-effect waves-float waves-light">Save</a>
                                <a href="{{route('lab.order.view', ['id'=>$order->id])}}" class="btn btn-outline-secondary waves-effect">Back</a>
                            </div>
                        </div>
                    </div>
                </form>
            </div>
        </div>
    </div>
</div>
@endsection



