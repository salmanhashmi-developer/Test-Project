@extends("backend.layouts.master")
@section('title') Lab View @endsection
@section('content')
<div class="app-content content ">
    <div class="content-wrapper p-0">
        <div class="content-body">
            @include('backend.message')
            <div class="card" data-select2-id="14">
                <div class="card-header border-bottom">
                    <h4 class="card-title">Lab Details View</h4>
                </div>
                <div class="card-body py-2 my-25" data-select2-id="53">
                    <section class="modern-horizontal-wizard">
                        <div class="bs-stepper wizard-modern modern-wizard-example">
                            <div class="bs-stepper-header">
                                <div class="step" data-target="#account-details-modern" role="tab" id="account-details-modern-trigger">
                                    <button type="button" class="step-trigger">
                                        <span class="bs-stepper-box"><i data-feather="user" class="font-medium-3"></i></span>
                                        <span class="bs-stepper-label">
                                            <span class="bs-stepper-title">Lab Details</span>
                                        </span>
                                    </button>
                                </div>
                                <div class="line"><i data-feather="chevron-right" class="font-medium-2"></i></div>
                                <div class="step" data-target="#personal-info-modern" role="tab" id="personal-info-modern-trigger">
                                    <button type="button" class="step-trigger">
                                        <span class="bs-stepper-box"><i data-feather="file-text" class="font-medium-3"></i></span>
                                        <span class="bs-stepper-label">
                                            <span class="bs-stepper-title">Lab Timing</span>
                                        </span>
                                    </button>
                                </div>
                                <div class="line"><i data-feather="chevron-right" class="font-medium-2"></i></div>
                                <div class="step" data-target="#service-gallery-modern" role="tab" id="service-gallery-modern-trigger">
                                    <button type="button" class="step-trigger">
                                        <span class="bs-stepper-box"><i data-feather="user" class="font-medium-3"></i></span>
                                        <span class="bs-stepper-label">
                                            <span class="bs-stepper-title">Service Gallery</span>
                                        </span>
                                    </button>
                                </div>
                            </div>
                            <div class="bs-stepper-content" style="font-size: 12px;">
                                <div  id="account-details-modern" class="content" role="tabpanel" aria-labelledby="account-details-modern-trigger">
                                    <div class="row">
                                        <div class="mb-1 col-md-2">
                                            <span><?= _('Name') ?></span>
                                            <br>
                                            <span class="fw-bolder me-25">{{ $lab->name }}</span>
                                        </div>
                                        <div class="mb-1 col-md-2">
                                            <span><?= _('Contact Person') ?>:</span>
                                            <br>
                                            <span class="fw-bolder me-25">{{ $lab->contact_person }}</span>
                                        </div>
                                        <div class="mb-1 col-md-2">
                                            <span><?= _('Phone No') ?>:</span>
                                            <br>
                                            <span class="fw-bolder me-25">{{ $lab->phone}}</span>
                                        </div>
                                        <div class="mb-1 col-md-2">
                                            <span><?= _('Mobile') ?>:</span>
                                            <br>
                                            <span class="fw-bolder me-25">{{ $lab->mobile  }}</span>
                                        </div>
                                        <div class="mb-1 col-md-3">
                                            <span><?= _('User') ?>:</span>
                                            <br>
                                            <?php if (!empty($lab->user)) { ?>
                                                <span class="fw-bolder me-25">{{ $lab->user->first_name.' '. $lab->user->last_name }}
                                                    ({{$lab->user->mobile}})</span>
                                            <?php } ?>
                                        </div>
                                    </div>
                                    <div class="row mt-2">
                                        <div class="mb-1 col-md-10">
                                            <span><?= _('Address') ?>:</span>
                                            <br>
                                            <span class="fw-bolder me-25">{{ $lab->address1 }}, {{ $lab->address2 }}, {{ $lab->area }}
                                                , {{ $lab->city->name }}, {{ $lab->state->name }}-, {{ $lab->pincode }}</span>
                                        </div>

                                    </div>
                                    <div class="row  mt-2">
                                        <div class="mb-1 col-md-2">
                                            <span><?= _('Discount') ?>:</span>
                                            <br>
                                            <span class="fw-bolder me-25">{{ $lab->discount?$lab->discount:'0.00'  }} %</span>
                                        </div>
                                        <div class="mb-1 col-md-2">
                                            <span><?= _('Latitude') ?>:</span><br>
                                            <span class="fw-bolder me-25">{{ $lab->latitude  }}</span>
                                        </div>
                                        <div class="mb-1 col-md-2">
                                            <span><?= _('Longitude') ?>:</span><br>
                                            <span class="fw-bolder me-25">{{ $lab->longitude  }}</span>
                                        </div>
                                        <div class="mb-1 col-md-2">
                                            <span><?= _('Status') ?>:</span><br>
                                            <span class="fw-bolder me-25">{{ $lab->status->name  }}</span>
                                        </div>
                                        <div class="mb-1 col-md-2">
                                            <span><?= _('Virtual Location') ?>:</span><br>
                                            <span class="fw-bolder me-25">{{ $lab->virtual_location=="1"?'YES':"NO"  }}</span>
                                        </div>
                                    </div>
                                    <div class="d-flex">
                                        <div class="col-xl-4 col-lg-3 col-md-3  d-flex align-items-start me-2">
                                            <div class="info-container">
                                                <ul class="list-unstyled">
                                                    <li class="mb-75">
                                                        <div class="user-avatar-section">
                                                            <div class="d-flex align-items-center flex-column">
                                                                <?php $src = !empty($lab->photo) != '' ? $lab->photo : '/admin-assets/images/icons/file-icons/no_document.png'; ?>
                                                                <a href="<?php echo $src; ?>" class="" target="_blank">
                                                                    <img class="img-fluid rounded mt-1 mb-3" height="110" width="110" alt="" src="<?php echo $src; ?>"  alt="User avatar" />
                                                                </a>

                                                            </div>
                                                        </div>
                                                    </li>

                                                </ul>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                <div id="personal-info-modern" class="content" role="tabpanel" aria-labelledby="personal-info-modern-trigger">
                                    <div class="row">
                                        <div class="mb-1 col-md-12">
                                            <div class="info-container">
                                                <div class="row">
                                                    <?php
                                                    if (!empty($lab->lab_details->timing_json)) {
                                                        $timingArr = $lab->lab_details->timing_json;
                                                        if (!empty($timingArr)) {
                                                            $html="";
                                                            foreach ($timingArr as $value) {
                                                                if (!empty($value['times'])) {
                                                                    foreach ($value['times'] as $timing) {
                                                                        $html .= "<div style='padding: 15px;border: 1px solid #e6e7e7;' class='col-md-2'>";
                                                                        $html .= "<div style='color: #2caa8a;font-size: 14px;'>" . $value['day'] . "</div>";
                                                                        $html .= "<div>" . $timing['start_time'] . ' - ' . $timing['end_time'] . "</div>";
                                                                        $html .= "</div>";
                                                                    }
                                                                }
                                                            }
                                                            echo $html;
                                                        }
                                                    } else {
                                                        echo "Visit Time Not Available";
                                                    }
                                                    ?>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                <div id="service-gallery-modern" class="content" role="tabpanel" aria-labelledby="service-gallery-modern-trigger">
                                    <div class="cws-content">
                                        <div class="row blog-list-wrapper">
                                            <?php
                                            if (!empty($images)) {
                                                foreach ($images as $row) {
                                                    ?>
                                                    <div class="col-md-4">
                                                        <div class=" border mt-1 ml-1 mr-1 mb-2 text-center">
                                                            <article class="card">
                                                                <a href="<?php echo $row ?>" class="" target="_blank">
                                                                    <img src="<?php echo $row ?>" alt="" class="card-img-top">
                                                                </a>
                                                            </article>
                                                        </div>
                                                    </div> 
                                                    <?php
                                                }
                                            }
                                            ?>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </section>
                    <div class="row" data-select2-id="12">
                        <div class="col-12">
                            <a href="{{ route('lab.edit', ['id'=>$lab->id] )  }}" class="btn btn-primary me-1 waves-effect waves-float waves-light" > Edit</a>
                            <a href="{{route('lab.branch')}}" class="btn btn-outline-secondary waves-effect">Back</a>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
@endsection
