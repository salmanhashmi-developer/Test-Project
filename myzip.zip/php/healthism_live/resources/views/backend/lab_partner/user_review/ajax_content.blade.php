<script>
    var csrf_field = "{{ csrf_token() }}";
</script>
<script src="{{ Helper::static_asset('admin-assets/js/module/common.js') }}"></script>
<div class="row f-12">
    <form class="" method="POST" action="{{ route('lab.review') }}" id="search_form" onsubmit="return false">
        {{ csrf_field() }}

        <div class="col-12">
            <div class="card">
                <div class="card-header border-bottom">
                    <h4 class="card-title">{{ __("User's Review")  }}</h4>
                </div>
                <!--Search Form -->
                <div class="card-body mt-1">
                    <input type="hidden" name="refId" id="refId" value="<?php echo $refId; ?>">
                    <div class="row g-1">
                        <div class="col-md-2">
                            <label class="form-label">Rating</label>
                            <select name="rating" class="form-select select2">
                                <option value="">ALL</option>
                                <?php
                                $rating = app('request')->input('rating');
                                ?>
                                @foreach($ratingList as $row)
                                <option value="<?= $row ?>" <?= $row == $rating ? 'selected' : '' ?>><?= $row ?></option>
                                @endforeach
                            </select>
                        </div>
                        <div class="col-md-2">
                            <label class="form-label">Status</label>
                            <select name="status_id" class="form-select select2">
                                <option value="">ALL</option>
                                <?php
                                $statusId = app('request')->input('status_id');
                                ?>
                                @foreach($statusList as $row)
                                <option value="<?= $row['id'] ?>" <?= $row['id'] == $statusId ? 'selected' : '' ?>><?= $row['name'] ?></option>
                                @endforeach
                            </select>
                        </div>
                        <div class="col-md-4">
                            <div class="col-md-5" style="float:left;margin-right:5px;">
                                <label class="form-label">Order Start Date</label>
                                <input type="text" name="start_date" class="form-control datepicker" placeholder="Start Date" value="{{ request_display('start_date') }}" />
                            </div>
                            <div class="col-md-5" style="float:left">
                                <label class="form-label">Order End Date</label>
                                <input type="text" name="end_date" class="form-control datepicker" placeholder="End Date" value="{{ request_display('end_date') }}" />
                            </div>
                        </div>
                        <div class="col-md-4 m-t-35">
                            <button type="submit" name='' class="btn btn-primary waves-effect waves-float waves-light">Search</button>
                            <a href="{{route('lab.review')}}" class="btn btn-outline-secondary waves-effect">Reset</a>
                        </div>
                    </div>
                </div>
                <hr class="my-0">
                <div class="card-datatable">
                    <?php echo parPageRecordDropDown([5, 10, 20, 30]) ?>
                    @if(!$userReview->isEmpty())
                    @php $start = $userReview->firstItem(); @endphp
                    <div class="table-responsive">
                        <table class="table table-bordered table-hover">
                            <thead>
                                <tr role="row">
                                    <th>Title</th>
                                    <th>Description</th>
                                    <th>Rating</th>
                                    <th>User</th>
                                    <th>Status</th>
                                    <th>Created At</th>
                                    <th>Action</th>
                                </tr>
                            </thead>
                            <tbody>
                                @foreach($userReview as $data)
                                <tr>
                                    <td valign="top">{{ $data->title}}</td>
                                    <td valign="top">{{ $data->description}}</td>
                                    <td valign="top">{{ $data->rating}}</td>
                                    <td valign="top">
                                        <?php if (!empty($data->user)) { ?>
                                            {{ $data->user->first_name.' '.$data->user->last_name  }}
                                            <br><span class="f-11">({{$data->user->mobile}})</span>
                                        <?php } ?>
                                    </td>
                                    <td data-id="status-name" valign="top">{{ $data->status->name}}</td>
                                    <td valign="top"><span class="f-11">{{ date("d/m/Y H:i",strtotime($data->created_at))}}</span></td>
                                    <td>
                                        <a title="View" href="{{  route('lab.review.view', ['id'=>$data->id] )  }}">
                                            <i data-feather="file-text" class="me-50 text-dark"></i>
                                        </a>
                                    </td>
                                </tr>
                                @endforeach
                            </tbody>
                        </table>
                    </div>
                    @endif
                    <?php echo pagination($userReview) ?>
                </div>
            </div>
        </div>
    </form>
</div>

