@extends("backend.layouts.master")
@section('title') User Review @endsection
@section('content')

<!-- BEGIN: Content-->
<div class="app-content content ">

    <div class="content-wrapper p-0">

        <div class="content-body">
            @include('backend.message')
            <div class="card" data-select2-id="14">
                <div class="card-header border-bottom">
                    <h4 class="card-title">User's Review</h4>
                </div>
                <div class="card-body py-2 my-25" data-select2-id="53">

                    <section class="modern-horizontal-wizard">
                        <div class="bs-stepper wizard-modern modern-wizard-example">
                            <div class="bs-stepper-content">
                                <div>
                                    <div class="row f-12" style="border-bottom: 1px solid #efefef;">
                                        <div class="mb-1 col-md-6 mb-2">
                                            <span><?= _('Title') ?></span>
                                            <br>
                                            <span class="fw-bolder me-25">{{ $userReview->title }}</span>
                                        </div>
                                        <div class="mb-1 col-md-12 mb-2">
                                            <span><?= _('Description') ?></span><br>
                                            <span class="fw-bolder me-25">{{ $userReview->description }}</span>
                                        </div>
                                        <div class="mb-1 col-md-3">
                                            <span><?= _('Rating') ?></span><br>
                                            <span class="fw-bolder me-25">{{ $userReview->rating }}</span>
                                        </div>
                                        <div class="mb-1 col-md-3">
                                            <span><?= _('Status') ?></span><br>
                                            <span class="fw-bolder me-25">{{ $userReview->status->name}}</span>
                                        </div>
                                        <div class="mb-1 col-md-3">
                                            <span><?= _('User') ?></span><br>
                                            <span class="fw-bolder me-25"><?php if (!empty($userReview->user)) { ?>
                                                {{ $userReview->user->first_name.' '.$userReview->user->last_name  }}
                                                <br><span class="f-11">({{$userReview->user->mobile}})</span>
                                                <?php } ?></span>
                                        </div>
                                        <div class="mb-1 col-md-3">
                                            <span><?= _('Created At') ?></span><br>
                                            <span class="fw-bolder me-25">{{ date("d/m/Y H:i",strtotime($userReview->created_at))}}</span>
                                        </div>
                                    </div>
                                    <div class="row" style="font-size: 12px;border-bottom: 1px solid #efefef;padding: 12px 0px;line-height: 2em;">
                                        <div class="mb-1 col-md-6">
                                            <span><?= _('Last Reply') ?></span>
                                            <br>
                                            <?php if (!empty($userReview->reply)) { ?>
                                                <span class="fw-bolder me-25">
                                                    {{$userReview->reply}} at {{date("d/m/Y H:i",strtotime($userReview->replied_at))}}
                                                </span>
                                                <?php
                                            } else {
                                                echo '-';
                                            }
                                            ?>
                                        </div>
                                        <div class="mb-1 col-md-6">
                                            <form class="needs-validation" method="POST" action="{{route('lab.review.update', $userReview->id)}}" method="POST" enctype="multipart/form-data" novalidate>
                                                {{ csrf_field() }}
                                                <div class="row">
                                                    <div class="mb-1 col-md-8">
                                                        <label class="form-label" for="preparation">Reply</label>
                                                        <textarea name="reply" cols="30" rows="3" class="form-control" required></textarea>
                                                    </div>
                                                    <div class="mb-1 col-md-4 mt-3">
                                                        <button type="submit" class="btn btn-primary mt-1 me-1 waves-effect waves-float waves-light">Reply</button>
                                                    </div>
                                                </div>
                                            </form>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </section>
                    <div class="row" data-select2-id="12">
                        <div class="col-12">
                           <a href="{{route('lab.review')}}" class="btn btn-outline-secondary waves-effect">Back</a>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
@endsection
