@extends("backend.layouts.master")
@section('title') Common Service List @endsection
@section('content')

    <!-- BEGIN: Content-->
    <div class="app-content content ">

        <div class="content-wrapper p-0">

            <div class="content-body" id="ajax_content">
                @include('backend.message')
                @include("backend.common_service.ajax_content")
            </div>


        </div>
    </div>
@endsection
