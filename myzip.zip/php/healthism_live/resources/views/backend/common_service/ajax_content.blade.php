<div class="row">
    <form class="" method="POST" action="{{ route('admin.common.service') }}" id="search_form"
        onsubmit="return false">
        {{ csrf_field() }}
        <div class="col-12">
            <div class="card">
                <div class="card-header border-bottom">
                    <h4 class="card-title">{{ __('Service List') }}</h4>
                    <div
                        class="dt-action-buttons d-flex align-items-center justify-content-center justify-content-lg-end flex-lg-nowrap flex-wrap">
                        <div class="dt-buttons d-inline-flex">
                            <a class="dt-button add-new btn btn-primary"
                                href="{{ route('admin.common.service.add') }}">{{ __('Add New Service') }}</a>
                            <a style="margin-left: 15px;" class="btn btn-outline-secondary waves-effect"
                                href="{{ route('admin.common.service.bulk.insert') }}">{{ __('Bulk Insert') }}</a>
                        </div>
                    </div>
                </div>
                <!--Search Form -->
                <div class="card-body mt-2">
                    <input type="hidden" name="page" id="page"
                        value="{{ empty(app('request')->input('page')) ? 1 : app('request')->input('page') }}">
                    <input type="hidden" name="sort_field" id="sort_field"
                        value="{{ app('request')->input('sort_field') }}">
                    <input type="hidden" name="sort_action" id="sort_action"
                        value="{{ app('request')->input('sort_action') }}">
                    <div class="row g-1 mb-md-1">
                        <div class="col-md-4">
                            <label class="form-label">Name</label>
                            <input type="text" class="form-control dt-input dt-full-name" placeholder="Service Name"
                                name="name" value="{{ app('request')->input('name') }}">
                        </div>
                        <div class="col-md-3">
                            <label class="form-label" for="category">Category</label>
                            <select name="category_id" id="category_id" class="select2 form-select">
                                <option value="">Select Category</option>
                                <?php
                                $set_values = request_display('category_id');
                                foreach ($categoryList as $category):
                                    ?>
                                <option value="{{ $category->id }}"
                                    <?= $category->id == $set_values ? 'selected' : '' ?>>{{ $category->name }}
                                </option><?php
                                endforeach;
                                ?>
                            </select>
                        </div>
                        <div class="col-md-3">
                            <label class="form-label">Phone</label>
                            <input type="text" class="form-control dt-input" placeholder="Phone No" name="phone"
                                value="{{ app('request')->input('phone') }}">
                        </div>
                        <div class="col-md-2">

                        </div>
                    </div>
                    <div class="row g-1">
                        <div class="col-md-4">
                            <label class="form-label">State</label>
                            <select name="state_id" id="state_id" class="select2 form-select">
                                <option value="">Select State</option>
                                <?php
                                $set_values = request_display('state_id');
                                foreach ($states as $state):
                                    ?>
                                <option value="{{ $state->id }}" <?= $state->id == $set_values ? 'selected' : '' ?>>
                                    {{ $state->name }}</option><?php
                                endforeach;
                                ?>
                            </select>
                        </div>
                        <div class="col-md-3">
                            <label class="form-label">City</label>
                            <select name="city_id" id="city_id" class="select2 form-select">
                                <option value="">Select City</option>
                                <?php
                                $set_values = request_display("city_id");
                                foreach ($cities as $city):
                                    ?>
                                <option value="{{ $city->id }}" {{ $city->id == $set_values ? 'selected' : '' }}>
                                    {{ $city->name }}</option><?php
                                endforeach;
                                ?>
                            </select>
                        </div>
                        <div class="col-md-3">
                            <label class="form-label">Pincode</label>
                            <input type="text" maxlength="6" class="form-control dt-input" placeholder="Pincode"
                                name="pincode" value="{{ app('request')->input('pincode') }}">
                        </div>
                        <div class="col-md-2">
                            <label class="form-label"></label>
                            <button type="submit"
                                class="btn btn-primary mt-2 waves-effect waves-float waves-light">Search</button>
                        </div>
                    </div>
                </div>
                <hr class="my-0">
                <div class="card-datatable">
                    <?php echo parPageRecordDropDown(); ?>
                    @if (!$commonService->isEmpty())
                        @php $start = $commonService->firstItem(); @endphp
                        <div class="table-responsive">

                            <table class="table table-bordered table-hover">
                                <thead>
                                    <tr role="row">
                                        <th></th>
                                        <th><?php echo sort_field_display('name', 'Name'); ?></th>
                                        <th>Phone</th>
                                        <th><?php echo sort_field_display('Area', 'Area'); ?></th>
                                        <th><?php echo sort_field_display('Pincode', 'Pincode'); ?></th>
                                        <th>City</th>
                                        <th>State</th>
                                        <th>Actions</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    @foreach ($commonService as $cs)
                                        <tr class="f-12">
                                            <td><?= $start++ ?></td>
                                            <td valign="top">{{ $cs->name }}</td>
                                            <td valign="top">{{ $cs->phone }}</td>
                                            <td valign="top">{{ $cs->area }}</td>
                                            <td valign="top">{{ $cs->pincode }}</td>
                                            <td valign="top">{{ $cs->city->name }}</td>
                                            <td valign="top">{{ $cs->state->name }}</td>
                                            <td>
                                                <div class="text-nowrap">
                                                    <a title="View"
                                                        href="{{ route('admin.common.service.view', ['id' => $cs->id]) }}">
                                                        <i data-feather="file-text" class="me-50 text-dark"></i>
                                                    </a>
                                                    <a title="Location"
                                                        href="{{ route('admin.common.service.location', ['id' => $cs->id]) }}">
                                                        <i data-feather="map-pin" class="me-50 text-dark"></i>
                                                    </a>
                                                    <a title="Edit"
                                                        href="{{ route('admin.common.service.edit', ['id' => $cs->id]) }}">
                                                        <i data-feather="edit" class="me-50 text-dark"></i>
                                                    </a>
                                                    <a title="Delete" data-cs-name="{{ $cs->name }}"
                                                        data-cs-id="{{ $cs->id }}" data-action="delete">
                                                        <i data-feather="trash-2" class="me-50 text-danger"></i>
                                                    </a>
                                                </div>
                                            </td>
                                        </tr>
                                    @endforeach
                                </tbody>
                            </table>
                        </div>
                    @endif
                    <?php echo pagination($commonService); ?>
                </div>
            </div>
        </div>
    </form>
</div>
@section('script')
    <script type="text/javascript">
        $(document).on("click", "a[data-action='delete']", function() {
            var name = $(this).attr("data-cs-name");
            confirmationAlertPopup(("Do you want to delete " + name), "Yes, delete it !", function(result) {
                if (result.isConfirmed) {
                    var $this = $(this);
                    var param = new Object();
                    param["common_service_id"] = $(this).attr("data-cs-id");
                    //console.log(param);
                    if (APP.BlockConcurrentReq(2000)) {
                        return;
                    }
                    loadingOverlay("body", "show");
                    jqueryAjax("{{ route('admin.common.service.delete') }}", param, function(res) {
                        loadingOverlay("body", "hide");
                        if (res.code != 200) {
                            resultAlertPopup("Error!", res.message, "error");
                            return;
                        }
                        resultAlertPopup("Deleted!", "Service " + name + " has been deleted.",
                            "success");

                        var $closestTr = $this.closest("tr");
                        $closestTr.hide();
                        $closestTr.next().remove();
                    }, "", "json");
                }
            });
        });
    </script>
@endsection
