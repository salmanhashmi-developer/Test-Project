@extends("backend.layouts.master")
@section('title') Service Data Import @endsection
@section('content')

<!-- BEGIN: Content-->
<div class="app-content content ">

    <div class="content-wrapper p-0">

        <div class="content-body">
            @include('backend.message')
            <form class="" method="POST" action="{{ route('admin.common.service.image.import') }}" enctype="multipart/form-data" novalidate>
                {{ csrf_field() }}
                <div class="col-12">
                    <div class="card">
                        <div class="card-header border-bottom">
                            <h4 class="card-title">{{ __("Service Image Import")  }}</h4>
                        </div>
                        <div class="card-body mt-2">
                            <div class="row g-1">
                                <div class="col-md-8">
                                    <label for="formFile1" class="form-label">Select Images</label>
                                    <input class="form-control" name="images[]" type="file" id="formFile1" required multiple/>
                                </div>
                                <div class="col-md-4">
                                    <label class="form-label"></label>
                                    <button type="submit" class="btn btn-primary mt-2 waves-effect waves-float waves-light">Upload</button>
                                    <a href="{{route('admin.common.service')}}" class="btn btn-outline-info suspend-user mt-2 waves-effect">Back</a>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </form>
            <form class="" method="POST" action="{{ route('admin.common.service.import') }}" enctype="multipart/form-data" novalidate>
                {{ csrf_field() }}
                <div class="col-12">
                    <div class="card">
                        <div class="card-header border-bottom">
                            <h4 class="card-title">{{ __("Service Data Import")  }}</h4>
                        </div>
                        <div class="card-body mt-2">
                            <div class="row g-1">
                                <div class="col-md-8">
                                    <label for="formFile" class="form-label">Select Excel File</label>
                                    <input class="form-control" name="file" type="file" id="formFile" required/>
                                </div>
                                <div class="col-md-4">
                                    <label class="form-label"></label>
                                    <button type="submit" class="btn btn-primary mt-2 waves-effect waves-float waves-light">Upload</button>
                                    <a href="{{route('admin.common.service')}}" class="btn btn-outline-info suspend-user mt-2 waves-effect">Back</a>
                                </div>
                            </div>
                        </div>
                        <hr class="my-0">
                        <div class="card-datatable">
                            @if(!empty($errorResult))
                            <div class="table-responsive">
                                <table class="table table-bordered table-hover">
                                    <thead>
                                        <tr role="row">
                                            <th style="width: 10%;">Import Id</th>
                                            <th>Error</th>

                                        </tr>
                                    </thead>
                                    <tbody>
                                        @foreach($errorResult as $er)
                                        <tr>
                                            <td valign="top">{{ $er['import_data_id'] }}</td>
                                            <td valign="top">{{ $er['error']  }}</td>
                                        </tr>
                                        @endforeach
                                    </tbody>
                                </table>
                            </div>
                            @endif
                        </div>
                    </div>
                </div>
            </form>

        </div>
    </div>
</div>
@endsection
