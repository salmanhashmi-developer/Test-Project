@extends("backend.layouts.master")
@section('title') Service View @endsection
@section('content')

<!-- BEGIN: Content-->
<div class="app-content content ">

    <div class="content-wrapper p-0">

        <div class="content-body">
            @include('backend.message')
            <div class="card" data-select2-id="14">
                <div class="card-header border-bottom">
                    <h4 class="card-title">Service Details View</h4>
                </div>
                <div class="card-body py-2 my-25" data-select2-id="53">
                    <!-- header section -->

                    <!-- Modern Horizontal Wizard -->
                    <section class="modern-horizontal-wizard">
                        <div class="bs-stepper wizard-modern modern-wizard-example">
                            <div class="bs-stepper-header">
                                <div class="step" data-target="#account-details-modern" role="tab" id="account-details-modern-trigger">
                                    <button type="button" class="step-trigger">
                                        <span class="bs-stepper-box"><i data-feather="user" class="font-medium-3"></i></span>
                                        <span class="bs-stepper-label">
                                            <span class="bs-stepper-title">Service Details</span>
                                        </span>
                                    </button>
                                </div>
                                <div class="line"><i data-feather="chevron-right" class="font-medium-2"></i></div>
                                <div class="step" data-target="#personal-info-modern" role="tab" id="personal-info-modern-trigger">
                                    <button type="button" class="step-trigger">
                                        <span class="bs-stepper-box"><i data-feather="file-text" class="font-medium-3"></i></span>
                                        <span class="bs-stepper-label">
                                            <span class="bs-stepper-title">Additional Details</span>
                                        </span>
                                    </button>
                                </div>
                                <div class="line"><i data-feather="chevron-right" class="font-medium-2"></i></div>
                                <div class="step" data-target="#service-gallery-modern" role="tab" id="service-gallery-modern-trigger">
                                    <button type="button" class="step-trigger">
                                        <span class="bs-stepper-box"><i data-feather="user" class="font-medium-3"></i></span>
                                        <span class="bs-stepper-label">
                                            <span class="bs-stepper-title">Service Gallery</span>
                                        </span>
                                    </button>
                                </div>
                            </div>
                            <div class="bs-stepper-content">
                                <div id="account-details-modern" class="content" role="tabpanel" aria-labelledby="account-details-modern-trigger">


                                    <div class="d-flex">
                                        <div class="col-xl-8 col-lg-8 col-md-8 align-items-start me-2">
                                            <div class="info-container">
                                                
                                                <ul class="list-unstyled f-12">
                                                    <li class="mb-75 mt-2">
                                                        <div class="row">
                                                            <div class="mb-1 col-md-3">
                                                                <span><?= _('Name') ?></span>
                                                                <br>
                                                                <span class="fw-bolder me-25">{{ $commonService->name }}</span>
                                                            </div>
                                                            <div class="mb-1 col-md-3">
                                                                <span><?= _('Phone No') ?>:</span>
                                                                <br>
                                                                <span class="fw-bolder me-25">{{ $commonService->phone }}</span>
                                                            </div>
                                                            <div class="mb-1 col-md-3">
                                                                <span><?= _('Discount') ?>:</span>
                                                                <br>
                                                                <span class="fw-bolder me-25">{{ $commonService->discount?$commonService->discount:'0.00'  }} %</span>
                                                            </div>
                                                            <div class="mb-1 col-md-3">
                                                                <span><?= _('Address 1') ?>:</span>
                                                                <br>
                                                                <span class="fw-bolder me-25">{{ $commonService->address1  }}</span>
                                                            </div>
                                                        </div>
                                                    </li>
                                                    <li class="mb-75 mt-2">
                                                        <div class="row">                                                        
                                                            <div class="mb-1 col-md-3">
                                                                <span><?= _('Addresss 2') ?>:</span>
                                                                <br>
                                                                <span class="fw-bolder me-25">{{ $commonService->address2 }}</span>
                                                            </div>
                                                            <div class="mb-1 col-md-3">
                                                                <span><?= _('Area') ?>:</span>
                                                                <br>
                                                                <span class="fw-bolder me-25">{{ $commonService->area }}</span>
                                                            </div>
                                                            <div class="mb-1 col-md-3">
                                                                <span><?= _('Pincode') ?>:</span>
                                                                <br>
                                                                <span class="fw-bolder me-25">{{ $commonService->pincode  }}</span>
                                                            </div>
                                                            <div class="mb-1 col-md-3">
                                                                <span><?= _('State') ?>:</span>
                                                                <br>
                                                                <span class="fw-bolder me-25">{{ $commonService->state->name  }}</span>
                                                            </div>
                                                        </div>
                                                    </li>
                                                    <li class="mb-75 mt-2">
                                                        <div class="row">                                                        
                                                            <div class="mb-1 col-md-3">
                                                                <span><?= _('City') ?>:</span>
                                                                <br>
                                                                <span class="fw-bolder me-25">{{ $commonService->city->name }}</span>
                                                            </div>
                                                            <div class="mb-1 col-md-3">
                                                                <span><?= _('Latitude') ?>:</span>
                                                                <br>
                                                                <span class="fw-bolder me-25">{{ $commonService->latitude }}</span>
                                                            </div>
                                                            <div class="mb-1 col-md-3">
                                                                <span><?= _('Longitude') ?>:</span>
                                                                <br>
                                                                <span class="fw-bolder me-25">{{ $commonService->longitude  }}</span>
                                                            </div>
                                                            <div class="mb-1 col-md-3">
                                                                <span><?= _('Status') ?>:</span>
                                                                <br>
                                                                <span class="fw-bolder me-25">{{ $commonService->status->name  }}</span>
                                                            </div>
                                                        </div>
                                                    </li>
                                                    <li class="mb-75 mt-2">
                                                        <div class="row">                                                        
                                                            <div class="mb-1 col-md-3">
                                                                <span><?= _('Virtual Location') ?>:</span>
                                                                <br>
                                                                <span class="fw-bolder me-25">{{ $commonService->virtual_location=="1"?'YES':"NO" }}</span>
                                                            </div>
                                                            <div class="mb-1 col-md-3">
                                                                <span><?= _('Cash Booking Allowed') ?>:</span>
                                                                <br>
                                                                <span class="fw-bolder me-25">{{ $commonService->latitude }}</span>
                                                            </div>
                                                            <div class="mb-1 col-md-3">
                                                                <span><?= _('Longitude') ?>:</span>
                                                                <br>
                                                                <span class="fw-bolder me-25">{{ post_display('cash_booking_allowed',$commonService->common_service_details->cash_booking_allowed) == 1 ? 'Yes':'No'  }}</span>
                                                            </div>
                                                            <div class="mb-1 col-md-3">
                                                                <span><?= _('Cancellation Allowed') ?>:</span>
                                                                <br>
                                                                <span class="fw-bolder me-25">{{ post_display('cancellation_allowed',$commonService->common_service_details->cancellation_allowed) == 1 ? 'Yes':'No'  }}</span>
                                                            </div>
                                                        </div>
                                                    </li>
                                                    
                                                    <?php
                                                        if (!empty($commonService->common_service_details->additional_search_json)) {
                                                            foreach (json_decode($commonService->common_service_details->additional_search_json, true) as $row) {
                                                                echo '<li>pincode : ' . $row['pincode'] . ', latitude : ' . $row['latitude'] . ', longitude : ' . $row['longitude'] . '</li>';
                                                            }
                                                        }
                                                        ?>
                                                </ul>
                                            </div>
                                        </div>
                                        <div class="col-xl-4 col-lg-4 col-md-4  d-flex align-items-start me-2">

                                            <div class="info-container">
                                                <ul class="list-unstyled">
                                                    <li class="mb-75">
                                                        <div class="user-avatar-section">
                                                            <div class="d-flex align-items-center flex-column">
                                                                <?php $src = !empty($commonService->photo) != '' ? '/image/common_service/' . $commonService->photo : '/admin-assets/images/icons/file-icons/no_document.png'; ?>
                                                                <a href="<?php echo $src; ?>" class="" target="_blank">
                                                                    <img class="img-fluid rounded mt-1 mb-3" height="110" width="110" alt="" src="<?php echo $src; ?>"  alt="User avatar" />
                                                                </a>

                                                            </div>
                                                        </div>
                                                    </li>

                                                </ul>
                                            </div>
                                        </div>
                                    </div>


                                </div>

                                <div id="personal-info-modern" class="content" role="tabpanel" aria-labelledby="personal-info-modern-trigger">
                                    <div class="d-flex">
                                        <div class="col-xl-7 col-lg-7 col-md-7 align-items-start me-2">
                                            <div class="info-container">
                                                
                                                <ul class="list-unstyled f-12">
                                                    <li class="mb-75 mt-2">
                                                        <div class="row">
                                                            <div class="mb-1 col-md-6">
                                                                <span><?= _('PAN No') ?></span>
                                                                <br>
                                                                <span class="fw-bolder me-25">{{ $commonService->common_service_details->pancard_number }}</span>
                                                            </div>
                                                            <div class="mb-1 col-md-6">
                                                                <span><?= _('PAN Card Document:') ?>:</span>
                                                                <br>
                                                                <span class="fw-bolder me-25">
                                                                    <?php $src = !empty($commonService->common_service_details->pancard_document) != '' ? '/image/common_service/' . $commonService->common_service_details->pancard_document : '/admin-assets/images/icons/file-icons/no_document.png'; ?>
                                                                    <a href="<?php echo $src; ?>" class="" target="_blank">View Document</a>
                                                                </span>
                                                            </div>
                                                        </div>
                                                    </li>
                                                    <li class="mb-75 mt-2">
                                                        <div class="row">                                                            
                                                            <div class="mb-1 col-md-6">
                                                                <span><?= _('GST No') ?>:</span>
                                                                <br>
                                                                <span class="fw-bolder me-25">{{ $commonService->common_service_details->gst_number  }}</span>
                                                            </div>
                                                            <div class="mb-1 col-md-6">
                                                                <span><?= _('GST Certificate') ?>:</span>
                                                                <br>
                                                                <span class="fw-bolder me-25"> <?php $src = !empty($commonService->common_service_details->gst_certificate) != '' ? '/image/common_service/' . $commonService->common_service_details->gst_certificate : '/admin-assets/images/icons/file-icons/no_document.png'; ?>
                                                                    <a href="<?php echo $src; ?>" class="" target="_blank">View Document</a> 
                                                                </span>
                                                            </div>
                                                        </div>
                                                    </li>
                                                    <li class="mb-75 mt-2">
                                                        <div class="row">
                                                            <div class="mb-1 col-md-6">
                                                                <span><?= _('Bank Account Number') ?>:</span>
                                                                <br>
                                                                <span class="fw-bolder me-25">{{ $commonService->common_service_details->bank_account_number }}</span>
                                                            </div>
                                                            <div class="mb-1 col-md-6">
                                                                <span><?= _('Bank Account Name') ?></span>
                                                                <br>
                                                                <span class="fw-bolder me-25">{{ $commonService->common_service_details->bank_account_name }}</span>
                                                            </div>
                                                        </div>
                                                    </li>
                                                    <li class="mb-75 mt-2">
                                                        <div class="row">                                                        
                                                            <div class="mb-1 col-md-6">
                                                                <span><?= _('Bank Name') ?>:</span>
                                                                <br>
                                                                <span class="fw-bolder me-25">{{ $commonService->common_service_details->bank_name }}</span>
                                                            </div>
                                                            <div class="mb-1 col-md-6">
                                                                <span><?= _('IFSC Code') ?>:</span>
                                                                <br>
                                                                <span class="fw-bolder me-25">{{ $commonService->common_service_details->bank_ifsc_code }}</span>
                                                            </div>
                                                        </div>
                                                    </li>
                                                    <li class="mb-75 mt-2">
                                                        <div class="row">                                                        
                                                            <div class="mb-1 col-md-6">
                                                                <span><?= _('Cancel Policy') ?>:</span>
                                                                <br>
                                                                <span class="fw-bolder me-25">
                                                                    <ul style="list-style-type: decimal;text-align:justify;" class="p-1">

                                                                        <?php
                                                                        if (!empty($commonService->common_service_details->cancel_policy)) {
                                                                            foreach (json_decode($commonService->common_service_details->cancel_policy, true) as $row) {
                                                                                echo '<li>' . $row . '</li>';
                                                                            }
                                                                        }
                                                                        ?>
                                                                    </ul>
                                                                </span>
                                                            </div>
                                                            <div class="mb-1 col-md-6">
                                                                <span><?= _('Cancel Policy Setting') ?>:</span>
                                                                <br>
                                                                <span class="fw-bolder me-25">
                                                                    <ul style="list-style-type: decimal;text-align:justify;" class="p-1">

                                                                        <?php
                                                                        if (!empty($commonService->common_service_details->cancel_policy_setting)) {
                                                                            foreach (json_decode($commonService->common_service_details->cancel_policy_setting, true) as $row) {
                                                                                echo '<li> ' . $row['charge'] . '% for  ' . $row['hours'] . ' Hours   </li>';
                                                                            }
                                                                        }
                                                                        ?>
                                                                    </ul>
                                                                </span>
                                                            </div>
                                                        </div>
                                                    </li>
                                                </ul>
                                                
                                            </div>
                                        </div>
                                        <div class="col-xl-5 col-lg-5 col-md-5  d-flex align-items-start me-2">
                                            <div class="info-container">
                                                <div class="border-bottom m-b-10 f-17"><b>Visit Time Detail</b></div>
                                                <?php
                                                if (!empty($commonService->common_service_details->timing_json)) {
                                                    $timingArr = json_decode($commonService->common_service_details->timing_json, true);
                                                    if (!empty($timingArr)) {
                                                        $html = '<table class="table table-bordered table-hover">';
                                                        foreach ($timingArr as $value) {
                                                            if (!empty($value['times'])) {
                                                                foreach ($value['times'] as $timing) {
                                                                    $html .= "<tr>";
                                                                    $html .= "<td>" . $value['day'] . "</td>";
                                                                    $html .= "<td>" . $timing['start_time'] . ' - ' . $timing['end_time'] . "</td>";
                                                                    $html .= "</tr>";
                                                                }
                                                            }
                                                        }
                                                        $html .= "</table>";
                                                        echo $html;
                                                    }
                                                } else {
                                                    echo "Visit Time Not Available";
                                                }
                                                ?>
                                            </div>
                                        </div>
                                        <!--												<div class="col-xl-5 col-lg-3 col-md-3  d-flex align-items-start me-2">
                                                                                                                                                        <div class="info-container">
                                                                                                                                                                        <ul class="list-unstyled">
                                        
                                                                                                                                                                        </ul>
                                        
                                                                                                                                                        </div>
                                                                                                                                         </div>
                                        -->


                                    </div>
                                </div>
                                <div id="service-gallery-modern" class="content" role="tabpanel" aria-labelledby="service-gallery-modern-trigger">
                                    <?php //echo "<pre>";print_r($images);?>

                                    <div class="cws-content">
                                        <div class="row blog-list-wrapper">
                                            <?php
                                            if (!empty($images)) {
                                                foreach ($images as $row) {
                                                    ?>
                                                    <div class="col-md-4">
                                                        <div class=" border mt-1 ml-1 mr-1 mb-2 text-center">
                                                            <article class="card">
                                                                <?php $src = '/image/common_service_gallery/' . $row['name']; ?>
                                                                <a href="<?php echo $src; ?>" class="" target="_blank">
                                                                    <img src="<?php echo $src; ?>" alt="" class="card-img-top">
                                                                </a>
                                                            </article>
                                                        </div>
                                                    </div> 
                                                    <?php
                                                }
                                            }
                                            ?>

                                        </div>
                                    </div>


                                </div>
                            </div>

                        </div>
                    </section>
                    <!-- /Modern Horizontal Wizard -->

                    <div class="row" data-select2-id="12">
                        <div class="col-12">
                            <a href="{{ route('admin.common.service.edit', ['id'=>$commonService->id] )  }}" class="btn btn-primary me-1 waves-effect waves-float waves-light" > Edit</a>
                            <a href="{{route('admin.common.service')}}" class="btn btn-outline-secondary waves-effect">Back</a>
                        </div>
                    </div>


                </div>

            </div>

        </div>
    </div>
</div>
@endsection
