<script>
    var csrf_field = "{{ csrf_token() }}";
</script>
<script src="{{ Helper::static_asset('admin-assets/js/module/common.js') }}"></script>
<div class="row">
    <form class="" method="POST" action="{{ route('admin.review') }}" id="search_form" onsubmit="return false">
        {{ csrf_field() }}

        <div class="col-12">
            <div class="card">
                <div class="card-header border-bottom">
                    <h4 class="card-title">{{ __("User Review")  }}</h4>
                </div>
                <!--Search Form -->
                <div class="card-body mt-1">
                    <input type="hidden" name="page" id="page" value="{{ empty(app('request')->input('page')) ? 1 : app('request')->input('page')  }}">
                    <input type="hidden" name="sort_field" id="sort_field" value="{{ app('request')->input('sort_field') }}">
                    <input type="hidden" name="sort_action" id="sort_action" value="{{ app('request')->input('sort_action') }}">
                    <div class="row g-1">
                        <div class="col-md-3">
                            <label class="form-label">Service</label>
                            <select name="service_id" class="form-select select2">
                                <option value="">ALL</option>
                                <?php
                                $serviceId = app('request')->input('service_id');
                                ?>
                                @foreach($service as $row)
                                <option value="<?= $row->id ?>" <?= $row->id == $serviceId ? 'selected' : '' ?>><?= $row->name ?></option>
                                @endforeach
                            </select>
                        </div>
                        <div class="col-md-3">
                            <label class="form-label">Rating</label>
                            <select name="rating" class="form-select select2">
                                <option value="">ALL</option>
                                <?php
                                $rating = app('request')->input('rating');
                                ?>
                                @foreach($ratingList as $row)
                                <option value="<?= $row ?>" <?= $row == $rating ? 'selected' : '' ?>><?= $row ?></option>
                                @endforeach
                            </select>
                        </div>
                        <div class="col-md-3">
                            <label class="form-label" for="user_id"><?= _('User') ?></label>
                            <input type="text" name="user" class="form-control user_search" placeholder="<?= _('Select User') ?>"
                                   value="{{app('request')->input('user')}}"/>
                            <input type="hidden" id="user_id" name="user_id" value="{{app('request')->input('user_id')}}">
                        </div>
                        <div class="col-md-3 m-t-35">
                            <label class="form-label"></label>
                            <button type="submit" name='' class="btn btn-primary waves-effect waves-float waves-light">Search</button>
                            <a id="refresh" data-url="/admin/review" class="btn btn-outline-secondary waves-effect">Reset</a>
                        </div>
                    </div>
                </div>
                <hr class="my-0">
                <div class="card-datatable">
                    <?php echo parPageRecordDropDown([5, 10, 20, 30]) ?>
                    @if(!$userReview->isEmpty())
                    @php $start = $userReview->firstItem(); @endphp
                    <div class="table-responsive">
                        <table class="table table-bordered table-hover">
                            <thead>
                                <tr role="row">
                                    <!--<th></th>-->
                                    <th>Service</th>
                                    <th>Ref Data</th>
                                    <th>Title</th>
                                    <th>User</th>
                                    <th>Status / Rating</th>
                                    <th>Action</th>
                                </tr>
                            </thead>
                            <tbody>
                                @foreach($userReview as $data)
                                <tr class="f-12">
                                    <!--<td><?= $start++; ?></td>-->
                                    <td valign="top">{{ $data->service->name  }}</td>
                                    <td valign="top">
                                        <?php if (!empty($data->user)) { ?>
                                            {{ $data->ref_data['title1']}} <br>
                                            <span class="f-11">{{ $data->ref_data['title3']}}</span><br>
                                            <span class="f-11">({{ $data->ref_data['title2']}})
                                            </span>
                                        <?php } ?>
                                    </td>
                                    <td valign="top">{{ $data->title}}</td>
                                    <td valign="top">
                                        <?php if (!empty($data->user)) { ?>
                                            {{ $data->user->first_name.' '.$data->user->last_name  }}
                                            <br><span class="f-11">{{$data->user->mobile}}</span>
                                        <?php } ?>
                                    </td>
                                    <td data-id="status-name" valign="top">{{ $data->status->name}} / {{ $data->rating}}</td>
                                    <td data-id="status-change">
                                        <?php if ($data->status_id != STATUS_APPROVED) { ?>
                                            <a title="Apporove" date-review-id="{{ $data->id  }}" date-status-id="<?php echo STATUS_APPROVED; ?>" data-action="update">
                                                <i data-feather="check-circle" class="me-50 text-success"></i>
                                            </a>
                                        <?php } else { ?>
                                            <a  title="Cancelled" date-review-id="{{ $data->id  }}" date-status-id="<?php echo STATUS_CANCELLED; ?>" data-action="update">
                                                <i data-feather="x-circle" class="me-50 text-danger"></i>
                                            </a>
                                        <?php } ?>
                                        <a  title="Delete" date-review-id="{{ $data->id  }}" data-action="delete">
                                            <i data-feather="trash-2" class="me-50 text-danger"></i>
                                        </a>
                                    </td>
                                </tr>
                                <tr class="action">
                                    <td colspan="4"><b class="theam-color">Description : </b><span class="f-11">{{$data->description}}</span></td>
                                    <td valign="top">
                                        <span class="f-11">{{ date("d/m/Y H:i",strtotime($data->created_at))}}</span>
                                    </td>
                                </tr>
                                @endforeach
                            </tbody>
                        </table>
                    </div>

                    @endif
                    <?php echo pagination($userReview) ?>

                </div>

            </div>
        </div>
    </form>

</div>
@section('script')
<script type="text/javascript">
    $(document).ready(initCommon);
    $(document).on("click", "a[data-action='update']", function () {
        var $this = $(this);
        var param = new Object();
        param["review_id"] = $(this).attr("date-review-id");
        param["status_id"] = $(this).attr("date-status-id");
        //console.log(param);
        if (APP.BlockConcurrentReq(2000)) {
            return;
        }
        loadingOverlay("body", "show");
        jqueryAjax("{{  route('admin.review.update')  }}", param, function (res) {
            loadingOverlay("body", "hide");
            if (res.code != 200) {
                Notification.show({type: "error", msg: res.message, timeout: 3000});
                return;
            }
            Notification.show({type: "success", msg: res.message, timeout: 3000});
            var $closestTr = $this.closest("tr");
            if (param["status_id"] == 7) {
                $closestTr.find("td[data-id='status-change']").html('<a title="Cancelled" date-review-id="' + param["review_id"] + '" date-status-id="<?php echo STATUS_CANCELLED; ?>" data-action="update"><svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="feather feather-x-circle me-50 text-danger"><circle cx="12" cy="12" r="10"></circle><line x1="15" y1="9" x2="9" y2="15"></line><line x1="9" y1="9" x2="15" y2="15"></line></svg></a>');
                $closestTr.find("td[data-id='status-name']").html("APPROVED");
            } else {
                $this.closest("td[data-id='status-change']").html('<a title="Apporove" date-review-id="' + param["review_id"] + '" date-status-id="<?php echo STATUS_APPROVED; ?>" data-action="update"><svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="feather feather-check-circle me-50 text-success"><path d="M22 11.08V12a10 10 0 1 1-5.93-9.14"></path><polyline points="22 4 12 14.01 9 11.01"></polyline></svg></a>');
                $closestTr.find("td[data-id='status-name']").html("CANCELLED");
            }
        }, "", "json");

    });
    $(document).on("click", "a[data-action='delete']", function () {
        var $this = $(this);
        var param = new Object();
        param["review_id"] = $(this).attr("date-review-id");
        //console.log(param);
        if (APP.BlockConcurrentReq(2000)) {
            return;
        }
        loadingOverlay("body", "show");
        jqueryAjax("{{  route('admin.review.delete')  }}", param, function (res) {
            loadingOverlay("body", "hide");
            if (res.code != 200) {
                Notification.show({type: "error", msg: res.message, timeout: 3000});
                return;
            }
            Notification.show({type: "success", msg: res.message, timeout: 3000});
            var $closestTr = $this.closest("tr");
            $closestTr.hide();
            $closestTr.next().remove();
        }, "", "json");

    });
</script>

@endsection
