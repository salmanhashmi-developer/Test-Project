@extends("backend.layouts.master")
@section('title') Common Service Enquiry view @endsection
@section('content')

<!-- BEGIN: Content-->
<div class="app-content content ">

    <div class="content-wrapper p-0">

        <div class="content-body">
            @include('backend.message')
            <section class="app-user-view-account">
                <div class="row">
                    <!-- User Sidebar -->
                    <div class="col-xl-12 col-lg-12 col-md-12 order-1 order-md-0">
                        <!-- User Card -->
                        <div class="card">
                            <div class="card-body">
                                <h4 class="fw-bolder border-bottom pb-50 mb-1">Common Service Enquiry View</h4>
                                <div class="d-flex">
                                    <div class="col-xl-12 col-lg-12 col-md-12  d-flex align-items-start me-2">
                                        <div class="info-container">
                                            <div class="table-responsive">
                                                <table class="table table-bordered table-hover">
                                                    <tr>
                                                        <th>User</th>
                                                        <td>{{ $commonServiceEnquiry->name  }}<span class="f-11">({{$commonServiceEnquiry->mobile}})</span></td>
                                                    </tr>
                                                    <tr>
                                                        <th>Service Operator</th>
                                                        <td>
                                                            <b>{{ $commonServiceEnquiry->common_service->name}}</b>
                                                            <br/><span class="f-11"><b>Mo : </b>{{$commonServiceEnquiry->common_service->phone}}</span>
                                                            <br/><span class="f-11"><b>Address :</b> 
                                                                {{$commonServiceEnquiry->common_service->address1}},
                                                                {{$commonServiceEnquiry->common_service->address2}},
                                                                {{$commonServiceEnquiry->common_service->area}},
                                                                {{$commonServiceEnquiry->common_service->city->name}},
                                                                {{$commonServiceEnquiry->common_service->pincode}}
                                                            </span>
                                                        </td>
                                                    </tr>
                                                    <tr>
                                                        <th>Category</th>
                                                        <td>{{ $commonServiceEnquiry->common_service->category->name }}</td>
                                                    </tr>
                                                    <tr>
                                                        <th>Status</th>
                                                        <td>{{ $commonServiceEnquiry->status->name  }}</td>
                                                    </tr>
                                                    <tr>
                                                        <th>Description</th>
                                                        <td>{{ $commonServiceEnquiry->description  }}</td>
                                                    </tr>
                                                    <tr>
                                                        <th>Appointment Date</th>
                                                        <td>{{ date("d/m/Y",strtotime($commonServiceEnquiry->appointment_date)) }}</td>
                                                    </tr>
                                                    <tr>
                                                        <th>Created At</th>
                                                        <td>{{ date("d/m/Y H:i",strtotime($commonServiceEnquiry->created_at)) }}</td>
                                                    </tr>
                                                </table>
                                            </div>
                                            <div class="d-flex pt-2">
                                                <button type="button" class="btn btn-primary me-1" data-bs-toggle="modal" data-bs-target="#changeStatusModal">Change Status</button>
                                                <a href="{{route('admin.common.service.enquiry')}}" class="btn btn-outline-secondary">Back</a>
                                            </div>
                                        </div>
                                    </div>
                                </div>	
                                <?php if (!empty($commonServiceEnquiry->remark_json)) { ?>

                                    <h4 class="fw-bolder border-bottom pb-50 mb-1" style="padding-top: 30px;font-size: 15px;">
                                        History
                                    </h4>
                                    <div class="d-flex">
                                        <div class="col-xl-12 col-lg-12 col-md-12  d-flex align-items-start me-2">
                                            <div class="info-container">
                                                <div class="table-responsive">
                                                    <table class="table table-bordered table-hover">
                                                        <tr>
                                                            <th>Updated At</th>
                                                            <th>User</th>
                                                            <th>Status</th>
                                                            <th>Remark</th>
                                                        </tr>
                                                        <?php
                                                        foreach (json_decode($commonServiceEnquiry->remark_json, true) as $value) {
                                                            if (!empty($value)) {
                                                                ?>
                                                                <tr>
                                                                    <td>{{date("d/m/Y H:i",strtotime($value['updated_at']))}}</td>
                                                                    <td>{{$value['updated_by_name']}}</td>
                                                                    <td>{{$value['status']}}</td>
                                                                    <td>{{$value['remark']}}</td>
                                                                </tr>
                                                                <?php
                                                            }
                                                        }
                                                        ?>
                                                    </table>
                                                </div>
                                            </div>
                                        </div>
                                    </div>	
                                    <?php
                                }
                                ?>
                            </div>
                        </div>
                    </div>
                </div>
            </section>
        </div>
    </div>
</div>
<!-- add new address modal -->
<div class="modal fade" id="changeStatusModal" tabindex="-1" aria-labelledby="changeStatusTitle" aria-hidden="true">
    <div class="modal-dialog modal-dialog-centered modal-lg">
        <div class="modal-content">
            <div class="modal-header bg-transparent">
                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
            </div>
            <div class="modal-body pb-3 px-sm-4 mx-50">
                <h1 class="address-title text-center mb-1" id="changeStatusTitle">Change Status</h1>
                <p class="address-subtitle text-center mb-2 pb-75">PLEASE UPDATE REMARK</p>

                <form class="row gy-1 gx-2" method="POST" action="{{route('admin.common.service.enquiry.update')}}">
                    {{ csrf_field() }}
                    <div class="col-12">
                        <label class="form-label" for="status_id">Status</label>
                        <select class="form-control select2" name="status_id">
                            <?php
                            $setValues = $commonServiceEnquiry->status_id;
                            ?>
                            @foreach($statusList as $key=>$val)
                            <option value="<?= $key ?>" <?= $key == $setValues ? 'selected' : '' ?>><?= $val ?></option>
                            @endforeach
                        </select>
                    </div>
                    <div class="col-12">
                        <label class="form-label" for="remark">Remark</label>
                        <textarea name="remark"class="form-control" rows="5" placeholder="Enter remark" required/></textarea>
                    </div>
                    <input type="hidden" name="id"  value="<?= $commonServiceEnquiry->id ?>" />
                    <div class="col-12 text-center">
                        <button type="submit" class="btn btn-primary me-1 mt-2">Submit</button>
                        <button type="reset" class="btn btn-outline-secondary mt-2" data-bs-dismiss="modal" aria-label="Close">Discard</button>
                    </div>
                </form>
            </div>
        </div>
    </div>
</div>
<!-- / add new address modal -->
@endsection