<script>
    var csrf_field = "{{ csrf_token() }}";
</script>
<script src="{{ Helper::static_asset('admin-assets/js/module/common.js') }}"></script>
<div class="row">
    <form class="" method="POST" action="{{ route('admin.complain') }}" id="search_form" onsubmit="return false">
        {{ csrf_field() }}
        <div class="col-12">
            <div class="card">
                <div class="card-header border-bottom">
                    <h4 class="card-title">{{ __("User Complain")  }}</h4>
                </div>
                <!--Search Form -->
                <div class="card-body mt-1">
                    <input type="hidden" name="page" id="page" value="{{ empty(app('request')->input('page')) ? 1 : app('request')->input('page')  }}">
                    <input type="hidden" name="sort_field" id="sort_field" value="{{ app('request')->input('sort_field') }}">
                    <input type="hidden" name="sort_action" id="sort_action" value="{{ app('request')->input('sort_action') }}">
                    <div class="row g-1">
                        <div class="col-md-3">
                            <label class="form-label">Service</label>
                            <select name="service_id" class="form-select select2">
                                <option value="">ALL</option>
                                <?php
                                $serviceId = app('request')->input('service_id');
                                ?>
                                @foreach($service as $row)
                                <option value="<?= $row->id ?>" <?= $row->id == $serviceId ? 'selected' : '' ?>><?= $row->name ?></option>
                                @endforeach
                            </select>
                        </div>
                        <div class="col-md-3">
                            <label class="form-label">Type</label>
                            <select name="type" class="form-select select2">
                                <option value="">ALL</option>
                                <?php
                                $type = app('request')->input('type');
                                ?>
                                @foreach($typeList as $row)
                                <option value="<?= $row->id ?>" <?= $row->id == $type ? 'selected' : '' ?>><?= $row->name ?></option>
                                @endforeach
                            </select>
                        </div>
                        <div class="col-md-3">
                            <label class="form-label" for="user_id"><?= _('User') ?></label>
                            <input type="text" name="user" class="form-control user_search" placeholder="<?= _('Select User') ?>"
                                   value="{{app('request')->input('user')}}"/>
                            <input type="hidden" id="user_id" name="user_id" value="{{app('request')->input('user_id')}}">
                        </div>
                        <div class="col-md-3 m-t-35">
                            <label class="form-label"></label>
                            <button type="submit" name='' class="btn btn-primary waves-effect waves-float waves-light">Search</button>
                            <a id="refresh" data-url="/admin/complain" class="btn btn-outline-secondary waves-effect">Reset</a>
                        </div>
                    </div>
                </div>
                <hr class="my-0">
                <div class="card-datatable">
                    <?php echo parPageRecordDropDown([5, 10, 20, 30]) ?>
                    @if(!$userComplain->isEmpty())
                    @php $start = $userComplain->firstItem(); @endphp
                    <div class="table-responsive">
                        <table class="table table-bordered table-hover">
                            <thead>
                                <tr role="row">
                                    <!--<th></th>-->
                                    <th>Service</th>
                                    <th>Ref Data</th>
                                    <th>Complain Type</th>
                                    <th>Status</th>
                                    <th>User</th>
                                </tr>
                            </thead>
                            <tbody>
                                @foreach($userComplain as $data)
                                <tr class="f-12">
                                    <!--<td><?= $start++; ?></td>-->
                                    <td valign="top">{{ $data->service->name  }}</td>
                                    <td valign="top">{{ $data->ref_data->title1}} <br>
                                        <span class="f-11">{{ $data->ref_data->title3}}</span><br>
                                        <span class="f-11">{{ $data->ref_data->title2}}</span>
                                    </td>
                                    <td valign="top">
                                        <?php
                                        $typeArr = explode(',', $data->type);
                                        if (!empty($typeArr) && !empty($typeList)) {
                                            foreach ($typeList as $key => $value) {
                                                if (in_array($value['id'], $typeArr)) {
                                                    echo $value['name'] . ". ";
                                                }
                                            }
                                        }
                                        ?>
                                    </td>
                                    <td valign="top">{{ $data->status->name}}</td>
                                    <td valign="top">
                                        {{ !empty($data->user)?$data->user->first_name.' '.$data->user->last_name:''  }}
                                        <br><span class="f-11">{{!empty($data->user)?$data->user->mobile:''}}</span>
                                    </td>
                                </tr>
                                <tr class="action">
                                    <td colspan="4"><b class="theam-color">Description : </b><span class="f-11">{{$data->description}}</span></td>
                                    <td valign="top">
                                        <span class="f-11">{{ date("d/m/Y H:i",strtotime($data->created_at))}}</span>
                                    </td>
                                </tr>
                                @endforeach
                            </tbody>
                        </table>
                    </div>
                    @endif
                    <?php echo pagination($userComplain) ?>
                </div>
            </div>
        </div>
    </form>
</div>
@section('script')
<script type="text/javascript">
    $(document).ready(initCommon);
</script>

@endsection
