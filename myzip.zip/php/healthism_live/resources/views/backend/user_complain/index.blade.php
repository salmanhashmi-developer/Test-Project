@extends("backend.layouts.master")
@section('title') User Complain @endsection
@section('content')
<!-- BEGIN: Content-->
<div class="app-content content ">

    <div class="content-wrapper p-0">

        <div class="content-body" id="ajax_content">
            @include('backend.message')
            @include("backend.user_complain.ajax_content")
        </div>


    </div>
</div>
@endsection

