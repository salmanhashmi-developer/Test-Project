<?php

namespace App\Imports;

use Maatwebsite\Excel\Concerns\Importable;
use Maatwebsite\Excel\Concerns\ToArray;
use Maatwebsite\Excel\Concerns\WithHeadingRow;
use Maatwebsite\Excel\Concerns\WithGroupedHeadingRow;

class CommonImport implements ToArray, WithHeadingRow,WithGroupedHeadingRow {

    use Importable;

    public function array($file) {
        
    }

}
