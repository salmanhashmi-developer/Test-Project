<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class OrderPayment extends Model {

    use HasFactory;

    protected $table = "order_payment";
    public $timestamps = false;
    public $fillable = [
        "order_id",
        "user_id",
        "payment_mode_id",
        "pg_amount",
        "refund_amount",
        "pg_reference_id",
        "pg_response",
        "pg_refund_response",
        "status_id",
        "payment_sync_retry_count",
        "ip_address",
        "created_at",
        "updated_at",
    ];

    public function paymentmode() {
        return $this->belongsTo(PaymentMode::class,'payment_mode_id');
    }
    public function user() {
        return $this->belongsTo(User::class,'user_id');
    }
    public function status() {
        return $this->belongsTo(Status::class);
    }

}
