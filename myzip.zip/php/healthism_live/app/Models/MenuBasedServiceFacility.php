<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class MenuBasedServiceFacility extends Model {

    use HasFactory;

    protected $table = "menu_based_service_facility";
    public $fillable = [
        'menu_based_service_id',
        'menu_based_service_parent_id',
        'name',
        'description',
        'gender',
        'time',
        'is_package',
        'category',
        'facility_count',
        'detail_json',
        'price',
        'discount',
        'sort_order',
        'status_id',
        'created_at',
        'updated_at',
        'import_id',
    ];

    public function status() {
        return $this->belongsTo(Status::class);
    }

    public function menuBasedService() {
        return $this->belongsTo(MenuBasedService::class, 'menu_based_service_id')->select(array('*'));
    }

    public function menuBasedServiceParent() {
        return $this->belongsTo(MenuBasedService::class, 'menu_based_service_parent_id')->select(array('*'));
    }

    public function getDetailJsonAttribute($value) {
        if ($value != null) {
            return json_decode($value, true);
        }
        return NULL;
    }

}
