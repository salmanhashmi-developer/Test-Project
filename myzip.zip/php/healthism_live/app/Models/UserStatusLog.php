<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class UserStatusLog extends Model {

    use HasFactory;

    protected $table = 'user_status_log';
    public $timestamps = false;
    public $fillable = [
        'created_by',
        'created_at',
        'remark_private',
        'remark_public',
        'user_id',
        'status_id'
    ];

    public function user() {
        return $this->belongsTo(User::class);
    }

    public function status() {
        return $this->belongsTo(Status::class);
    }

    public function createdBy() {
        return $this->belongsTo(User::class, 'created_by');
    }

}
