<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class LabBookingDetail extends Model {

    use HasFactory;

    protected $table = "lab_booking_details";
    public $fillable = [
        'lab_booking_id',
        'lab_id',
        'lab_parent_id',
        'test_id',
        'amount',
        'tax',
        'discount',
        'refund_amount',
        'status_id',
        'created_at',
        'updated_at',
    ];

    public function test() {
        return $this->belongsTo(LabTest::class);
    }

}
