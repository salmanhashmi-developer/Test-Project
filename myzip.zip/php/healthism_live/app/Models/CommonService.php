<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class CommonService extends Model {

    use HasFactory;

    protected $table = "common_service";
    public $fillable = [
        "import_data_id",
        "name",
        "phone",
        "mobile",
        "email",
        "address1",
        "address2",
        "area",
        "pincode",
        "city_id",
        "state_id",
        "latitude",
        "longitude",
        "discount",
        "category_id",
        "photo",
        "virtual_location",
        "status_id",
        "created_at",
        "updated_at",
        "virtual_location"
    ];

    public function status() {
        return $this->belongsTo(Status::class);
    }

    public function common_service_details() {
        return $this->hasOne(CommonServiceDetails::class);
    }
    public function common_service_search() {
        return $this->hasMany(CommonServiceSearch::class);
    }

    public function state() {
        return $this->belongsTo(State::class);
    }

    public function city() {
        return $this->belongsTo(City::class);
    }
    public function category() {
       return $this->belongsTo(Category::class, 'category_id')->select(array('id', 'name'));
    }

}
