<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class SubscriptionBasedServiceBookingDetails extends Model {

    use HasFactory;

    protected $table = "subscription_based_service_booking_details";
    public $fillable = [
        'subscription_based_service_booking_id',
        'subscription_based_service_id',
        'subscription_based_service_parent_id',
        'subscription_based_service_facility_id',
        'amount',
        'tax',
        'discount',
        'refund_amount',
        'status_id',
        'created_at',
        'updated_at',
    ];

    public function subscriptionBasedServiceFacility() {
        return $this->belongsTo(SubscriptionBasedServiceFacility::class);
    }

}
