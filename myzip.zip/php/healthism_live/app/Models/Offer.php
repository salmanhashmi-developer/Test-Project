<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class Offer extends Model {

    use HasFactory;

    protected $table = "offer";
    public $timestamps = false;
    public $fillable = [
        'name',
        'discount_type',
        'start_time',
        'end_time',
        'fix_code',
        'max_code_use',
        'max_code_use_per_user',
        'max_discount_qty',
        'max_discount_txn',
        'max_offer_use',
        'max_offer_use_per_user',
        'max_discount_per_user',
        'description',
        'used_count',
        'is_active',
        'locked_count',
        'service_ids',
        'alert_quantity',
        'created_at',
        'created_by',
        'updated_at',
        'updated_by',
    ];

    public function offerDetail() {
        return $this->hasOne(OfferDetail::class);
    }

}
