<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class CorporateSubscription extends Model {

    use HasFactory;

    protected $table = "corporate_subscription";
    public $timestamps = false;
    public $fillable = [
        'subscription_id',
        'company_id',
        'expiry_date',
        'qty',
        'used',
        'amount',
        'tax',
        'order_id',
        'status_id',
        'created_by',
        'created_at',
    ];
    public static $rules = [
        "subscription_id" => "Required",
        "company_id" => "Required",
        "qty" => "Required",
        "amount" => "Required",
    ];

    public function subscription() {
        return $this->belongsTo(Subscription::class);
    }

    public function company() {
        return $this->belongsTo(CorporateCompany::class);
    }

    public function status() {
        return $this->belongsTo(Status::class);
    }

    public function createdby() {
        return $this->belongsTo(User::class,'created_by');
    }

}
