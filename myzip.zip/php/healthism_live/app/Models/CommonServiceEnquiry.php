<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class CommonServiceEnquiry extends Model {

    use HasFactory;

    protected $table = "common_service_enquiry";
    public $fillable = [
        "user_id",
        "common_service_id",
        "name",
        "mobile",
        "appointment_date",
        "description",
        "status_id",
        "remark_json",
        "created_at",
        "updated_at",
    ];
    public static $rules = [
        "name" => "Required",
        "common_service_id" => "Required",
        "mobile" => "Required|regex:/^([0-9]*)$/|min:10",
        "appointment_date" => "Required",
        "description" => "Required",
    ];

    public function common_service() {
        return $this->belongsTo(CommonService::class);
    }

    public function user() {
        return $this->belongsTo(User::class);
    }

    public function status() {
        return $this->belongsTo(Status::class);
    }

}
