<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class SubscriptionBasedServiceBooking extends Model {

    use HasFactory;

    protected $table = "subscription_based_service_booking";
    public $timestamps = false;
    public $fillable = [
        'order_id',
        'user_id',
        'user_subscription_id',
        'subscription_based_service_id',
        'subscription_based_service_parent_id',
        'user_member_id',
        'member_name',
        'member_mobile',
        'appointment_date',
        'amount',
        'tax',
        'refund_amount',
        'discount',
        'status_id',
        'created_by',
        'created_at',
        'updated_at',
    ];

    public function subscriptionBasedService() {
        return $this->belongsTo(SubscriptionBasedService::class);
    }

    public function order() {
        return $this->belongsTo(Orders::class);
    }

    public function subscriptionBasedServiceBookingDetails() {
        return $this->hasMany(SubscriptionBasedServiceBookingDetails::class);
    }

    public function userMember() {
        return $this->belongsTo(UserPatientMapping::class, 'user_member_id')->select(array('id', 'first_name', 'last_name', 'email', 'mobile', 'dob', 'blood_group'));
    }

    public function status() {
        return $this->belongsTo(Status::class);
    }

    public function user() {
        return $this->belongsTo(User::class, 'created_by')->select(array('id', 'first_name', 'last_name', 'mobile', 'email', 'photo'));
    }

    public function getAddressAttribute($value) {
        if ($value != null) {
            return json_decode($value, true);
        }
        return NULL;
    }

    public function userSubscription() {
        return $this->belongsTo(UserSubscription::class, 'user_subscription_id')->select(array('id', 'card_no'));
    }

}
