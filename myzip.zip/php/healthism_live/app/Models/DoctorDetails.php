<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class DoctorDetails extends Model
{

    use HasFactory;

    protected $table = "doctor_details";
    public $timestamps = false;
    public $fillable = [
        'doctor_id',
        'description',
        'registration_number',
        'registration_council',
        'registration_date',
        'registration_proof',
        'last_degree_obtained',
        'date_of_completion',
        'college_institute_name',
        'qualification_certificates',
        'aadhar_card_no',
        'aadhar_card_document',
        'pan_card_no',
        'pan_card_document',
        'service_json',
        'specialization_json',
        'education_json',
        'membership_json',
        'experience_json',
        'registration_json'
    ];

    public function getRegistrationProofAttribute($value)
    {
        if ($value != NULL) {
            return getUrl('image/doctor_mix') . $value;
        }
        return NULL;
    }
    public function getQualificationCertificatesAttribute($value)
    {
        if ($value != NULL) {
            return getUrl('image/doctor_mix') . $value;
        }
        return NULL;
    }
    public function getAadharCardDocumentAttribute($value)
    {
        if ($value != NULL) {
            return getUrl('image/doctor_mix') . $value;
        }
        return NULL;
    }
    public function getPanCardDocumentAttribute($value)
    {
        if ($value != NULL) {
            return getUrl('image/doctor_mix') . $value;
        }
        return NULL;
    }
}
