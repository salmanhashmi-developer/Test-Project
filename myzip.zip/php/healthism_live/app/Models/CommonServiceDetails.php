<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class CommonServiceDetails extends Model {

    use HasFactory;

    protected $table = "common_service_details";
    public $fillable = [
        "common_service_id",
        "description",
        "timing_json",
        "additional_search_json",
        "gallery_json",
        "cash_booking_allowed",
        "cancellation_allowed",
        "cancel_policy",
        "cancel_policy_setting",
        "pancard_number",
        "pancard_document",
        "gst_number",
        "gst_certificate",
        "bank_account_number",
        "bank_account_name",
        "bank_name",
        "bank_ifsc_code",
        "created_at",
        "updated_at",
    ];

    public function common_service() {
        return $this->belongsTo(common_service::class);
    }

}
