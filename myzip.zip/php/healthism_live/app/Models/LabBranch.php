<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class LabBranch extends Model {

    use HasFactory;

    protected $table = "lab_branch";
    public $fillable = [
    ];

    public function status() {
        return $this->belongsTo(Status::class);
    }

    public function state() {
        return $this->belongsTo(State::class);
    }

    public function city() {
        return $this->belongsTo(City::class);
    }

    public function user() {
        return $this->belongsTo(User::class);
    }

    public function getGalleryJsonAttribute($value) {
        return json_decode($value, true);
    }
    public function getTimingJsonAttribute($value) {
        return json_decode($value, true);
    }

}
