<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class CommonServiceMapping extends Model {

    use HasFactory;

    protected $table = "common_service_mapping";

    public function category() {
        return $this->belongsTo(Category::class);
    }

}
