<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class UserFamilyMember extends Model {

    use HasFactory;

    protected $table = 'user_family_member';
    public $timestamps = false;
    public $fillable = [
        "user_id",
        "user_subscription_id",
        "created_at",
        "expiry_date",
        "first_name",
        "last_name",
        "mobile",
        "relation",
        "status_id",
        "updated_at",
    ];
    public static $rules = [
        "first_name" => "Required",
        "last_name" => "Required",
        "mobile" => "Required|regex:/^([0-9]*)$/|min:10",
    ];

    public function user() {
        return $this->belongsTo(User::class);
    }

    public function usersubscription() {
        return $this->belongsTo(UserSubscription::class, 'user_subscription_id')->select(array('*'));
    }

}
