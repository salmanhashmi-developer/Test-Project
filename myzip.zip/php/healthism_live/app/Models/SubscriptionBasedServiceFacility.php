<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class SubscriptionBasedServiceFacility extends Model {

    use HasFactory;

    protected $table = "subscription_based_service_facility";
    public $fillable = [
        'subscription_based_service_id',
        'subscription_based_service_parent_id',
        'name',
        'description',
        'gender',
        'days',
        'sub_category_ids',
        'calories_burn',
        'result',
        'note',
        'detail_json',
        'price',
        'discount',
        'status_id',
        'sort_order',
        'created_at',
        'updated_at',
    ];

    public function status() {
        return $this->belongsTo(Status::class);
    }

    public function subscriptionBasedService() {
        return $this->belongsTo(SubscriptionBasedService::class, 'subscription_based_service_id')->select(array('*'));
    }

    public function subscriptionBasedServiceParent() {
        return $this->belongsTo(SubscriptionBasedService::class, 'subscription_based_service_parent_id')->select(array('*'));
    }

    public function getDetailJsonAttribute($value) {
        if ($value != null) {
            return json_decode($value, true);
        }
        return NULL;
    }

}
