<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class MenuBasedServiceSlot extends Model {

    use HasFactory;

    protected $table = "menu_based_service_slot";
    public $fillable = [
        'menu_based_service_id',
        'day',
        'date',
        'from_time',
        'to_time',
        'status_id',
        'created_at',
        'created_by'
    ];

    public function menuBasedService() {
        return $this->hasOne(MenuBasedService::class, 'menu_based_service_id');
    }

}
