<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class Log extends Model {

    use HasFactory;

    protected $table = 'log';
    public $timestamps = false;
    public $fillable = [
        'created_by',
        'created_for',
        'type',
        'sub_type',
        'log_detail',
        'ip',
        'extra_detail',
        'created_at'
    ];

}
