<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class OfferCodeTrack extends Model {

    use HasFactory;

    protected $table = "offer_code_track";
    public $timestamps = false;
    public $fillable = [
        'benifit_amount',
        'benifit_time',
        'complimentary_offer_code',
        'offer_id',
        'order_amount',
        'order_id',
        'service_id',
        'user_id',
        'offer_code_id',
        'status_id',
        'created_at',
        'updated_at',
    ];

}
