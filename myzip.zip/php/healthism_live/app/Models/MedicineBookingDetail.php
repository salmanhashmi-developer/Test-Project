<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class MedicineBookingDetail extends Model {

    use HasFactory;

    protected $table = "user_medical_history_mapping";
    public $fillable = [
        'user_medial_history_id',
        'original_file_name',
        'file',
        'medicine',
        'days',
        'qty',
        'frequency_json',
        'created_at',
    ];

    public function medicine_booking() {
        return $this->belongsTo(MedicineBooking::class,'id');
    }
}