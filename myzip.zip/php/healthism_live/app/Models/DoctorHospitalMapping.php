<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class DoctorHospitalMapping extends Model {

    use HasFactory;

    protected $table = "doctor_hospital_mapping";
    public $timestamps = false;
    public $fillable = [
        'doctor_id',
        'hospital_id',
        'timing_json',
        'fees',
        'discount',
        'video_consultation_available',
        'slot_type'
    ];

    public function hospital() {
        return $this->belongsTo(Hospital::class, 'hospital_id')->select(array('id', 'name', 'area', 'status_id', 'type', 'photo', 'cancellation_allowed', 'cancel_policy', 'cancel_policy_setting', 'cash_booking_allowed'));
    }

    public function doctor() {
        return $this->belongsTo(Doctor::class, 'doctor_id')->select(array('id', 'first_name', 'last_name', 'phone', 'specialization', 'photo'));
    }

}
