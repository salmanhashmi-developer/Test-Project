<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class UserUpload extends Model {

    use HasFactory;

    protected $table = "user_upload";
    public $timestamps = false;
    public $fillable = [
        'user_id',
        'service_ref_id',
        'user_patient_id',
        'ref_id',
        'service_id',
        'uploaded_by',
        'file_json',
        'status_id',
        'created_at',
        'updated_at',
        'address_id',
        'user_remark',
    ];
    public static $rules = [
        "ref_id" => "Required",
        "service_id" => "Required",
        "user_id" => "Required",
    ];

    public function getFileJsonAttribute($value) {
        if ($value != null) {
            $result = [];
            $arr = explode(',', $value);
            foreach ($arr as $img) {
                if (!empty($img)) {
                    $result[] = getUrl('image/user_medical_history') . trim($img);
                }
            }
            return $result;
        }
        return NULL;
    }

    public function user() {
        return $this->belongsTo(User::class);
    }

    public function service() {
        return $this->belongsTo(Service::class);
    }

    public function status() {
        return $this->belongsTo(Status::class);
    }

    public function userPatient() {
        return $this->belongsTo(UserPatientMapping::class, 'user_patient_id')->select(array('id', 'first_name', 'last_name', 'email', 'mobile', 'dob', 'blood_group'));
    }

    public function address() {
        return $this->belongsTo(UserAddress::class);
    }

    public function mapping() {
        return $this->hasOne(UserMedicalHistoryMapping::class, 'user_medical_history_id');
    }

    public function quotation() {
        return $this->hasOne(MedicineQuotation::class, 'user_upload_id');
    }

    public function uploadedBy() {
        return $this->belongsTo(User::class, 'uploaded_by')->select(array('id', 'first_name', 'last_name', 'mobile'));
    }

}
