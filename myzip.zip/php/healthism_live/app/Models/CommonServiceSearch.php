<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class CommonServiceSearch extends Model {

    use HasFactory;

    protected $table = "common_service_search";
    public $timestamps = false;
    public $fillable = [
        "common_service_id",
        "category_id",
        "name",
        "city_id",
        "state_id",
        "pincode",
        "latitude",
        "longitude",
    ];

    public function category() {
        return $this->belongsTo(Category::class);
    }

    public function common_service() {
        return $this->hasOne(CommonService::class);
    }

    public function state() {
        return $this->belongsTo(State::class);
    }

    public function city() {
        return $this->belongsTo(City::class);
    }

}
