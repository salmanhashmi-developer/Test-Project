<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class LabSlot extends Model {

    use HasFactory;

    protected $table = "lab_slot";
    public $fillable = [
        'lab_id',
        'day',
        'date',
        'from_time',
        'to_time',
        'is_home_collection',
        'is_offline',
        'charge',
        'status_id',
        'created_at',
        'created_by',
    ];

    public function lab() {
        return $this->hasOne(Lab::class, 'lab_id');
    }

}
