<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class SubscriptionBasedServiceSearch extends Model {

    use HasFactory;

    protected $table = "subscription_based_service_search";
    public $timestamps = false;
    public $fillable = [
        'subscription_based_service_id',
        'subscription_based_service_parent_id',
        'category_id',
        'name',
        'city_id',
        'state_id',
        'pincode',
        'latitude',
        'longitude',
    ];

    public function subscriptionBasedService() {
        return $this->hasOne(SubscriptionBasedService::class, 'subscription_based_service_id');
    }

    public function subscriptionBasedServiceParent() {
        return $this->hasOne(SubscriptionBasedService::class, 'subscription_based_service_parent_id');
    }

}
