<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class CorporateEnquiry extends Model {

    use HasFactory;

    protected $table = "corporate_enquiry";
    public $timestamps = false;
    public $fillable = [
        'id',
        'user_id',
        'company_name',
        'no_of_employee',
        'contact_person',
        'contact_no',
        'email_id',
        'status_id',
        'created_at',
        'updated_at'
    ];
    public static $rules = [
        "company_name" => "Required",
        "no_of_employee" => "Required",
        "contact_person" => "Required",
        "contact_no" => "Required",
        "email_id" => "Required|email",
    ];

    public function user() {
        return $this->belongsTo(User::class);
    }
    public function status() {
        return $this->belongsTo(Status::class);
    }

}
