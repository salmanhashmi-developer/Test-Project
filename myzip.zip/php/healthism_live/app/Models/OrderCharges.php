<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class OrderCharges extends Model {

    use HasFactory;

    protected $table = "order_charges";
    public $timestamps = false;
    public $fillable = [
        'user_id',
        'service_id',
        'order_id',
        'order_detail_id',
        'charge_type_id',
        'name',
        'amount',
        'created_at',
    ];
    public function user() {
        return $this->belongsTo(User::class,'user_id');
    }
    public function service() {
        return $this->belongsTo(Service::class,'service_id');
    }
    public function chargeType() {
        return $this->belongsTo(Service::class,'charge_type_id');
    }

}
