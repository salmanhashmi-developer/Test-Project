<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class UserSubscription extends Model {

    use HasFactory;

    protected $table = 'user_subscription';
    public $timestamps = false;
    public $fillable = [
        'subscription_id',
        'user_id',
        'card_no',
        'created_at',
        'expiry_date',
        'status_id',
        'amount',
        'tax',
        'order_id',
        'created_by',
        'updated_at'
    ];

    public function subscription() {
        return $this->belongsTo(Subscription::class, 'subscription_id')->select(array('*'));
    }

    public function user() {
        return $this->belongsTo(User::class, 'user_id')->select('id', 'first_name', 'last_name', 'email', 'mobile');
    }

    public function bookby() {
        return $this->belongsTo(User::class, 'created_by')->select('id', 'first_name', 'last_name', 'email', 'mobile');
    }

    public function status() {
        return $this->belongsTo(Status::class, 'status_id')->select(array('*'));
    }

    public function order() {
        return $this->belongsTo(Orders::class, 'order_id')->select(array('*'));
    }

}