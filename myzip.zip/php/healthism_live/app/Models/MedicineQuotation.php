<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class MedicineQuotation extends Model {

    use HasFactory;

    protected $table = "medicine_quotation";
    public $timestamps = false;
    public $fillable = [
        "user_upload_id",
        "comment_json",
        "medicine_json",
        "created_by",
        "created_at"
    ];

    public function getCommentJsonAttribute($value) {
        if ($value != null) {
            return json_decode($value);
        }
        return NULL;
    }
    public function getMedicineJsonAttribute($value) {
        if ($value != null) {
            return json_decode($value);
        }
        return NULL;
    }

    public function createdBy() {
        return $this->belongsTo(User::class, 'created_by')->select(array('id', 'first_name', 'last_name', 'mobile'));
    }

}
