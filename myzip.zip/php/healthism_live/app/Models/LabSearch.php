<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class LabSearch extends Model {

    use HasFactory;

    protected $table = "lab_search";
    public $timestamps = false;
    public $fillable = [
        "lab_id",
        "lab_parent_id",
        "name",
        "city_id",
        "state_id",
        "pincode",
        "latitude",
        "longitude",
    ];

    public function lab() {
        return $this->hasOne(Lab::class, 'lab_id');
    }

    public function lab_branch() {
        return $this->hasOne(LabBranch::class, 'lab_brach_id');
    }

}
