<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class UserMedicalHistory extends Model {

    use HasFactory;

    protected $table = "user_medical_history";
    public $timestamps = false;
    public $fillable = [
        "user_id",
        "service_ref_id",
        "ref_id",
        "service_id",
        "uploaded_by",
        "status_id",
        "created_at",
    ];
    public static $rules = [
        "ref_id" => "Required",
        "service_id" => "Required",
        "user_id" => "Required",
    ];

    public function user() {
        return $this->belongsTo(User::class)->select(array('id', 'first_name', 'last_name', 'mobile'));
    }

    public function service() {
        return $this->belongsTo(Service::class);
    }

    public function status() {
        return $this->belongsTo(Status::class);
    }

    public function mapping() {
        return $this->hasMany(UserMedicalHistoryMapping::class, 'user_medical_history_id');
    }

    public function uploadedby() {
        return $this->belongsTo(User::class, 'uploaded_by')->select(array('id', 'first_name', 'last_name', 'mobile'));
    }

}
