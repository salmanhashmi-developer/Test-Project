<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class UserAddress extends Model {

    use HasFactory;

    protected $table = "user_address";
    public $fillable = [
        'user_id',
        'type',
        'address_1',
        'address_2',
        'pincode',
        'state_id',
        'state',
        'city_id',
        'city',
        'latitude',
        'longitude',
        'created_at',
    ];
    public static $rules = [
        "type" => "Required",
        "address_1" => "Required",
        "address_2" => "Required",
        "pincode" => "Required",
        "latitude" => "Required",
        "longitude" => "Required",
        "state" => "Required",
        "city" => "Required",
    ];

    public function state() {
        return $this->belongsTo(State::class);
    }

    public function city() {
        return $this->belongsTo(City::class);
    }

}
