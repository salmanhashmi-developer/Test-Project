<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class MenuBasedServiceBookingDetails extends Model {

    use HasFactory;

    protected $table = "menu_based_service_booking_details";
    public $fillable = [
        'menu_based_service_booking_id',
        'menu_based_service_id',
        'menu_based_service_parent_id',
        'menu_based_service_facility_id',
        'amount',
        'tax',
        'discount',
        'refund_amount',
        'status_id',
        'created_at',
        'updated_at',
    ];

    public function menuBasedServiceFacility() {
        return $this->belongsTo(MenuBasedServiceFacility::class);
    }

}
