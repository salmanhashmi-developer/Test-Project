<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class OrderHistories extends Model {

    use HasFactory;

    protected $table = "order_histories";
    public $timestamps = false;
    public $fillable = [
        'order_id',
        'order_detail_id',
        'type',
        'status_id',
        'remark',
        'created_at',
        'updated_at',
        'updated_by',
    ];
    public function user() {
        return $this->belongsTo(User::class,'updated_by');
    }
    public function status() {
        return $this->belongsTo(Status::class);
    }

}
