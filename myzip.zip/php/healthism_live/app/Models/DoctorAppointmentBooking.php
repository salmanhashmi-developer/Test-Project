<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class DoctorAppointmentBooking extends Model {

    use HasFactory;

    protected $table = "doctor_appointment_booking";
    public $timestamps = false;
    public $fillable = [
        'hospital_id',
        'doctor_id',
        'user_patient_id',
        'patient_name',
        'patient_mobile',
        'doctor_hospital_slot_id',
        'appointment_date',
        'appointment_time',
        'appointment_start',
        'appointment_end',
        'amount',
        'tax',
        'refund_amount',
        'discount',
        'created_by',
        'user_id',
        'is_video',
        'status_id',
        'created_at',
        'order_id',
        'user_subscription_id',
    ];

    public function hospital() {
        return $this->belongsTo(Hospital::class, 'hospital_id')->select(array('id', 'name', 'address1', 'address2', 'area', 'pincode', 'city_id', 'state_id', 'latitude', 'longitude', 'phone', 'cancellation_allowed', 'cancel_policy', 'cancel_policy_setting'));
    }

    public function doctor() {
        return $this->belongsTo(Doctor::class, 'doctor_id')->select(array('id', 'first_name', 'last_name', 'photo', 'specialization', 'phone', 'gender','user_id'));
    }

    public function user_patient() {
        return $this->belongsTo(UserPatientMapping::class, 'user_patient_id')->select(array('id', 'first_name', 'last_name', 'email', 'mobile', 'dob', 'blood_group'));
    }

    public function status() {
        return $this->belongsTo(Status::class);
    }

    public function user() {
        return $this->belongsTo(User::class, 'created_by')->select(array('id', 'first_name', 'last_name', 'mobile', 'email', 'photo'));
    }

    public function hospitalslot() {
        return $this->belongsTo(DoctorHospitalSlot::class, 'doctor_hospital_slot_id')->select(array('id', 'day', 'date', 'from_time', 'to_time', 'is_video', 'is_offline', 'status_id'));
    }

    public function order() {
        return $this->belongsTo(Orders::class, 'order_id')->select(array('*'));
    }

    public function user_subscription() {
        return $this->belongsTo(UserSubscription::class, 'user_subscription_id')->select(array('id', 'card_no'));
    }

}
