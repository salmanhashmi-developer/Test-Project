<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class Notification extends Model {

    use HasFactory;

    protected $table = 'notification';
    public $timestamps = false;
    public $fillable = [
        "title",
        "details",
        "image",
        "user_id",
        "extra_data",
        "notification_type",
        "platform_id",
        "app_id",
        "created_at",
        "response",
    ];

    public function readlog() {
        return $this->hasOne(NotificationReadLog::class, 'notification_id');
    }

}
