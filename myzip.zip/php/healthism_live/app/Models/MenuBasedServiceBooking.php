<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class MenuBasedServiceBooking extends Model {

    use HasFactory;

    protected $table = "menu_based_service_booking";
    public $timestamps = false;
    public $fillable = [
        'order_id',
        'user_id',
        'user_subscription_id',
        'menu_based_service_id',
        'menu_based_service_parent_id',
        'menu_based_service_category_id',
        'user_member_id',
        'member_name',
        'member_mobile',
        'menu_based_service_slot_id',
        'appointment_date',
        'appointment_time',
        'amount',
        'tax',
        'refund_amount',
        'discount',
        'status_id',
        'created_by',
        'created_at',
        'updated_at',
    ];

    public function menuBasedService() {
        return $this->belongsTo(MenuBasedService::class);
    }

    public function order() {
        return $this->belongsTo(Orders::class);
    }

    public function menuBasedServiceBookingDetails() {
        return $this->hasMany(MenuBasedServiceBookingDetails::class);
    }

    public function userMember() {
        return $this->belongsTo(UserPatientMapping::class, 'user_member_id')->select(array('id', 'first_name', 'last_name', 'email', 'mobile', 'dob', 'blood_group'));
    }

    public function status() {
        return $this->belongsTo(Status::class);
    }

    public function user() {
        return $this->belongsTo(User::class, 'created_by')->select(array('id', 'first_name', 'last_name', 'mobile', 'email', 'photo'));
    }

    public function getAddressAttribute($value) {
        if ($value != null) {
            return json_decode($value, true);
        }
        return NULL;
    }

    public function userSubscription() {
        return $this->belongsTo(UserSubscription::class, 'user_subscription_id')->select(array('id', 'card_no'));
    }

}
