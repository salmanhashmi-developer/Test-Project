<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class UserMedicalHistoryMapping extends Model {

    use HasFactory;

    protected $table = "user_medical_history_mapping";
    public $timestamps = false;
    public $fillable = [
        "user_medical_history_id",
        "original_file_name",
        "file",
        "medicine",
        "days",
        "qty",
        "frequency_json",
        "created_at"
    ];

    public function getFrequencyJsonAttribute($value) {
        return json_decode($value, true);
    }

}
