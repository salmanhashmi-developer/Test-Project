<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class MenuBasedServiceBlockSlot extends Model {

    use HasFactory;

    protected $table = "menu_based_service_block_slot";
    public $fillable = [
    ];

}
