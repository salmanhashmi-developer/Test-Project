<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class HealthTrack extends Model {

    use HasFactory;

    protected $table = "health_track";
    public $fillable = [
        'user_id',
        'step',
        'calories',
        'created_at'
    ];
    public static $rules = [
        "step" => "Required",
        "calories" => "Required",
    ];
    public function user() {
        return $this->belongsTo(User::class);
    }

}
