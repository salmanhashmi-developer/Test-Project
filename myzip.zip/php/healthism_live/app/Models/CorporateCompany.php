<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class CorporateCompany extends Model {

    use HasFactory;

    protected $table = "corporate_company";
    public $timestamps = false;
    public $fillable = [
        'name',
        'contact_no',
        'email_id',
        'no_of_employee',
        'contact_person_no',
        'contact_person',
        'cin',
        'gstno',
        'status_id',
        'created_at',
        'updated_at',
        'user_id',
        'ref_code',
    ];
    public static $rules = [
        "name" => "Required",
        "contact_no" => "Required",
        "contact_person_no" => "Required",
        "no_of_employee" => "Required",
        "email_id" => "Required|email",
        "contact_person" => "Required",
    ];

    public function status() {
        return $this->belongsTo(Status::class);
    }
    public function user() {
        return $this->belongsTo(User::class);
    }
}
