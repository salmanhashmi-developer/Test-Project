<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class State extends Model {

    use HasFactory;

    protected $table = 'state';
    public $timestamps = false;
    public $fillable = [
        'name',
        'active',
        'ref_id',
    ];

    public function cities() {
        return $this->hasMany(City::class,'state_id');
    }

}
