<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class AppDashboard extends Model {

    use HasFactory;

    protected $table = "app_dashboard";
    public $fillable = [
        'type',
        'name',
        'file',
        'file_type',
        'sort_order',
        'data_json',
        'created_at'
    ];

    public function getCreatedAtAttribute($date) {
        return date("Y-m-d H:i:s", strtotime($date));
    }

    public function getUpdatedAtAttribute($date) {
        return date("Y-m-d H:i:s", strtotime($date));
    }

    public function getDataJsonAttribute($value) {
        if ($value != null) {
            return json_decode($value, true);
        }
        return NULL;
    }

}
