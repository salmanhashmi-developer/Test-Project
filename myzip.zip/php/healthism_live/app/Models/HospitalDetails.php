<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class HospitalDetails extends Model
{
    use HasFactory;

    protected $table = "hospital_details";
    public $fillable = [
        'hospital_id',
        'gallery_json',
        'pancard_number',
        'pancard_document',
        'gst_number',
        'gst_certificate',
        'gst_certificate',
        'bank_account_name',
        'bank_name',
        'bank_ifsc_code'
    ];

    public function hospital()
    {
        return $this->belongsTo(Hospital::class);
    }
}
