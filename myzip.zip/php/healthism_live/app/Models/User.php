<?php

namespace App\Models;

// use Illuminate\Contracts\Auth\MustVerifyEmail;
use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Foundation\Auth\User as Authenticatable;
use Illuminate\Notifications\Notifiable;
use Laravel\Sanctum\HasApiTokens;

class User extends Authenticatable {

    use HasApiTokens,
        HasFactory,
        Notifiable;

    /**
     * The attributes that are mass assignable.
     *
     * @var array<int, string>
     */
    protected $table = "user";
    public $timestamps = false;
    public $fillable = [
        'first_name',
        'last_name',
        'email',
        'mobile',
        'dob',
        'blood_group',
        'gender',
        'photo',
        'user_type_id',
        'status_id',
        'ref_code',
        'created_at',
        'updated_at',
    ];
    public static $rules = [
        "first_name" => "Required",
        "last_name" => "Required",
        "mobile" => "Required|regex:/^([0-9]*)$/|min:10",
        "user_type_id" => "Required",
        "email" => "Required|email",
    ];

    public function userType() {
        return $this->belongsTo(UserType::class);
    }

    public function status() {
        return $this->belongsTo(Status::class);
    }

    public function lab() {
        return $this->hasOne(Lab::class, 'user_id', 'id')->whereNull('parent_id');
    }

    public function company() {
        return $this->hasOne(CorporateCompany::class, 'user_id', 'id');
    }

    public function detail() {
        return $this->hasOne(UserDetails::class, 'user_id', 'id');
    }

    public function getCompanyIdAttribute($value) {
        return $value;
    }

    public function userSubsciption()
    {
        return $this->hasOne(UserSubscription::class);
    }

}