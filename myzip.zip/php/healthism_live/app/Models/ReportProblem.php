<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class ReportProblem extends Model {

    use HasFactory;

    protected $table = "report_problem";
    public $fillable = [
        'user_id',
        'service_id',
        'ref_id',
        'description',
        'type',
        'status_id',
        'created_at',
    ];
    public static $rules = [
        "service_id" => "Required",
        "ref_id" => "Required",
        "description" => "Required",
        "type" => "Required",
    ];

    public function user() {
        return $this->belongsTo(User::class)->select(array('id', 'first_name', 'last_name', 'mobile'));
    }

    public function service() {
        return $this->belongsTo(Service::class);
    }

    public function status() {
        return $this->belongsTo(Status::class);
    }

}
