<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class DoctorHospitalSlot extends Model {

    use HasFactory;

    protected $table = "doctor_hospital_slot";
    public $fillable = [
        "doctor_id",
        "hospital_id",
        "day",
        "date",
        "from_time",
        "to_time",
        "is_video",
        "is_offline",
        "status_id",
        "created_at",
        "created_by",
        "updated_at",
        "updated_by",
    ];

    public function hospital() {
        return $this->belongsTo(Hospital::class, 'hospital_id')->select(array('id', 'name', 'area', 'status_id', 'cash_booking_allowed', 'cancel_policy'));
    }

    public function status() {
        return $this->belongsTo(Status::class);
    }

    public function doctor() {
        return $this->belongsTo(Doctor::class, 'doctor_id')->select(array('id', 'first_name', 'last_name', 'status_id', 'specialization'));
    }

}
