<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class UserPatientMapping extends Model {

    use HasFactory;

    protected $table = 'user_patient_mapping';
    public $fillable = [
        'user_id',
        'first_name',
        'last_name',
        'email',
        'mobile',
        'dob',
        'blood_group',
        'gender',
        'relation',
        'status_id',
        'created_at',
        'is_deleted',
        //'updated_at',
    ];
    public static $rules = [
        "first_name" => "Required",
        "last_name" => "Required",
        "mobile" => "Required|regex:/^([0-9]*)$/|min:10",
    ];

    public function user() {
        return $this->belongsTo(User::class);
    }

    public function status() {
        return $this->belongsTo(Status::class);
    }

}
