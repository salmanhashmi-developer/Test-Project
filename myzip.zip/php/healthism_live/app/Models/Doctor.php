<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class Doctor extends Model {

    use HasFactory;

    protected $table = "doctor";
    public $fillable = [
        'user_id',
        'first_name',
        'middle_name',
        'last_name',
        'phone',
        'email',
        'specialization',
        'sub_category_id',
        'short_desc',
        'photo',
        'gender',
        'experience',
        'status_id',
        'created_at',
        'code',
    ];
    public static $rules = [
        "first_name" => "Required",
        "last_name" => "Required",
        "middle_name" => "Required",
        "phone" => "Required",
        "email" => "Required",
        "specialization" => "Required",
        "sub_category_id" => "Required",
        "short_desc" => "Required",
        "gender" => "Required",
    ];

    public function status() {
        return $this->belongsTo(Status::class);
    }

    public function user() {
        return $this->belongsTo(User::class);
    }

    public function doctor_details() {
        return $this->hasOne(DoctorDetails::class);
    }

//    public function getPhotoAttribute($value) {
//        if ($value != NULL) {
//            return getUrl('image/doctor_profile') . $value;
//        }
//        return NULL;
//    }

}
