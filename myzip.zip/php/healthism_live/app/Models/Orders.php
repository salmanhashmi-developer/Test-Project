<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class Orders extends Model {

    use HasFactory;

    protected $table = "orders";
    public $timestamps = false;
    public $fillable = [
        'order_code',
        'user_id',
        'user_subscription_id',
        'service_id',
        'amount',
        'charges',
        'status_id',
        'remark',
        'remark_color_code',
        'description_json',
        'transaction_json',
        'created_at',
        'updated_at',
    ];

    public function detail() {
        return $this->hasMany(OrderDetail::class, 'order_id');
    }

    public function payment() {
        return $this->hasOne(OrderPayment::class, 'order_id');
    }

    public function charges() {
        return $this->hasMany(OrderCharges::class, 'order_id');
    }

    public function histories() {
        return $this->hasMany(OrderHistories::class, 'order_id');
    }

    public function status() {
        return $this->belongsTo(Status::class);
    }

    public function user() {
        return $this->belongsTo(User::class);
    }

    public function service() {
        return $this->belongsTo(Service::class);
    }

    public function subscription() {
        return $this->belongsTo(UserSubscription::class);
    }
}
