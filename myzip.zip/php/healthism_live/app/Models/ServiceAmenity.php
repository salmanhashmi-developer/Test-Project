<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class ServiceAmenity extends Model {

    use HasFactory;

    protected $table = "service_amenity";
    public $timestamps = false;
    public $fillable = [
    ];

    public function getImageAttribute($value) {
        if ($value != NULL) {
            return getUrl('image/service_animity') . $value;
        }
        return NULL;
    }

}
