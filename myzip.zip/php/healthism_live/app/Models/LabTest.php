<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class LabTest extends Model {

    use HasFactory;

    protected $table = "lab_test";
    public $fillable = [
        "test_master_id",
        "import_id",
        "lab_id",
        "lab_parent_id",
        "name",
        "test_count",
        "test_json",
        "description",
        "requirement",
        "preparation",
        "gender",
        "is_package",
        "package_category",
        "price",
        "discount",
        "home_collection",
        "e_report_hours",
        "sort_order",
        "status_id",
        "alias_name",
        "body_part",
        "disease_name",
    ];

    public function status() {
        return $this->belongsTo(Status::class);
    }

    public function lab() {
        return $this->belongsTo(Lab::class, 'lab_id')->select(array('*'));
    }

    public function labParent() {
        return $this->belongsTo(Lab::class, 'lab_parent_id')->select(array('*'));
    }

    public function getTestJsonAttribute($value) {
        if ($value != null) {
            return json_decode($value, true);
        }
        return NULL;
    }

}
