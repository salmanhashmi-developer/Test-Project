<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class MenuBasedServiceDetails extends Model {

    use HasFactory;

    protected $table = "menu_based_service_details";
    protected $primaryKey = 'menu_based_service_id';
    public $timestamps = false;
    public $fillable = [
        'menu_based_service_id',
        'description',
        'gallery_json',
        'timing_json',
        'pancard_number',
        'pancard_document',
        'gst_number',
        'gst_certificate',
        'bank_account_number',
        'bank_account_name',
        'bank_name',
        'bank_ifsc_code',
        'permissions_json',
    ];

    public function getGalleryJsonAttribute($value) {
        if ($value != null) {
            $result = [];
            foreach (json_decode($value, true) as $date) {
                $result[] = $date;
//                $result[] = getUrl('image/menu_base_service_gallery') . $date;
            }
            return $result;
        }
        return NULL;
    }

    public function getTimingJsonAttribute($value) {
        if ($value != null) {
            return json_decode($value, true);
        }
        return NULL;
    }

    public function getPancardDocumentAttribute($value) {
        if ($value != NULL) {
            return getUrl('image/menu_base_service/pan') . $value;
        }
        return NULL;
    }

    public function getGstCertificateAttribute($value) {
        if ($value != NULL) {
            return getUrl('image/menu_base_service/gst') . $value;
        }
        return NULL;
    }

}
