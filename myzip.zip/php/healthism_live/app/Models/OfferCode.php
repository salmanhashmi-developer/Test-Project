<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class OfferCode extends Model {

    use HasFactory;

    protected $table = "offer_code";
    public $timestamps = false;
    public $fillable = [
        'name',
        'offer_id',
        'status_id',
        'user_id',
        'expiration_time',
        'created_at',
        'updated_at',
        'voucher_code_id'
    ];

    public function offer() {
        return $this->belongsTo(Offer::class, 'offer_id');
    }

    public function offerCodeTrack() {
        return $this->hasOne(OfferCodeTrack::class);
    }

}
