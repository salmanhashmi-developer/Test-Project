<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class SmsLog extends Model {

    use HasFactory;

    protected $table = 'sms_log';
    public $timestamps = false;
    public $fillable = [
        'created_at',
        'sms_content',
        'gateway_id',
        'response',
        'mobile',
        'notification_template_id'
    ];

    public function notificationTemplate() {
        return $this->belongsTo(NotificationTemplate::class, "notification_template_id")->select(array('id', 'service_id', 'alert_type'));
    }
    public function geteay() {
        return $this->belongsTo(NotificationGateway::class, "gateway_id")->select(array('id', 'name'));
    }

}
