<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class UserDetails extends Model {

    use HasFactory;

    protected $table = "user_details";
    protected $primaryKey = 'user_id';
    public $timestamps = false;
    public $fillable = [
        'user_id',
        'company_id',
        'designation_id',
        'department_id',
        'branch_id',
    ];

    public function user() {
        return $this->belongsTo(User::class);
    }

    public function company() {
        return $this->belongsTo(CorporateCompany::class);
    }

    public function department() {
        return $this->belongsTo(Department::class);
    }

    public function designation() {
        return $this->belongsTo(Designation::class);
    }

    public function branch() {
        return $this->belongsTo(CorporateCompanyBranch::class);
    }

}
