<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class Hospital extends Model {

    use HasFactory;

    protected $table = "hospital";
    public $fillable = [
        'name',
        'phone',
        'address1',
        'address2',
        'area',
        'pincode',
        'city_id',
        'state_id',
        'latitude',
        'longitude',
        'cash_booking_allowed',
        'cancellation_allowed',
        'cancel_policy',
        'cancel_policy_setting',
        'type',
        'photo',
        'status_id',
    ];

    public function status() {
        return $this->belongsTo(Status::class);
    }

    public function hospital_details() {
        return $this->hasOne(HospitalDetails::class);
    }

    public function state() {
        return $this->belongsTo(State::class);
    }

    public function city() {
        return $this->belongsTo(City::class);
    }

}
