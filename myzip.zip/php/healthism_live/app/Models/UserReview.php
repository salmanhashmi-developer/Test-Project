<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class UserReview extends Model
{

    use HasFactory;

    protected $table = "review";
    public $fillable = [
        'ref_id',
        'service_id',
        'user_id',
        'title',
        'description',
        'rating',
        'reply',
        'replied_at',
        'status_id',
        'created_at',
        'updated_at',
    ];
    public static $rules = [
        "ref_id" => "Required",
        "service_id" => "Required",
        "title" => "Required",
        "description" => "Required",
        "rating" => "Required|in:1,2,3,4,5",
    ];

    public function user()
    {
        return $this->belongsTo(User::class)->select(array('id', 'first_name', 'last_name', 'mobile'));
    }

    public function service()
    {
        return $this->belongsTo(Service::class);
    }

    public function status()
    {
        return $this->belongsTo(Status::class);
    }
    
    protected function serializeDate(\DateTimeInterface $date)
    {
        return $date->format('Y-m-d H:i:s');
    }
}
