<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class LabDetails extends Model {

    use HasFactory;

    protected $table = "lab_details";
    protected $primaryKey = 'lab_id';
    public $timestamps = false;
    public $fillable = [
        "lab_id",
        "description",
        "gallery_json",
        "timing_json",
        "nabl_document",
        "mou_document",
        "pancard_number",
        "pancard_document",
        "gst_number",
        "gst_certificate",
        "bank_account_number",
        "bank_account_name",
        "bank_name",
        "bank_ifsc_code",
        "permissions_json",
    ];

    public function getGalleryJsonAttribute($value) {
        if ($value != null) {
            $result = [];
            foreach (json_decode($value, true) as $imageName) {
                $result[] = getUrl('image/lab/gallery') . $imageName;
            }
            return $result;
        }
        return NULL;
    }

    public function getTimingJsonAttribute($value) {
        if ($value != null) {
            return json_decode($value, true);
        }
        return NULL;
    }

    public function getNablDocumentAttribute($value) {
        if ($value != NULL) {
            return getUrl('image/lab/nabl') . $value;
        }
        return NULL;
    }

    public function getMouDocumentAttribute($value) {
        if ($value != NULL) {
            return getUrl('image/lab/mou') . $value;
        }
        return NULL;
    }

    public function getPancardDocumentAttribute($value) {
        if ($value != NULL) {
            return getUrl('image/lab/pan') . $value;
        }
        return NULL;
    }

    public function getGstCertificateAttribute($value) {
        if ($value != NULL) {
            return getUrl('image/lab/gst') . $value;
        }
        return NULL;
    }

}
