<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class DoctorHospitalBlockSlot extends Model {

    use HasFactory;

    protected $table = "doctor_hospital_block_slot";
    public $timestamps = false;
    public $fillable = [
        'doctor_id',
        'hospital_id',
        'date',
        'doctor_hospital_slot_id',
        'from_time',
        'to_time',
        'is_video',
        'is_offline',
        'created_at',
        'created_by',
    ];

}
