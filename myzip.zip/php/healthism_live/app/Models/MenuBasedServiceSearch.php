<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class MenuBasedServiceSearch extends Model {

    use HasFactory;

    protected $table = "menu_based_service_search";
    public $timestamps = false;
    public $fillable = [
        'menu_based_service_id',
        'menu_based_service_parent_id',
        'name',
        'city_id',
        'state_id',
        'pincode',
        'latitude',
        'longitude',
        'category_id',
    ];

    public function menuBasedService() {
        return $this->hasOne(MenuBasedService::class, 'menu_based_service_id');
    }

    public function menuBasedServiceParent() {
        return $this->hasOne(MenuBasedService::class, 'menu_based_service_parent_id');
    }

}
