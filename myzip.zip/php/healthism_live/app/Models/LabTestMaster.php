<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class LabTestMaster extends Model {

    use HasFactory;

    protected $table = "lab_test_master";
    public $fillable = [
        "name",
        "test_count",
        "test_json",
        "description",
        "requirement",
        "preparation",
        "gender",
        "is_package",
        "package_category",
        "status_id",
        "alias_name",
        "body_part",
        "disease_name",
    ];

    public function status() {
        return $this->belongsTo(Status::class);
    }

    public function getTestJsonAttribute($value) {
        if ($value != null) {
            return json_decode($value, true);
        }
        return NULL;
    }

}
