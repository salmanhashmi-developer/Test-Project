<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class LabBooking extends Model {

    use HasFactory;

    protected $table = "lab_booking";
    public $timestamps = false;
    public $fillable = [
        'order_id',
        'user_id',
        'user_subscription_id',
        'lab_id',
        'lab_parent_id',
        'user_patient_id',
        'patient_name',
        'patient_mobile',
        'lab_slot_id',
        'appointment_date',
        'appointment_time',
        'amount',
        'tax',
        'refund_amount',
        'discount',
        'created_by',
        'is_home_collection',
        'status_id',
        'created_at',
        'updated_at',
        'address',
    ];

    public function lab() {
        return $this->belongsTo(Lab::class);
    }
    public function order() {
        return $this->belongsTo(Orders::class);
    }

    public function labBookingDetail() {
        return $this->hasMany(LabBookingDetail::class);
    }

    public function user_patient() {
        return $this->belongsTo(UserPatientMapping::class, 'user_patient_id')->select(array('id', 'first_name', 'last_name', 'email', 'mobile', 'dob', 'blood_group'));
    }

    public function status() {
        return $this->belongsTo(Status::class);
    }

    public function user() {
        return $this->belongsTo(User::class, 'created_by')->select(array('id', 'first_name', 'last_name', 'mobile', 'email', 'photo'));
    }

    public function getAddressAttribute($value) {
        if ($value != null) {
            return json_decode($value, true);
        }
        return NULL;
    }

    public function user_subscription() {
        return $this->belongsTo(UserSubscription::class, 'user_subscription_id')->select(array('id', 'card_no'));
    }

}
