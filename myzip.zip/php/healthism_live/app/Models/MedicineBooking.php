<?php

namespace App\Models;

use Illuminate\Support\Facades\DB;
use App\Models\MedicineBookingDetail;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Factories\HasFactory;

class MedicineBooking extends Model {

    use HasFactory;

    protected $table = "user_medical_history";
    public $timestamps = false;
    public $fillable = [
        'user_id',
        'service_ref_id',
        'ref_id',
        'service_id',
        'updated_by',
        'created_at',
        'status_id',
    ];

    public function bookingDetail()
    {
        return $this->hasMany(MedicineBookingDetail::class,'user_medical_history_id','id');
    }

    public function status() {
        return $this->belongsTo(Status::class);
    }

    public function user() {
        return $this->belongsTo(User::class, 'id')->select(array('id', 'first_name', 'last_name', 'mobile', 'email', 'photo','user_type_id','status_id'));
    }

    public function getAddressAttribute($value) {
        if ($value != null) {
            return json_decode($value, true);
        }
        return NULL;
    }

    // public function user_subscription() {
    //     return $this->belongsTo(UserSubscription::class, 'user_subscription_id')->select(array('id', 'card_no'));
    // }

}