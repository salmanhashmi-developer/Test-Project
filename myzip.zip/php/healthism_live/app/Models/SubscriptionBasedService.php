<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class SubscriptionBasedService extends Model {

    use HasFactory;

    protected $table = "subscription_based_service";
    public $fillable = [
        'user_id',
        'parent_id',
        'category_id',
        'contact_person',
        'name',
        'phone',
        'mobile',
        'email',
        'address1',
        'address2',
        'area',
        'pincode',
        'city_id',
        'state_id',
        'latitude',
        'longitude',
        'photo',
        'discount',
        'self_facility_available',
        'cash_booking_allowed',
        'cancellation_allowed',
        'cancel_policy',
        'cancel_policy_setting',
        'sub_category_ids',
        'amenity_ids',
        'free_trial',
        'gender',
        'status_id',
        'created_at',
        'updated_at',
    ];

    public function status() {
        return $this->belongsTo(Status::class);
    }

    public function user() {
        return $this->belongsTo(User::class);
    }

    public function category() {
        return $this->belongsTo(Category::class);
    }

    public function subscriptionBasedServiceDetails() {
        return $this->hasOne(SubscriptionBasedServiceDetails::class);
    }

    public function subscriptionBasedServiceFacility() {
        return $this->hasMany(SubscriptionBasedServiceFacility::class);
    }

    public function state() {
        return $this->belongsTo(State::class);
    }

    public function city() {
        return $this->belongsTo(City::class);
    }

    public function getPhotoAttribute($value) {
        if ($value != NULL) {
            return getUrl('image/subscription_base_service') . $value;
        }
        return NULL;
    }

    public function getSubCategoryIdsAttribute($value) {
        if ($value != NULL) {
            $ids = explode(',', $value);
            if (!empty($ids)) {
                return Category::whereIn('id', $ids)->get();
            }
        }
        return NULL;
    }

    public function getAmenityIdsAttribute($value) {
        if ($value != NULL) {
            $ids = explode(',', $value);
            if (!empty($ids)) {
                return ServiceAmenity::whereIn('id', $ids)->get();
            }
        }
        return NULL;
    }

    public function getCancelPolicyAttribute($value) {
        if ($value != null) {
            return json_decode($value, true);
        }
        return NULL;
    }

    public function getCancelPolicySettingAttribute($value) {
        if ($value != null) {
            return json_decode($value, true);
        }
        return NULL;
    }

}
