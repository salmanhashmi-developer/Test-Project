<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class OrderDetail extends Model {

    use HasFactory;

    protected $table = "order_details";
    public $timestamps = false;
    public $fillable = [
        "order_id",
        "service_id",
        "ref_id",
        "coupon_id",
        "coupon_amount",
        "wallet_amount",
        "pg_amount",
        "paid_amount",
        "refund_amount",
        "cancellation_charge",
        "tax",
        "charges",
        "status_id",
        "tracking_status_id",
        "remark",
        "remark_color_code",
        "histories_json",
        "tracking_json",
        "created_at",
        "updated_at",
    ];
    public function service() {
        return $this->belongsTo(Service::class,'service_id');
    }
    public function status() {
        return $this->belongsTo(Status::class,'status_id');
    }
    public function user() {
        return $this->belongsTo(User::class, 'ref_id');
    }

}
