<?php

namespace App\Observers;

use App\Models\UserAddress;

class UserAddressObserver
{
    /**
     * Handle the UserAddress "created" event.
     *
     * @param  \App\Models\UserAddress  $userAddress
     * @return void
     */
    public function created(UserAddress $userAddress)
    {
        //
    }

    /**
     * Handle the UserAddress "updated" event.
     *
     * @param  \App\Models\UserAddress  $userAddress
     * @return void
     */
    public function updated(UserAddress $userAddress)
    {
        //
    }

    /**
     * Handle the UserAddress "deleted" event.
     *
     * @param  \App\Models\UserAddress  $userAddress
     * @return void
     */
    public function deleted(UserAddress $userAddress)
    {
        //
    }

    /**
     * Handle the UserAddress "restored" event.
     *
     * @param  \App\Models\UserAddress  $userAddress
     * @return void
     */
    public function restored(UserAddress $userAddress)
    {
        //
    }

    /**
     * Handle the UserAddress "force deleted" event.
     *
     * @param  \App\Models\UserAddress  $userAddress
     * @return void
     */
    public function forceDeleted(UserAddress $userAddress)
    {
        //
    }
}
