<?php

namespace App\Observers;

use App\Models\HospitalMapping;

class HospitalObserver
{
    /**
     * Handle the HospitalMapping "created" event.
     *
     * @param  \App\Models\HospitalMapping  $hospitalMapping
     * @return void
     */
    public function created(HospitalMapping $hospitalMapping)
    {
        //
    }

    /**
     * Handle the HospitalMapping "updated" event.
     *
     * @param  \App\Models\HospitalMapping  $hospitalMapping
     * @return void
     */
    public function updated(HospitalMapping $hospitalMapping)
    {
        //
    }

    /**
     * Handle the HospitalMapping "deleted" event.
     *
     * @param  \App\Models\HospitalMapping  $hospitalMapping
     * @return void
     */
    public function deleted(HospitalMapping $hospitalMapping)
    {
        //
    }

    /**
     * Handle the HospitalMapping "restored" event.
     *
     * @param  \App\Models\HospitalMapping  $hospitalMapping
     * @return void
     */
    public function restored(HospitalMapping $hospitalMapping)
    {
        //
    }

    /**
     * Handle the HospitalMapping "force deleted" event.
     *
     * @param  \App\Models\HospitalMapping  $hospitalMapping
     * @return void
     */
    public function forceDeleted(HospitalMapping $hospitalMapping)
    {
        //
    }
}
