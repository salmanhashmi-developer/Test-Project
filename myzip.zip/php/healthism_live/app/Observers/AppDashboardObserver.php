<?php

namespace App\Observers;

use App\Models\AppDashboard;

class AppDashboardObserver
{
    /**
     * Handle the AppDashboard "created" event.
     *
     * @param  \App\Models\AppDashboard  $appDashboard
     * @return void
     */
    public function created(AppDashboard $appDashboard)
    {
        //
    }

    /**
     * Handle the AppDashboard "updated" event.
     *
     * @param  \App\Models\AppDashboard  $appDashboard
     * @return void
     */
    public function updated(AppDashboard $appDashboard)
    {
        //
    }

    /**
     * Handle the AppDashboard "deleted" event.
     *
     * @param  \App\Models\AppDashboard  $appDashboard
     * @return void
     */
    public function deleted(AppDashboard $appDashboard)
    {
        //
    }

    /**
     * Handle the AppDashboard "restored" event.
     *
     * @param  \App\Models\AppDashboard  $appDashboard
     * @return void
     */
    public function restored(AppDashboard $appDashboard)
    {
        //
    }

    /**
     * Handle the AppDashboard "force deleted" event.
     *
     * @param  \App\Models\AppDashboard  $appDashboard
     * @return void
     */
    public function forceDeleted(AppDashboard $appDashboard)
    {
        //
    }
}
