<?php

namespace App\Observers;

use App\Models\UserPatientMapping;

class UserPatientMappingObserver
{
    /**
     * Handle the UserPatientMapping "created" event.
     *
     * @param  \App\Models\UserPatientMapping  $userPatientMapping
     * @return void
     */
    public function created(UserPatientMapping $userPatientMapping)
    {
        //
    }

    /**
     * Handle the UserPatientMapping "updated" event.
     *
     * @param  \App\Models\UserPatientMapping  $userPatientMapping
     * @return void
     */
    public function updated(UserPatientMapping $userPatientMapping)
    {
        //
    }

    /**
     * Handle the UserPatientMapping "deleted" event.
     *
     * @param  \App\Models\UserPatientMapping  $userPatientMapping
     * @return void
     */
    public function deleted(UserPatientMapping $userPatientMapping)
    {
        //
    }

    /**
     * Handle the UserPatientMapping "restored" event.
     *
     * @param  \App\Models\UserPatientMapping  $userPatientMapping
     * @return void
     */
    public function restored(UserPatientMapping $userPatientMapping)
    {
        //
    }

    /**
     * Handle the UserPatientMapping "force deleted" event.
     *
     * @param  \App\Models\UserPatientMapping  $userPatientMapping
     * @return void
     */
    public function forceDeleted(UserPatientMapping $userPatientMapping)
    {
        //
    }
}
