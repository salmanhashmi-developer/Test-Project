<?php

namespace App\Observers;

use App\Models\UserStatusLogMapping;

class UserStatusLogObserver
{
    /**
     * Handle the UserStatusLogMapping "created" event.
     *
     * @param  \App\Models\UserStatusLogMapping  $userStatusLogMapping
     * @return void
     */
    public function created(UserStatusLogMapping $userStatusLogMapping)
    {
        //
    }

    /**
     * Handle the UserStatusLogMapping "updated" event.
     *
     * @param  \App\Models\UserStatusLogMapping  $userStatusLogMapping
     * @return void
     */
    public function updated(UserStatusLogMapping $userStatusLogMapping)
    {
        //
    }

    /**
     * Handle the UserStatusLogMapping "deleted" event.
     *
     * @param  \App\Models\UserStatusLogMapping  $userStatusLogMapping
     * @return void
     */
    public function deleted(UserStatusLogMapping $userStatusLogMapping)
    {
        //
    }

    /**
     * Handle the UserStatusLogMapping "restored" event.
     *
     * @param  \App\Models\UserStatusLogMapping  $userStatusLogMapping
     * @return void
     */
    public function restored(UserStatusLogMapping $userStatusLogMapping)
    {
        //
    }

    /**
     * Handle the UserStatusLogMapping "force deleted" event.
     *
     * @param  \App\Models\UserStatusLogMapping  $userStatusLogMapping
     * @return void
     */
    public function forceDeleted(UserStatusLogMapping $userStatusLogMapping)
    {
        //
    }
}
