<?php

namespace App\Observers;

use App\Models\ApplicationConstant;

class ApplicationConstantObserver
{
    /**
     * Handle the ApplicationConstant "created" event.
     *
     * @param  \App\Models\ApplicationConstant  $applicationConstant
     * @return void
     */
    public function created(ApplicationConstant $applicationConstant)
    {
        //
    }

    /**
     * Handle the ApplicationConstant "updated" event.
     *
     * @param  \App\Models\ApplicationConstant  $applicationConstant
     * @return void
     */
    public function updated(ApplicationConstant $applicationConstant)
    {
        //
    }

    /**
     * Handle the ApplicationConstant "deleted" event.
     *
     * @param  \App\Models\ApplicationConstant  $applicationConstant
     * @return void
     */
    public function deleted(ApplicationConstant $applicationConstant)
    {
        //
    }

    /**
     * Handle the ApplicationConstant "restored" event.
     *
     * @param  \App\Models\ApplicationConstant  $applicationConstant
     * @return void
     */
    public function restored(ApplicationConstant $applicationConstant)
    {
        //
    }

    /**
     * Handle the ApplicationConstant "force deleted" event.
     *
     * @param  \App\Models\ApplicationConstant  $applicationConstant
     * @return void
     */
    public function forceDeleted(ApplicationConstant $applicationConstant)
    {
        //
    }
}
