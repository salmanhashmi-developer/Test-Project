<?php

namespace App\Observers;

use App\Models\DoctorMapping;

class DoctorObserver
{
    /**
     * Handle the DoctorMapping "created" event.
     *
     * @param  \App\Models\DoctorMapping  $doctorMapping
     * @return void
     */
    public function created(DoctorMapping $doctorMapping)
    {
        //
    }

    /**
     * Handle the DoctorMapping "updated" event.
     *
     * @param  \App\Models\DoctorMapping  $doctorMapping
     * @return void
     */
    public function updated(DoctorMapping $doctorMapping)
    {
        //
    }

    /**
     * Handle the DoctorMapping "deleted" event.
     *
     * @param  \App\Models\DoctorMapping  $doctorMapping
     * @return void
     */
    public function deleted(DoctorMapping $doctorMapping)
    {
        //
    }

    /**
     * Handle the DoctorMapping "restored" event.
     *
     * @param  \App\Models\DoctorMapping  $doctorMapping
     * @return void
     */
    public function restored(DoctorMapping $doctorMapping)
    {
        //
    }

    /**
     * Handle the DoctorMapping "force deleted" event.
     *
     * @param  \App\Models\DoctorMapping  $doctorMapping
     * @return void
     */
    public function forceDeleted(DoctorMapping $doctorMapping)
    {
        //
    }
}
