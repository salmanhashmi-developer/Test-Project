<?php

namespace App\Http\Middleware;

use Closure;
use Auth;
use User;

class IsPharmacy {

    /**
     * Handle an incoming request.
     *
     * @param \Illuminate\Http\Request $request
     * @param \Closure $next
     * @return mixed
     */
    public function handle($request, Closure $next) {
        if (Auth::user()->user_type_id == PHARMACY_USER) {
            return $next($request);
        } else {
            if (!empty(Auth::user()->user_type_id)) {
                return redirectRoutePath(Auth::user()->user_type_id);
            } else {
                abort(404);
            }
        }
    }

}
