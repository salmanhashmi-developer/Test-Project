<?php

namespace App\Http\Middleware;

use Illuminate\Auth\Middleware\Authenticate as Middleware;

class Authenticate extends Middleware {

    /**
     * Get the path the user should be redirected to when they are not authenticated.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return string|null
     */
    protected function redirectTo($request) {
        if ($request->type == 'admin') {
            if (!$request->expectsJson()) {
                return route('admin.login');
            }
        } elseif ($request->type == 'lab') {
            if (!$request->expectsJson()) {
                return route('lab.login');
            }
        } elseif ($request->type == 'mbs') {
            if (!$request->expectsJson()) {
                return route('mbs.login');
            }
        } elseif ($request->type == 'sbs') {
            if (!$request->expectsJson()) {
                return route('sbs.login');
            }
        } elseif ($request->type == 'corporate') {
            if (!$request->expectsJson()) {
                return route('corporate.login');
            }
        } elseif ($request->type == 'pharmacy') {
            if (!$request->expectsJson()) {
                return route('pharmacy.login');
            }
        } else {
            return view('welcome');
        }
    }

}
