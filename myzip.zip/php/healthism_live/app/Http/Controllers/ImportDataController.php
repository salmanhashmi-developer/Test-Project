<?php

namespace App\Http\Controllers;

use App\Imports\CommonImport;
use App\Models\CommonService;
use App\Models\CommonServiceDetails;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use Intervention\Image\ImageManagerStatic as Image;
use Excel;

class ImportDataController extends Controller {

    public function importCommanServiceImage(Request $request) {
        $input = $request->all();
        $images = array();
        if ($files = $request->file('images')) {
            foreach ($files as $file) {
                $image = $file;
                $imageName = pathinfo($image->getClientOriginalName(), PATHINFO_FILENAME) . '.' . $image->extension();
                $image_resize = Image::make($image->getRealPath());
                $image_resize->resize(800, null, function ($constraint) {
                    $constraint->aspectRatio();
                });
                $image_resize->save(public_path('image/common_service/' . $imageName));
            }
        }
        return redirect()->route('admin.common.service.bulk.insert')->with('success', 'Image import Successfully!');
    }

    public function importCommanServiceExcel(Request $request) {
        if (empty($request->file)) {
            return view('backend.common_service.import');
        }
        //$path = $request->file('file')->getRealPath();
        $file = $request->file('file');
        $data = Excel::toArray(new CommonImport, $file);
        if (!empty($data[0])) {
            $errorResult = [];
            foreach ($data[0] as $value) {
                $stateList = \App\Models\State::all()->toArray();
                $cityList = \App\Models\City::all()->toArray();
                $query = "SELECT id,`name` FROM `category` WHERE id IN (SELECT category_id FROM common_service_mapping ) ";
                $categoryList = executeSelectQueryOnMySQLDB($query);
                if (!empty($value)) {
                    $validation = $this->checkCommonServiceValidation($value, $stateList, $cityList, $categoryList);
                    if (!empty($validation)) {
                        $errorResult[] = array('import_data_id' => $value['import_data_id'], 'error' => $validation);
                    }
                }
            }
            if (!empty($errorResult)) {
                return view('backend.common_service.import', compact('errorResult'));
            } else {
                $this->importCommanServiceData($data[0], $stateList, $cityList, $categoryList);
                return redirect()->route('admin.common.service')->with('success', 'Data import Successfully!');
            }
        }
    }

    public function importCommanServiceData($data, $stateList, $cityList, $categoryList) {
        foreach ($data as $key => $value) {
            $checkData = CommonService::where('import_data_id', $value['import_data_id'])->count();
            if (empty($checkData)) {
                $cityIndex = array_search($value['city'], array_column($cityList, 'name'));
                $stateIndex = array_search($value['state'], array_column($stateList, 'name'));
                $categoryIndex = array_search($value['category'], array_column($categoryList, 'name'));
                $commonService = new CommonService;
                $commonService->import_data_id = $value['import_data_id'];
                $commonService->name = $value['name'];
                $commonService->phone = $value['phone'];
                $commonService->mobile = $value['mobile'];
                $commonService->email = $value['email'];
                $commonService->address1 = $value['address1'];
                $commonService->address2 = $value['address2'];
                $commonService->area = $value['area'];
                $commonService->pincode = $value['pincode'];
                $commonService->city_id = $cityList[$cityIndex]['id'];
                $commonService->state_id = $cityList[$stateIndex]['id'];
                $commonService->latitude = $value['latitude'];
                $commonService->longitude = $value['longitude'];
                $commonService->discount = !empty($value['discount']) ? $value['discount'] : null;
                $commonService->virtual_location = !empty($value['virtual_location']) ? $value['virtual_location'] : null;
                $commonService->category_id = $categoryList[$categoryIndex]['id'];
                $commonService->photo = $value['photo'];
                $commonService->status_id = STATUS_ACTIVE;
                $commonService->created_at = date('Y-m-d H:i:s');
                $commonService->save();
                if (!empty($commonService->id)) {
                    $commonServiceDetails = new CommonServiceDetails;
                    $commonServiceDetails->common_service_id = $commonService->id;
                    $commonServiceDetails->description = $value['description'];
                    $commonServiceDetails->pancard_number = $value['pancard_number'];
                    $commonServiceDetails->gst_number = $value['gst_number'];
                    $commonServiceDetails->bank_account_number = $value['bank_account_number'];
                    $commonServiceDetails->bank_account_name = $value['bank_account_name'];
                    $commonServiceDetails->bank_name = $value['bank_name'];
                    $commonServiceDetails->bank_ifsc_code = $value['bank_ifsc_code'];
                    $commonServiceDetails->save();

                    \App\Models\CommonServiceSearch::where('common_service_id', $commonService->id)->delete();
                    $searchData = array(
                        'common_service_id' => $commonService->id,
                        'category_id' => $commonService->category_id,
                        'name' => $commonService->name,
                        'city_id' => $commonService->city_id,
                        'state_id' => $commonService->state_id,
                        'pincode' => $commonService->pincode,
                        'latitude' => $commonService->latitude,
                        'longitude' => $commonService->longitude
                    );
                    \App\Models\CommonServiceSearch::insert($searchData);
                }
            }
        }
    }

    public function checkCommonServiceValidation($value, $stateList, $cityList, $categoryList) {
        $error = '';
        if (empty($value['import_data_id'])) {
            $error .= "import_data_id is empty - ";
        }
        if (empty($value['name'])) {
            $error .= "name is empty - ";
        }
        if (empty($value['address1'])) {
            $error .= "address1 is empty - ";
        }
        if (empty($value['address2'])) {
            $error .= "address2 is empty - ";
        }
        if (empty($value['area'])) {
            $error .= "area is empty - ";
        }
        if (empty($value['pincode'])) {
            $error .= "pincode is empty - ";
        } else {
            if (strlen($value['pincode']) != 6) {
                $error .= "pincode Invalid : " . $value['pincode'] . " - ";
            }
        }
        $errorMap = 0;
        if (empty($value['latitude'])) {
            $error .= "latitude is empty - ";
            $errorMap = 1;
        }
        if (empty($value['longitude'])) {
            $error .= "longitude is empty - ";
            $errorMap = 1;
        }
        if ($errorMap == 0) {
            $validateLatLong = validateLatLong($value['latitude'], $value['longitude']);
            if (empty($validateLatLong)) {
                $error .= "invalid " . $value['latitude'] . " latitud and " . $value['longitude'] . " longitude - ";
            }
        }
        if (empty($value['description'])) {
            $error .= "description is empty - ";
        }
        if (empty($value['city'])) {
            $error .= "city is empty - ";
        } else {
            if (array_search($value['city'], array_column($cityList, 'name')) === FALSE) {
                $error .= $value['city'] . " city not found - ";
            }
        }
        if (empty($value['state'])) {
            $error .= "state is empty - ";
        } else {
            if (array_search($value['state'], array_column($stateList, 'name')) === FALSE) {
                $error .= $value['state'] . " state not found - ";
            }
        }
        if (empty($value['category'])) {
            $error .= "category is empty - ";
        } else {
            if (array_search($value['category'], array_column($categoryList, 'name')) === FALSE) {
                $error .= $value['category'] . " category not found - ";
            }
        }
        return $error;
    }

    public function importCommanServiceLocation(Request $request) {
        if (empty($request->file)) {
            return view('backend.common_service.location');
        }
        $file = $request->file('file');
        $data = Excel::toArray(new CommonImport, $file);
        if (!empty($data[0])) {
            $errorResult = [];
            foreach ($data[0] as $value) {
                if (!empty($value)) {
                    $validation = $this->checkLocationValidation($value);
                    if (!empty($validation)) {
                        $errorResult[] = array('import_data_id' => $value['import_data_id'], 'error' => $validation);
                    }
                }
            }
            if (!empty($errorResult)) {
                $commonService = CommonService::findOrFail($request->common_service_id);
                return view('backend.common_service.location', compact('errorResult', 'commonService'));
            } else {
                $this->importLocationData($data[0], $request->all());
                return redirect()->route('admin.common.service.location', $request->common_service_id)->with('success', 'Data import Successfully!');
            }
        }
    }

    public function importLocationData($data, $input) {
        foreach ($data as $key => $value) {
            $searchData = array(
                'common_service_id' => $input['common_service_id'],
                'category_id' => $input['category_id'],
                'name' => $input['name'],
                'pincode' => $value['pincode'],
                'latitude' => $value['latitude'],
                'longitude' => $value['longitude']
            );
            $result = \App\Models\CommonServiceSearch::firstOrCreate(
                            [
                        'pincode' => $value['pincode'],
                        'latitude' => $value['latitude'],
                        'longitude' => $value['longitude'],
                        'common_service_id' => $input['common_service_id']
                            ], $searchData);
        }
    }

    public function importLabLocation(Request $request) {
        if (empty($request->file)) {
            if (Auth::user()->user_type_id == LAB) {
                return redirect()->route('lab.location', $request->lab_id)->with('error', 'Please, Select file');
            }
            return redirect()->route('admin.lab.location', $request->lab_id)->with('error', 'Please, Select file');
        }
        $file = $request->file('file');
        $data = Excel::toArray(new CommonImport, $file);
        if (!empty($data[0])) {
            $errorResult = [];
            foreach ($data[0] as $value) {
                if (!empty($value)) {
                    $validation = $this->checkLocationValidation($value);
                    if (!empty($validation)) {
                        $errorResult[] = array('import_data_id' => $value['import_data_id'], 'error' => $validation);
                    }
                }
            }
            if (!empty($errorResult)) {
                $lab = \App\Models\Lab::findOrFail($request->lab_id);
                if (Auth::user()->user_type_id == LAB) {
                    return view('backend.lab_partner.branch.location', compact('errorResult', 'lab'));
                } else {
                    return view('backend.lab.location', compact('errorResult', 'lab'));
                }
            } else {
                $this->importLabLocationData($data[0], $request->all());
                if (Auth::user()->user_type_id == LAB) {
                    return redirect()->route('lab.location', $request->lab_id)->with('success', 'Data import Successfully!');
                }
                return redirect()->route('admin.lab.location', $request->lab_id)->with('success', 'Data import Successfully!');
            }
        }
    }

    public function importLabLocationData($data, $input) {
        foreach ($data as $key => $value) {
            $searchData = array(
                'lab_id' => $input['lab_id'],
                'lab_parent_id' => $input['lab_parent_id'],
                'name' => $input['name'],
                'pincode' => $value['pincode'],
                'latitude' => $value['latitude'],
                'longitude' => $value['longitude']
            );
            $result = \App\Models\LabSearch::firstOrCreate(
                            [
                        'pincode' => $value['pincode'],
                        'latitude' => $value['latitude'],
                        'longitude' => $value['longitude'],
                        'lab_id' => $input['lab_id']
                            ], $input);
        }
    }

    public function importMenubasedServiceLocation(Request $request) {
        if (empty($request->file)) {
            if (Auth::user()->user_type_id == MBS_USER) {
                return redirect()->route('mbs.location', $request->menu_based_service_id)->with('error', 'Please, Select file');
            }
            return redirect()->route('admin.menu_based_service.location', $request->menu_based_service_id)->with('error', 'Please, Select file');
        }
        $file = $request->file('file');
        $data = Excel::toArray(new CommonImport, $file);
        if (!empty($data[0])) {
            $errorResult = [];
            foreach ($data[0] as $value) {
                if (!empty($value)) {
                    $validation = $this->checkLocationValidation($value);
                    if (!empty($validation)) {
                        $errorResult[] = array('import_data_id' => $value['import_data_id'], 'error' => $validation);
                    }
                }
            }
            if (!empty($errorResult)) {
                $mbs = \App\Models\MenuBasedService::findOrFail($request->menu_based_service_id);
                if (Auth::user()->user_type_id == MBS_USER) {
                    return view('backend.menu_based_service_partner.branch.location', compact('errorResult', 'mbs'));
                } else {
                    return view('backend.menu_based_service.location', compact('errorResult', 'mbs'));
                }
            } else {
                $this->addMenubasedServiceLocationData($data[0], $request->all());
                if (Auth::user()->user_type_id == MBS_USER) {
                    return redirect()->route('mbs.location', $request->menu_based_service_id)->with('success', 'Data import Successfully!');
                }
                return redirect()->route('admin.menu_based_service.location', $request->menu_based_service_id)->with('success', 'Data import Successfully!');
            }
        }
    }

    public function addMenubasedServiceLocationData($data, $input) {
        foreach ($data as $key => $value) {
            $searchData = array(
                'menu_based_service_id' => $input['menu_based_service_id'],
                'menu_based_service_parent_id' => $input['menu_based_service_parent_id'],
                'category_id' => $input['category_id'],
                'name' => $input['name'],
                'pincode' => $value['pincode'],
                'latitude' => $value['latitude'],
                'longitude' => $value['longitude']
            );
            $result = \App\Models\MenuBasedServiceSearch::firstOrCreate(
                            [
                        'pincode' => $value['pincode'],
                        'latitude' => $value['latitude'],
                        'longitude' => $value['longitude'],
                        'menu_based_service_id' => $input['menu_based_service_id']
                            ], $input);
        }
    }

    public function checkLocationValidation($value) {
        $error = '';
        if (empty($value['pincode'])) {
            $error .= "pincode is empty - ";
        } else {
            if (strlen($value['pincode']) != 6) {
                $error .= "pincode Invalid : " . $value['pincode'] . " - ";
            }
        }
        $errorMap = 0;
        if (!empty($value['latitude']) || !empty($value['longitude'])) {
            if (empty($value['latitude'])) {
                $error .= "latitude is empty - ";
                $errorMap = 1;
            }
            if (empty($value['longitude'])) {
                $error .= "longitude is empty - ";
                $errorMap = 1;
            }
            if ($errorMap == 0) {
                $validateLatLong = validateLatLong($value['latitude'], $value['longitude']);
                if (empty($validateLatLong)) {
                    $error .= "invalid " . $value['latitude'] . " latitude and " . $value['longitude'] . " longitude - ";
                }
            }
        }
        return $error;
    }

    public function importSubscriptionbasedServiceLocation(Request $request) {
        if (empty($request->file)) {
            if (Auth::user()->user_type_id == SBS_USER) {
                return redirect()->route('sbs.location', $request->subscription_based_service_id)->with('error', 'Please, Select file');
            }
            return redirect()->route('admin.subscription_based_service.location', $request->subscription_based_service_id)->with('error', 'Please, Select file');
        }
        $file = $request->file('file');
        $data = Excel::toArray(new CommonImport, $file);
        if (!empty($data[0])) {
            $errorResult = [];
            foreach ($data[0] as $value) {
                if (!empty($value)) {
                    $validation = $this->checkLocationValidation($value);
                    if (!empty($validation)) {
                        $errorResult[] = array('import_data_id' => $value['import_data_id'], 'error' => $validation);
                    }
                }
            }
            if (!empty($errorResult)) {
                $mbs = \App\Models\SubscriptionBasedService::findOrFail($request->subscription_based_service_id);
                if (Auth::user()->user_type_id == SBS_USER) {
                    return view('backend.subscription_based_service_partner.branch.location', compact('errorResult', 'mbs'));
                } else {

                    return view('backend.subscription_based_service.location', compact('errorResult', 'mbs'));
                }
            } else {
                $this->addSubsciptionbasedServiceLocationData($data[0], $request->all());
                if (Auth::user()->user_type_id == SBS_USER) {
                    return redirect()->route('sbs.location', $request->subscription_based_service_id)->with('success', 'Data import Successfully!');
                }
                return redirect()->route('admin.subscription_based_service.location', $request->subscription_based_service_id)->with('success', 'Data import Successfully!');
            }
        }
    }

    public function addSubsciptionbasedServiceLocationData($data, $input) {
        foreach ($data as $key => $value) {
            $searchData = array(
                'subscription_based_service_id' => $input['subscription_based_service_id'],
                'subscription_based_service_parent_id' => $input['subscription_based_service_parent_id'],
                'category_id' => $input['category_id'],
                'name' => $input['name'],
                'pincode' => $value['pincode'],
                'latitude' => $value['latitude'],
                'longitude' => $value['longitude']
            );
            $result = \App\Models\SubscriptionBasedServiceSearch::firstOrCreate(
                            [
                        'pincode' => $value['pincode'],
                        'latitude' => $value['latitude'],
                        'longitude' => $value['longitude'],
                        'subscription_based_service_id' => $input['subscription_based_service_id']
                            ], $input);
        }
    }

    public function importLabtest(Request $request) {
        if (empty($request->file)) {
            return redirect()->route('admin.lab.test.add', ['lab_id' => $request->lab_id])->with('error', 'Please, Select file');
        }
        $lab = \App\Models\Lab::where('id', $request->lab_id)->first();
        $file = $request->file('file');
        $data = Excel::toArray(new CommonImport, $file);
        if (!empty($data[0])) {
            $ids = "";
            $errorResult = "";
            foreach ($data[0] as $value) {
                if (!empty($value)) {
                    if (!empty($value['import_id'])) {
                        $exist = \App\Models\LabTest::where(['import_id' => $value['import_id'], 'lab_id' => $request->lab_id])->first();
                        if (!empty($exist)) {
                            $ids = $ids . ',' . $value['import_id'];
                        }
                    }
                }
            }
            if (!empty($ids)) {
                $errorResult = $ids . " import ids are already exists in database. ";
                return view('backend.lab_test.add', compact('errorResult', 'lab'));
            } else {
                foreach ($data[0] as $value) {
                    if (!empty($value)) {
                        if (!empty($value['import_id'])) {
                            $value['is_package'] = empty($value['is_package']) ? 0 : 1;
                            $value['lab_id'] = $request->lab_id;
                            $value['lab_parent_id'] = $request->lab_parent_id;
                            $value['discount'] = !empty($value['discount']) ? $value['discount'] : $lab->discount;
                            $value['status_id'] = STATUS_ACTIVE;
                            // $value['test_master_id'] = $value['id'];
                            $value['import_id'] = $value['import_id'];
//                            pr($value);
                            \App\Models\LabTest::create($value);
                        }
                    }
                }
            }
            $lab->self_test_available = 1;
            $lab->save();
            return redirect()->route('admin.lab.test', ['lab_id' => $request->lab_id])->with('success', 'Test has been uploaded successfully');
        }
        return redirect()->route('admin.lab.test.add', ['lab_id' => $request->lab_id])->with('error', 'No data in excel');
    }

    public function importMBSFacility(Request $request) {
        if (empty($request->file)) {
            return redirect()->route('admin.menu_based_service.facility.add', ['menu_based_service_id' => $request->menu_based_service_id])->with('error', 'Please, Select file');
        }
        $menuBasedService = \App\Models\MenuBasedService::where('id', $request->menu_based_service_id)->first();
        $file = $request->file('file');
        $data = Excel::toArray(new CommonImport, $file);
        if (!empty($data[0])) {
            $ids = "";
            $errorResult = "";
            foreach ($data[0] as $value) {
                if (!empty($value)) {
                    if (!empty($value['import_id'])) {
                        $exist = \App\Models\MenuBasedServiceFacility::where(['import_id' => $value['import_id'], 'menu_based_service_id' => $request->menu_based_service_id])->first();
                        if (!empty($exist)) {
                            $ids = $ids . ',' . $value['import_id'];
                        }
                    }
                }
            }
            if (!empty($ids)) {
                $errorResult = $ids . " import ids are already exists in database. ";
                return view('backend.menu_based_service.facility.add', compact('errorResult', 'menuBasedService'));
            } else {
                foreach ($data[0] as $value) {
                    if (!empty($value)) {
                        if (!empty($value['import_id'])) {
                            $value['is_package'] = empty($value['is_package']) ? 0 : 1;
                            $value['menu_based_service_id'] = $request->menu_based_service_id;
                            $value['menu_based_service_parent_id'] = $request->menu_based_service_parent_id;
                            $value['discount'] = $menuBasedService->discount;
                            $value['status_id'] = STATUS_ACTIVE;
                            \App\Models\MenuBasedServiceFacility::create($value);
                        }
                    }
                }
            }
            $menuBasedService->self_facility_available = 1;
            $menuBasedService->save();
            return redirect()->route('admin.menu_based_service.facility', ['menu_based_service_id' => $request->menu_based_service_id])->with('success', 'Test has been uploaded successfully');
        }
        return redirect()->route('admin.menu_based_service.facility.add', ['menu_based_service_id' => $request->menu_based_service_id])->with('error', 'No data in excel');
    }

    public function userImport(Request $request) {
        if (empty($request->file)) {
            return redirect()->route('corporate.user.add')->with('error', 'Please, Select file');
        }
        $file = $request->file('file');
        $data = Excel::toArray(new CommonImport, $file);
        if (!empty($data[0])) {
            $ids = "";
            $errorResult = [];
            foreach ($data[0] as $value) {
                $error = "";
                if (!empty($value)) {
                    if (empty($value['mobile'])) {
                        $error .= "Sorry, Mobile no is empty. ";
                    } else {
                        $user = \App\Models\User::where('mobile', $value['mobile'])->count();
                        if ($user > 0) {
                            $error .= $value['mobile'] . " mobile no already exists. ";
                        }
                    }
                    if (empty($value['email'])) {
                        $error .= "Sorry, Email is empty. ";
                    } else {
                        $user = \App\Models\User::where('email', $value['email'])->count();
                        if ($user > 0) {
                            $error .= $value['email'] . " email already exists. ";
                        }
                    }
                }
                if (!empty($error)) {
                    $errorResult[] = $value['first_name'] . ' ' . $value['last_name'] . ': ' . $error;
                }
            }
            if (!empty($errorResult)) {
                return view('backend.corporate.users.add', compact('errorResult'));
            } else {
                foreach ($data[0] as $value) {
                    if (!empty($value)) {
                        $value['status_id'] = STATUS_ACTIVE;
                        $value['user_type_id'] = END_USER;
                        $value['created_at'] = date('Y-m-d H:i:s');
                        $user = \App\Models\User::create($value);
                        if (!empty($user->id)) {
                            $data['user_id'] = $user->id;
                            $data['company_id'] = $request->user()->company->id;
                            \App\Models\UserDetails::create($data);
                        }
                    }
                }
            }
            return redirect()->route('corporate.user')->with('success', 'Employee has been uploaded successfully');
        }
        return redirect()->route('corporate.user.add')->with('error', 'No data in excel');
    }

}
