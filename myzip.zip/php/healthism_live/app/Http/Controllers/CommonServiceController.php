<?php

namespace App\Http\Controllers;

use App\Helpers\Helpers;
use App\Http\Requests\CommonServiceRequest;
use App\Models\CommonService;
use App\Models\CommonServiceDetails;
use App\Models\State;
use App\Models\City;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use Intervention\Image\ImageManagerStatic as Image;
use function Psr\Log\debug;

class CommonServiceController extends Controller {

    public function location($id) {
        $commonService = CommonService::findOrFail($id)->toArray();
        $location = \App\Models\CommonServiceSearch::where('common_service_id', $id)->get()->toArray();
        return view('backend.common_service.location', compact('commonService', 'location'));
    }

    public function locationDelete($id) {
        $commonServiceSearch = \App\Models\CommonServiceSearch::findOrFail($id);
        if (!empty($commonServiceSearch))
            $commonServiceSearch->delete();
        return success($id, "Location has been deleted successfully");
    }

    public function locationSave(Request $request) {
        $inputArr['common_service_id'] = $request->common_service_id;
        $inputArr['pincode'] = $request->pincode;
        $inputArr['latitude'] = $request->latitude;
        $inputArr['longitude'] = $request->longitude;
        $duplicate = \App\Models\CommonServiceSearch::where($inputArr)->count();
        if ($duplicate > 0) {
            return error("Duplicate Entry");
        }
        $inputArr['category_id'] = $request->category_id;
        $inputArr['name'] = $request->name;
//        $inputArr['city_id'] = $request->city_id;
//        $inputArr['state_id'] = $request->state_id;
        $result = \App\Models\CommonServiceSearch::Create($inputArr);
        return success($result, "Location has been saved successfully");
    }

    public function serviceSearch(Request $request) {
        $search = $request->get('search');

        $data = CommonService::where('name', 'LIKE', '%' . $search . '%')->limit(10)->get();
        $result = [];
        if (!empty($data)) {
            foreach ($data as $value) {
                $commonService['label'] = $value['name'] . '(' . $value['area'] . ',' . $value['city']['name'] . ',' . $value['state']['name'] . ')';
                $commonService['id'] = $value['id'];
            }
            $result[] = $commonService;
        }
        return response()->json($result);
    }

    public function index(Request $request) {
        $commonService = CommonService::query();
        $records_per_page = 10;
        if (!empty($request->name)) {
            $commonService = $commonService->where('name', 'like', '%' . $request->name . '%');
        }
        if (!empty($request->phone)) {
            $commonService = $commonService->where('phone', 'like', '%' . $request->phone . '%');
        }
        if (!empty($request->pincode)) {
            $commonService = $commonService->where('pincode', 'like', '%' . $request->pincode . '%');
        }
        if (!empty($request->city_id)) {
            //$commonService = $commonService->whereRelation('city', 'name', 'like', '%' . $request->city . '%');
            $commonService = $commonService->where('city_id', "=", $request->city_id);
        }
        if (!empty($request->state_id)) {
            //   $commonService = $commonService->whereRelation('state', 'name', 'like', '%' . $request->state . '%');
            $commonService = $commonService->where('state_id', "=", $request->state_id);
        }
        if (!empty($request->category_id)) {
            //   $commonService = $commonService->whereRelation('state', 'name', 'like', '%' . $request->state . '%');
            $commonService = $commonService->where('category_id', "=", $request->category_id);
        }

        if (!empty($request->records_per_page) && is_numeric($request->records_per_page)) {
            $records_per_page = $request->records_per_page;
        }
        if (!empty($request->sort_field)) {
            if ($request->sort_field == 'name' && ($request->sort_action == 'ASC' || $request->sort_action == 'DESC')) {
                $commonService = $commonService->orderBy("name", $request->sort_action);
            } elseif ($request->sort_field == 'Area' && ($request->sort_action == 'ASC' || $request->sort_action == 'DESC')) {
                $commonService = $commonService->orderBy("area", $request->sort_action);
            } elseif ($request->sort_field == 'Pincode' && ($request->sort_action == 'ASC' || $request->sort_action == 'DESC')) {
                $commonService = $commonService->orderBy("pincode", $request->sort_action);
            }
        } else {
            $commonService = $commonService->orderBy("id", "DESC");
        }

        $commonService = $commonService->paginate($records_per_page);
        $states = State::where('active', 1)->get();
        $cities = [];
        if (!empty($request->state_id)) {
            $cities = City::where(['active' => 1, 'state_id' => $request->state_id])->get();
        }
        $categoryData = \App\Models\CommonServiceMapping::all();
        $categoryList = [];
        if (!empty($categoryData)) {
            foreach ($categoryData as $key => $value) {
                $categoryList[] = $value->category;
            }
        }
        if ($request->ajax()) {
            return view('backend.common_service.ajax_content', compact('commonService', 'states', 'cities', 'categoryList'));
        } else {
            return view('backend.common_service.index', compact('commonService', 'states', 'cities', 'categoryList'));
        }
    }

    public function bulkInsert(Request $request) {
        return view('backend.common_service.import');
    }

    public function add(Request $request) {
        $day_list = ['Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday', 'Saturday', 'Sunday'];
        $states = State::where('active', 1)->get();
        $categoryData = \App\Models\CommonServiceMapping::all();
        $category_list = [];
        if (!empty($categoryData)) {
            foreach ($categoryData as $key => $value) {
                $category_list[] = $value->category;
            }
        }
        return view('backend.common_service.add', compact('states', 'day_list', 'category_list'));
    }

    public function edit($id) {
        $commonService = CommonService::findOrFail($id);
        $day_list = ['Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday', 'Saturday', 'Sunday'];
        $states = State::where('active', 1)->get();
        $cities = City::where(['active' => 1, 'state_id' => $commonService->state_id])->get();
        $categoryData = \App\Models\CommonServiceMapping::all();
        $category_list = [];
        if (!empty($categoryData)) {
            foreach ($categoryData as $key => $value) {
                $category_list[] = $value->category;
            }
        }
        return view('backend.common_service.edit', compact('commonService', 'states', 'cities', 'category_list', 'day_list'));
    }

    public function removeProfile($id) {
        $commonService = CommonService::findOrFail($id);
        $images = [];
        if ($commonService->common_service_details->gallery_json != 'NULL' && !empty($commonService->common_service_details->gallery_json)) {
            $gallery_images = json_decode($commonService->common_service_details->gallery_json, true);
            if (!empty($gallery_images)) {
                foreach ($gallery_images as $row) {
                    $images[] = ['name' => $row];
                }
            }
        }
        if (!empty($commonService->photo)) {
            if (file_exists(public_path('image/common_service/' . $commonService->photo))) {
                unlink(public_path('image/common_service/' . $commonService->photo));
            }
            $commonService->photo = null;
            $commonService->save();
        }
        return view('backend.common_service.view', compact('commonService', 'images'));
    }

    public function view($id) {
        $commonService = CommonService::findOrFail($id);
        $images = [];
        if ($commonService->common_service_details->gallery_json != 'NULL' && !empty($commonService->common_service_details->gallery_json)) {
            $gallery_images = json_decode($commonService->common_service_details->gallery_json, true);
            if (!empty($gallery_images)) {
                foreach ($gallery_images as $row) {
                    $images[] = ['name' => $row];
                }
            }
        }
        return view('backend.common_service.view', compact('commonService', 'images'));
    }

    public function fetchGalleryImages(Request $request, $id) {
        $commonService = CommonService::findOrFail($id);
        $gallery_images = json_decode($commonService->common_service_details->gallery_json, true);
        $images = [];
        if (!empty($gallery_images)) {
            foreach ($gallery_images as $row) {
                $size = @filesize("image/common_service_gallery/" . $row);
                $images[] = ['name' => $row, 'size' => $size, 'path' => "/image/common_service_gallery/"];
            }
        }
        return $images;
    }

    public function galleryImagesDelete(Request $request, $id) {
        if (!empty($id)) {
            $commonService = CommonService::findOrFail($id);
            $gallery_images = json_decode($commonService->common_service_details->gallery_json, true);
            $gallery_images = array_filter($gallery_images, fn($m) => $m != $request->name);
            $commonService->common_service_details->gallery_json = json_encode($gallery_images);
            @unlink('image/common_service_gallery/' . $request->name);
            $commonService->common_service_details->save();
        } else {
            unlink(public_path('/image/temp/') . $request->name);
        }
    }

    public function updateSortOrderGallery(Request $request, $id) {
        $commonService = CommonService::findOrFail($id);
        $commonService->common_service_details->gallery_json = json_encode(array_values($request->order_list));
        $commonService->common_service_details->save();
    }

    public function galleryImages(Request $request, $id) {
        if (!empty($id)) {
            $commonService = CommonService::findOrFail($id);

            $gallery_images = json_decode($commonService->common_service_details->gallery_json, true);
            if (!empty($request->file) && in_array($request->file->extension(), allow_file_type_uploads)) {
                $image = $request->file('file');
                $imageName = seo_url("healthism  {$commonService->name}") . '.' . $request->file->extension();
                $image_resize = Image::make($image->getRealPath());
                $image_resize->resize(800, null, function ($constraint) {
                    $constraint->aspectRatio();
                });
                $image_resize->save(public_path('image/common_service_gallery/' . $imageName));
                $gallery_images[] = $imageName;
            }
            echo $imageName;
            $commonService->common_service_details->gallery_json = json_encode(array_values($gallery_images));
            $commonService->common_service_details->save();
        } else {
            if (!empty($request->file) && in_array($request->file->extension(), allow_file_type_uploads)) {
                $image = $request->file('file');
                $fileName = pathinfo($request->file->getClientOriginalName(), PATHINFO_FILENAME);
                $imageName = seo_url($fileName) . '.' . $request->file->extension();
                $image_resize = Image::make($image->getRealPath());
                $image_resize->resize(800, null, function ($constraint) {
                    $constraint->aspectRatio();
                });
                $image_resize->save(public_path('/image/temp/' . $imageName));
                echo $imageName;
            }
        }
    }

    public function update(CommonServiceRequest $request, $id) {
        $commonService = CommonService::findOrFail($id);

        $deleteConditionArr['common_service_id'] = $commonService->id;
        $deleteConditionArr['pincode'] = $commonService->pincode;
        $deleteConditionArr['latitude'] = $commonService->latitude;
        $deleteConditionArr['longitude'] = $commonService->longitude;

        $commonService->name = $request->name;
        $commonService->phone = $request->phone;
        $commonService->email = $request->email;
        $commonService->address1 = $request->address1;
        $commonService->address2 = $request->address2;
        $commonService->area = $request->area;
        $commonService->pincode = $request->pincode;
        $commonService->city_id = $request->city_id;
        $commonService->state_id = $request->state_id;
        $commonService->mobile = $request->mobile;
        $commonService->discount = $request->discount;
        $commonService->virtual_location = $request->virtual_location == 'on' ? 1 : 0;
        $validateLatLong = validateLatLong($request->latitude, $request->longitude);
        $errorMessageLetLong = "";
        if (!empty($validateLatLong)) {
            $commonService->latitude = $request->latitude;
            $commonService->longitude = $request->longitude;
        } else {
            $errorMessageLetLong .= 'longitude and latitude are not valid';
        }
        $commonService->discount = $request->discount;
        $commonService->category_id = $request->category_id;
        $commonService->status_id = !empty($request->status_id) ? $request->status_id : STATUS_ACTIVE;

        /*
         * Common Service details
         */
        $commonService->common_service_details->cash_booking_allowed = $request->cash_booking_allowed == 'on' ? 1 : 0;
        $commonService->common_service_details->cancellation_allowed = $request->cancellation_allowed == 'on' ? 1 : 0;
        if (!empty($request->cancel_policy)) {
            $cancel_policy = [];
            foreach ($request->cancel_policy as $key => $val) {
                if (!empty($val['cancel_policy'])) {
                    $cancel_policy[] = $val['cancel_policy'];
                }
            }
            if (!empty($cancel_policy)) {
                $commonService->common_service_details->cancel_policy = json_encode($cancel_policy);
            }
        } else {
            $commonService->common_service_details->cancel_policy = null;
        }
        if (!empty($request->cancel_policy_setting)) {
            $cancelPolicySetting = [];
            foreach ($request->cancel_policy_setting as $value) {
                if (!empty($value['hours']) && !empty($value['charge'])) {
                    $cancelPolicySetting[] = $value;
                }
            }
            if (!empty($cancelPolicySetting)) {
                $commonService->common_service_details->cancel_policy_setting = json_encode($cancelPolicySetting);
            }
        } else {
            $commonService->common_service_details->cancel_policy_setting = null;
        }

        $multipleLocation = [];
//        if (!empty($request->multiple_location)) {
//            foreach ($request->multiple_location as $multipeLocation) {
//                if (!empty($multipeLocation['multiple_location_pincode'])) {
//                    $duplicate = 0;
//                    foreach ($multipleLocation as $checkData) {
//                        if ($checkData['pincode'] == $multipeLocation['multiple_location_pincode'] &&
//                                $checkData['latitude'] == $multipeLocation['multiple_location_latitude'] &&
//                                $checkData['longitude'] == $multipeLocation['multiple_location_longitude']) {
//                            $duplicate = 1;
//                        }
//                    }
//                    if ($duplicate == 0) {
//                        $locationArr = [
//                            'pincode' => $multipeLocation['multiple_location_pincode'],
//                            'latitude' => null,
//                            'longitude' => null
//                        ];
//                        if (!empty($multipeLocation['multiple_location_latitude']) && !empty($multipeLocation['multiple_location_longitude'])) {
//                            if (!empty(validateLatLong($multipeLocation['multiple_location_latitude'], $multipeLocation['multiple_location_longitude']))) {
//                                $locationArr['latitude'] = $multipeLocation['multiple_location_latitude'];
//                                $locationArr['longitude'] = $multipeLocation['multiple_location_longitude'];
//                            } else {
//                                $errorMessageLetLong .= "Multiple Location lat : " . $multipeLocation['multiple_location_latitude'] . " or long : " . $multipeLocation['multiple_location_longitude'] . " not valid.";
//                            }
//                        }
//                        $multipleLocation[] = $locationArr;
//                    }
//                }
//            }
//        }
//
//        $commonService->common_service_details->additional_search_json = !empty($multipleLocation) ? json_encode($multipleLocation) : null;
        $commonService->common_service_details->timing_json = $request->slot_data_obj;
        $commonService->common_service_details->description = $request->description;
        $commonService->common_service_details->pancard_number = $request->pancard_number;
        $commonService->common_service_details->gst_number = $request->gst_number;
        $commonService->common_service_details->bank_account_number = $request->bank_account_number;
        $commonService->common_service_details->bank_account_name = $request->bank_account_name;
        $commonService->common_service_details->bank_name = $request->bank_name;
        $commonService->common_service_details->bank_ifsc_code = $request->bank_ifsc_code;
        if (!empty($request->photo) && in_array($request->photo->extension(), allow_file_type_uploads)) {
            $image = $request->file('photo');
            $imageName = seo_url("healthism {$request->name}") . '.' . $request->photo->extension();
            $image_resize = Image::make($image->getRealPath());
            $image_resize->resize(800, null, function ($constraint) {
                $constraint->aspectRatio();
            });
            $image_resize->save(public_path('image/common_service/' . $imageName));
            $commonService->photo = $imageName;
        }

        if (!empty($request->pancard_document)) {
            $imageName = seo_url("pan healthism {$request->name}") . '.' . $request->pancard_document->extension();
            $imageName = change_filename("image/common_service/", $imageName);

            if ($request->pancard_document->move(public_path('image/common_service'), $imageName)) {
                if (!empty($commonService->common_service_details->pancard_document)) {
                    @unlink('image/common_service/' . $commonService->common_service_details->pancard_document);
                }
            }
            $commonService->common_service_details->pancard_document = $imageName;
        }

        if (!empty($request->gst_certificate)) {
            $imageName = seo_url("gst healthism {$request->name}") . '.' . $request->gst_certificate->extension();
            $imageName = change_filename("image/common_service/", $imageName);

            if ($request->gst_certificate->move(public_path('image/common_service'), $imageName)) {
                if (!empty($commonService->common_service_details->gst_certificate)) {
                    @unlink('image/common_service/' . $commonService->common_service_details->gst_certificate);
                }
            }
            $commonService->common_service_details->gst_certificate = $imageName;
        }
        $commonService->common_service_details->save();
        $commonService->save();
        if (!empty($commonService)) {
            if (!empty($validateLatLong)) {
                $multipleLocation = [
                    'pincode' => $request->pincode,
                    'latitude' => $request->latitude,
                    'longitude' => $request->longitude
                ];
            }
            \App\Models\CommonServiceSearch::where($deleteConditionArr)->delete();
            $this->addSearchData($commonService, $multipleLocation);
        }
        if (!empty($errorMessageLetLong)) {
            return redirect()->route('admin.common.service.view', $commonService->id)->with('error', $errorMessageLetLong);
        }
        return redirect()->route('admin.common.service.view', $commonService->id)->with('success', 'Command service Details Updated Successfully!');
    }

    public function store(CommonServiceRequest $request) {
        $commonService = new CommonService;
        $commonServiceDetails = new CommonServiceDetails();

        $gallery_images = [];
        if (!empty($request->images_list)) {
            foreach ($request->images_list as $row) {
                $fileName = explode(".", $row);
                $imageName = seo_url("healthism  $request->name {$fileName[0]}") . "." . $fileName[1];
                $imageName = change_filename("image/common_service/", $imageName);
                copy(public_path("/image/temp/{$row}"), public_path('image/common_service_gallery/' . $imageName));
                $gallery_images[] = $imageName;
            }
            $commonServiceDetails->gallery_json = json_encode(array_values($gallery_images));
        }

        $commonService->name = $request->name;
        $commonService->phone = $request->phone;
        $commonService->mobile = $request->mobile;
        $commonService->email = $request->email;
        $commonService->address1 = $request->address1;
        $commonService->address2 = $request->address2;
        $commonService->area = $request->area;
        $commonService->pincode = $request->pincode;
        $commonService->city_id = $request->city_id;
        $commonService->state_id = $request->state_id;
        $commonService->discount = $request->discount;
        $commonService->virtual_location = $request->virtual_location == 'on' ? 1 : 0;
        $validateLatLong = validateLatLong($request->latitude, $request->longitude);
        $errorMessageLetLong = "";
        if (!empty($validateLatLong)) {
            $commonService->latitude = $request->latitude;
            $commonService->longitude = $request->longitude;
        } else {
            $errorMessageLetLong .= 'longitude and latitude are not valid';
        }
        $commonService->discount = $request->discount;
        $commonService->category_id = $request->category_id;
        $commonService->status_id = !empty($request->status_id) ? $request->status_id : STATUS_ACTIVE;

        /*
         * Common Service details
         */
        $commonServiceDetails->cash_booking_allowed = $request->cash_booking_allowed == 'on' ? 1 : 0;
        $commonServiceDetails->cancellation_allowed = $request->cancellation_allowed == 'on' ? 1 : 0;
        if (!empty($request->cancel_policy)) {
            $cancel_policy = [];
            foreach ($request->cancel_policy as $key => $val) {
                if (!empty($val['cancel_policy'])) {
                    $cancel_policy[] = $val['cancel_policy'];
                }
            }
            if (!empty($cancel_policy)) {
                $commonServiceDetails->cancel_policy = json_encode($cancel_policy);
            }
        }
        if (!empty($request->cancel_policy_setting)) {
            $cancelPolicySetting = [];
            foreach ($request->cancel_policy_setting as $value) {
                if (!empty($value['hours']) && !empty($value['charge'])) {
                    $cancelPolicySetting[] = $value;
                }
            }
            if (!empty($cancelPolicySetting)) {
                $commonServiceDetails->cancel_policy_setting = json_encode($cancelPolicySetting);
            }
        }
        $commonServiceDetails->timing_json = $request->slot_data_obj;
        $commonServiceDetails->description = $request->description;
        $commonServiceDetails->pancard_number = $request->pancard_number;
        $commonServiceDetails->gst_number = $request->gst_number;
        $commonServiceDetails->bank_account_number = $request->bank_account_number;
        $commonServiceDetails->bank_account_name = $request->bank_account_name;
        $commonServiceDetails->bank_name = $request->bank_name;
        $commonServiceDetails->bank_ifsc_code = $request->bank_ifsc_code;

        $multipleLocation = [];
//        if (!empty($request->multiple_location)) {
//            foreach ($request->multiple_location as $multipeLocation) {
//                if (!empty($multipeLocation['multiple_location_pincode'])) {
//                    $duplicate = 0;
//                    foreach ($multipleLocation as $checkData) {
//                        if ($checkData['pincode'] == $multipeLocation['multiple_location_pincode'] &&
//                                $checkData['latitude'] == $multipeLocation['multiple_location_latitude'] &&
//                                $checkData['longitude'] == $multipeLocation['multiple_location_longitude']) {
//                            $duplicate = 1;
//                        }
//                    }
//                    if ($duplicate == 0) {
//                        $locationArr = [
//                            'pincode' => $multipeLocation['multiple_location_pincode'],
//                            'latitude' => null,
//                            'longitude' => null
//                        ];
//                        if (!empty($multipeLocation['multiple_location_latitude']) && !empty($multipeLocation['multiple_location_longitude'])) {
//                            if (!empty(validateLatLong($multipeLocation['multiple_location_latitude'], $multipeLocation['multiple_location_longitude']))) {
//                                $locationArr['latitude'] = $multipeLocation['multiple_location_latitude'];
//                                $locationArr['longitude'] = $multipeLocation['multiple_location_longitude'];
//                            } else {
//                                $errorMessageLetLong .= "Multiple Location lat : " . $multipeLocation['multiple_location_latitude'] . " or long : " . $multipeLocation['multiple_location_longitude'] . " not valid.";
//                            }
//                        }
//                        $multipleLocation[] = $locationArr;
//                    }
//                }
//            }
//        }
//        $commonServiceDetails->additional_search_json = !empty($multipleLocation) ? json_encode($multipleLocation) : null;
        if (!empty($validateLatLong)) {
            $multipleLocation = [
                'pincode' => $request->pincode,
                'latitude' => $request->latitude,
                'longitude' => $request->longitude
            ];
        }
        if (!empty($request->photo) && in_array($request->photo->extension(), allow_file_type_uploads)) {
            $image = $request->file('photo');
            $imageName = seo_url("healthism {$request->name}") . '.' . $request->photo->extension();
            $image_resize = Image::make($image->getRealPath());
            $image_resize->resize(800, null, function ($constraint) {
                $constraint->aspectRatio();
            });
            $image_resize->save(public_path('image/common_service/' . $imageName));
            $commonService->photo = $imageName;
        }

        if (!empty($request->pancard_document)) {
            $imageName = seo_url("pan healthism {$request->name}") . '.' . $request->pancard_document->extension();
            $imageName = change_filename("image/common_service/", $imageName);
            if ($request->pancard_document->move(public_path('image/common_service'), $imageName)) {
                $commonServiceDetails->pancard_document = $imageName;
            }
        }

        if (!empty($request->gst_certificate)) {
            $imageName = seo_url("gst healthism {$request->name}") . '.' . $request->gst_certificate->extension();
            $imageName = change_filename("image/common_service/", $imageName);

            if ($request->gst_certificate->move(public_path('image/common_service'), $imageName)) {
                if (!empty($doctor->gst_certificate)) {
                    @unlink('image/common_service/' . $commonService->common_service_details->gst_certificate);
                }
            }
            $commonServiceDetails->gst_certificate = $imageName;
        }
        $commonService->save();
        $commonServiceDetails->common_service_id = $commonService->id;
        $commonServiceDetails->save();
        if (!empty($commonService)) {
            $this->addSearchData($commonService, $multipleLocation);
        }
        if (!empty($errorMessageLetLong)) {
            return redirect()->route('admin.common.service.view', $commonService->id)->with('error', $errorMessageLetLong);
        }
        return redirect()->route('admin.common.service.view', $commonService->id)->with('success', 'Common service Details Added Successfully!');
    }

    private function addSearchData($commonService, $multipleLocation) {
        $searchData = array(
            'common_service_id' => $commonService->id,
            'category_id' => $commonService->category_id,
            'name' => $commonService->name,
            'city_id' => $commonService->city_id,
            'state_id' => $commonService->state_id
        );
        if (!empty($multipleLocation)) {
            $searchData['pincode'] = $multipleLocation['pincode'];
            $searchData['latitude'] = $multipleLocation['latitude'];
            $searchData['longitude'] = $multipleLocation['longitude'];
            $multipleLocation['common_service_id'] = $commonService->id;
            $duplicate = \App\Models\CommonServiceSearch::where($multipleLocation)->count();
            if ($duplicate > 0) {
                return false;
            } else {
                \App\Models\CommonServiceSearch::insert($searchData);
            }
        }
    }

    public function delete(Request $request) {
        $input = $request->all();
        if (empty($input['common_service_id'])) {
            return error('Sorry, Id is empty.');
        }
        $commonService = CommonService::findOrFail($input['common_service_id']);
        if (!empty($commonService)) {
            $booking = \App\Models\CommonServiceEnquiry::where('common_service_id', $input['common_service_id'])->count();
            if ($booking == 0) {
                if (!empty($commonService->photo)) {
                    @unlink('image/common_service/' . $commonService->photo);
                }
                if (!empty($commonService->common_service_details->gst_certificate)) {
                    @unlink('image/common_service/' . $commonService->common_service_details->gst_certificate);
                }
                if (!empty($commonService->common_service_details->gst_certificate)) {
                    @unlink('image/common_service/' . $commonService->common_service_details->gst_certificate);
                }
                $commonService->delete();
                CommonServiceDetails::where('common_service_id', $input['common_service_id'])->delete();
                \App\Models\CommonServiceSearch::where('common_service_id', $input['common_service_id'])->delete();
                \App\Models\ReportProblem::where('ref_id', $input['common_service_id'])->where('service_id', SERVICE_COMMON)->delete();
                \App\Models\UserReview::where('ref_id', $input['common_service_id'])->where('service_id', SERVICE_COMMON)->delete();
            } else {
                return error('Sorry, Enquiry has generated for Common service');
            }
        }
        return success(array(), 'Common service has been deleted successfully!');
    }

}
