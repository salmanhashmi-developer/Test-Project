<?php

namespace App\Http\Controllers\Partner;

use App\Http\Controllers\Controller;
use Carbon\Carbon;
use App\Models\CommonService;
use App\Models\Doctor;
use App\Models\Lab;
use App\Models\Subscription;
use App\Models\UserReview;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Validator;

class PartnerBranchReviewController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index(Request $request)
    {
        $lab_ids = Lab::where('user_id', $request->user()->id)->pluck('id')->toArray();
        $userReview = UserReview::query();
        $userReview->where('service_id', 2)->whereIn('ref_id', $lab_ids);
        // $records_per_page = 5;
        if (!empty($request->user_id) && is_numeric($request->user_id)) {
            $userReview->where('user_id', '=', trim($request->user_id));
        }
        if (!empty($request->service_id) && is_numeric($request->service_id)) {
            $userReview->where('service_id', '=', trim($request->service_id));
        }
        if (!empty($request->rating) && is_numeric($request->rating)) {
            $userReview->where('rating', '=', trim($request->rating));
        }
        if (!empty($request->from_date) && !empty($request->to_date)) {
            // $userReview->where('created_at', ">=", $request->from_date)->where('created_at',  "<=", $request->to_date);
            $userReview->whereBetween('created_at', [$request->from_date, $request->to_date]);
        }
        $userReview->orderBy("id", 'DESC');
        // if (!empty($request->records_per_page) && is_numeric($request->records_per_page)) {
        //     $records_per_page = $request->records_per_page;
        // }
        // $userReview = $userReview->paginate($records_per_page);
        $userReview = $userReview->with(['user', 'service', 'status'])->get();

        if (!empty($userReview)) {
            foreach ($userReview as $key => $value) {
                if (!empty($value['ref_id']) && !empty($value['service_id'])) {
                    $refData['title1'] = $refData['title2'] = $refData['title3'] = "";
                    if ($value['service_id'] == SERVICE_DOCTOR_APPOINTMENT) {
                        $refDetail = Doctor::findOrFail($value['ref_id']);
                        if (!empty($refDetail)) {
                            $refData['title1'] = $refDetail['first_name'] . ' ' . $refDetail['last_name'];
                            $refData['title2'] = $refDetail['phone'];
                            $refData['title3'] = $refDetail['specialization'];
                        }
                    }
                    if ($value['service_id'] == SERVICE_LAB_REPORT) {
                        $refDetail = Lab::findOrFail($value['ref_id']);
                        if (!empty($refDetail)) {
                            $refData['title1'] = $refDetail['name'];
                            $refData['title2'] = $refDetail['phone'];
                            $refData['title3'] = $refDetail['area'] . " - " . $refDetail->city->name;
                        }
                    }
                    if ($value['service_id'] == SERVICE_SUBSCRIPTION_PLAN) {
                        $refDetail = Subscription::findOrFail($value['ref_id']);
                        if (!empty($refDetail)) {
                            $refData['title1'] = $refDetail['name'];
                            $refData['title2'] = $refDetail['member'] . ' Member plan for ' . $refDetail['validity_in_days'] . ' Days';
                            $refData['title3'] = 'Price : ' . $refDetail['price'];
                        }
                    }
                    if ($value['service_id'] == SERVICE_COMMON) {
                        $refDetail = CommonService::findOrFail($value['ref_id']);
                        if (!empty($refDetail)) {
                            $refData['title1'] = $refDetail['name'] . '(' . $refDetail->category->name . ')';
                            $refData['title2'] = $refDetail['phone'];
                            $refData['title3'] = $refDetail['area'] . "," . $refDetail->city->name;
                        }
                    }
                    $userReview[$key]['ref_data'] = $refData;
                }
            }
        }
        // $ratingList = [1, 2, 3, 4, 5];
        // $service = Service::all();
        // if ($request->ajax()) {
        //     return view('backend.user_review.ajax_content', compact('userReview', 'ratingList', 'service'));
        // } else {
        //     return view('backend.user_review.index', compact('userReview', 'ratingList', 'service'));
        // }
        return success($userReview, "User Review Fetch successfully.");
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        //
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        //
    }

    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function show($id)
    {
        $review = UserReview::with(['user', 'service', 'status'])->where('id', $id)->first();
        if ($review) {
            $review['lab_details'] = Lab::where('id', $review->ref_id)->first();
            return success($review, "Review fetch Succesfully.");
        } else {
            return error("This Review is not available.");
        }
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function edit($id)
    {
        //
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, $id)
    {
        //
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function destroy($id)
    {
        $review = UserReview::where('id', $id)->first();
        if ($review) {
            $review->delete();
            return success([], "Lab Review delete Succesfully.");
        } else {
            return error("This Lab Review is not available.");
        }
    }

    public function replyOnReview(Request $request)
    {
        $validator = Validator::make($request->all(), [
            'id' => "required",
            'reply' => "required|string"
        ]);
        if ($validator->fails()) {
            return error($validator->errors()->first());
        } else {
            $review = UserReview::where('id', $request->id)->whereNull('reply')->first();
            if ($review) {
                $review->update(['reply' => $request->reply, 'replied_at' => Carbon::now()->toDateTimeString()]);
                return success($review, "Reply given successfully.");
            } else {
                return error("Reply Already given.");
            }
        }
    }
}
