<?php

namespace App\Http\Controllers\Partner;

use App\Http\Controllers\Controller;
use App\Models\Lab;
use App\Models\LabTest;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Validator;

class PartnerLabTestController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function getAllLabTest(Request $request)
    {
        $user = $request->user();
        $lab_test = LabTest::query();
        $lab_test->where('lab_id', $user->lab->id);
        $records_per_page = 10;
        if (!empty($request->name)) {
            $lab_test = $lab_test->where('name', 'like', '%' . $request->name . '%');
        }
        if (!empty($request->status)) {
            $lab_test = $lab_test->where('status', $request->status);
        }

        // if (!empty($request->records_per_page) && is_numeric($request->records_per_page)) {
        //     $records_per_page = $request->records_per_page;
        // }
        $lab_test = $lab_test->orderBy("id", "DESC");


        if (isset($request->limit)) {
            $lab_test->limit($request->limit);
        }
        if (isset($request->offset)) {
            $lab_test->offset($request->offset);
        }
        $data = [];
        $data['lab_test_data'] = $lab_test->with('status')->get();
        $data['total_records'] = $lab_test->count();
        // $lab = $lab->paginate($records_per_page);

        return success($data, "Lab test data fetch Succesfully.");
    }

    public function getAllLabBranchTests(Request $request, $id)
    {
        $user = $request->user();
        $lab_branch_test = LabTest::query();
        $lab_branch_test = $lab_branch_test->where('lab_id', $id)->where('lab_parent_id', $user->lab->id);
        if ($lab_branch_test->exists()) {
            if (!empty($request->name)) {
                $lab_branch_test = $lab_branch_test->where('name', 'like', '%' . $request->name . '%');
            }
            if (!empty($request->status)) {
                $lab_branch_test = $lab_branch_test->where('status', $request->status);
            }

            // if (!empty($request->records_per_page) && is_numeric($request->records_per_page)) {
            //     $records_per_page = $request->records_per_page;
            // }
            $lab_branch_test = $lab_branch_test->orderBy("id", "DESC");

            if (isset($request->limit)) {
                $lab_branch_test->limit($request->limit);
            }
            if (isset($request->offset)) {
                $lab_branch_test->offset($request->offset);
            }
            $data = [];
            $data['lab_branch_test_data'] = $lab_branch_test->with('status')->get();
            $data['total_records'] = $lab_branch_test->count();
            // $lab = $lab->paginate($records_per_page);

            return success($data, "Lab's branch test data fetch Succesfully.");
        } else {
            return error("something went wrong.");
        }
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        //
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function addLabTest(Request $request)
    {
        $user = $request->user();
        $data = $request->all();
        $validator = Validator::make($data, [
            'name' => "required",
            'gender' => "required",
            'description' => "required",
            'requirement' => "required",
            'preparation' => "required",
            'home_collection' => "required|in:off,on",
            'is_package' => "nullable|in:off,on",
            'package_category' => "required_with:is_package,on",
            'price' => "required",
            'discount' => "required",
            'test_count' => "required",
            'test_json' => "required",
        ]);

        if ($validator->fails()) {
            return error($validator->errors()->first());
        } else {
            $check_lab = Lab::where('id', $user->lab->id)->first();
            if ($check_lab) {
                $labTest = new LabTest();

                $labTest->lab_id = $user->lab->id;
                $labTest->lab_parent_id = !empty($request->lab_parent_id) ? $request->lab_parent_id : NULL;
                $labTest->name = $request->name;
                $labTest->gender = $request->gender;
                $labTest->description = $request->description;
                $labTest->requirement = $request->requirement;
                $labTest->preparation = $request->preparation;
                $labTest->test_count = $request->test_count;
                $labTest->test_json = $request->test_json;
                $labTest->price = $request->price;
                $labTest->discount = $request->discount;
                $labTest->e_report_hours = !empty($request->e_report_hours) ? $request->e_report_hours : NULL;
                $labTest->sort_order = !empty($request->sort_order) ? $request->sort_order : NULL;
                $labTest->home_collection = !empty($request->home_collection) ? ($request->home_collection == 'on' ? 1 : 0) : 0;
                $labTest->is_package = !empty($request->is_package) ? ($request->is_package == 'on' ? 1 : 0) : 0;
                $labTest->package_category = !empty($request->package_category) ? $request->package_category : NULL;
                $labTest->status_id = !empty($request->status_id) ? $request->status_id : STATUS_ACTIVE;

                $labTest->save();
                $lab_test = LabTest::with(['status'])->where('id', $labTest->id)->first();

                // when first test add for lab - self test available field update to 1
                $check_lab->update(['self_test_available' => 1]);

                return success($lab_test, "Lab test Details Added Succesfully.");
            } else {
                return error("Lab is not Available.");
            }
        }
    }

    public function addLabBranchTest(Request $request)
    {
        $user = $request->user();
        $data = $request->all();
        $validator = Validator::make($data, [
            'lab_id' => "required",
            'lab_parent_id' => "required",
            'name' => "required",
            'gender' => "required",
            'description' => "required",
            'requirement' => "required",
            'preparation' => "required",
            'home_collection' => "required|in:off,on",
            'is_package' => "nullable|in:off,on",
            'package_category' => "required_with:is_package,on",
            'price' => "required",
            'discount' => "required",
            'test_count' => "required",
            'test_json' => "required",
        ]);

        if ($validator->fails()) {
            return error($validator->errors()->first());
        } else {
            $check_lab = Lab::where('id', $request->lab_id)->where('parent_id', $user->lab->id)->where('parent_id', $request->lab_parent_id)->first();
            if ($check_lab) {
                $labTest = new LabTest();

                $labTest->lab_id = $request->lab_id;
                $labTest->lab_parent_id = !empty($request->lab_parent_id) ? $request->lab_parent_id : NULL;
                $labTest->name = $request->name;
                $labTest->gender = $request->gender;
                $labTest->description = $request->description;
                $labTest->requirement = $request->requirement;
                $labTest->preparation = $request->preparation;
                $labTest->test_count = $request->test_count;
                $labTest->test_json = $request->test_json;
                $labTest->price = $request->price;
                $labTest->discount = $request->discount;
                $labTest->e_report_hours = !empty($request->e_report_hours) ? $request->e_report_hours : NULL;
                $labTest->sort_order = !empty($request->sort_order) ? $request->sort_order : NULL;
                $labTest->home_collection = !empty($request->home_collection) ? ($request->home_collection == 'on' ? 1 : 0) : 0;
                $labTest->is_package = !empty($request->is_package) ? ($request->is_package == 'on' ? 1 : 0) : 0;
                $labTest->package_category = !empty($request->package_category) ? $request->package_category : NULL;
                $labTest->status_id = !empty($request->status_id) ? $request->status_id : STATUS_ACTIVE;

                $labTest->save();
                $lab_test = LabTest::with(['status'])->where('id', $labTest->id)->first();

                // when first test add for lab - self test available field update to 1
                $check_lab->update(['self_test_available' => 1]);

                return success($lab_test, "Lab test Details Added Succesfully.");
            } else {
                return error("Lab is not Available.");
            }
        }
    }

    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function showLabTest(Request $request, $id)
    {
        $user = $request->user();
        $lab_test = LabTest::with(['status'])->where('id', $id)->where('lab_id', $user->lab->id)->first();
        if ($lab_test) {
            return success($lab_test, "Lab test fetch Succesfully.");
        } else {
            return error("This Lab test master is not available.");
        }
    }


    public function showLabBranchTest(Request $request, $id)
    {
        $user = $request->user();
        $lab_branch_test = LabTest::with(['status'])->where('id', $id)->where('lab_parent_id', $user->lab->id)->first();
        if ($lab_branch_test) {
            return success($lab_branch_test, "Lab branch test fetch Succesfully.");
        } else {
            return error("This Lab branch test is not available.");
        }
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function edit($id)
    {
        //
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function updateLabTest(Request $request, $id)
    {
        // $labTest = LabTest::findOrFail($id);
        $user = $request->user();
        $labTest = LabTest::with(['status'])->where('id', $id)->where('lab_id', $user->lab->id)->first();
        if ($labTest) {
            $labTest->is_package = !empty($request->is_package) ? ($request->is_package == 'on' ? 1 : 0) : 0;
            $labTest->home_collection = !empty($request->home_collection) ? ($request->home_collection == 'on' ? 1 : 0) : 0;
            $labTest->update($request->except('is_package', 'home_collection'));
            return success($labTest, "Lab test Details Updated Successfully!");
        } else {
            return error("This Lab test is not available.");
        }
    }

    public function updateLabBranchTest(Request $request, $id)
    {
        // $labTest = LabTest::findOrFail($id);
        $user = $request->user();
        $labBranchTest = LabTest::with(['status'])->where('id', $id)->where('lab_parent_id', $user->lab->id)->first();
        if ($labBranchTest) {
            $labBranchTest->is_package = !empty($request->is_package) ? ($request->is_package == 'on' ? 1 : 0) : 0;
            $labBranchTest->home_collection = !empty($request->home_collection) ? ($request->home_collection == 'on' ? 1 : 0) : 0;
            $labBranchTest->update($request->except('is_package', 'home_collection'));
            return success($labBranchTest, "Lab branch test Details Updated Successfully!");
        } else {
            return error("This Lab branch test is not available.");
        }
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function destroyLabTest(Request $request, $id)
    {
        $user = $request->user();
        $lab_test = LabTest::with(['status'])->where('id', $id)->where('lab_id', $user->lab->id)->first();
        if ($lab_test) {
            $lab_test->delete();
            return success([], "Lab test delete Succesfully.");
        } else {
            return error("This Lab test is not available.");
        }
    }

    public function destroyLabBranchTest(Request $request, $id)
    {
        $user = $request->user();
        $lab_branch_test = LabTest::with(['status'])->where('id', $id)->where('lab_parent_id', $user->lab->id)->first();
        if ($lab_branch_test) {
            $lab_branch_test->delete();
            return success([], "Lab branch test delete Succesfully.");
        } else {
            return error("This Lab branch test is not available.");
        }
    }
}
