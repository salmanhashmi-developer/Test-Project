<?php

namespace App\Http\Controllers\Partner;

use App\Http\Controllers\Controller;
use App\Models\Lab;
use App\Models\LabDetails;
use App\Models\LabSearch;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Validator;
use Intervention\Image\ImageManagerStatic as Image;

class PartnerLabBranchController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index(Request $request)
    {
        $user = $request->user();
        $labBranch = Lab::query();
        $records_per_page = 10;
        // $labBranch->whereNotNull('parent_id');
        $labBranch->where('parent_id', $user->lab->id);
        if (!empty($request->name)) {
            $labBranch = $labBranch->where('name', 'like', '%' . $request->name . '%');
        }
        if (!empty($request->phone)) {
            $labBranch = $labBranch->where('phone', 'like', '%' . $request->phone . '%')->orWhere('mobile', 'like', '%' . $request->phone . '%');
        }
        if (!empty($request->pincode)) {
            $labBranch = $labBranch->where('pincode', 'like', '%' . $request->pincode . '%');
        }
        if (!empty($request->city_id)) {
            //$labBranch = $labBranch->whereRelation('city', 'name', 'like', '%' . $request->city . '%');
            $labBranch = $labBranch->where('city_id', "=", $request->city_id);
        }
        if (!empty($request->state_id)) {
            //   $labBranch = $labBranch->whereRelation('state', 'name', 'like', '%' . $request->state . '%');
            $labBranch = $labBranch->where('state_id', "=", $request->state_id);
        }

        // if (!empty($request->records_per_page) && is_numeric($request->records_per_page)) {
        //     $records_per_page = $request->records_per_page;
        // }
        if (!empty($request->sort_field)) {
            if ($request->sort_field == 'name' && ($request->sort_action == 'ASC' || $request->sort_action == 'DESC')) {
                $labBranch = $labBranch->orderBy("name", $request->sort_action);
            } elseif ($request->sort_field == 'Area' && ($request->sort_action == 'ASC' || $request->sort_action == 'DESC')) {
                $labBranch = $labBranch->orderBy("area", $request->sort_action);
            } elseif ($request->sort_field == 'Pincode' && ($request->sort_action == 'ASC' || $request->sort_action == 'DESC')) {
                $labBranch = $labBranch->orderBy("pincode", $request->sort_action);
            }
        } else {
            $labBranch = $labBranch->orderBy("id", "DESC");
        }

        if (isset($request->limit)) {
            $labBranch->limit($request->limit);
        }
        if (isset($request->offset)) {
            $labBranch->offset($request->offset);
        }
        $lab_branch_data = [];
        $lab_branch_data['lab_data'] = $labBranch->get();
        $lab_branch_data['total_records'] = $labBranch->count();
        // $lab = $lab->paginate($records_per_page);

        return success($lab_branch_data, "Lab branch fetch Succesfully.");
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        //
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        $user = $request->user();
        $data = $request->all();
        $validator = Validator::make($data, [
            // 'user_id' => "required",
            // 'parent_id' => "required",
            'name' => "required",
            'address1' => "required",
            'address2' => "required",
            'area' => "required",
            'pincode' => "required",
            'city_id' => "required",
            'state_id' => "required",
            'latitude' => "required",
            'longitude' => "required",
            'photo' => "required",
            'description' => "required",
        ]);

        if ($validator->fails()) {
            return error($validator->errors()->first());
        } else {
            $check_lab = Lab::where('id', $user->lab->id)->first();
            // dd($check_lab, $user->lab->id);
            if (!empty($check_lab)) {
                $labBranch = new Lab();
                $labBranchDetails = new LabDetails();

                // $labBranch->user_id = 0;
                $labBranch->parent_id = $user->lab->id; // login user's lab id
                $labBranch->name = $request->name;
                $labBranch->phone = $request->phone;
                $labBranch->mobile = $request->mobile;
                $labBranch->email = $request->email;
                $labBranch->address1 = $request->address1;
                $labBranch->address2 = $request->address2;
                $labBranch->area = $request->area;
                $labBranch->pincode = $request->pincode;
                $labBranch->city_id = $request->city_id;
                $labBranch->state_id = $request->state_id;
                $validateLatLong = validateLatLong($request->latitude, $request->longitude);
                if (!empty($validateLatLong)) {
                    $labBranch->latitude = $request->latitude;
                    $labBranch->longitude = $request->longitude;
                } else {
                    return error("longitude and latitude are not valid.");
                }
                $labBranch->discount = !empty($request->discount) ? $request->discount : NULL;
                $labBranch->contact_person = !empty($request->contact_person) ? $request->contact_person : NULL;
                $labBranch->virtual_location = !empty($request->virtual_location) ? ($request->virtual_location == 'on' ? 1 : 0) : 0;
                $labBranch->status_id = !empty($request->status_id) ? $request->status_id : STATUS_ACTIVE;

                /*
                    * Lab Branch details
                */

                $labBranchDetails->description = $request->description;
                $labBranchDetails->timing_json = $request->slot_data_obj;
                $labBranchDetails->permissions_json = !empty($request->permissions_json) ? $request->permissions_json : NULL;

                if (!empty($request->photo) && in_array($request->photo->extension(), allow_file_type_uploads)) {
                    $image = $request->file('photo');
                    $imageName = seo_url("healthism lab branch profile {$request->name}") . '.' . $request->photo->extension();
                    $image_resize = Image::make($image->getRealPath());
                    $image_resize->resize(800, null, function ($constraint) {
                        $constraint->aspectRatio();
                    });
                    $image_resize->save(public_path('image/lab/' . $imageName));
                    $labBranch->photo = $imageName;
                }

                if (!empty($request->images_list)) {
                    $gallery_images = [];

                    foreach ($request->images_list as $row) {
                        $imageName = seo_url("healthism {$request->name}") . "." . $row->extension();
                        $imageName = change_filename("image/lab_gallery/", $imageName);
                        if ($row->move(public_path('image/lab_gallery'), $imageName)) {
                            $gallery_images[] = $imageName;
                        }
                    }
                    $labBranchDetails->gallery_json = json_encode(array_values($gallery_images));
                }

                $labBranch->save();
                $labBranchDetails->lab_id = $labBranch->id;
                $labBranchDetails->save();
                $lab_service = Lab::with(['lab_details', 'status', 'state', 'city'])->where('id', $labBranch->id)->first();
                return success($lab_service, "Lab Branch Details Added Succesfully.");
            } else {
                return error("This lab is not available in our record.");
            }
        }
    }

    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function show(Request $request, $id)
    {
        $user = $request->user();
        $labBranch = Lab::with(['lab_details', 'status', 'state', 'city'])->where('id', $id)->where('parent_id', $user->lab->id)->first();
        if ($labBranch) {
            return success($labBranch, "Lab Branch fetch Succesfully.");
        } else {
            return error("This Lab is not available.");
        }
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function edit($id)
    {
        //
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, $id)
    {
        $user = $request->user();
        // $labBranch = Lab::findOrFail($id);
        $labBranch = Lab::with(['lab_details'])->where('id', $id)->where('parent_id', $user->lab->id)->first();
        if ($labBranch) {
            if (isset($request->latitude) && isset($request->longitude)) {
                $validateLatLong = validateLatLong($request->latitude, $request->longitude);
                if (!empty($validateLatLong)) {
                    $labBranch->latitude = $request->latitude;
                    $labBranch->longitude = $request->longitude;
                } else {
                    return error("longitude and latitude are not valid.");
                }
            }
            $labBranch->virtual_location = !empty($request->virtual_location) ? ($request->virtual_location == 'on' ? 1 : 0) : 0;
            if (!empty($request->slot_data_obj)) {
                $labBranch->lab_details->timing_json = $request->slot_data_obj;
            }

            if (!empty($request->photo) && in_array($request->photo->extension(), allow_file_type_uploads)) {
                $photo_name = substr($labBranch->photo, strrpos($labBranch->photo, '/') + 1);
                if (!empty($labBranch->photo)) {
                    @unlink(public_path('image/lab/' . $photo_name));
                }
                $image = $request->file('photo');
                $imageName = seo_url("healthism lab branch profile {$request->name}") . '.' . $request->photo->extension();
                $image_resize = Image::make($image->getRealPath());
                $image_resize->resize(800, null, function ($constraint) {
                    $constraint->aspectRatio();
                });
                $image_resize->save(public_path('image/lab/' . $imageName));
                $labBranch->photo = $imageName;
            }

            // $labBranch->save();
            // $labBranch->lab_details->save();
            $labBranch->update($request->except('photo', 'virtual_location'));
            $labBranch->lab_details->update($request->all());

            return success($labBranch, "Lab Branch Details Updated Successfully!");
        } else {
            return error("Something gone worng.");
        }
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function destroy($id)
    {
        //
    }

    public function removeProfile(Request $request, $id)
    {
        $user = $request->user();
        // $labBranch = Lab::findOrFail($id);
        $labBranch = Lab::with(['lab_details'])->where('id', $id)->where('parent_id', $user->lab->id)->first();
        if ($labBranch) {
            $profile_name = substr($labBranch->photo, strrpos($labBranch->photo, '/') + 1);
            if (!empty($labBranch->photo)) {
                if (file_exists(public_path('image/lab/' . $profile_name))) {
                    @unlink(public_path('image/lab/' . $profile_name));
                }
                $labBranch->photo = null;
                $labBranch->save();
            }
            return success([], "Remove lab branch profile.");
        } else {
            return error("Something gone worng.");
        }
    }

    public function fetchGalleryImages(Request $request, $id)
    {
        $user = $request->user();
        // $lab = Lab::findOrFail($id);
        $lab = Lab::with(['lab_details'])->where('id', $id)->where('parent_id', $user->lab->id)->first();
        if ($lab) {
            $gallery_images = $lab->lab_details->gallery_json;
            $images = [];
            if (!empty($gallery_images)) {
                foreach ($gallery_images as $row) {
                    $name = substr($row, strrpos($row, '/') + 1);
                    $size = @filesize("image/lab_gallery/" . $name);
                    $images[] = ['name' => $name, 'size' => $size, 'path' => $row];
                }
            }
            return success($images, "Lab gallery fetch Succesfully.");
        } else {
            return error("Something gone worng.");
        }
    }

    public function galleryImagesDelete(Request $request, $id)
    {
        if (!empty($id)) {
            $user = $request->user();
            // $lab = Lab::findOrFail($id);
            $lab = Lab::with(['lab_details'])->where('id', $id)->where('parent_id', $user->lab->id)->first();
            if ($lab) {
                $gallery_images = $lab->lab_details->gallery_json;
                if ($gallery_images != null) {
                    foreach ($gallery_images as $key => $value) {
                        $name = substr($value, strrpos($value, '/') + 1);
                        $update_gallery_images[] = $name;
                    }
                    $update_gallery_images = array_filter($update_gallery_images, fn ($m) => $m != $request->name);

                    $update_gallery_images = array_values($update_gallery_images);

                    if (empty($update_gallery_images)) {
                        $lab->lab_details->gallery_json = NULL;
                    } else {
                        $update_gallery_images = $lab->lab_details->gallery_json = json_encode($update_gallery_images, true);
                    }
                    $lab->lab_details->save();
                    @unlink('image/lab_gallery/' . $request->name);
                    return success($lab, 'Remove image successfully.');
                } else {
                    return success([], "Images Not Available.");
                }
            } else {
                return error("Something gone worng.");
            }
        } else {
            @unlink(public_path('/image/lab_gallery/') . $request->name);
        }
    }

    public function getAllSingleBranchLocations(Request $request, $id)
    {
        $user = $request->user();
        $lab = Lab::where("id", $id)->where('parent_id', $user->lab->id)->first();
        if ($lab) {
            $location = LabSearch::where('lab_id', $id)->where('lab_parent_id', $user->lab->id)->orderby("id", "DESC")->get()->toArray();
            if (!empty($location)) {
                return success($location, "Get all location.");
            } else {
                return success([], "No any data stored yet.");
            }
        } else {
            return error("This Lab is not available.");
        }
    }

    public function branchlocationSave(Request $request)
    {
        $user = $request->user();
        $validator = Validator::make($request->all(), [
            'lab_id' => "required",
            'city_id' => "nullable",
            'state_id' => "nullable",
            'latitude' => "nullable|required_with:longitude",
            'longitude' => "nullable|required_with:latitude",
            'pincode' => "required_without:latitude,longitude|nullable",
        ]);
        if ($validator->fails()) {
            return error($validator->errors()->first());
        } else {
            $lab = Lab::where('id', $request->lab_id)->where('parent_id', $user->lab->id)->first();
            if ($lab) {
                $inputArr['lab_id'] = $request->lab_id;
                $inputArr['lab_parent_id'] = $lab->parent_id;
                $inputArr['pincode'] = !empty($request->pincode) ? $request->pincode : NULL;

                if (isset($request->latitude) && isset($request->longitude)) {
                    $validateLatLong = validateLatLong($request->latitude, $request->longitude);
                    if (!empty($validateLatLong)) {
                        $inputArr['latitude'] = !empty($request->latitude) ? $request->latitude : NULL;
                        $inputArr['longitude'] = !empty($request->longitude) ? $request->longitude : NULL;
                    } else {
                        return error("longitude and latitude are not valid.");
                    }
                }
                $inputArr['city_id'] = !empty($request->city_id) ? $request->city_id : NULL;
                $inputArr['state_id'] = !empty($request->state_id) ? $request->state_id : NULL;

                $duplicate = LabSearch::where($inputArr)->count();
                if ($duplicate > 0) {
                    return error("Duplicate Entry");
                } else {
                    $inputArr['name'] = $lab->name;
                    $result = LabSearch::Create($inputArr);
                    return success($result, "Lab Location has been saved successfully");
                }
            } else {
                return error("This Lab is not available.");
            }
        }
    }

    public function branchlocationDelete(Request $request, $id)
    {
        $user = $request->user();
        $labSearch = LabSearch::where("id", $id)->where('lab_parent_id', $user->lab->id)->first();
        if (!empty($labSearch)) {
            $labSearch->delete();
            return success([], "Location has been deleted successfully");
        } else {
            return error("Location has been Not found.");
        }
    }
}
