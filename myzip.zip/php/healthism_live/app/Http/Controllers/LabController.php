<?php

namespace App\Http\Controllers;

use App\Helpers\Helpers;
use App\Http\Requests\LabRequest;
use App\Models\Lab;
use App\Models\LabDetails;
use App\Models\State;
use App\Models\City;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Auth;
use Intervention\Image\ImageManagerStatic as Image;
use function Psr\Log\debug;

class LabController extends Controller {

    public function location($id) {
        $lab = Lab::findOrFail($id)->toArray();
        $location = \App\Models\LabSearch::where('lab_id', $id)->get()->toArray();
        if (Auth::user()->user_type_id == LAB) {
            return view('backend.lab_partner.branch.location', compact('lab', 'location'));
        }
        return view('backend.lab.location', compact('lab', 'location'));
    }

    public function profile(Request $request) {
        $lab = Lab::where('user_id', $request->user()->id)->first();
        $images = $lab->lab_details->gallery_json;
        return view('backend.lab_partner.profile', compact('lab', 'images'));
    }

    public function locationDelete($id) {
        $labSearch = \App\Models\LabSearch::findOrFail($id);
        if (!empty($labSearch))
            $labSearch->delete();
        return success($id, "Location has been deleted successfully");
    }

    public function locationSave(Request $request) {
        $inputArr['lab_id'] = $request->lab_id;
        $inputArr['pincode'] = $request->pincode;
        $inputArr['latitude'] = $request->latitude;
        $inputArr['longitude'] = $request->longitude;
        $duplicate = \App\Models\LabSearch::where($inputArr)->count();
        if ($duplicate > 0) {
            return error("Duplicate Entry");
        }
        $inputArr['lab_parent_id'] = !empty($request->lab_parent_id) ? $request->lab_parent_id : 0;
        $inputArr['name'] = $request->name;
//        $inputArr['city_id'] = $request->city_id;
//        $inputArr['state_id'] = $request->state_id;
        $result = \App\Models\LabSearch::Create($inputArr);
        return success($result, "Location has been saved successfully");
    }

    public function labSearch(Request $request) {
        $search = $request->get('search');
        $parentId = !empty($request->get('parent_id')) ? $request->get('parent_id') : '';
        $data = Lab::where('name', 'LIKE', '%' . $search . '%');
        if ($request->user()->user_type_id == LAB) {
            $labData = \App\Models\Lab::where('user_id', $request->user()->id)->first();
            $parentId = $labData->id;
        }
        if (!empty($parentId)) {
            $data->where('parent_id', $parentId);
        }
        $data = $data->limit(25)->get();
        $result = [];
        if (!empty($data)) {
            $lab = [];
            foreach ($data as $value) {
                $lab['label'] = $value['name'] . '(' . $value['area'] . ',' . $value['city']['name'] . ',' . $value['state']['name'] . ')';
                $lab['id'] = $value['id'];
            }
            $result[] = $lab;
        }
        return response()->json($result);
    }

    public function index(Request $request) {
        $lab = Lab::query();
        $records_per_page = 10;
        $lab->where('parent_id', '=', 0);
        if (!empty($request->name)) {
            $lab = $lab->where('name', 'like', '%' . $request->name . '%');
        }
        if (!empty($request->area)) {
            $lab = $lab->where('area', 'like', '%' . $request->area . '%');
        }
        if (!empty($request->pincode)) {
            $lab = $lab->where('pincode', 'like', '%' . $request->pincode . '%');
        }
        if (!empty($request->city_id)) {
            //$lab = $lab->whereRelation('city', 'name', 'like', '%' . $request->city . '%');
            $lab = $lab->where('city_id', "=", $request->city_id);
        }
        if (!empty($request->state_id)) {
            //   $lab = $lab->whereRelation('state', 'name', 'like', '%' . $request->state . '%');
            $lab = $lab->where('state_id', "=", $request->state_id);
        }

        if (!empty($request->records_per_page) && is_numeric($request->records_per_page)) {
            $records_per_page = $request->records_per_page;
        }
        if (!empty($request->sort_field)) {
            if ($request->sort_field == 'name' && ($request->sort_action == 'ASC' || $request->sort_action == 'DESC')) {
                $lab = $lab->orderBy("name", $request->sort_action);
            } elseif ($request->sort_field == 'Area' && ($request->sort_action == 'ASC' || $request->sort_action == 'DESC')) {
                $lab = $lab->orderBy("area", $request->sort_action);
            } elseif ($request->sort_field == 'Pincode' && ($request->sort_action == 'ASC' || $request->sort_action == 'DESC')) {
                $lab = $lab->orderBy("pincode", $request->sort_action);
            }
        } else {
            $lab = $lab->orderBy("id", "DESC");
        }

        $lab = $lab->paginate($records_per_page);
        $states = State::where('active', 1)->get();
        $cities = [];
        if (!empty($request->state_id)) {
            $cities = City::where(['active' => 1, 'state_id' => $request->state_id])->get();
        }
        if ($request->ajax()) {
            return view('backend.lab.ajax_content', compact('lab', 'states', 'cities'));
        } else {
            return view('backend.lab.index', compact('lab', 'states', 'cities'));
        }
    }

    public function bulkInsert(Request $request) {
        return view('backend.lab.import');
    }

    public function add(Request $request) {
        $input = $request->all();
        $parent_lab = "";
        if (!empty($input['lab_id'])) {
            $parent_lab = Lab::findOrFail($request->lab_id);
        } else {
            if (Auth::user()->user_type_id == LAB) {
                $parent_lab = \App\Models\Lab::where('user_id', Auth::user()->id)->first();
            }
        }
        $day_list = ['Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday', 'Saturday', 'Sunday'];
        $states = State::where('active', 1)->get();
        if (Auth::user()->user_type_id == LAB) {
            return view('backend.lab_partner.branch.add', compact('states', 'day_list', 'parent_lab'));
        }
        return view('backend.lab.add', compact('states', 'day_list', 'parent_lab'));
    }

    public function edit($id) {
        $lab = Lab::findOrFail($id);
        $day_list = ['Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday', 'Saturday', 'Sunday'];
        $states = State::where('active', 1)->get();
        $cities = City::where(['active' => 1, 'state_id' => $lab->state_id])->get();
        if (Auth::user()->user_type_id == LAB) {
            return view('backend.lab_partner.branch.edit', compact('lab', 'states', 'cities', 'day_list'));
        }
        return view('backend.lab.edit', compact('lab', 'states', 'cities', 'day_list'));
    }

    public function removeProfile($id) {
        $lab = Lab::findOrFail($id);
        $images = [];
        if ($lab->lab_details->gallery_json != 'NULL' && !empty($lab->lab_details->gallery_json)) {
            $gallery_images = json_decode($lab->lab_details->gallery_json, true);
            if (!empty($gallery_images)) {
                foreach ($gallery_images as $row) {
                    $images[] = ['name' => $row];
                }
            }
        }
        if (!empty($lab->photo)) {
            if (file_exists(public_path('image/lab/' . $lab->photo))) {
                unlink(public_path('image/lab/' . $lab->photo));
            }
            $lab->photo = null;
            $lab->save();
        }
        return view('backend.lab.view', compact('lab', 'images'));
    }

    public function view($id) {
        $lab = Lab::findOrFail($id);
        $images = !empty($lab->lab_details) ? $lab->lab_details->gallery_json : [];
        if (Auth::user()->user_type_id == LAB) {
            return view('backend.lab_partner.branch.view', compact('lab', 'images'));
        }
        return view('backend.lab.view', compact('lab', 'images'));
    }

    public function fetchGalleryImages(Request $request, $id) {
        $lab = Lab::findOrFail($id);
        $gallery_images = $lab->lab_details->gallery_json;
        $images = [];
        if (!empty($gallery_images)) {
            foreach ($gallery_images as $row) {
                $row = str_replace(getUrl('image/lab/gallery'), "", $row);
                $size = @filesize("image/lab/gallery/" . $row);
                $images[] = ['name' => $row, 'size' => $size, 'path' => "/image/lab/gallery/"];
            }
        }
        return $images;
    }

    public function galleryImagesDelete(Request $request, $id) {
        if (!empty($id)) {
            $lab = Lab::findOrFail($id);
            $gallery_images = $lab->lab_details->gallery_json;
            $result = [];
            foreach ($gallery_images as $imageName) {
                $result[] = str_replace(getUrl('image/lab/gallery/'), "", $imageName);
            }
            $gallery_images = $result;
            $gallery_images = array_filter($gallery_images, fn($m) => $m != $request->name);
            $lab->lab_details->gallery_json = json_encode($gallery_images);
            @unlink('image/lab/gallery/' . $request->name);
            $lab->lab_details->save();
        } else {
            unlink(public_path('/image/temp/') . $request->name);
        }
    }

    public function updateSortOrderGallery(Request $request, $id) {
        $lab = Lab::findOrFail($id);
        $lab->lab_details->gallery_json = json_encode(array_values($request->order_list));
        $lab->lab_details->save();
    }

    public function galleryImages(Request $request, $id) {
        if (!empty($id)) {
            $lab = Lab::findOrFail($id);

            $result = [];
            $gallery_images = $lab->lab_details->gallery_json;
            if (!empty($request->file) && in_array($request->file->extension(), allow_file_type_uploads)) {
                $image = $request->file('file');
                $imageName = seo_url("healthism  {$lab->name}") . '.' . $request->file->extension();
                $image_resize = Image::make($image->getRealPath());
                $image_resize->resize(800, null, function ($constraint) {
                    $constraint->aspectRatio();
                });
                $image_resize->save(public_path('image/lab/gallery/' . $imageName));
                $gallery_images[] = $imageName;
                foreach ($gallery_images as $imageName) {
                    $result[] = str_replace(getUrl('image/lab/gallery/'), "", $imageName);
                }
            }
            echo $imageName;
            $lab->lab_details->gallery_json = json_encode(array_values($result));
            $lab->lab_details->save();
        } else {
            if (!empty($request->file) && in_array($request->file->extension(), allow_file_type_uploads)) {
                $image = $request->file('file');
                $fileName = pathinfo($request->file->getClientOriginalName(), PATHINFO_FILENAME);
                $imageName = seo_url($fileName) . '.' . $request->file->extension();
                $image_resize = Image::make($image->getRealPath());
                $image_resize->resize(800, null, function ($constraint) {
                    $constraint->aspectRatio();
                });
                $image_resize->save(public_path('/image/temp/' . $imageName));
                echo $imageName;
            }
        }
    }

    public function update(LabRequest $request, $id) {
        $lab = Lab::findOrFail($id);
        $deleteConditionArr['lab_id'] = $lab->id;
        $deleteConditionArr['pincode'] = $lab->pincode;
        $deleteConditionArr['latitude'] = $lab->latitude;
        $deleteConditionArr['longitude'] = $lab->longitude;

        $lab->contact_person = $request->contact_person;
        $lab->user_id = !empty($request->user) ? $request->user_id : null;
        $lab->parent_id = !empty($request->parent_id) ? $request->parent_id : 0;
        $lab->name = $request->name;
        $lab->phone = $request->phone;
        $lab->email = $request->email;
        $lab->address1 = $request->address1;
        $lab->address2 = $request->address2;
        $lab->area = $request->area;
        $lab->pincode = $request->pincode;
        $lab->city_id = $request->city_id;
        $lab->state_id = $request->state_id;
        $lab->mobile = $request->mobile;
        $lab->discount = $request->discount;
        $lab->virtual_location = $request->virtual_location == 'on' ? 1 : 0;
        $validateLatLong = validateLatLong($request->latitude, $request->longitude);
        $errorMessageLetLong = "";
        if (!empty($validateLatLong)) {
            $lab->latitude = $request->latitude;
            $lab->longitude = $request->longitude;
        } else {
            $errorMessageLetLong .= 'longitude and latitude are not valid';
        }
        $lab->discount = $request->discount;
        $lab->status_id = !empty($request->status_id) ? $request->status_id : STATUS_ACTIVE;

        /*
         *  details
         */
        $lab->cash_booking_allowed = $request->cash_booking_allowed == 'on' ? 1 : 0;
        $lab->cancellation_allowed = $request->cancellation_allowed == 'on' ? 1 : 0;
        if (!empty($request->cancel_policy)) {
            $cancel_policy = [];
            foreach ($request->cancel_policy as $key => $val) {
                if (!empty($val['cancel_policy'])) {
                    $cancel_policy[] = $val['cancel_policy'];
                }
            }
            if (!empty($cancel_policy)) {
                $lab->cancel_policy = json_encode($cancel_policy);
            }
        } else {
            $lab->cancel_policy = null;
        }
        if (!empty($request->cancel_policy_setting)) {
            $cancelPolicySetting = [];
            foreach ($request->cancel_policy_setting as $value) {
                if (!empty($value['hours']) && !empty($value['charge'])) {
                    $cancelPolicySetting[] = $value;
                }
            }
            if (!empty($cancelPolicySetting)) {
                $lab->cancel_policy_setting = json_encode($cancelPolicySetting);
            }
        } else {
            $lab->cancel_policy_setting = null;
        }
        $multipleLocation = [];
        $lab->lab_details->timing_json = !empty($request->slot_data_obj) ? $request->slot_data_obj : null;
        $lab->lab_details->description = $request->description;
        $lab->lab_details->pancard_number = strtoupper($request->pancard_number);
        $lab->lab_details->gst_number = strtoupper($request->gst_number);
        $lab->lab_details->bank_account_number = $request->bank_account_number;
        $lab->lab_details->bank_account_name = $request->bank_account_name;
        $lab->lab_details->bank_name = $request->bank_name;
        $lab->lab_details->bank_ifsc_code = strtoupper($request->bank_ifsc_code);
        if (!empty($request->photo) && in_array($request->photo->extension(), allow_file_type_uploads)) {
            $image = $request->file('photo');
            $imageName = seo_url("healthism {$request->name}") . '.' . $request->photo->extension();
            $image_resize = Image::make($image->getRealPath());
            $image_resize->resize(800, null, function ($constraint) {
                $constraint->aspectRatio();
            });
            $image_resize->save(public_path('image/lab/' . $imageName));
            $lab->photo = $imageName;
        }

        if (!empty($request->pancard_document)) {
            $imageName = seo_url("pan healthism {$request->name}") . '.' . $request->pancard_document->extension();
            $imageName = change_filename("image/lab/pan", $imageName);

            if ($request->pancard_document->move(public_path('image/lab/pan'), $imageName)) {
                if (!empty($lab->lab_details->pancard_document)) {
                    @unlink('image/lab/pan/' . $lab->lab_details->pancard_document);
                }
            }
            $lab->lab_details->pancard_document = $imageName;
        }

        if (!empty($request->gst_certificate)) {
            $imageName = seo_url("gst healthism {$request->name}") . '.' . $request->gst_certificate->extension();
            $imageName = change_filename("image/lab/gst/", $imageName);

            if ($request->gst_certificate->move(public_path('image/lab/gst'), $imageName)) {
                if (!empty($lab->lab_details->gst_certificate)) {
                    @unlink('image/lab/gst/' . $lab->lab_details->gst_certificate);
                }
            }
            $lab->lab_details->gst_certificate = $imageName;
        }

        if (!empty($request->nabl_document)) {
            $imageName = seo_url("nabl healthism {$request->name}") . '.' . $request->nabl_document->extension();
            $imageName = change_filename("image/lab/nabl/", $imageName);

            if ($request->nabl_document->move(public_path('image/lab/nabl'), $imageName)) {
                if (!empty($lab->lab_details->nabl_document)) {
                    @unlink('image/lab/nabl/' . $lab->lab_details->nabl_document);
                }
            }
            $lab->lab_details->nabl_document = $imageName;
        }

        if (!empty($request->mou_document)) {
            $imageName = seo_url("mou healthism {$request->name}") . '.' . $request->mou_document->extension();
            $imageName = change_filename("image/lab/mou/", $imageName);
            if ($request->mou_document->move(public_path('image/lab/mou'), $imageName)) {
                if (!empty($lab->lab_details->mou_document)) {
                    @unlink('image/lab/mou/' . $lab->lab_details->mou_document);
                }
            }
            $lab->lab_details->mou_document = $imageName;
        }
        $lab->lab_details->save();
        $lab->save();
        if (Auth::user()->user_type_id == LAB) {
            if (!empty($errorMessageLetLong)) {
                return redirect()->route('lab.view', $lab->id)->with('error', $errorMessageLetLong);
            }
            return redirect()->route('lab.view', $lab->id)->with('success', 'Lab Details Updated Successfully!');
        }
        if (!empty($errorMessageLetLong)) {
            return redirect()->route('admin.lab.view', $lab->id)->with('error', $errorMessageLetLong);
        }
        return redirect()->route('admin.lab.view', $lab->id)->with('success', 'Lab Details Updated Successfully!');
    }

    public function store(LabRequest $request) {
        $lab = new Lab;
        $labDetails = new LabDetails();
        $gallery_images = [];
        if (!empty($request->images_list)) {
            foreach ($request->images_list as $row) {
                $fileName = explode(".", $row);
                $imageName = seo_url("healthism  $request->name {$fileName[0]}") . "." . $fileName[1];
                $imageName = change_filename("image/lab/", $imageName);
                copy(public_path("/image/temp/{$row}"), public_path('image/lab/gallery/' . $imageName));
                $gallery_images[] = $imageName;
            }
            $labDetails->gallery_json = json_encode(array_values($gallery_images));
        }
        $lab->contact_person = $request->contact_person;
        $lab->user_id = !empty($request->user) ? $request->user_id : null;
        $lab->parent_id = !empty($request->parent_id) ? $request->parent_id : 0;
        $lab->self_test_available = 0;
        $lab->name = $request->name;
        $lab->phone = $request->phone;
        $lab->mobile = $request->mobile;
        $lab->email = $request->email;
        $lab->address1 = $request->address1;
        $lab->address2 = $request->address2;
        $lab->area = $request->area;
        $lab->pincode = $request->pincode;
        $lab->city_id = $request->city_id;
        $lab->state_id = $request->state_id;
        $lab->discount = $request->discount;
        $lab->virtual_location = $request->virtual_location == 'on' ? 1 : 0;
        $validateLatLong = validateLatLong($request->latitude, $request->longitude);
        $errorMessageLetLong = "";
        if (!empty($validateLatLong)) {
            $lab->latitude = $request->latitude;
            $lab->longitude = $request->longitude;
        } else {
            $errorMessageLetLong .= 'longitude and latitude are not valid';
        }
        $lab->discount = $request->discount;
        $lab->status_id = !empty($request->status_id) ? $request->status_id : STATUS_ACTIVE;

        /*
         * details
         */
        $lab->cash_booking_allowed = $request->cash_booking_allowed == 'on' ? 1 : 0;
        $lab->cancellation_allowed = $request->cancellation_allowed == 'on' ? 1 : 0;
        if (!empty($request->cancel_policy)) {
            $cancel_policy = [];
            foreach ($request->cancel_policy as $key => $val) {
                if (!empty($val['cancel_policy'])) {
                    $cancel_policy[] = $val['cancel_policy'];
                }
            }
            if (!empty($cancel_policy)) {
                $lab->cancel_policy = json_encode($cancel_policy);
            }
        }
        if (!empty($request->cancel_policy_setting)) {
            $cancelPolicySetting = [];
            foreach ($request->cancel_policy_setting as $value) {
                if (!empty($value['hours']) && !empty($value['charge'])) {
                    $cancelPolicySetting[] = $value;
                }
            }
            if (!empty($cancelPolicySetting)) {
                $lab->cancel_policy_setting = json_encode($cancelPolicySetting);
            }
        }
        $labDetails->timing_json = !empty($request->slot_data_obj) ? $request->slot_data_obj : null;
        $labDetails->description = $request->description;
        $labDetails->pancard_number = strtoupper($request->pancard_number);
        $labDetails->gst_number = strtoupper($request->gst_number);
        $labDetails->bank_account_number = $request->bank_account_number;
        $labDetails->bank_account_name = $request->bank_account_name;
        $labDetails->bank_name = $request->bank_name;
        $labDetails->bank_ifsc_code = strtoupper($request->bank_ifsc_code);

        $multipleLocation = [];
        if (!empty($validateLatLong)) {
            $multipleLocation = [
                'pincode' => $request->pincode,
                'latitude' => $request->latitude,
                'longitude' => $request->longitude
            ];
        }
        if (!empty($request->photo) && in_array($request->photo->extension(), allow_file_type_uploads)) {
            $image = $request->file('photo');
            $imageName = seo_url("healthism {$request->name}") . '.' . $request->photo->extension();
            $image_resize = Image::make($image->getRealPath());
            $image_resize->resize(800, null, function ($constraint) {
                $constraint->aspectRatio();
            });
            $image_resize->save(public_path('image/lab/' . $imageName));
            $lab->photo = $imageName;
        }

        if (!empty($request->pancard_document)) {
            $imageName = seo_url("pan healthism {$request->name}") . '.' . $request->pancard_document->extension();
            $imageName = change_filename("image/lab/pan/", $imageName);
            if ($request->pancard_document->move(public_path('image/lab/pan'), $imageName)) {
                $labDetails->pancard_document = $imageName;
            }
        }

        if (!empty($request->gst_certificate)) {
            $imageName = seo_url("gst healthism {$request->name}") . '.' . $request->gst_certificate->extension();
            $imageName = change_filename("image/lab/gst/", $imageName);
            if ($request->gst_certificate->move(public_path('image/lab/gst'), $imageName)) {
                $labDetails->gst_certificate = $imageName;
            }
        }
        if (!empty($request->nabl_document)) {
            $imageName = seo_url("nabl healthism {$request->name}") . '.' . $request->nabl_document->extension();
            $imageName = change_filename("image/lab/nabl/", $imageName);
            if ($request->nabl_document->move(public_path('image/lab/nabl'), $imageName)) {
                $labDetails->nabl_document = $imageName;
            }
        }
        if (!empty($request->mou_document)) {
            $imageName = seo_url("mou healthism {$request->name}") . '.' . $request->mou_document->extension();
            $imageName = change_filename("image/lab/mou/", $imageName);
            if ($request->mou_document->move(public_path('image/lab/mou'), $imageName)) {
                $labDetails->mou_document = $imageName;
            }
        }

        $lab->save();
        $labDetails->lab_id = $lab->id;
        $labDetails->save();
        if (Auth::user()->user_type_id == LAB) {
            if (!empty($errorMessageLetLong)) {
                return redirect()->route('lab.view', $lab->id)->with('error', $errorMessageLetLong);
            }
            return redirect()->route('lab.view', $lab->id)->with('success', 'Lab Details Added Successfully!');
        }
        if (!empty($errorMessageLetLong)) {
            return redirect()->route('admin.lab.view', $lab->id)->with('error', $errorMessageLetLong);
        }
        return redirect()->route('admin.lab.view', $lab->id)->with('success', 'Lab Details Added Successfully!');
    }

    private function addSearchData($lab, $multipleLocation) {
        $searchData = array(
            'lab_id' => $lab->id,
            'name' => $lab->name,
            'city_id' => $lab->city_id,
            'state_id' => $lab->state_id
        );
        if (!empty($multipleLocation)) {
            $searchData['pincode'] = $multipleLocation['pincode'];
            $searchData['latitude'] = $multipleLocation['latitude'];
            $searchData['longitude'] = $multipleLocation['longitude'];
            $multipleLocation['lab_id'] = $lab->id;
            $duplicate = \App\Models\LabSearch::where($multipleLocation)->count();
            if ($duplicate > 0) {
                return false;
            } else {
                \App\Models\LabSearch::insert($searchData);
            }
        }
    }

    public function delete(Request $request) {
        $input = $request->all();
        if (empty($input['lab_id'])) {
            return error('Sorry, Id is empty.');
        }
        $lab = Lab::findOrFail($input['lab_id']);
        if (!empty($lab)) {
            $booking = \App\Models\LabBooking::where('lab_id', $input['lab_id'])->count();
            if ($booking == 0) {
                if (!empty($lab->photo)) {
                    @unlink('image/lab/' . $lab->photo);
                }
                if (!empty($lab->lab_details->gst_certificate)) {
                    @unlink('image/lab/gst/' . $lab->lab_details->gst_certificate);
                }
                if (!empty($lab->lab_details->pancard_document)) {
                    @unlink('image/lab/pan/' . $lab->lab_details->pancard_document);
                }
                if (!empty($lab->lab_details->mou_document)) {
                    @unlink('image/lab/mou/' . $lab->lab_details->mou_document);
                }
                if (!empty($lab->lab_details->nabl_document)) {
                    @unlink('image/lab/nabl/' . $lab->lab_details->nabl_document);
                }
                $lab->delete();
                LabDetails::where('lab_id', $input['lab_id'])->delete();
                \App\Models\LabSlot::where('lab_id', $input['lab_id'])->delete();
                \App\Models\LabBlockSlot::where('lab_id', $input['lab_id'])->delete();
                \App\Models\LabTest::where('lab_id', $input['lab_id'])->delete();
                \App\Models\LabSearch::where('lab_id', $input['lab_id'])->delete();
                \App\Models\ReportProblem::where('ref_id', $input['lab_id'])->where('service_id', SERVICE_LAB_REPORT)->delete();
                \App\Models\UserReview::where('ref_id', $input['lab_id'])->where('service_id', SERVICE_LAB_REPORT)->delete();
            } else {
                return error('Sorry, Lab has too many booking');
            }
        }
        return success(array(), 'Lab has been deleted successfully!');
    }

    public function labUserSearch(Request $request) {
        $search = $request->get('search');
        $type = $request->get('type');
        $data = \App\Models\User::select(DB::raw("CONCAT(user.first_name,' ',user.last_name,' (', user.email,' - ', user.mobile,')') as label"), "id", DB::raw("CONCAT(user.first_name,' ',user.last_name) as value"))
                        ->where('user_type_id', $type)
                        ->where(function ($data) use ($search) {
                            return $data->where('first_name', 'LIKE', '%' . $search . '%')
                                    ->orwhere('last_name', 'LIKE', '%' . $search . '%')
                                    ->orwhere('mobile', 'LIKE', '%' . $search . '%');
                        })->limit(10)->get();
        if (!empty($data)) {
            foreach ($data as $key => $value) {
                $labUser = Lab::where('user_id', $value['id'])->where('status_id', STATUS_ACTIVE)->count();
                if ($labUser > 0) {
                    unset($data[$key]);
                }
            }
        }
        return response()->json($data);
    }

    public function labBranch(Request $request) {
        $lab_branch = Lab::query();
        $records_per_page = 10;
        $parentId = 0;
        if (Auth::user()->user_type_id == LAB) {
            $lab = \App\Models\Lab::where('user_id', Auth::user()->id)->first();
            if (!empty($lab)) {
                $parentId = $lab->id;
            }
        } else {
            if (!empty($request->lab_id)) {
                $parentId = $request->lab_id;
            }
        }
        $lab_branch = $lab_branch->where('parent_id', '=', $parentId);
        if (!empty($request->name)) {
            $lab_branch = $lab_branch->where('name', 'like', '%' . $request->name . '%');
        }
        if (!empty($request->phone)) {
            $lab_branch = $lab_branch->where('phone', 'like', '%' . $request->phone . '%');
        }
        if (!empty($request->pincode)) {
            $lab_branch = $lab_branch->where('pincode', 'like', '%' . $request->pincode . '%');
        }
        if (!empty($request->city_id)) {
            $lab_branch = $lab_branch->where('city_id', "=", $request->city_id);
        }
        if (!empty($request->state_id)) {
            $lab_branch = $lab_branch->where('state_id', "=", $request->state_id);
        }

        if (!empty($request->records_per_page) && is_numeric($request->records_per_page)) {
            $records_per_page = $request->records_per_page;
        }

        $lab_branch = $lab_branch->orderBy("id", "DESC");
        $lab_branch = $lab_branch->paginate($records_per_page);
        $states = State::where('active', 1)->get();
        $cities = [];
        $lab = Lab::findOrFail($parentId);
        if (!empty($request->state_id)) {
            $cities = City::where(['active' => 1, 'state_id' => $request->state_id])->get();
        }
        if (Auth::user()->user_type_id == ADMIN) {
            if ($request->ajax()) {
                return view('backend.lab.branch_content', compact('lab_branch', 'states', 'cities', 'lab'));
            } else {
                return view('backend.lab.branch', compact('lab_branch', 'states', 'cities', 'lab'));
            }
        }
        if (Auth::user()->user_type_id == LAB) {
            if ($request->ajax()) {
                return view('backend.lab_partner.branch.ajax_content', compact('lab_branch', 'states', 'cities', 'lab'));
            } else {
                return view('backend.lab_partner.branch.index', compact('lab_branch', 'states', 'cities', 'lab'));
            }
        }
    }

    public function slotList(Request $request) {
        $input = $request->all();
        if (empty($input['id'])) {
            return false;
        }
        $order = \App\Models\LabBooking::findOrFail($input['id']);
        $weekOfdays = array();
        $noOfDay = 15;
        for ($i = 0; $i <= $noOfDay; $i++) {
            $date = date('Y-m-d'); //today date
            $date = date('Y-m-d', strtotime('+' . $i . ' day', strtotime($date)));

            $day = date('D', strtotime($date));
            $date = date('Y-m-d', strtotime($date));
            $checkDateBlock = \App\Models\LabBlockSlot::where('lab_id', $order->lab_id)
                    ->where('date', $date)
                    ->whereNull('lab_slot_id')
                    ->count();
            if (empty($checkDateBlock)) {
                $slot = $this->getSlotByDay($order, $day, $date);
                $slotCount = count($slot) > 0 ? count($slot) : 0;
                if ($slotCount != 0) {
                    $weekOfdays[] = array(
                        "day" => $day,
                        "date" => $date,
                        "slot_count" => $slotCount,
                        "slot" => $slot,
                    );
                }
            }
        }
        if ($request->user()->user_type_id == ADMIN) {
            return view('backend.lab_orders.slot', compact('order', 'weekOfdays'));
        } else {
            return view('backend.lab_partner.orders.slot', compact('order', 'weekOfdays'));
        }
    }

    private function getSlotByDay($order, $day, $date) {
        try {
            $query = "SELECT
                        ls.*,
                        ls.id AS slot_id
                FROM
                        lab_slot AS ls 
                WHERE
                        ls.lab_id = " . $order->lab_id;
            if ($order->is_home_collection == 0) {
                //Report at lab
                $query .= " AND ls.is_offline = 1";
            }
            if ($order->is_home_collection == 1) {
                //Home collection
                $query .= " AND ls.is_home_collection = 1";
            }
            $query .= " AND ls.status_id = " . STATUS_ACTIVE . "
                        AND ls.`day` = '" . $day . "' 
                        AND (
                                ls.id NOT IN ( 
                                SELECT lab_slot_id FROM lab_block_slot
                                WHERE date = '" . $date . "'
                            )
                        )";
            if ($date == date('Y-m-d')) {
                $query .= " AND ls.from_time >= '" . date('H:i:s') . "'";
            }
            $query .= " ORDER BY 
                            ls.from_time ASC";

            //For to time to greter : AND ls.from_time >= '" . date('H:i:s') . "'
            return executeSelectQueryOnMySQLDB($query);
        } catch (Exception $exc) {
            errorLog($exc);
        }
        return error(COMMON_ERROR);
    }

    public function labList(Request $request) {
        $lab = Lab::query();
        if (!empty($request->name)) {
            $lab->where('name', 'like', '%' . $request->name . '%');
        }
        if (!empty($request->area)) {
            $lab->where('area', 'like', '%' . $request->area . '%');
        }
        if (!empty($request->pincode)) {
            $lab->whereRelation('lab_search', 'pincode', '=', trim($request->pincode));
            // $lab->where('pincode', '=', $request->pincode);
        }
        $lab->where('status_id', '=', STATUS_ACTIVE);
        $lab->limit(30);
        $result = $lab->with('city', 'state')->get();
        return success($result, "Lab List");
    }

}
