<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

class HospitalDetailsController extends Controller {
    //
}
