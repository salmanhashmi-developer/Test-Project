<?php

namespace App\Http\Controllers;

use App\Http\Controllers\Controller;
use Illuminate\Support\Facades\Auth;
use App\Models\UserReview;
use Illuminate\Http\Request;

class UserReviewController extends Controller {

    public function index(Request $request) {
        $userReview = UserReview::query();
        $records_per_page = 5;
        if (!empty($request->user_id) && is_numeric($request->user_id)) {
            $userReview->where('user_id', '=', trim($request->user_id));
        }
        if (!empty($request->service_id) && is_numeric($request->service_id)) {
            $userReview->where('service_id', '=', trim($request->service_id));
        }
        if (!empty($request->rating) && is_numeric($request->rating)) {
            $userReview->where('rating', '=', trim($request->rating));
        }
        $userReview->orderBy("id", 'DESC');
        if (!empty($request->records_per_page) && is_numeric($request->records_per_page)) {
            $records_per_page = $request->records_per_page;
        }
        $userReview = $userReview->paginate($records_per_page);
        if (!empty($userReview)) {
            foreach ($userReview as $key => $value) {
                if (!empty($value['ref_id']) && !empty($value['service_id'])) {
                    $refData['title1'] = $refData['title2'] = $refData['title3'] = "";
                    if ($value['service_id'] == SERVICE_DOCTOR_APPOINTMENT) {
                        $refDetail = \App\Models\Doctor::findOrFail($value['ref_id']);
                        if (!empty($refDetail)) {
                            $refData['title1'] = $refDetail['first_name'] . ' ' . $refDetail['last_name'];
                            $refData['title2'] = $refDetail['phone'];
                            $refData['title3'] = $refDetail['specialization'];
                        }
                    }
                    if ($value['service_id'] == SERVICE_LAB_REPORT) {
                        $refDetail = \App\Models\Lab::findOrFail($value['ref_id']);
                        if (!empty($refDetail)) {
                            $refData['title1'] = $refDetail['name'];
                            $refData['title2'] = $refDetail['phone'];
                            $refData['title3'] = $refDetail['area'] . " - " . $refDetail->city->name;
                        }
                    }
                    if ($value['service_id'] == SERVICE_SUBSCRIPTION_PLAN) {
                        $refDetail = \App\Models\Subscription::findOrFail($value['ref_id']);
                        if (!empty($refDetail)) {
                            $refData['title1'] = $refDetail['name'];
                            $refData['title2'] = $refDetail['member'] . ' Member plan for ' . $refDetail['validity_in_days'] . ' Days';
                            $refData['title3'] = 'Price : ' . $refDetail['price'];
                        }
                    }
                    if ($value['service_id'] == SERVICE_COMMON) {
                        $refDetail = \App\Models\CommonService::findOrFail($value['ref_id']);
                        if (!empty($refDetail)) {
                            $refData['title1'] = $refDetail['name'] . '(' . $refDetail->category->name . ')';
                            $refData['title2'] = $refDetail['phone'];
                            $refData['title3'] = $refDetail['area'] . "," . $refDetail->city->name;
                        }
                    }
                    if ($value['service_id'] == MENU_BASED_SERVICE) {
                        $refDetail = \App\Models\MenuBasedService::findOrFail($value['ref_id']);
                        if (!empty($refDetail)) {
                            $refData['title1'] = $refDetail['name'] . '(' . $refDetail->category->name . ')';
                            $refData['title2'] = $refDetail['phone'];
                            $refData['title3'] = $refDetail['area'] . "," . $refDetail->city->name;
                        }
                    }
                    if ($value['service_id'] == SUBSCRIPTION_BASED_SERVICE) {
                        $refDetail = \App\Models\SubscriptionBasedService::findOrFail($value['ref_id']);
                        if (!empty($refDetail)) {
                            $refData['title1'] = $refDetail['name'] . '(' . $refDetail->category->name . ')';
                            $refData['title2'] = $refDetail['phone'];
                            $refData['title3'] = $refDetail['area'] . "," . $refDetail->city->name;
                        }
                    }
                    $userReview[$key]['ref_data'] = $refData;
                }
            }
        }
        $ratingList = [1, 2, 3, 4, 5];
        $service = \App\Models\Service::all();
        if ($request->ajax()) {
            return view('backend.user_review.ajax_content', compact('userReview', 'ratingList', 'service'));
        } else {
            return view('backend.user_review.index', compact('userReview', 'ratingList', 'service'));
        }
    }

    public function adminUpdateReview(Request $request) {
        $input = $request->all();
        $review = UserReview::findOrFail($input['review_id']);
        if (!empty($review)) {
            if ($review->status_id != $input['status_id']) {
                $review->fill(['status_id' => $input['status_id']])->save();
            }
        }
        return success(array(), 'Review updated successfully!');
    }

    public function adminDeleteReview(Request $request) {
        $input = $request->all();
        $review = UserReview::findOrFail($input['review_id']);
        if (!empty($review)) {
            $review->delete();
        }
        return success(array(), 'Review deleted successfully!');
    }

    public function partnerReviewList(Request $request) {
        $userReview = UserReview::query();
        $records_per_page = 5;
        $serviceId = getServiceFromUserType(Auth::user()->user_type_id);
        $refId = 0;
        if (!empty($request->refId)) {
            $refId = $request->refId;
        } else {
            if ($serviceId == SERVICE_LAB_REPORT) {
                $data = \App\Models\Lab::where('user_id', Auth::user()->id)->first();
            }
            if ($serviceId == MENU_BASED_SERVICE) {
                $data = \App\Models\MenuBasedService::where('user_id', Auth::user()->id)->first();
            }
            if ($serviceId == SUBSCRIPTION_BASED_SERVICE) {
                $data = \App\Models\SubscriptionBasedService::where('user_id', Auth::user()->id)->first();
            }
            if (!empty($data)) {
                $refId = $data->id;
            }
        }
        $userReview->where('service_id', '=', $serviceId);
        $userReview->where('ref_id', '=', $refId);
        if (!empty($request->rating) && is_numeric($request->rating)) {
            $userReview->where('rating', '=', trim($request->rating));
        }
        if (!empty($request->status_id) && is_numeric($request->status_id)) {
            $userReview->where('status_id', '=', trim($request->status_id));
        }
        if (!empty($request->start_date)) {
            $userReview->whereDate('created_at', '>=', date('Y-m-d', strtotime($request->start_date)));
        }
        if (!empty($request->end_date)) {
            $userReview->whereDate('created_at', '<=', date('Y-m-d', strtotime($request->end_date)));
        }
        $userReview->orderBy("id", 'DESC');
        if (!empty($request->records_per_page) && is_numeric($request->records_per_page)) {
            $records_per_page = $request->records_per_page;
        }
        $userReview = $userReview->paginate($records_per_page);
        $ratingList = [1, 2, 3, 4, 5];
        $statusList = [
            ['id' => 2, 'name' => 'INACTIVE'],
            ['id' => 7, 'name' => 'APPROVED'],
            ['id' => 10, 'name' => 'CANCELLED'],
        ];
        if (Auth::user()->user_type_id == LAB) {
            if ($request->ajax()) {
                return view('backend.lab_partner.user_review.ajax_content', compact('userReview', 'ratingList', 'refId', 'statusList'));
            } else {
                return view('backend.lab_partner.user_review.index', compact('userReview', 'ratingList', 'refId', 'statusList'));
            }
        }
        if (Auth::user()->user_type_id == MBS_USER) {
            if ($request->ajax()) {
                return view('backend.menu_based_service_partner.user_review.ajax_content', compact('userReview', 'ratingList', 'refId', 'statusList'));
            } else {
                return view('backend.menu_based_service_partner.user_review.index', compact('userReview', 'ratingList', 'refId', 'statusList'));
            }
        }
        if (Auth::user()->user_type_id == SBS_USER) {
            if ($request->ajax()) {
                return view('backend.subscription_based_service_partner.user_review.ajax_content', compact('userReview', 'ratingList', 'refId', 'statusList'));
            } else {
                return view('backend.subscription_based_service_partner.user_review.index', compact('userReview', 'ratingList', 'refId', 'statusList'));
            }
        }
    }

    public function partnerReviewView($id) {
        $userReview = UserReview::findOrFail($id);
        if (Auth::user()->user_type_id == LAB) {
            return view('backend.lab_partner.user_review.view', compact('userReview'));
        }
        if (Auth::user()->user_type_id == MBS_USER) {
            return view('backend.menu_based_service_partner.user_review.view', compact('userReview'));
        }
        if (Auth::user()->user_type_id == SBS_USER) {
            return view('backend.subscription_based_service_partner.user_review.view', compact('userReview'));
        }
    }

    public function partnerReviewUpdate(Request $request, $id) {
        $input = $request->all();
        $review = UserReview::findOrFail($id);
        $review->reply = $request->reply;
        $review->replied_at = date('Y-m-d H:i:s');
        $review->save();
        if (Auth::user()->user_type_id == LAB) {
            return redirect()->route('lab.review.view', $review->id)->with('success', 'Reply Successfully!');
        }
        if (Auth::user()->user_type_id == MBS_USER) {
            return redirect()->route('mbs.review.view', $review->id)->with('success', 'Reply Successfully!');
        }
        if (Auth::user()->user_type_id == SBS_USER) {
            return redirect()->route('sbs.review.view', $review->id)->with('success', 'Reply Successfully!');
        }
    }

}
