<?php

namespace App\Http\Controllers;

use App\Helpers\Helpers;
use Illuminate\Http\Request;
use App\Models\UserPatientMapping;

class UserPatientMappingController extends Controller {

    public function index(Request $request) {
        $userPatientMapping = UserPatientMapping::query();
        $records_per_page = 10;
        if (!empty($request->mobile)) {
            $userPatientMapping->where('mobile', '=', trim($request->mobile));
        }
        if (!empty($request->user_id) && is_numeric($request->user_id)) {
            $userPatientMapping->where('user_id', '=', trim($request->user_id));
        }
        if (!empty($request->blood_group)) {
            $userPatientMapping->where('blood_group', '=', trim($request->blood_group));
        }
        $userPatientMapping->orderBy("id", 'DESC');
        if (!empty($request->records_per_page) && is_numeric($request->records_per_page)) {
            $records_per_page = $request->records_per_page;
        }
        $userPatientMapping = $userPatientMapping->paginate($records_per_page);
        $bloodGroupList = Helpers::getEnumValues('user_patient_mapping', 'blood_group');
        if ($request->ajax()) {
            return view('backend.user_patient.ajax_content', compact('userPatientMapping', 'bloodGroupList'));
        } else {
            return view('backend.user_patient.index', compact('userPatientMapping', 'bloodGroupList'));
        }
    }

    public function store(Request $request) {
        $rules = UserPatientMapping::$rules;
        if (sizeof($rules) > 0) {
            $validation = $this->validateRequest($request, $rules);
            if (!empty($validation)) {
                return error($validation);
            }
        }
        $input = $request->all();
        $input['status_id'] = STATUS_ACTIVE;
        $input['first_name'] = ucwords($input['first_name']);
        $input['last_name'] = ucwords($input['last_name']);
        $input['created_at'] = date('Y-m-d H:i:s');
        if (!empty($input['dob'])) {
            $input['dob'] = date_format(date_create($input['dob']), "Y-m-d");
        }
        $result = UserPatientMapping::create($input);
        return success($result, "User patient has been saved successfully");
    }

}
