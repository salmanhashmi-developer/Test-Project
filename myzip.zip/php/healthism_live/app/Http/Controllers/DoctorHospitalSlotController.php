<?php

namespace App\Http\Controllers;

use App\Helpers\Helpers;
use App\Models\Hospital;
use App\Models\Doctor;
use App\Models\DoctorHospitalSlot;
use Illuminate\Http\Request;

class DoctorHospitalSlotController extends Controller {

    public function index(Request $request) {
        if (!empty($request->id)) {
            $mapping = \App\Models\DoctorHospitalMapping::findOrFail($request->id);
        }
        $slot = DoctorHospitalSlot::query();
        if (!empty($mapping->doctor_id)) {
            $slot->where('doctor_id', $mapping->doctor_id);
        }
        if (!empty($mapping->hospital_id)) {
            $slot->where('hospital_id', $mapping->hospital_id);
        }
        if (!empty($mapping)) {
            $slot->orderBy('day','ASC');
            $slot->orderBy('from_time','ASC');
            $slot = $slot->get();
        }
        $slotData = [];
        if (!empty($slot)) {
            foreach ($slot as $key => $value) {
                $fromTime = substr($value['from_time'], 0, -3);
                $slotData[$value['day']][$fromTime] = [
                    'id' => $value['id'],
                    'startTime' => $fromTime,
                    'endTime' => substr($value['to_time'], 0, -3),
                    'videoAvailable' => $value['is_video'],
                    'offlineAvailable' => $value['is_offline'],
                ];
            }
        }
        $mapping->slot = empty($slotData) ? '' : json_encode($slotData);
        //pr($mapping);
        return view('backend.doctor_hospital_mapping.add_slot', compact('mapping'));
    }

    public function store(Request $request) {
        $input = $request->all();
        if (empty($input['slot_data_obj'])) {
            return redirect()->route('admin.doctor.hospital.slot', '')->with('error', 'Slot object is empty');
        }
        if (empty($input['hospital_id'])) {
            return redirect()->route('admin.doctor.hospital.slot', '')->with('error', 'hospital_id is empty');
        }
        if (empty($input['doctor_id'])) {
            return redirect()->route('admin.doctor.hospital.slot', '')->with('error', 'doctor_id is empty');
        }
        if (!empty($input['delete_slot_data_obj'])) {
            $deleteSlotArr = json_decode($input['delete_slot_data_obj'], TRUE);
            if (!empty($deleteSlotArr)) {
                DoctorHospitalSlot::whereIn('id', $deleteSlotArr)->delete();
            }
        }
        $slotArr = json_decode($input['slot_data_obj'], TRUE);
        if (!empty($slotArr)) {
            $insertData = [];
            foreach ($slotArr as $key => $day) {
                foreach ($day as $slot) {
                    if (empty($slot['id'])) {
                        $data['day'] = $key;
                        $data['is_video'] = $slot['videoAvailable'];
                        $data['is_offline'] = $slot['offlineAvailable'];
                        $data['from_time'] = $slot['startTime'];
                        $data['to_time'] = $slot['endTime'];
                        $data['hospital_id'] = $input['hospital_id'];
                        $data['doctor_id'] = $input['doctor_id'];
                        $data['status_id'] = STATUS_ACTIVE;
                        $data['created_at'] = date('Y-m-d H:i:s');
                        $data['created_by'] = $request->user()->id;
                        $insertData[] = $data;
                    }
                }
            }
            if (!empty($insertData)) {
                DoctorHospitalSlot::insert($insertData);
            }
        }

        $mapping = \App\Models\DoctorHospitalMapping::where('doctor_id', $request->doctor_id)
                ->where('hospital_id', $request->hospital_id)
                ->first();
        return redirect()->route('admin.doctor.hospital.slot', ['id' => $mapping->id])->with('success', 'Slot Details Added Successfully!');
    }

}
