<?php

namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Controller;
use App\Models\Lab;
use App\Models\LabDetails;
use App\Models\LabSearch;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Validator;
use Intervention\Image\ImageManagerStatic as Image;

class LabController extends Controller {

    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index(Request $request) {
        $lab = Lab::query();
        $records_per_page = 10;
        $lab->whereNull('parent_id');
        if (!empty($request->name)) {
            $lab = $lab->where('name', 'like', '%' . $request->name . '%');
        }
        if (!empty($request->phone)) {
            $lab = $lab->where('phone', 'like', '%' . $request->phone . '%')->orWhere('mobile', 'like', '%' . $request->phone . '%');
        }
        if (!empty($request->pincode)) {
            $lab = $lab->where('pincode', 'like', '%' . $request->pincode . '%');
        }
        if (!empty($request->area)) {
            $lab = $lab->where('area', 'like', '%' . $request->pincode . '%');
        }
        if (!empty($request->city_id)) {
            //$lab = $lab->whereRelation('city', 'name', 'like', '%' . $request->city . '%');
            $lab = $lab->where('city_id', "=", $request->city_id);
        }
        if (!empty($request->state_id)) {
            //   $lab = $lab->whereRelation('state', 'name', 'like', '%' . $request->state . '%');
            $lab = $lab->where('state_id', "=", $request->state_id);
        }
        if (!empty($request->status_id)) {
            //   $lab = $lab->whereRelation('state', 'name', 'like', '%' . $request->state . '%');
            $lab = $lab->where('status_id', "=", $request->status_id);
        } else {
            $lab = $lab->where('status_id', "=", STATUS_ACTIVE);
        }

        // if (!empty($request->records_per_page) && is_numeric($request->records_per_page)) {
        //     $records_per_page = $request->records_per_page;
        // }
        if (!empty($request->sort_field)) {
            if ($request->sort_field == 'name' && ($request->sort_action == 'ASC' || $request->sort_action == 'DESC')) {
                $lab = $lab->orderBy("name", $request->sort_action);
            } elseif ($request->sort_field == 'Area' && ($request->sort_action == 'ASC' || $request->sort_action == 'DESC')) {
                $lab = $lab->orderBy("area", $request->sort_action);
            } elseif ($request->sort_field == 'Pincode' && ($request->sort_action == 'ASC' || $request->sort_action == 'DESC')) {
                $lab = $lab->orderBy("pincode", $request->sort_action);
            }
        } else {
            $lab = $lab->orderBy("id", "DESC");
        }


        if (isset($request->limit)) {
            $lab->limit($request->limit);
        }
        if (isset($request->offset)) {
            $lab->offset($request->offset);
        }
        $data = [];
        $data['total_records'] = $lab->count();
        $data['lab_data'] = $lab->get();
        // $data['total_records'] = Lab::get()->count();
        // $lab = $lab->paginate($records_per_page);

        return success($data, "Lab fetch Succesfully.");
    }

    public function getLabBranch(Request $request, $id) {
        // $lab = Lab::with(['lab_details', 'status', 'state', 'city'])->where('parent_id', $id)->get();
        $lab = Lab::query();
        $lab->where('parent_id', $id);
        if (!empty($request->name)) {
            $lab = $lab->where('name', 'like', '%' . $request->name . '%');
        }
        if (!empty($request->phone)) {
            $lab = $lab->where('phone', 'like', '%' . $request->phone . '%')
                    ->orWhere('mobile', 'like', '%' . $request->phone . '%');
        }
        if (!empty($request->pincode)) {
            $lab = $lab->where('pincode', 'like', '%' . $request->pincode . '%');
        }
        if (!empty($request->city_id)) {
            //$lab = $lab->whereRelation('city', 'name', 'like', '%' . $request->city . '%');
            $lab = $lab->where('city_id', "=", $request->city_id);
        }
        if (!empty($request->state_id)) {
            //   $lab = $lab->whereRelation('state', 'name', 'like', '%' . $request->state . '%');
            $lab = $lab->where('state_id', "=", $request->state_id);
        }

        // if (!empty($request->records_per_page) && is_numeric($request->records_per_page)) {
        //     $records_per_page = $request->records_per_page;
        // }
        if (!empty($request->sort_field)) {
            if ($request->sort_field == 'name' && ($request->sort_action == 'ASC' || $request->sort_action == 'DESC')) {
                $lab = $lab->orderBy("name", $request->sort_action);
            } elseif ($request->sort_field == 'Area' && ($request->sort_action == 'ASC' || $request->sort_action == 'DESC')) {
                $lab = $lab->orderBy("area", $request->sort_action);
            } elseif ($request->sort_field == 'Pincode' && ($request->sort_action == 'ASC' || $request->sort_action == 'DESC')) {
                $lab = $lab->orderBy("pincode", $request->sort_action);
            }
        } else {
            $lab = $lab->orderBy("id", "DESC");
        }

        if (isset($request->limit)) {
            $lab->limit($request->limit);
        }
        if (isset($request->offset)) {
            $lab->offset($request->offset);
        }
        $lab_data = [];
        $lab_data['lab_data'] = $lab->with(['lab_details', 'status', 'state', 'city'])->get();
        $lab_data['total_records'] = $lab->get()->count();
        return success($lab_data, "Lab's branch fetch Succesfully.");

        // if ($lab) {
        //     return success($lab, "Lab's branch fetch Succesfully.");
        // } else {
        //     return error("This Lab is not available.");
        // }
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create() {
        //
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request) {
        $data = $request->all();
        $validator = Validator::make($data, [
                    'user_id' => "required",
                    'name' => "required",
                    'address1' => "required",
                    'address2' => "required",
                    'area' => "required",
                    'pincode' => "required",
                    'city_id' => "required",
                    'state_id' => "required",
                    'latitude' => "required",
                    'longitude' => "required",
                    'photo' => "required",
                    'description' => "required",
        ]);

        if ($validator->fails()) {
            return error($validator->errors()->first());
        } else {
            $check_user = Lab::where('user_id', $request->user_id)
                    ->whereNull('parent_id')
                    ->first();
            if (empty($check_user)) {
                $lab = new Lab();
                $labDetails = new LabDetails();

                $lab->user_id = $request->user_id;
                $lab->name = $request->name;
                $lab->phone = $request->phone;
                $lab->mobile = $request->mobile;
                $lab->email = $request->email;
                $lab->address1 = $request->address1;
                $lab->address2 = $request->address2;
                $lab->area = $request->area;
                $lab->pincode = $request->pincode;
                $lab->city_id = $request->city_id;
                $lab->state_id = $request->state_id;
                $validateLatLong = validateLatLong($request->latitude, $request->longitude);
                if (!empty($validateLatLong)) {
                    $lab->latitude = $request->latitude;
                    $lab->longitude = $request->longitude;
                } else {
                    return error("longitude and latitude are not valid.");
                }
                $lab->discount = !empty($request->discount) ? $request->discount : NULL;
                $lab->contact_person = !empty($request->contact_person) ? $request->contact_person : NULL;
                $lab->virtual_location = !empty($request->virtual_location) ? ($request->virtual_location == 'on' ? 1 : 0) : 0;
                $lab->status_id = !empty($request->status_id) ? $request->status_id : STATUS_ACTIVE;

                /*
                 * Lab details
                 */
                $lab->cash_booking_allowed = $request->cash_booking_allowed == 'on' ? 1 : 0;
                $lab->cancellation_allowed = $request->cancellation_allowed == 'on' ? 1 : 0;

                if (!empty($request->cancel_policy)) {
                    $lab->cancel_policy = $request->cancel_policy;
                }
                if (!empty($request->cancel_policy_setting)) {
                    $lab->cancel_policy_setting = $request->cancel_policy_setting;
                }

                $labDetails->description = $request->description;
                $labDetails->timing_json = $request->slot_data_obj;
                $labDetails->pancard_number = $request->pancard_number;
                $labDetails->gst_number = $request->gst_number;
                $labDetails->bank_account_number = $request->bank_account_number;
                $labDetails->bank_account_name = $request->bank_account_name;
                $labDetails->bank_name = $request->bank_name;
                $labDetails->bank_ifsc_code = $request->bank_ifsc_code;
                $labDetails->permissions_json = !empty($request->permissions_json) ? $request->permissions_json : NULL;


                if (!empty($request->photo) && in_array($request->photo->extension(), allow_file_type_uploads)) {
                    $image = $request->file('photo');
                    $imageName = seo_url("healthism lab profile {$request->name}") . '.' . $request->photo->extension();
                    $image_resize = Image::make($image->getRealPath());
                    $image_resize->resize(800, null, function ($constraint) {
                        $constraint->aspectRatio();
                    });
                    $image_resize->save(public_path('image/lab/' . $imageName));
                    $lab->photo = $imageName;
                }

                if (!empty($request->images_list)) {
                    $gallery_images = [];

                    foreach ($request->images_list as $row) {
                        $imageName = seo_url("healthism {$request->name}") . "." . $row->extension();
                        $imageName = change_filename("image/lab_gallery/", $imageName);
                        if ($row->move(public_path('image/lab_gallery'), $imageName)) {
                            $gallery_images[] = $imageName;
                        }
                    }
                    $labDetails->gallery_json = json_encode(array_values($gallery_images));
                }

                if (!empty($request->pancard_document)) {
                    $imageName = seo_url("pan healthism {$request->name}") . '.' . $request->pancard_document->extension();
                    $imageName = change_filename("image/lab/", $imageName);
                    if ($request->pancard_document->move(public_path('image/lab'), $imageName)) {
                        $labDetails->pancard_document = $imageName;
                    }
                }

                if (!empty($request->gst_certificate)) {
                    $imageName = seo_url("gst healthism {$request->name}") . '.' . $request->gst_certificate->extension();
                    $imageName = change_filename("image/lab/", $imageName);

                    if ($request->gst_certificate->move(public_path('image/lab'), $imageName)) {
                        if (!empty($request->gst_certificate)) {
                            @unlink('image/lab/' . $lab->lab_details->gst_certificate);
                        }
                        $labDetails->gst_certificate = $imageName;
                    }
                }

                if (!empty($request->nabl_document)) {
                    $imageName = seo_url("nabl healthism {$request->name}") . '.' . $request->nabl_document->extension();
                    $imageName = change_filename("image/lab/", $imageName);
                    if ($request->nabl_document->move(public_path('image/lab'), $imageName)) {
                        $labDetails->nabl_document = $imageName;
                    }
                }

                if (!empty($request->mou_document)) {
                    $imageName = seo_url("mou healthism {$request->name}") . '.' . $request->mou_document->extension();
                    $imageName = change_filename("image/lab/", $imageName);
                    if ($request->mou_document->move(public_path('image/lab'), $imageName)) {
                        $labDetails->mou_document = $imageName;
                    }
                }

                $lab->save();
                $labDetails->lab_id = $lab->id;
                $labDetails->save();
                $lab_service = Lab::with(['lab_details', 'status', 'state', 'city'])->where('id', $lab->id)->first();
                return success($lab_service, "Lab Details Added Succesfully.");
            } else {
                return error("This User Lab already registered.");
            }
        }
    }

    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function show($id) {
        $lab = Lab::with(['lab_details', 'status', 'state', 'city'])->where('id', $id)->first();
        if ($lab) {
            return success($lab, "Lab fetch Succesfully.");
        } else {
            return error("This Lab is not available.");
        }
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function edit($id) {
        //
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, $id) {
        $lab = Lab::findOrFail($id);
        // dd($lab);
        if (isset($request->latitude) && isset($request->longitude)) {
            $validateLatLong = validateLatLong($request->latitude, $request->longitude);
            if (!empty($validateLatLong)) {
                $lab->latitude = $request->latitude;
                $lab->longitude = $request->longitude;
            } else {
                return error("longitude and latitude are not valid.");
            }
        }

        /*
         * Lab service details
         */

        if (!empty($request->cash_booking_allowed) || !empty($request->cancellation_allowed) || !empty($request->virtual_location)) {
            $lab->cash_booking_allowed = $request->cash_booking_allowed == 'on' ? 1 : 0;
            $lab->cancellation_allowed = $request->cancellation_allowed == 'on' ? 1 : 0;
            $lab->virtual_location = !empty($request->virtual_location) ? ($request->virtual_location == 'on' ? 1 : 0) : 0;
        }
        if (!empty($request->slot_data_obj)) {
            $lab->lab_details->timing_json = $request->slot_data_obj;
        }
        // if (!empty($request->cancel_policy)) {
        //     $lab->cancel_policy = $request->cancel_policy;
        // }
        // if (!empty($request->cancel_policy_setting)) {
        //     $lab->cancel_policy_setting = $request->cancel_policy_setting;
        // }

        if (!empty($request->photo) && in_array($request->photo->extension(), allow_file_type_uploads)) {
            $photo_name = substr($lab->photo, strrpos($lab->photo, '/') + 1);
            if (!empty($lab->photo)) {
                @unlink(public_path('image/lab/' . $photo_name));
            }
            $image = $request->file('photo');
            $imageName = seo_url("healthism lab profile {$request->name}") . '.' . $request->photo->extension();
            $image_resize = Image::make($image->getRealPath());
            $image_resize->resize(800, null, function ($constraint) {
                $constraint->aspectRatio();
            });
            $image_resize->save(public_path('image/lab/' . $imageName));
            $lab->photo = $imageName;
        }

        if (!empty($request->images_list)) {
            $gallery_images = [];
            foreach ($lab->lab_details->gallery_json as $value) {
                $name = substr($value, strrpos($value, '/') + 1);
                $gallery_images[] = $name;
            }
            foreach ($request->images_list as $row) {
                $imageName = seo_url("healthism {$request->name}") . "." . $row->extension();
                $imageName = change_filename("image/lab_gallery/", $imageName);
                if ($row->move(public_path('image/lab_gallery'), $imageName)) {
                    $gallery_images[] = $imageName;
                }
            }
            $lab->lab_details->gallery_json = json_encode(array_values($gallery_images));
        }

        if (!empty($request->pancard_document)) {
            $imageName = seo_url("pan healthism {$request->name}") . '.' . $request->pancard_document->extension();
            $imageName = change_filename("image/lab/", $imageName);
            if ($request->pancard_document->move(public_path('image/lab'), $imageName)) {
                if (!empty($lab->lab_details->pancard_document)) {
                    $pan_name = substr($lab->lab_details->pancard_document, strrpos($lab->lab_details->pancard_document, '/') + 1);
                    @unlink('image/lab/' . $pan_name);
                }
            }
            $lab->lab_details->pancard_document = $imageName;
        }

        if (!empty($request->gst_certificate)) {
            $imageName = seo_url("gst healthism {$request->name}") . '.' . $request->gst_certificate->extension();
            $imageName = change_filename("image/lab/", $imageName);

            if ($request->gst_certificate->move(public_path('image/lab'), $imageName)) {
                if (!empty($lab->lab_details->gst_certificate)) {
                    $gst_name = substr($lab->lab_details->gst_certificate, strrpos($lab->lab_details->gst_certificate, '/') + 1);
                    @unlink('image/lab/' . $gst_name);
                }
            }
            $lab->lab_details->gst_certificate = $imageName;
        }

        if (!empty($request->nabl_document)) {
            $imageName = seo_url("nabl healthism {$request->name}") . '.' . $request->nabl_document->extension();
            $imageName = change_filename("image/lab/", $imageName);

            if ($request->nabl_document->move(public_path('image/lab'), $imageName)) {
                if (!empty($lab->lab_details->nabl_document)) {
                    $nabl_name = substr($lab->lab_details->nabl_document, strrpos($lab->lab_details->nabl_document, '/') + 1);
                    @unlink('image/lab/' . $nabl_name);
                }
            }
            $lab->lab_details->nabl_document = $imageName;
        }

        if (!empty($request->mou_document)) {
            $imageName = seo_url("mou healthism {$request->name}") . '.' . $request->mou_document->extension();
            $imageName = change_filename("image/lab/", $imageName);

            if ($request->mou_document->move(public_path('image/lab'), $imageName)) {
                if (!empty($lab->lab_details->mou_document)) {
                    $mou_name = substr($lab->lab_details->mou_document, strrpos($lab->lab_details->mou_document, '/') + 1);
                    @unlink('image/lab/' . $mou_name);
                }
            }
            $lab->lab_details->mou_document = $imageName;
        }

        // $lab->save();
        // $lab->lab_details->save();
        $lab->update($request->except('photo', 'cash_booking_allowed', 'cancellation_allowed', 'virtual_location'));
        $lab->lab_details->update($request->except('gallery_json', 'pancard_document', 'gst_certificate', 'nabl_document', 'mou_document'));

        return success($lab, "Lab Details Updated Successfully!");
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function destroy($id) {
        //
    }

    public function labSearch(Request $request) {
        $search = $request->get('search');
        $data = Lab::where('name', 'LIKE', '%' . $search . '%')->limit(10)->get();
        $result = [];
        if (!empty($data)) {
            foreach ($data as $value) {
                $lab['label'] = $value['name'] . '(' . $value['area'] . ',' . $value['city']['name'] . ',' . $value['state']['name'] . ')';
                $lab['id'] = $value['id'];
                $result[] = $lab;
            }
            return success($result, "Lab Details get Succesfully.");
        } else {
            return error($result, "Lab Details not found.");
        }
    }

    public function fetchGalleryImages(Request $request, $id) {
        $lab = Lab::findOrFail($id);
        $gallery_images = $lab->lab_details->gallery_json;
        $images = [];
        if (!empty($gallery_images)) {
            foreach ($gallery_images as $row) {
                $name = substr($row, strrpos($row, '/') + 1);
                $size = @filesize("image/lab_gallery/" . $name);
                $images[] = ['name' => $name, 'size' => $size, 'path' => $row];
            }
        }
        return success($images, "Lab gallery fetch Succesfully.");
    }

    public function galleryImagesDelete(Request $request, $id) {
        if (!empty($id)) {
            $lab = Lab::findOrFail($id);
            $gallery_images = $lab->lab_details->gallery_json;
            if ($gallery_images != null) {
                foreach ($gallery_images as $key => $value) {
                    $name = substr($value, strrpos($value, '/') + 1);
                    $update_gallery_images[] = $name;
                }
                $update_gallery_images = array_filter($update_gallery_images, fn ($m) => $m != $request->name);

                $update_gallery_images = array_values($update_gallery_images);

                if (empty($update_gallery_images)) {
                    $lab->lab_details->gallery_json = NULL;
                } else {
                    $update_gallery_images = $lab->lab_details->gallery_json = json_encode($update_gallery_images, true);
                }
                $lab->lab_details->save();
                @unlink('image/lab_gallery/' . $request->name);
                return success($lab, 'Remove image successfully.');
            } else {
                return success([], "Images Not Available.");
            }
        } else {
            @unlink(public_path('/image/lab_gallery/') . $request->name);
        }
    }

    public function removeProfile($id) {
        $lab = Lab::findOrFail($id);
        $profile_name = substr($lab->photo, strrpos($lab->photo, '/') + 1);
        if (!empty($lab->photo)) {
            if (file_exists(public_path('image/lab/' . $profile_name))) {
                @unlink(public_path('image/lab/' . $profile_name));
            }
            $lab->photo = null;
            $lab->save();
        }
        return success([], "Remove lab profile.");
    }

    public function getAllLocation($id) {
        $lab = Lab::where("id", $id)->first();
        if ($lab) {
            $location = LabSearch::where('lab_id', $id)->orderby("id", "DESC")->get()->toArray();
            if (!empty($location)) {
                return success($location, "Get all location.");
            } else {
                return success([], "No any data stored yet.");
            }
        } else {
            return error("This Lab is not available.");
        }
    }

    public function locationSave(Request $request) {
        $validator = Validator::make($request->all(), [
                    'lab_id' => "required",
                    'city_id' => "nullable",
                    'state_id' => "nullable",
                    'latitude' => "nullable|required_with:longitude",
                    'longitude' => "nullable|required_with:latitude",
                    'pincode' => "required_without:latitude,longitude|nullable",
        ]);
        if ($validator->fails()) {
            return error($validator->errors()->first());
        } else {
            $lab = Lab::where('id', $request->lab_id)->first();
            $inputArr['lab_id'] = $request->lab_id;
            $inputArr['pincode'] = !empty($request->pincode) ? $request->pincode : NULL;

            if (isset($request->latitude) && isset($request->longitude)) {
                $validateLatLong = validateLatLong($request->latitude, $request->longitude);
                if (!empty($validateLatLong)) {
                    $inputArr['latitude'] = !empty($request->latitude) ? $request->latitude : NULL;
                    $inputArr['longitude'] = !empty($request->longitude) ? $request->longitude : NULL;
                } else {
                    return error("longitude and latitude are not valid.");
                }
            }
            $inputArr['city_id'] = !empty($request->city_id) ? $request->city_id : NULL;
            $inputArr['state_id'] = !empty($request->state_id) ? $request->state_id : NULL;

            $duplicate = LabSearch::where($inputArr)->count();
            if ($duplicate > 0) {
                return error("Duplicate Entry");
            } else {
                $inputArr['name'] = $lab->name;
                $result = LabSearch::Create($inputArr);
                return success($result, "Lab Location has been saved successfully");
            }
        }
    }

    public function locationDelete($id) {
        $labSearch = LabSearch::findOrFail($id);
        if (!empty($labSearch))
            $labSearch->delete();
        return success($id, "Location has been deleted successfully");
    }

}
