<?php

namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Controller;
use App\Models\City;
use App\Models\State;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Validator;

class CityController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index(Request $request)
    {
        $city = City::query();
        $records_per_page = 10;
        if (!empty($request->name)) {
            $city = $city->where('name', 'like', '%' . $request->name . '%');
        }
        if (!empty($request->state_id)) {
            $city = $city->where('state_id', $request->state_id);
        }
        // if (!empty($request->records_per_page) && is_numeric($request->records_per_page)) {
        //     $records_per_page = $request->records_per_page;
        // }
        $city = $city->orderBy("name", "ASC");
        $stateList = State::get();
        // $cityList = $city->paginate($records_per_page);
        if (isset($request->limit)) {
            $city->limit($request->limit);
        }
        if (isset($request->offset)) {
            $city->offset($request->offset);
        }
        $data = [];
        $data['total_records'] = $city->count();
        $data['city_data'] = $city->get();
        return success($data, 'Get all cities.');

        // if ($request->ajax()) {
        //     return view('backend.city.ajax_content', compact('cityList', 'stateList'));
        // } else {
        //     return view('backend.city.index', compact('cityList', 'stateList'));
        // }
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        //
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        $validator = Validator::make($request->all(), [
            'name' => "required",
            'state_id' => "required",
        ]);
        if ($validator->fails()) {
            return error($validator->errors()->first());
        } else {
            $city = new City;
            $name = ucfirst($request->name);
            $duplicate = City::where('name', $name)->where('state_id', $request->state_id)->first();
            if (!empty($duplicate)) {
                return error($name . ': City already exists');
            }
            $city->name = $name;
            $city->state_id = $request->state_id;
            $city->save();
            return success($city, $name . ' City Details Added Successfully!');
        }
    }

    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function show($id)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function edit($id)
    {
        //
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, $id)
    {
        $city = City::findOrFail($id);
        $name = ucfirst($request->name);
        $duplicate = City::where('name', $name)->where('state_id', $request->state_id)->first();
        if (!empty($duplicate)) {
            if ($duplicate->id != $id) {
                return error($name . ': City already exists');
            }
        }
        $city->name = $request->name;
        $city->state_id = $request->state_id;
        $city->save();
        return success($city, $request->name . ' : City  Updated Successfully!');
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function destroy($id)
    {
        //
    }
}
