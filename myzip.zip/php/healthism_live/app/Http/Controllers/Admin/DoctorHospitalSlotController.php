<?php

namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Controller;
use App\Models\DoctorHospitalSlot;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Validator;

class DoctorHospitalSlotController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index(Request $request)
    {
        if (!empty($request->id)) {
            $mapping = \App\Models\DoctorHospitalMapping::findOrFail($request->id);
        }
        $slot = DoctorHospitalSlot::query();
        if (!empty($mapping->doctor_id)) {
            $slot->where('doctor_id', $mapping->doctor_id);
        }
        if (!empty($mapping->hospital_id)) {
            $slot->where('hospital_id', $mapping->hospital_id);
        }
        if (!empty($mapping)) {
            $slot->orderBy('day', 'ASC');
            $slot->orderBy('from_time', 'ASC');
            $slot = $slot->get();
        }
        $slotData = [];
        if (!empty($slot)) {
            foreach ($slot as $key => $value) {
                $fromTime = substr($value['from_time'], 0, -3);
                $slotData[$value['day']][$fromTime] = [
                    'id' => $value['id'],
                    'startTime' => $fromTime,
                    'endTime' => substr($value['to_time'], 0, -3),
                    'videoAvailable' => $value['is_video'],
                    'offlineAvailable' => $value['is_offline'],
                ];
            }
        }
        $mapping->slot = empty($slotData) ? '' : json_encode($slotData);
        return success($mapping, "Slot fetch successfully.");
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        //
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        $input = $request->all();
        $validator = Validator::make($input, [
            'slot_data_obj' => "required",
            'hospital_id' => "required",
            'doctor_id' => "required",
            'delete_slot_data_obj' => "nullable"
        ]);
        if ($validator->fails()) {
            return error($validator->errors()->first());
        } else {
            if (!empty($input['delete_slot_data_obj'])) {
                $deleteSlotArr = json_decode($input['delete_slot_data_obj'], TRUE);
                if (!empty($deleteSlotArr)) {
                    DoctorHospitalSlot::whereIn('id', $deleteSlotArr)->delete();
                }
            }
            $slotArr = json_decode($input['slot_data_obj'], TRUE);
            if (!empty($slotArr)) {
                $insertData = [];
                foreach ($slotArr as $key => $day) {
                    foreach ($day as $slot) {
                        if (empty($slot['id'])) {
                            $data['day'] = $key;
                            $data['is_video'] = $slot['videoAvailable'];
                            $data['is_offline'] = $slot['offlineAvailable'];
                            $data['from_time'] = $slot['startTime'];
                            $data['to_time'] = $slot['endTime'];
                            $data['hospital_id'] = $input['hospital_id'];
                            $data['doctor_id'] = $input['doctor_id'];
                            $data['status_id'] = STATUS_ACTIVE;
                            $data['created_at'] = date('Y-m-d H:i:s');
                            $data['created_by'] = $request->user()->id;
                            $insertData[] = $data;
                        }
                    }
                }
                if (!empty($insertData)) {
                    DoctorHospitalSlot::insert($insertData);
                }
            }

            $mapping = \App\Models\DoctorHospitalMapping::where('doctor_id', $request->doctor_id)
                ->where('hospital_id', $request->hospital_id)
                ->first();
            return success(['id' => $mapping->id], 'Slot Details Added Successfully.');

            // return redirect()->route('admin.doctor.hospital.slot', ['id' => $mapping->id])->with('success', 'Slot Details Added Successfully!');
        }
    }

    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function show($id)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function edit($id)
    {
        //
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, $id)
    {
        //
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function destroy($id)
    {
        //
    }
}
