<?php

namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Controller;
use App\Models\LabTestMaster;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Validator;


class LabTestMasterController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index(Request $request)
    {
        $lab_test_master = LabTestMaster::query();
        $records_per_page = 10;
        if (!empty($request->name)) {
            $lab_test_master = $lab_test_master->where('name', 'like', '%' . $request->name . '%');
        }
        if (!empty($request->status)) {
            $lab_test_master = $lab_test_master->where('status_id', $request->status);
        }

        // if (!empty($request->records_per_page) && is_numeric($request->records_per_page)) {
        //     $records_per_page = $request->records_per_page;
        // }
        $lab_test_master = $lab_test_master->orderBy("id", "DESC");


        if (isset($request->limit)) {
            $lab_test_master->limit($request->limit);
        }
        if (isset($request->offset)) {
            $lab_test_master->offset($request->offset);
        }
        $data = [];
        $data['total_records'] = $lab_test_master->count();
        $data['lab_test_data'] = $lab_test_master->get();
        // $lab = $lab->paginate($records_per_page);

        return success($data, "Lab test master fetch Succesfully.");
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        //
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        $data = $request->all();
        $validator = Validator::make($data, [
            'name' => "required",
            'gender' => "required",
            'description' => "required",
            'requirement' => "required",
            'preparation' => "required",
            'is_package' => "nullable|in:off,on",
            'package_category' => "required_with:is_package,on",
            'test_count' => "required",
            'test_json' => "required",
        ]);

        if ($validator->fails()) {
            return error($validator->errors()->first());
        } else {
            $labTestMaster = new LabTestMaster();

            $labTestMaster->name = $request->name;
            $labTestMaster->gender = $request->gender;
            $labTestMaster->description = $request->description;
            $labTestMaster->requirement = $request->requirement;
            $labTestMaster->preparation = $request->preparation;
            $labTestMaster->test_count = $request->test_count;
            $labTestMaster->test_json = $request->test_json;
            $labTestMaster->is_package = !empty($request->is_package) ? ($request->is_package == 'on' ? 1 : 0) : 0;
            $labTestMaster->package_category = !empty($request->package_category) ? $request->package_category : NULL;
            $labTestMaster->status_id = !empty($request->status_id) ? $request->status_id : STATUS_ACTIVE;

            $labTestMaster->save();
            $lab_test_master = LabTestMaster::with(['status'])->where('id', $labTestMaster->id)->first();
            return success($lab_test_master, "Lab test master Details Added Succesfully.");
        }
    }

    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function show($id)
    {
        $lab_test_master = LabTestMaster::with(['status'])->where('id', $id)->first();
        if ($lab_test_master) {
            return success($lab_test_master, "Lab test master fetch Succesfully.");
        } else {
            return error("This Lab test master is not available.");
        }
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function edit($id)
    {
        //
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, $id)
    {
        $labTestMaster = LabTestMaster::findOrFail($id);
        $labTestMaster->is_package = !empty($request->is_package) ? ($request->is_package == 'on' ? 1 : 0) : 0;
        if (!empty($request->test_json)) {
            $labTestMaster->test_json = $request->test_json;
        }

        $labTestMaster->update($request->except('is_package'));
        return success($labTestMaster, "Lab test master Details Updated Successfully!");
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function destroy($id)
    {
        $lab_test_master = LabTestMaster::with(['status'])->where('id', $id)->first();
        if ($lab_test_master) {
            $lab_test_master->delete();
            return success([], "Lab test master delete Succesfully.");
        } else {
            return error("This Lab test master is not available.");
        }
    }
}
