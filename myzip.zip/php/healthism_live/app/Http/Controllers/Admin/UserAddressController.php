<?php

namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Controller;
use App\Models\UserAddress;
use Illuminate\Http\Request;

class UserAddressController extends Controller {

    public function index(Request $request) {
        if (empty($request->user_id)) {
            return error("Sorry, User id is empty");
        }
        $result = UserAddress::where([
                    'user_id' => $request->user_id,
                ])->orderBy('created_at', 'desc')->with('city', 'state')->get();
        return success($result, "User Address");
    }

    public function store(Request $request) {
        if (empty($request->user_id)) {
            return error("Sorry, User id is empty");
        }
        $rules = UserAddress::$rules;
        if (sizeof($rules) > 0) {
            $validation = $this->validateRequest($request, $rules);
            if (!empty($validation)) {
                return error($validation);
            }
        }
        $input = $request->all();
        $cityStateId = $this->getCityStateIdFromName($input);
        $input['state_id'] = $cityStateId['state_id'];
        $input['city_id'] = $cityStateId['city_id'];
        $input['user_id'] = $input['user_id'];
        //$input['created_at'] = $request->user()->id;
        $result = UserAddress::create($input);
        return success($result, "User address has been saved successfully");
    }

    private function getCityStateIdFromName($input) {
        $response = ['state_id' => 0, 'city_id' => 0];
        $stateName = trim($input['state']);
        $state = \App\Models\State::where('name', $stateName)->first();
        if (!empty($state)) {
            $response['state_id'] = $state->id;
        }
        $cityName = trim($input['city']);
        $city = \App\Models\City::where('name', $cityName)->first();
        if (!empty($city)) {
            $response['city_id'] = $city->id;
        }
        return $response;
    }

}
