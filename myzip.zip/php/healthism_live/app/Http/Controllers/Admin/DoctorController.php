<?php

namespace App\Http\Controllers\Admin;

use App\Helpers\Helpers;
use App\Http\Controllers\Controller;
use App\Models\Category;
use App\Models\Doctor;
use App\Models\DoctorDetails;
use App\Models\User;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use Intervention\Image\ImageManagerStatic as Image;
use Illuminate\Support\Facades\Validator;



class DoctorController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index(Request $request)
    {
        $doctors = Doctor::query();
        $records_per_page = 10;
        if (!empty($request->name)) {
            $doctors = $doctors->where('first_name', 'like', '%' . trim($request->name) . '%')
                ->orWhere('last_name', 'like', '%' . trim($request->name) . '%');
        }
        if (!empty($request->phone)) {
            $doctors = $doctors->where('phone', 'like', '%' . trim($request->phone) . '%');
        }
        if (!empty($request->email)) {
            $doctors = $doctors->where('email', 'like', '%' . trim($request->email) . '%');
        }
        if (!empty($request->specialization)) {
            $doctors = $doctors->where('specialization', 'like', '%' . trim($request->specialization) . '%');
        }
        if (!empty($request->gender)) {
            $doctors = $doctors->where('gender', $request->gender);
        }

        if (!empty($request->records_per_page) && is_numeric($request->records_per_page)) {
            $records_per_page = $request->records_per_page;
        }
        if (!empty($request->sort_field)) {
            if ($request->sort_field == 'name' && ($request->sort_action == 'ASC' || $request->sort_action == 'DESC')) {
                $doctors = $doctors->orderBy("first_name", $request->sort_action);
            } elseif ($request->sort_field == 'Specialization' && ($request->sort_action == 'ASC' || $request->sort_action == 'DESC')) {
                $doctors = $doctors->orderBy("specialization", $request->sort_action);
            } elseif ($request->sort_field == 'Gender' && ($request->sort_action == 'ASC' || $request->sort_action == 'DESC')) {
                $doctors = $doctors->orderBy("gender", $request->sort_action);
            }
        } else {
            $doctors = $doctors->orderBy("id", "DESC");
        }
        if (isset($request->limit)) {
            $doctors->limit($request->limit);
        }
        if (isset($request->offset)) {
            $doctors->offset($request->offset);
        }
        // $specialization = Helpers::getEnumValues('doctor', 'specialization');
        // $gender = Helpers::getEnumValues('doctor', 'gender');

        // $doctors = $doctors->paginate($records_per_page);
        // if ($request->ajax()) {
        //     return view('backend.doctor.ajax_content', compact('doctors', 'specialization', 'gender'));
        // } else {
        //     return view('backend.doctor.index', compact('doctors', 'specialization', 'gender'));
        // }
        $data = [];
        $data['total_records'] = $doctors->count();
        $data['doctors_data'] = $doctors->get();
        return success($data, "User fetch Succesfully.");
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        //
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        $data = $request->all();
        $validator = Validator::make($data, [
            'user_id' => "required",
            'first_name' => "required|string",
            'last_name' => "required|string",
            'email' => "required|email",
            'gender' => "required|in:Male,Female,Transgender",
            'short_desc' => "required",
            'experience' => "required",
            'sub_category_id' => "required",
            'specialization' => "required",
            'registration_council' => "required",
        ]);

        if ($validator->fails()) {
            return error($validator->errors()->first());
        } else {
            $check_doctor = Doctor::where('user_id', $request->user_id)->first();
            if ($check_doctor != null) {
                return error("Record Already added by this doctor.");
            } else {
                $doctor = new Doctor();
                $doctor_details = new DoctorDetails();

                $doctor->first_name = $request->first_name;
                $doctor->middle_name = $request->middle_name;
                $doctor->last_name = $request->last_name;
                $doctor->phone = $request->phone;
                $doctor->email = $request->email;
                $doctor->specialization = $request->specialization;
                $doctor->gender = $request->gender;
                $doctor->status_id = $request->status_id;
                $doctor->short_desc = $request->short_desc;
                $doctor->experience = $request->experience;
                $doctor->user_id = $request->user_id;
                // $doctor->sub_category_id = count($request->sub_category_id) > 1 ? ',' . implode(",", $request->sub_category_id) . ',' : implode(",", $request->sub_category_id);
                $doctor->sub_category_id = $request->sub_category_id;
                if (!empty($request->photo) && in_array($request->photo->extension(), allow_file_type_uploads)) {
                    $image = $request->file('photo');
                    $imageName = seo_url("healthism doctor {$request->first_name} {$request->last_name}") . '.' . $request->photo->extension();
                    $image_resize = Image::make($image->getRealPath());
                    $image_resize->resize(400, null, function ($constraint) {
                        $constraint->aspectRatio();
                    });
                    $image_resize->save(public_path('image/doctor_profile/' . $imageName));
                    $doctor->photo = $imageName;
                }
                $doctor->save();
                // dd($request->all());

                $doctor_details->doctor_id = $doctor->id;
                $doctor_details->description = $request->description;
                $doctor_details->registration_number = $request->registration_number;
                $doctor_details->registration_council = $request->registration_council;
                $doctor_details->last_degree_obtained = $request->last_degree_obtained;
                $doctor_details->college_institute_name = $request->college_institute_name;
                $doctor_details->aadhar_card_no = $request->aadhar_card_no;
                $doctor_details->pan_card_no = $request->pan_card_no;
                $doctor_details->service_json = !empty($request->services) ? json_encode($request->services) : null;
                $doctor_details->specialization_json = !empty($request->specialization_json) ? json_encode($request->specialization_json) : null;
                $doctor_details->education_json = !empty($request->education) ? json_encode($request->education) : null;
                $doctor_details->membership_json = !empty($request->membership) ? json_encode($request->membership) : null;
                $doctor_details->experience_json = !empty($request->experience_json) ? json_encode($request->experience_json) : null;
                $doctor_details->registration_json = !empty($request->registration) ? json_encode($request->registration) : null;
                $doctor_details->registration_date = date('Y-m-d', strtotime($request->registration_date));
                $doctor_details->date_of_completion = date('Y-m-d', strtotime($request->date_of_completion));
                // dd($doctor_details);
                if (!empty($request->registration_proof)) {
                    $imageName = seo_url("registration healthism doctor {$request->first_name} {$request->last_name}") . '.' . $request->registration_proof->extension();
                    $imageName = change_filename("image/doctor_mix/", $imageName);
                    if ($request->registration_proof->move(public_path('image/doctor_mix/'), $imageName)) {
                        $doctor_details->registration_proof = $imageName;
                    }
                }
                if (!empty($request->qualification_certificates)) {
                    $imageName = seo_url("qualification healthism doctor {$request->first_name} {$request->last_name}") . '.' . $request->qualification_certificates->extension();
                    $imageName = change_filename("image/doctor_mix/", $imageName);
                    if ($request->qualification_certificates->move(public_path('image/doctor_mix/'), $imageName)) {
                        $doctor_details->qualification_certificates = $imageName;
                    }
                }
                if (!empty($request->pan_card_document)) {
                    $imageName = seo_url("pan healthism doctor {$request->first_name} {$request->last_name}") . '.' . $request->pan_card_document->extension();
                    $imageName = change_filename("image/doctor_mix/", $imageName);
                    if ($request->pan_card_document->move(public_path('image/doctor_mix/'), $imageName)) {
                        $doctor_details->pan_card_document = $imageName;
                    }
                }
                if (!empty($request->aadhar_card_document)) {
                    $imageName = seo_url("aadhar healthism doctor {$request->first_name} {$request->last_name}") . '.' . $request->aadhar_card_document->extension();
                    $imageName = change_filename("image/doctor_mix/", $imageName);
                    if ($request->aadhar_card_document->move(public_path('image/doctor_mix/'), $imageName)) {
                        $doctor_details->aadhar_card_document = $imageName;
                    }
                }

                $doctor_details->save();
                $doctor = Doctor::with('doctor_details')->where('id', $doctor->id)->first();
                return success($doctor, "Doctor Details Added Succesfully.");
                // return redirect()->route('admin.doctor.view', $doctor->id)->with('success', 'Doctor Details Added Successfully!');
            }
        }
    }

    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function show($id)
    {
        $doctor = Doctor::with(['doctor_details', 'status', 'user'])->where('id', $id)->first();
        if ($doctor) {
            return success($doctor, "Doctor fetch Succesfully.");
        } else {
            return error("This Doctor is not available.");
        }
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function edit($id)
    {
        //
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, $id)
    {
        $doctor = Doctor::findOrFail($id);
        if ($doctor) {

            if (!empty($request->photo) && in_array($request->photo->extension(), allow_file_type_uploads)) {
                if (!empty($doctor->photo)) {
                    @unlink('image/doctor_profile/' . $doctor->photo);
                }

                $image = $request->file('photo');
                $filename = seo_url("healthism doctor {$request->first_name} {$request->last_name}") . '.' . $request->photo->extension();
                $image_resize = Image::make($image->getRealPath());
                $image_resize->resize(400, null, function ($constraint) {
                    $constraint->aspectRatio();
                });
                $image_resize->save(public_path('image/doctor_profile/' . $filename));
                $doctor->photo = $filename;
            }

            if (!empty($request->registration_proof)) {

                if (!empty($doctor->doctor_details->registration_proof)) {
                    @unlink('image/doctor_mix/' . $doctor->doctor_details->registration_proof);
                }

                $imageName = seo_url("registration healthism doctor {$request->first_name} {$request->last_name}") . '.' . $request->registration_proof->extension();
                $imageName = change_filename("image/doctor_mix/", $imageName);

                if ($request->registration_proof->move(public_path('image/doctor_mix'), $imageName)) {
                    $doctor->doctor_details->registration_proof = $imageName;
                }
            }

            if (!empty($request->qualification_certificates)) {
                $imageName = seo_url("qualification healthism doctor {$request->first_name} {$request->last_name}") . '.' . $request->qualification_certificates->extension();
                $imageName = change_filename("image/doctor_mix/", $imageName);

                if ($request->qualification_certificates->move(public_path('image/doctor_mix'), $imageName)) {
                    if (!empty($doctor->doctor_details->qualification_certificates)) {
                        @unlink('image/doctor_mix/' . $doctor->doctor_details->qualification_certificates);
                    }
                }
                $doctor->doctor_details->qualification_certificates = $imageName;
            }

            if (!empty($request->pan_card_document)) {
                if (!empty($doctor->doctor_details->pan_card_document)) {
                    @unlink('image/doctor_mix/' . $doctor->doctor_details->pan_card_document);
                }

                $imageName = seo_url("pan healthism doctor {$request->first_name} {$request->last_name}") . '.' . $request->pan_card_document->extension();
                $imageName = change_filename("image/doctor_mix/", $imageName);

                if ($request->pan_card_document->move(public_path('image/doctor_mix'), $imageName)) {
                    $doctor->doctor_details->pan_card_document = $imageName;
                }
            }

            if (!empty($request->aadhar_card_document)) {
                if (!empty($doctor->doctor_details->aadhar_card_document)) {
                    @unlink('image/doctor_mix/' . $doctor->doctor_details->aadhar_card_document);
                }

                $imageName = seo_url("aadhar healthism doctor {$request->first_name} {$request->last_name}") . '.' . $request->aadhar_card_document->extension();
                $imageName = change_filename("image/doctor_mix/", $imageName);

                if ($request->aadhar_card_document->move(public_path('image/doctor_mix'), $imageName)) {
                    $doctor->doctor_details->aadhar_card_document = $imageName;
                }
            }
            $doctor->update($request->except('photo'));
            $doctor->doctor_details->update($request->except('registration_proof', 'qualification_certificates', 'pan_card_document', 'aadhar_card_document'));
            return success($doctor, "Doctor Details Updated Succesfully.");
        } else {
            return error("User is not available");
        }

        // return redirect()->route('admin.doctor.view', $doctor->id)->with('success', 'Doctor Details Updated Successfully!');
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function destroy($id)
    {
        //
    }

    public function userSearch(Request $request)
    {
        $search = $request->get('search');
        $data = User::select(
            "id",
            DB::raw("CONCAT(user.first_name,' ',user.last_name,' (', user.email,' - ', user.mobile,')') as label"),
            DB::raw("CONCAT(user.first_name,' ',user.last_name) as value")
        )
            ->where('user_type_id', DOCTOR)
            ->where(function ($data) use ($search) {
                return $data->where('first_name', 'LIKE', '%' . $search . '%')
                    ->orwhere('last_name', 'LIKE', '%' . $search . '%')
                    ->orwhere('mobile', 'LIKE', '%' . $search . '%');
            })->limit(10)->get();

        return success($data, "User Details get Succesfully.");
    }

    public function doctorSearch(Request $request)
    {
        $search = $request->get('search');
        $data = Doctor::select(
            "id",
            DB::raw("CONCAT(doctor.first_name,' ',doctor.last_name,' (', doctor.email,' - ', doctor.phone,')') as label"),
            DB::raw("CONCAT(doctor.first_name,' ',doctor.last_name) as value")
        )
            ->where(function ($data) use ($search) {
                return $data->where('first_name', 'LIKE', '%' . $search . '%')
                    ->orwhere('last_name', 'LIKE', '%' . $search . '%')
                    ->orwhere('phone', 'LIKE', '%' . $search . '%');
            })->get();
        return success($data, "Doctor Details get Succesfully.");
    }

    public function getDoctorEnums(Request $request)
    {

        $data = $request->all();
        $validator = Validator::make($data, [
            'type' => "required|in:categories,specialization,gender,registration_council"
        ]);
        $type = $data['type'];
        if ($validator->fails()) {
            return error($validator->errors()->first());
        } else {
            if ($type == "categories") {
                $pay_load = Category::where(['parent_id' => CATEGORY_DOCTOR])->get();
            } else if ($type == "specialization") {
                $pay_load = Helpers::getEnumValues('doctor', 'specialization');
            } else if ($type == "gender") {
                $pay_load = Helpers::getEnumValues('doctor', 'gender');
            } else if ($type == "registration_council") {
                $pay_load = Helpers::getEnumValues('doctor_details', 'registration_council');
            }
        }
        return success($pay_load, "Doctor Details get Succesfully.");
        // return view('backend.doctor.add', compact('categories', 'specialization', 'gender', 'registration_council'));
    }

    public function removeProfile($id)
    {
        $doctor = Doctor::findOrFail($id);
        if ($doctor) {
            if (!empty($doctor->photo)) {
                if (file_exists(public_path('image/doctor_profile/' . $doctor->photo))) {
                    @unlink(public_path('image/doctor_profile/' . $doctor->photo));
                }
                $doctor->photo = null;
                $doctor->save();
            }
            return success($doctor, "Doctor Profile Image Remove Succesfully.");
        } else {
            return error("This Doctor is not available.");
        }
    }
}
