<?php

namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Controller;
use App\Models\User;
use App\Models\UserPatientMapping;
use App\Models\UserType;
use Illuminate\Http\Request;
use Intervention\Image\ImageManagerStatic as Image;
use Illuminate\Support\Facades\Validator;
use Illuminate\Support\Facades\DB;
use Illuminate\Validation\Rule;

class UserController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index(Request $request)
    {
        $users = User::query();
        $records_per_page = 10;
        if (!empty($request->first_name)) {
            $users = $users->where('first_name', 'like', '%' . $request->first_name . '%');
        }
        if (!empty($request->last_name)) {
            $users = $users->where('last_name', 'like', '%' . $request->last_name . '%');
        }
        if (!empty($request->email)) {
            $users = $users->where('email', 'like', '%' . $request->email . '%');
        }
        if (!empty($request->mobile)) {
            $users = $users->where('mobile', 'like', '%' . $request->mobile . '%');
        }
        if (!empty($request->user_type)) {
            $users = $users->where('user_type_id', '=', $request->user_type);
        }
        if (!empty($request->ref_code)) {
             $users = $users->where('ref_code', 'like', '%' . $request->ref_code . '%');
        }

        if (!empty($request->records_per_page) && is_numeric($request->records_per_page)) {
            $records_per_page = $request->records_per_page;
        }
        if (!empty($request->sort_field)) {
            if ($request->sort_field == 'fname' && ($request->sort_action == 'ASC' || $request->sort_action == 'DESC')) {
                $users = $users->orderBy("first_name", $request->sort_action);
            } elseif ($request->sort_field == 'lname' && ($request->sort_action == 'ASC' || $request->sort_action == 'DESC')) {
                $users = $users->orderBy("last_name", $request->sort_action);
            } elseif ($request->sort_field == 'email' && ($request->sort_action == 'ASC' || $request->sort_action == 'DESC')) {
                $users = $users->orderBy("email", $request->sort_action);
            } elseif ($request->sort_field == 'mobile' && ($request->sort_action == 'ASC' || $request->sort_action == 'DESC')) {
                $users = $users->orderBy("mobile", $request->sort_action);
            } elseif ($request->sort_field == 'dob' && ($request->sort_action == 'ASC' || $request->sort_action == 'DESC')) {
                $users = $users->orderBy("dob", $request->sort_action);
            } elseif ($request->sort_field == 'bloodGroup' && ($request->sort_action == 'ASC' || $request->sort_action == 'DESC')) {
                $users = $users->orderBy("blood_group", $request->sort_action);
            } elseif ($request->sort_field == 'gender' && ($request->sort_action == 'ASC' || $request->sort_action == 'DESC')) {
                $users = $users->orderBy("gender", $request->sort_action);
            } elseif ($request->sort_field == 'userType' && ($request->sort_action == 'ASC' || $request->sort_action == 'DESC')) {
                $users = $users->orderBy("user_type_id", $request->sort_action);
            } elseif ($request->sort_field == 'status' && ($request->sort_action == 'ASC' || $request->sort_action == 'DESC')) {
                $users = $users->orderBy("status_id", $request->sort_action);
            }
        } else {
            $users = $users->orderBy("id", "DESC");
        }
        if (isset($request->limit)) {
            $users->limit($request->limit);
        }
        if (isset($request->offset)) {
            $users->offset($request->offset);
        }
        // $userType = UserType::get();
        // $users = $users->paginate($records_per_page);
        $data = [];
        $data['total_records'] = $users->count();
        $data['users_data'] = $users->get();
        return success($data, "User fetch Succesfully.");

        // if ($request->ajax()) {
        //     return view('backend.users.ajax_content', compact('users', 'userType'));
        // } else {
        //     return view('backend.users.index', compact('users', 'userType'));
        // }
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        //
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        $user = $request->user(); // auth user token or data
        $validator = Validator::make($request->all(), [
            'first_name' => 'required|string',
            'last_name' => 'required|string',
            'email' => [
                'required',
                'email' => Rule::unique('user')->where(function ($query) use ($request) {
                    return $query->where('user_type_id', $request->user_type_id);
                })
            ],
            'mobile' => [
                'required',
                'mobile' => Rule::unique('user')->where(function ($query) use ($request) {
                    return $query->where('user_type_id', $request->user_type_id);
                })
            ],
        ], [
            "mobile.unique" => 'Sorry, ' . $request['mobile'] . ' Mobile no already use by other user try with different Mobile no.',
            "email.unique" => 'Sorry, ' . $request['email'] . ' Email already use by other user try with different email.'
        ]);

        if ($validator->fails()) {
            return error($validator->errors()->first());
        } else {
            $user = new User;
            $user->first_name = $request->first_name;
            $user->last_name = $request->last_name;
            $user->email = $request->email;
            $user->mobile = $request->mobile;
            $user->dob = !empty($request->dob) ? date('Y-m-d', strtotime($request->dob)) : null;
            $user->blood_group = $request->blood_group;
            $user->gender = $request->gender;
            $user->user_type_id = $request->user_type_id;
            $user->status_id = $request->status_id;

            if (!empty($request->photo) && in_array($request->photo->extension(), allow_file_type_uploads)) {
                $image = $request->file('photo');
                $imageName = seo_url("{$request->first_name} {$request->last_name}") . '.' . $request->photo->extension();
                $image_resize = Image::make($image->getRealPath());
                $image_resize->resize(400, null, function ($constraint) {
                    $constraint->aspectRatio();
                });
                $image_resize->save(public_path('image/use_profile/' . $imageName));
                $user->photo = $imageName;
            }
            $user->save();
            if (!empty($user) && $user->user_type_id == END_USER) {
                UserPatientMapping::create([
                    "first_name" => $request->first_name,
                    "last_name" => $request->last_name,
                    "email" => $request->email,
                    "mobile" => $request->mobile,
                    "blood_group" => $request->blood_group,
                    "gender" => $request->gender,
                    "user_id" => $user->id,
                    "status_id" => STATUS_ACTIVE,
                    "relation" => 'SELF',
                    "created_at" => date('Y-m-d H:i:s')
                ]);
            }
            return success($user, "User Details Added Succesfully.");
        }
    }

    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function show($id)
    {
        $user = User::with(['status', 'userType'])->where("id", $id)->first();
        if ($user) {
            return success($user, "User Fetch Successfully.");
        } else {
            return error("User Not Available in our database.");
        }
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function edit($id)
    {
        //
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, $id)
    {
        $data = $request->all();
        $input['id'] = $id;
        $validator = Validator::make($request->all(), [
            'user_type_id' => "required_with:email,mobile",
            'email' => [
                'nullable',
                'email' => Rule::unique('user')->where(function ($query) use ($request) {
                    return $query->where('user_type_id', $request->user_type_id);
                })
            ],
            'mobile' => [
                'nullable',
                'mobile' => Rule::unique('user')->where(function ($query) use ($request) {
                    return $query->where('user_type_id', $request->user_type_id);
                })
            ],
        ], [
            "mobile.unique" => 'Sorry, ' . $request['mobile'] . ' Mobile no already use by other user try with different Mobile no.',
            "email.unique" => 'Sorry, ' . $request['email'] . ' Email already use by other user try with different email.'
        ]);

        if ($validator->fails()) {
            return error($validator->errors()->first());
        } else {
            $user = User::where('id', $id)->first();
            if ($user) {
                if (!empty($request->photo) && in_array($request->photo->extension(), allow_file_type_uploads)) {
                    if (!empty($user->photo)) {
                        $path = "image/use_profile/";
                        @unlink(public_path($path . $user->photo));
                    }
                    $image = $request->file('photo');
                    $imageName = seo_url("{$user->first_name} {$user->last_name}") . '.' . $request->photo->extension();
                    $image_resize = Image::make($image->getRealPath());
                    $image_resize->resize(400, null, function ($constraint) {
                        $constraint->aspectRatio();
                    });
                    $image_resize->save(public_path('image/use_profile/' . $imageName));
                    $user->photo = $imageName;
                    $user->save();
                }
                $user->update($request->except('photo'));

                if ($user->user_type_id == END_USER) {
                    $input['first_name'] = $user->first_name;
                    $input['last_name'] = $user->last_name;
                    $input['email'] = $user->email;
                    $input['mobile'] = $user->mobile;
                    $input['dob'] = !empty($user->dob) ? date('Y-m-d', strtotime($user->dob)) : null;
                    $input['blood_group'] = $user->blood_group;
                    $input['gender'] = $user->gender;
                    $input['user_type_id'] = $user->user_type_id;
                    $input['status_id'] = $user->status_id;
                    $userPatientMapping = \App\Models\UserPatientMapping::where(['user_id' => $user->id, "relation" => 'SELF'])->first();
                    $userPatientMapping->fill($input)->save();
                }
                return success($user, "User Details Updated Succesfully.");
            } else {
                return error("User is not available");
            }
        }
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function destroy($id)
    {
        //
    }

    public function getMobileUser($input)
    {
        $user = User::where('mobile', $input['mobile'])
            ->where('user_type_id', $input['user_type_id'])
            ->first();
        return $user;
    }

    public function getMobileEmail($input)
    {
        $user = User::where('email', $input['email'])
            ->where('user_type_id', $input['user_type_id'])
            ->first();
        return $user;
    }

    public function userSearch(Request $request)
    {
        $search = $request->get('search');
        $data = User::select(DB::raw("CONCAT(user.first_name,' ',user.last_name,' (', user.email,' - ', user.mobile,')') as label"), "id", DB::raw("CONCAT(user.first_name,' ',user.last_name) as value"))
            ->where(function ($data) use ($search) {
                return $data->where('first_name', 'LIKE', '%' . $search . '%')
                    ->orwhere('last_name', 'LIKE', '%' . $search . '%')
                    ->orwhere('email', 'LIKE', '%' . $search . '%')
                    ->orwhere('mobile', 'LIKE', '%' . $search . '%');
            })->get();

        return success($data, "User Details get Succesfully.");
    }
}
