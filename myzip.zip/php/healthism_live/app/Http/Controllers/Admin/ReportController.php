<?php

namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Controller;
use App\Models\Doctor;
use App\Models\Lab;
use App\Models\ReportProblem;
use App\Models\ReportProblemType;
use App\Models\Service;
use App\Models\Subscription;
use Illuminate\Http\Request;

class ReportController extends Controller
{
    public function index(Request $request)
    {
        $userComplain = ReportProblem::query();
        $records_per_page = 5;
        if (!empty($request->user_id) && is_numeric($request->user_id)) {
            $userComplain->where('user_id', '=', trim($request->user_id));
        }
        if (!empty($request->service_id) && is_numeric($request->service_id)) {
            $userComplain->where('service_id', '=', trim($request->service_id));
        }
        if (!empty($request->type)) {
            $userComplain->where('type', 'like', '%' . $request->type . '%');
        }
        $userComplain->orderBy("id", 'DESC');
        // if (!empty($request->records_per_page) && is_numeric($request->records_per_page)) {
        //     $records_per_page = $request->records_per_page;
        // }
        // $userComplain = $userComplain->paginate($records_per_page);
        $userComplain = $userComplain->get();
        if (!empty($userComplain)) {
            foreach ($userComplain as $key => $value) {
                if (!empty($value['ref_id']) && !empty($value['service_id'])) {
                    if ($value['service_id'] == SERVICE_DOCTOR_APPOINTMENT) {
                        $refData = Doctor::findOrFail($value['ref_id']);
                        if (!empty($refData)) {
                            $refData['title1'] = $refData['first_name'] . ' ' . $refData['last_name'];
                            $refData['title2'] = $refData['phone'];
                            $refData['title3'] = $refData['specialization'];
                        }
                    }
                    if ($value['service_id'] == SERVICE_LAB_REPORT) {
                        $refData = Lab::findOrFail($value['ref_id']);
                        if (!empty($refData)) {
                            $refData['title1'] = $refData['name'];
                            $refData['title2'] = $refData['phone'];
                            $refData['title3'] = $refData['area'];
                        }
                    }
                    if ($value['service_id'] == SERVICE_SUBSCRIPTION_PLAN) {
                        $refData = Subscription::findOrFail($value['ref_id']);
                        if (!empty($refData)) {
                            $refData['title1'] = $refData['name'];
                            $refData['title2'] = $refData['member'] . ' Member plan for ' . $refData['validity_in_days'] . ' Days';
                            $refData['title3'] = 'Price : ' . $refData['price'];
                        }
                    }
                    $userComplain[$key]['ref_data'] = $refData;
                }
            }
        }
        $typeList = ReportProblemType::all();
        $service = Service::all();
        return success($userComplain, "User Complain fetch successfully.");
        // if ($request->ajax()) {
        //     return view('backend.user_complain.ajax_content', compact('userComplain', 'typeList', 'service'));
        // } else {
        //     return view('backend.user_complain.index', compact('userComplain', 'typeList', 'service'));
        // }
    }
}
