<?php

namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Controller;
use App\Models\Feedback;
use App\Models\Platform;
use Illuminate\Http\Request;

class FeedbackController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index(Request $request)
    {
        // $records_per_page = 10;
        $feedback = Feedback::query();
        if (!empty($request->app_id) && is_numeric($request->app_id)) {
            $feedback->where('app_id', '=', trim($request->app_id));
        }
        if (!empty($request->platform_id) && is_numeric($request->platform_id)) {
            $feedback->where('platform_id', '=', trim($request->platform_id));
        }

        $feedback->orderBy("id", 'DESC');
        // if (!empty($request->records_per_page) && is_numeric($request->records_per_page)) {
        //     $records_per_page = $request->records_per_page;
        // }
        // $feedback = $feedback->paginate($records_per_page);
        // $platformList = Platform::all();
        // $appList = [["id" => END_USER_APP, 'name' => 'USER APP'], ["id" => MERCHANT_APP, 'name' => 'MERCHANT APP']];
        $feedback = $feedback->with(['user', 'platform'])->get();
        $data = [];
        $data['total_records'] = $feedback->count();
        $data['feedback_data'] = $feedback;
        return success($data, "Feedback fetch successfully");
        // if ($request->ajax()) {
        //     return view('backend.feedback.ajax_content', compact('feedback', 'appList', 'platformList'));
        // } else {
        //     return view('backend.feedback.index', compact('feedback', 'appList', 'platformList'));
        // }
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        //
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        //
    }

    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function show($id)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function edit($id)
    {
        //
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, $id)
    {
        //
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function destroy($id)
    {
        //
    }
}
