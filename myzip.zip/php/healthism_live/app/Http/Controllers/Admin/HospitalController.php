<?php

namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Controller;
use App\Models\City;
use App\Models\Hospital;
use App\Models\HospitalDetails;
use App\Models\State;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Validator;
use Intervention\Image\ImageManagerStatic as Image;


class HospitalController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index(Request $request)
    {
        $hospitals = Hospital::query();
        $records_per_page = 10;
        if (!empty($request->name)) {
            $hospitals = $hospitals->where('name', 'like', '%' . $request->name . '%');
        }
        if (!empty($request->phone)) {
            $hospitals = $hospitals->where('phone', 'like', '%' . $request->phone . '%');
        }
        if (!empty($request->pincode)) {
            $hospitals = $hospitals->where('pincode', 'like', '%' . $request->pincode . '%');
        }
        if (!empty($request->city_id)) {
            //$hospitals = $hospitals->whereRelation('city', 'name', 'like', '%' . $request->city . '%');
            $hospitals = $hospitals->where('city_id', "=", $request->city_id);
        }
        if (!empty($request->state_id)) {
            //   $hospitals = $hospitals->whereRelation('state', 'name', 'like', '%' . $request->state . '%');
            $hospitals = $hospitals->where('state_id', "=", $request->state_id);
        }

        if (!empty($request->records_per_page) && is_numeric($request->records_per_page)) {
            $records_per_page = $request->records_per_page;
        }
        if (!empty($request->sort_field)) {
            if ($request->sort_field == 'name' && ($request->sort_action == 'ASC' || $request->sort_action == 'DESC')) {
                $hospitals = $hospitals->orderBy("name", $request->sort_action);
            } elseif ($request->sort_field == 'Area' && ($request->sort_action == 'ASC' || $request->sort_action == 'DESC')) {
                $hospitals = $hospitals->orderBy("area", $request->sort_action);
            } elseif ($request->sort_field == 'Pincode' && ($request->sort_action == 'ASC' || $request->sort_action == 'DESC')) {
                $hospitals = $hospitals->orderBy("pincode", $request->sort_action);
            }
        } else {
            $hospitals = $hospitals->orderBy("id", "DESC");
        }

        // $hospitals = $hospitals->paginate($records_per_page);
        if (isset($request->limit)) {
            $hospitals->limit($request->limit);
        }
        if (isset($request->offset)) {
            $hospitals->offset($request->offset);
        }
        $data = [];
        $data['total_records'] = $hospitals->count();
        $data['hospitals_data'] = $hospitals->with(['state', 'city'])->get();
        return success($data, "Hospitals fetch Succesfully.");

        // $states = State::where('active', 1)->get();
        // $cities = [];
        // if (!empty($request->state_id)) {
        //     $cities = City::where(['active' => 1, 'state_id' => $request->state_id])->get();
        // }
        // if ($request->ajax()) {
        //     return view('backend.hospitals.ajax_content', compact('hospitals', 'states', 'cities'));
        // } else {
        //     return view('backend.hospitals.index', compact('hospitals', 'states', 'cities'));
        // }
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        //
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        $data = $request->all();
        $validator = Validator::make($data, [
            'name' => "required",
            'phone' => "required",
            'type' => "required|in:Hospital,Clinic",
            'address1' => "required",
            'address2' => "required",
            'area' => "required",
            'pincode' => "required",
            'city_id' => "required",
            'state_id' => "required",
            'latitude' => "required",
            'longitude' => "required",
            'pancard_number' => "required|min:11|max:11",
        ]);

        if ($validator->fails()) {
            return error($validator->errors()->first());
        } else {

            $hospital = new Hospital();
            $hospital_details = new HospitalDetails();

            $hospital->name = $request->name;
            $hospital->phone = $request->phone;
            $hospital->address1 = $request->address1;
            $hospital->address2 = $request->address2;
            $hospital->area = $request->area;
            $hospital->pincode = $request->pincode;
            $hospital->city_id = $request->city_id;
            $hospital->state_id = $request->state_id;
            $validateLatLong = validateLatLong($request->latitude, $request->longitude);
            if (!empty($validateLatLong)) {
                $hospital->latitude = $request->latitude;
                $hospital->longitude = $request->longitude;
            } else {
                return error("longitude and latitude are not valid");
            }
            $hospital->type = $request->type;
            $hospital->cash_booking_allowed = $request->cash_booking_allowed == 'on' ? 1 : 0;
            $hospital->cancellation_allowed = $request->cancellation_allowed == 'on' ? 1 : 0;
            $hospital->status_id = $request->status_id;

            if (!empty($request->photo) && in_array($request->photo->extension(), allow_file_type_uploads)) {
                $image = $request->file('photo');
                $imageName = seo_url("healthism hospital {$request->name}") . '.' . $request->photo->extension();
                $image_resize = Image::make($image->getRealPath());
                $image_resize->resize(800, null, function ($constraint) {
                    $constraint->aspectRatio();
                });
                $image_resize->save(public_path('image/hospital/' . $imageName));
                $hospital->photo = $imageName;
            }

            if (!empty($request->cancel_policy)) {
                $cancel_policy = explode(",", $request->cancel_policy);
                $hospital->cancel_policy = $request->cancel_policy;
                // dump($hospital->cancel_policy);
                // $cancel_policy = [];
                // foreach ($request->cancel_policy as $key => $val) {
                //     $val = array_values($val);
                //     if (!empty($val && !empty(trim($val[0])))) {
                //         $cancel_policy[] = trim($val[0]);
                //     }
                // }
                // if (!empty($cancel_policy)) {
                //     $hospital->cancel_policy = json_encode($cancel_policy);
                // }
            }

            if (!empty($request->cancel_policy_setting)) {
                $hospital->cancel_policy_setting = $request->cancel_policy_setting;
                // dd($request->cancel_policy_setting);
                // $cancel_policy_setting = [];
                // foreach ($request->cancel_policy_setting as $val) {
                //     if (!empty(trim($val['hours'])) && !empty(trim($val['charge']))) {
                //         $cancel_policy_setting[] = $val;
                //     }
                // }
                // if (!empty($cancel_policy_setting)) {
                //     $hospital->cancel_policy_setting = json_encode($cancel_policy_setting);
                // }
            }


            /*
             * hospital details
             */

            $hospital_details->pancard_number = $request->pancard_number;
            $hospital_details->gst_number = $request->gst_number;
            $hospital_details->bank_account_number = $request->bank_account_number;
            $hospital_details->bank_account_name = $request->bank_account_name;
            $hospital_details->bank_name = $request->bank_name;
            $hospital_details->bank_ifsc_code = $request->bank_ifsc_code;

            $gallery_images = [];
            if (!empty($request->images_list)) {
                // foreach ($request->images_list as $row) {
                //     $fileName = explode(".", $row);
                //     $imageName = seo_url("healthism hospital $request->name {$fileName[0]}") . "." . $fileName[1];
                //     $imageName = change_filename("image/hospital/", $imageName);
                //     copy(public_path("/image/temp/{$row}"), public_path('image/hospital_gallery/' . $imageName));
                //     $gallery_images[] = $imageName;
                // }
                // $hospital_details->gallery_json = json_encode(array_values($gallery_images));

                foreach ($request->images_list as $row) {
                    $imageName = seo_url("healthism hospital {$request->name}") . "." . $row->extension();
                    $imageName = change_filename("image/hospital_gallery/", $imageName);
                    if ($row->move(public_path('image/hospital_gallery'), $imageName)) {
                        // $hospital_details->pancard_document = $imageName;
                        $gallery_images[] = $imageName;
                    }
                }
                $hospital_details->gallery_json = json_encode(array_values($gallery_images));
            }

            if (!empty($request->pancard_document)) {
                $imageName = seo_url("pan healthism hospital {$request->name}") . '.' . $request->pancard_document->extension();
                $imageName = change_filename("image/hospital/", $imageName);
                if ($request->pancard_document->move(public_path('image/hospital'), $imageName)) {
                    $hospital_details->pancard_document = $imageName;
                }
            }

            if (!empty($request->gst_certificate)) {
                $imageName = seo_url("gst healthism hospital {$request->name}") . '.' . $request->gst_certificate->extension();
                $imageName = change_filename("image/hospital/", $imageName);

                if ($request->gst_certificate->move(public_path('image/hospital'), $imageName)) {
                    if (!empty($hospital->gst_certificate)) {
                        @unlink('image/hospital/' . $hospital->hospital_details->gst_certificate);
                    }
                }
                $hospital_details->gst_certificate = $imageName;
            }
            // dd($request->all());

            $hospital->save();
            $hospital_details->hospital_id = $hospital->id;
            $hospital_details->save();

            $doctor = Hospital::with(['hospital_details', 'state', 'city'])->where('id', $hospital->id)->first();
            return success($doctor, "Hospital Details Added Succesfully.");
        }
    }

    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function show($id)
    {
        $hospital = Hospital::with(['hospital_details', 'status', 'state', 'city'])->where('id', $id)->first();
        if ($hospital) {
            return success($hospital, "Hospital fetch Succesfully.");
        } else {
            return error("This Hospital is not available.");
        }
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function edit($id)
    {
        //
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, $id)
    {
        $hospital = Hospital::findOrFail($id);
        if ($hospital) {
            if (!empty($request->cash_booking_allowed) || !empty($request->cancellation_allowed)) {
                $hospital->cash_booking_allowed = $request->cash_booking_allowed == 'on' ? 1 : 0;
                $hospital->cancellation_allowed = $request->cancellation_allowed == 'on' ? 1 : 0;
            }

            // $cancel_policy = [];
            if (!empty($request->cancel_policy)) {
                $hospital->cancel_policy = $request->cancel_policy;
                // foreach ($request->cancel_policy as $key => $val) {
                //     $val = array_values($val);
                //     if (!empty($val && !empty(trim($val[0])))) {
                //         $cancel_policy[] = trim($val[0]);
                //     }
                // }
            }
            // if (!empty($cancel_policy)) {
            //     $hospital->cancel_policy = json_encode($cancel_policy);
            // }

            // $cancel_policy_setting = [];
            if (!empty($request->cancel_policy_setting)) {
                $hospital->cancel_policy_setting = $request->cancel_policy_setting;
                // foreach ($request->cancel_policy_setting as $val) {
                //     if (!empty(trim($val['hours'])) && !empty(trim($val['charge']))) {
                //         $cancel_policy_setting[] = $val;
                //     }
                // }
            }
            // if (!empty($cancel_policy_setting)) {
            //     $hospital->cancel_policy_setting = json_encode($cancel_policy_setting);
            // }


            if (!empty($request->photo) && in_array($request->photo->extension(), allow_file_type_uploads)) {
                if (!empty($hospital->photo)) {
                    @unlink('image/hospital/' . $hospital->photo);
                }

                $image = $request->file('photo');
                $imageName = seo_url("healthism hospital {$request->name}") . '.' . $request->photo->extension();
                $image_resize = Image::make($image->getRealPath());
                $image_resize->resize(800, null, function ($constraint) {
                    $constraint->aspectRatio();
                });
                $image_resize->save(public_path('image/hospital/' . $imageName));
                $hospital->photo = $imageName;
            }

            if (!empty($request->pancard_document)) {
                $imageName = seo_url("pan healthism hospital {$request->name}") . '.' . $request->pancard_document->extension();
                $imageName = change_filename("image/hospital/", $imageName);

                if ($request->pancard_document->move(public_path('image/hospital'), $imageName)) {
                    if (!empty($hospital->hospital_details->pancard_document)) {
                        @unlink('image/hospital/' . $hospital->hospital_details->pancard_document);
                    }
                }
                $hospital->hospital_details->pancard_document = $imageName;
            }

            if (!empty($request->gst_certificate)) {
                $imageName = seo_url("gst healthism hospital {$request->name}") . '.' . $request->gst_certificate->extension();
                $imageName = change_filename("image/hospital/", $imageName);

                if ($request->gst_certificate->move(public_path('image/hospital'), $imageName)) {
                    if (!empty($hospital->hospital_details->gst_certificate)) {
                        @unlink('image/hospital/' . $hospital->hospital_details->gst_certificate);
                    }
                }
                $hospital->hospital_details->gst_certificate = $imageName;
            }

            $hospital->update($request->except('photo', 'cash_booking_allowed', 'cancellation_allowed'));
            $hospital->hospital_details->update($request->except('pancard_document', 'gst_certificate'));
            return success($hospital, "Hospital Details Updated Succesfully.");
        } else {
            return error("hospital is not available");
        }
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function destroy($id)
    {
        //
    }

    public function hospitalSearch(Request $request)
    {
        $search = $request->get('search');
        //    $data = Hospital::select(DB::raw("CONCAT(hospital.name,' (', hospital.area,')') as label"), "id", DB::raw("CONCAT(hospital.name,' (', hospital.area,')') as value"))
        //                    ->where('name', 'LIKE', '%' . $search . '%')->get();
        $data = Hospital::where('name', 'LIKE', '%' . $search . '%')->limit(10)->get();
        $result = [];
        if (!empty($data)) {
            foreach ($data as $value) {
                $hospital['label'] = $value['name'] . '(' . $value['area'] . ',' . $value['city']['name'] . ',' . $value['state']['name'] . ')';
                $hospital['id'] = $value['id'];
                $result[] = $hospital;
            }
            return success($result, "Hospital Details get Succesfully.");
        } else {
            return error($result, "Hospital Details not found.");
        }
    }

    public function getState()
    {
        $states = State::where('active', 1)->get();
        return success($states, 'get all states.');
    }

    public function getCities()
    {
        $states = city::where('active', 1)->get();
        return success($states, 'get all cities.');
    }

    public function fetchGalleryImages(Request $request, $id)
    {
        $hospital = Hospital::findOrFail($id);
        $gallery_images = json_decode($hospital->hospital_details->gallery_json, true);
        $images = [];
        if (!empty($gallery_images)) {
            foreach ($gallery_images as $row) {
                $size = @filesize("image/hospital_gallery/" . $row);
                $images[] = ['name' => $row, 'size' => $size, 'path' => "/image/hospital_gallery/{$row}"];
            }
        }

        return success($images, "Hospital gallery fetch Succesfully.");
    }

    public function galleryImagesDelete(Request $request, $id)
    {
        if (!empty($id)) {
            $hospital = Hospital::findOrFail($id);
            $gallery_images = json_decode($hospital->hospital_details->gallery_json, true);
            $gallery_images = array_filter($gallery_images, fn ($m) => $m != $request->name);
            $gallery_images = array_values($gallery_images);
            $hospital->hospital_details->gallery_json = json_encode($gallery_images);
            @unlink('image/hospital_gallery/' . $request->name);
            $hospital->hospital_details->save();
            return success($hospital, 'remove image success.');
        } else {
            unlink(public_path('/image/temp/') . $request->name);
        }
    }

    public function removeProfile($id)
    {
        $hospital = Hospital::findOrFail($id);
        // $images = [];
        // if ($hospital->hospital_details->gallery_json != 'NULL' && !empty($hospital->hospital_details->gallery_json)) {
        //     $gallery_images = json_decode($hospital->hospital_details->gallery_json, true);
        //     if (!empty($gallery_images)) {
        //         foreach ($gallery_images as $row) {
        //             $images[] = ['name' => $row];
        //         }
        //     }
        // }
        if (!empty($hospital->photo)) {
            if (file_exists(public_path('image/hospital/' . $hospital->photo))) {
                @unlink(public_path('image/hospital/' . $hospital->photo));
            }
            $hospital->photo = null;
            $hospital->save();
        }
        return success([], "Remove hospital profile.");
    }
}
