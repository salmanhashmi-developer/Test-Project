<?php

namespace App\Http\Controllers\Admin;

use App\Helpers\Helpers;
use App\Http\Controllers\Controller;
use App\Models\UserPatientMapping;
use Illuminate\Http\Request;

class UserPatientMappingController extends Controller {

    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index(Request $request) {
        $userPatientMapping = UserPatientMapping::query();
        $records_per_page = 10;
        if (!empty($request->mobile)) {
            $userPatientMapping->where('mobile', '=', trim($request->mobile));
        }
        if (!empty($request->user_id) && is_numeric($request->user_id)) {
            $userPatientMapping->where('user_id', '=', trim($request->user_id));
        }
        if (!empty($request->blood_group)) {
            $userPatientMapping->where('blood_group', '=', trim($request->blood_group));
        }
        $userPatientMapping->with(['user', 'status'])->orderBy("id", 'DESC');
        // if (!empty($request->records_per_page) && is_numeric($request->records_per_page)) {
        //     $records_per_page = $request->records_per_page;
        // }
        // $userPatientMapping = $userPatientMapping->paginate($records_per_page);
        // $bloodGroupList = Helpers::getEnumValues('user_patient_mapping', 'blood_group');
        $data = [];
        $data['total_records'] = $userPatientMapping->count();
        $data['user_patient_mapping_data'] = $userPatientMapping->get();
        return success($data, "Patient fetch successfully.");
        // if ($request->ajax()) {
        //     return view('backend.user_patient.ajax_content', compact('userPatientMapping', 'bloodGroupList'));
        // } else {
        //     return view('backend.user_patient.index', compact('userPatientMapping', 'bloodGroupList'));
        // }
    }

    public function userPatient(Request $request) {
        if (empty($request->user_id)) {
            return error("Sorry, User id is empty");
        }
        $result = UserPatientMapping::where([
                    'user_id' => $request->user_id,
                    'status_id' => STATUS_ACTIVE,
                    'is_deleted' => 0
                ])->orderBy('created_at', 'desc')->get();
        return success($result, "User patient list");
    }

    public function store(Request $request) {
        if (empty($request->user_id)) {
            return error("Sorry, User id is empty");
        }
        $rules = UserPatientMapping::$rules;
        if (sizeof($rules) > 0) {
            $validation = $this->validateRequest($request, $rules);
            if (!empty($validation)) {
                return error($validation);
            }
        }
        $input = $request->all();
        $input['user_id'] = $input['user_id'];
        $input['status_id'] = STATUS_ACTIVE;
        $input['first_name'] = ucwords($input['first_name']);
        $input['last_name'] = ucwords($input['last_name']);
        $input['created_at'] = date('Y-m-d H:i:s');
        $result = UserPatientMapping::create($input);
        return success($result, "User patient has been saved successfully");
    }

    public function create() {
        //
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function show($id) {
        //
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function edit($id) {
        //
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, $id) {
        //
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function destroy($id) {
        //
    }

}
