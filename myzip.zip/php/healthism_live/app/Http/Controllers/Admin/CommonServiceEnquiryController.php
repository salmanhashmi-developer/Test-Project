<?php

namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Controller;
use App\Models\CommonServiceEnquiry;
use Illuminate\Http\Request;

class CommonServiceEnquiryController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index(Request $request)
    {
        $commonServiceEnquiry = CommonServiceEnquiry::query();
        $records_per_page = 10;
        $commonServiceEnquiry->join('common_service', 'common_service_enquiry.common_service_id', '=', 'common_service.id');
        //$commonServiceEnquiry->join('status', 'common_service_enquiry.status_id', '=', 'status.id');
        if (!empty($request->mobile)) {
            $commonServiceEnquiry->where('mobile', 'like', '%' . $request->mobile . '%')->orWhere('mobile', "=", $request->mobile);
        }
        if (!empty($request->user_id)) {
            $commonServiceEnquiry->where('user_id', "=", $request->user_id);
        }
        if (!empty($request->start_date)) {
            $commonServiceEnquiry->whereDate('appointment_date', '>=', date('Y-m-d', strtotime($request->start_date)));
        }
        if (!empty($request->end_date)) {
            $commonServiceEnquiry->whereDate('appointment_date', '<=', date('Y-m-d', strtotime($request->end_date)));
        }
        if (!empty($request->catogry_id)) {
            $commonServiceEnquiry->where('common_service.category_id', "=", $request->catogry_id);
        }
        $commonServiceEnquiry->select('common_service_enquiry.*', 'common_service.name AS operator_name', 'common_service.phone', 'common_service.category_id');
        if (!empty($request->records_per_page) && is_numeric($request->records_per_page)) {
            $records_per_page = $request->records_per_page;
        }
        // $commonServiceEnquiry = $commonServiceEnquiry->paginate($records_per_page);
        if (isset($request->limit)) {
            $commonServiceEnquiry->limit($request->limit);
        }
        if (isset($request->offset)) {
            $commonServiceEnquiry->offset($request->offset);
        }

        $data = [];
        $data['total_records'] = $commonServiceEnquiry->count();
        $data['common_service_enquiry_data'] = $commonServiceEnquiry->get();

        return success($data, "Common Service Enquiry fetch Succesfully.");
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        //
    }


    public function adminUpdateOrder(Request $request)
    {
        $input = $request->all();
        $commonServiceEnquiry = CommonServiceEnquiry::findOrFail($input['id']);
        if ($commonServiceEnquiry->status_id != $input['status_id']) {
            $remarks = [];
            if (!empty($commonServiceEnquiry->remark_json)) {
                $remarks = json_decode($commonServiceEnquiry->remark_json, true);
            }
            $statusList = [STATUS_PENDING => 'PENDING', STATUS_INPROGRESS => 'INPROGRESS', STATUS_DONE => 'DONE', STATUS_CANCELLED => 'CANCELLED'];
            $updatedBy = $request->user()->first_name . ' ' . $request->user()->last_name . '(' . $request->user()->mobile . ')';
            $remarks = [
                'remark' => $input['remark'],
                'status' => $statusList[$input['status_id']],
                'updated_at' => date('Y-m-d H:i:s'),
                'updated_by_name' => $updatedBy,
                'updated_by' => $request->user()->id
            ];
            $updateData = ['status_id' => $input['status_id'], 'remark_json' => json_encode($remarks)];
            $commonServiceEnquiry->fill($updateData)->save();
        }
        return success($input['id'],  'Enquiry status Updated Successfully!');
    }
    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        //
    }

    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function show($id)
    {
        // $commonServiceEnquiry = CommonServiceEnquiry::findOrFail($id);
        // dd($commonServiceEnquiry->status);
        $commonServiceEnquiry = CommonServiceEnquiry::with(['common_service', 'user', 'status'])->where('id', $id)->first();
        $statusList = [STATUS_PENDING => 'PENDING', STATUS_INPROGRESS => 'INPROGRESS', STATUS_DONE => 'DONE', STATUS_CANCELLED => 'CANCELLED'];
        return success([$commonServiceEnquiry, $statusList], "Enquiry fetch successfully.");
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function edit($id)
    {
        //
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, $id)
    {
        //
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function destroy($id)
    {
        //
    }
}
