<?php

namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Controller;
use App\Models\CommonService;
use App\Models\Lab;
use App\Models\Service;
use App\Models\Subscription;
use App\Models\UserReview;
use Illuminate\Http\Request;

class UserReviewController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index(Request $request)
    {
        $userReview = UserReview::query();
        $records_per_page = 5;
        if (!empty($request->user_id) && is_numeric($request->user_id)) {
            $userReview->where('user_id', '=', trim($request->user_id));
        }
        if (!empty($request->service_id) && is_numeric($request->service_id)) {
            $userReview->where('service_id', '=', trim($request->service_id));
        }
        if (!empty($request->rating) && is_numeric($request->rating)) {
            $userReview->where('rating', '=', trim($request->rating));
        }
        $userReview->orderBy("id", 'DESC');
        // if (!empty($request->records_per_page) && is_numeric($request->records_per_page)) {
        //     $records_per_page = $request->records_per_page;
        // }
        // $userReview = $userReview->paginate($records_per_page);
        $userReview = $userReview->with(['user', 'service', 'status'])->get();

        if (!empty($userReview)) {
            foreach ($userReview as $key => $value) {
                if (!empty($value['ref_id']) && !empty($value['service_id'])) {
                    $refData['title1'] = $refData['title2'] = $refData['title3'] = "";
                    if ($value['service_id'] == SERVICE_DOCTOR_APPOINTMENT) {
                        $refDetail = \App\Models\Doctor::findOrFail($value['ref_id']);
                        if (!empty($refDetail)) {
                            $refData['title1'] = $refDetail['first_name'] . ' ' . $refDetail['last_name'];
                            $refData['title2'] = $refDetail['phone'];
                            $refData['title3'] = $refDetail['specialization'];
                        }
                    }
                    if ($value['service_id'] == SERVICE_LAB_REPORT) {
                        $refDetail = Lab::findOrFail($value['ref_id']);
                        if (!empty($refDetail)) {
                            $refData['title1'] = $refDetail['name'];
                            $refData['title2'] = $refDetail['phone'];
                            $refData['title3'] = $refDetail['area'] . " - " . $refDetail->city->name;
                        }
                    }
                    if ($value['service_id'] == SERVICE_SUBSCRIPTION_PLAN) {
                        $refDetail = Subscription::findOrFail($value['ref_id']);
                        if (!empty($refDetail)) {
                            $refData['title1'] = $refDetail['name'];
                            $refData['title2'] = $refDetail['member'] . ' Member plan for ' . $refDetail['validity_in_days'] . ' Days';
                            $refData['title3'] = 'Price : ' . $refDetail['price'];
                        }
                    }
                    if ($value['service_id'] == SERVICE_COMMON) {
                        $refDetail = CommonService::findOrFail($value['ref_id']);
                        if (!empty($refDetail)) {
                            $refData['title1'] = $refDetail['name'] . '(' . $refDetail->category->name . ')';
                            $refData['title2'] = $refDetail['phone'];
                            $refData['title3'] = $refDetail['area'] . "," . $refDetail->city->name;
                        }
                    }
                    $userReview[$key]['ref_data'] = $refData;
                }
            }
        }
        // $ratingList = [1, 2, 3, 4, 5];
        // $service = Service::all();
        // if ($request->ajax()) {
        //     return view('backend.user_review.ajax_content', compact('userReview', 'ratingList', 'service'));
        // } else {
        //     return view('backend.user_review.index', compact('userReview', 'ratingList', 'service'));
        // }
        return success($userReview, "User Review Fetch successfully.");
    }


    public function adminUpdateReview(Request $request)
    {
        $input = $request->all();
        $review = UserReview::findOrFail($input['review_id']);
        if (!empty($review)) {
            if ($review->status_id != $input['status_id']) {
                $review->fill(['status_id' => $input['status_id']])->save();
            }
        }
        return success([], 'Review updated successfully!');
    }

    public function adminDeleteReview($id)
    {
        $review = UserReview::findOrFail($id);
        if (!empty($review)) {
            $review->delete();
        }
        return success([], 'Review deleted successfully!');
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        //
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        //
    }

    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function show($id)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function edit($id)
    {
        //
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, $id)
    {
        //
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function destroy($id)
    {
        //
    }
}
