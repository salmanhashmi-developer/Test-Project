<?php

namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Controller;
use App\Models\UserUpload;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Validator;

class LabBookingController extends Controller {

    public function index(Request $request) {
        $result = [];
        $query = UserUpload::query();
        $records_per_page = 10;
        $query->where('service_id', SERVICE_LAB_REPORT);
        if (!empty($request->first_name)) {
            $query->whereRelation('user', 'first_name', '=', trim($request->first_name));
        }
        if (!empty($request->email)) {
            $query->whereRelation('user', 'email', '=', trim($request->email));
        }
        if (!empty($request->mobile)) {
            $query->whereRelation('user', 'mobile', '=', trim($request->mobile));
        }
        if (!empty($request->status_id)) {
            $query->whereRelation('user', 'status_id', '=', trim($request->status_id));
        }
        if (!empty($request->start_date)) {
            $query->whereDate('created_at', '>=', date('Y-m-d', strtotime($request->start_date)));
        }
        if (!empty($request->end_date)) {
            $query->whereDate('created_at', '<=', date('Y-m-d', strtotime($request->end_date)));
        }
        $query->orderBy("id", "DESC");
        $result['total_records'] = $query->count();
        if (isset($request->limit)) {
            $query->limit($request->limit);
        }
        if (isset($request->offset)) {
            $query->offset($request->offset);
        }
        $result['records'] = $query->with('user', 'userPatient', 'status')->get();
        return success($result, "Data list");
    }

    public function userDetail(Request $request) {
        $query = "SELECT
                        u.*,
                        us.id AS user_subscription_id,
                        us.card_no,
                        us.expiry_date,
                        us.status_id AS user_subscription_status_id,
                        s.`name` as subscription_name,
                        s.member,
                        s.validity_in_days
                 FROM
                        `user` AS u
                        LEFT JOIN user_subscription AS us ON (u.id = us.user_id AND us.status_id=" . STATUS_ACTIVE . ")
                        LEFT JOIN subscription AS s ON us.subscription_id=s.id 
                        WHERE ";
        if (!empty($request->user_id)) {
            $query .= " us.user_id = " . $request->user_id;
        } else {
            if (empty($request->card_no)) {
                return error("Sorry, User id and card no both are empty");
            }
            $query .= " us.card_no = " . $request->card_no;
        }
        $result = executeSelectQueryOnMySQLDB($query);
        if (empty(count($result))) {
            return error("Sorry, User not found");
        }
        $result = $result[0];
        if ($result['status_id'] != STATUS_ACTIVE) {
            return error("Sorry, User is inactive/blocked");
        }
        $expiryDate = date('Y-m-d', strtotime($result['expiry_date']));
        if (date('Y-m-d') > $expiryDate) {
            $result['plan_expire'] = 1;
            //return null;
            return error("Sorry, User's plan is expired", $result);
        }
        return success($result, "User detail");
    }

}
