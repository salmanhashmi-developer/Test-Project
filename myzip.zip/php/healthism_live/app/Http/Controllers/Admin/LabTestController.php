<?php

namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Controller;
use App\Models\Lab;
use App\Models\LabTest;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Validator;

class LabTestController extends Controller
{

    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function labTestList(Request $request)
    {
        $input = $request->all();
        if (empty($input['lab_id'])) {
            return error("Sorry, Lab id is empty");
        }
        if (empty($input['type'])) {
            return error("Sorry, Type is empty");
        }
        $page = !empty($input['page']) ? $input['page'] : 1;
        $skip = $page > 1 ? ($page * LIMIT) - LIMIT : 0;
        if (!empty($input['lab_id']) && !empty($input['self_test_available'])) {
            $query = LabTest::where('lab_id', $input['lab_id']);
        } else {
            $query = LabTest::where('lab_id', $input['parent_id']);
        }
        $query->where('status_id', STATUS_ACTIVE);
        if ($input['type'] == 'PACKAGE') {
            $query->where('is_package', 1);
        } else {
            $query->where('is_package', 0);
        }
        if (!empty($input['name'])) {
            $name = $input['name'];
            $query->where('name', 'like', '%' . $name . '%');
        }
        $result['total_records'] = $query->count();
        if (isset($input['limit'])) {
            $query->limit($input['limit']);
        }
        if (isset($input['offset'])) {
            $query->offset($input['offset']);
        }
        $result['records'] = $query->get();
        return success($result, 'Lab test list');
    }

    public function index(Request $request)
    {
        $lab_test = LabTest::query();
        $records_per_page = 10;
        if (!empty($request->name)) {
            $lab_test = $lab_test->where('name', 'like', '%' . $request->name . '%');
        }
        if (!empty($request->status)) {
            $lab_test = $lab_test->where('status', $request->status);
        }

        // if (!empty($request->records_per_page) && is_numeric($request->records_per_page)) {
        //     $records_per_page = $request->records_per_page;
        // }
        $lab_test = $lab_test->orderBy("id", "DESC");


        $data['total_records'] = $lab_test->count();
        if (isset($request->limit)) {
            $lab_test->limit($request->limit);
        }
        if (isset($request->offset)) {
            $lab_test->offset($request->offset);
        }
        $data = [];
        $data['lab_test_data'] = $lab_test->get();
        // $lab = $lab->paginate($records_per_page);

        return success($data, "Lab test data fetch Succesfully.");
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        //
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        $data = $request->all();
        $validator = Validator::make($data, [
            'lab_id' => 'required',
            'name' => "required",
            'gender' => "required",
            'description' => "required",
            'requirement' => "required",
            'preparation' => "required",
            'home_collection' => "required|in:off,on",
            'is_package' => "nullable|in:off,on",
            'package_category' => "required_with:is_package,on",
            'price' => "required",
            'discount' => "required",
            'test_count' => "required",
            'test_json' => "required",
        ]);

        if ($validator->fails()) {
            return error($validator->errors()->first());
        } else {
            $check_lab = Lab::where('id', $request->lab_id)->first();
            if ($check_lab) {
                $labTest = new LabTest();

                $labTest->lab_id = $request->lab_id;
                $labTest->lab_parent_id = !empty($request->lab_parent_id) ? $request->lab_parent_id : NULL;
                $labTest->name = $request->name;
                $labTest->gender = $request->gender;
                $labTest->description = $request->description;
                $labTest->requirement = $request->requirement;
                $labTest->preparation = $request->preparation;
                $labTest->test_count = $request->test_count;
                $labTest->test_json = $request->test_json;
                $labTest->price = $request->price;
                $labTest->discount = $request->discount;
                $labTest->e_report_hours = !empty($request->e_report_hours) ? $request->e_report_hours : NULL;
                $labTest->sort_order = !empty($request->sort_order) ? $request->sort_order : NULL;
                $labTest->home_collection = !empty($request->home_collection) ? ($request->home_collection == 'on' ? 1 : 0) : 0;
                $labTest->is_package = !empty($request->is_package) ? ($request->is_package == 'on' ? 1 : 0) : 0;
                $labTest->package_category = !empty($request->package_category) ? $request->package_category : NULL;
                $labTest->status_id = !empty($request->status_id) ? $request->status_id : STATUS_ACTIVE;

                $labTest->save();
                $lab_test = LabTest::with(['status'])->where('id', $labTest->id)->first();

                // when first test add for lab - self test available field update to 1
                $check_lab->whereNull('self_test_available')->update(['self_test_available' => 1]);

                return success($lab_test, "Lab test Details Added Succesfully.");
            } else {
                return error("Lab is not Available.");
            }
        }
    }

    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function show($id)
    {
        $lab_test = LabTest::with(['status'])->where('id', $id)->first();
        if ($lab_test) {
            return success($lab_test, "Lab test fetch Succesfully.");
        } else {
            return error("This Lab test master is not available.");
        }
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function edit($id)
    {
        //
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, $id)
    {
        $labTest = LabTest::findOrFail($id);
        $labTest->is_package = !empty($request->is_package) ? ($request->is_package == 'on' ? 1 : 0) : 0;
        $labTest->home_collection = !empty($request->home_collection) ? ($request->home_collection == 'on' ? 1 : 0) : 0;
        $labTest->update($request->except('is_package', 'home_collection'));
        return success($labTest, "Lab test Details Updated Successfully!");
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function destroy($id)
    {
        $lab_test = LabTest::with(['status'])->where('id', $id)->first();
        if ($lab_test) {
            $lab_test->delete();
            return success([], "Lab test master Succesfully.");
        } else {
            return error("This Lab test master is not available.");
        }
    }
}
