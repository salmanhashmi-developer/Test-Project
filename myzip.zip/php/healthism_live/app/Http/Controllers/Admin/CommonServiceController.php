<?php

namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Controller;
use App\Models\CommonService;
use App\Models\CommonServiceDetails;
use App\Models\CommonServiceMapping;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\URL;
use Illuminate\Support\Facades\Validator;
use Intervention\Image\ImageManagerStatic as Image;

class CommonServiceController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index(Request $request)
    {
        $commonService = CommonService::query();
        $records_per_page = 10;
        if (!empty($request->name)) {
            $commonService = $commonService->where('name', 'like', '%' . $request->name . '%');
        }
        if (!empty($request->phone)) {
            $commonService = $commonService->where('phone', 'like', '%' . $request->phone . '%');
        }
        if (!empty($request->pincode)) {
            $commonService = $commonService->where('pincode', 'like', '%' . $request->pincode . '%');
        }
        if (!empty($request->city_id)) {
            //$commonService = $commonService->whereRelation('city', 'name', 'like', '%' . $request->city . '%');
            $commonService = $commonService->where('city_id', "=", $request->city_id);
        }
        if (!empty($request->state_id)) {
            //   $commonService = $commonService->whereRelation('state', 'name', 'like', '%' . $request->state . '%');
            $commonService = $commonService->where('state_id', "=", $request->state_id);
        }

        if (!empty($request->records_per_page) && is_numeric($request->records_per_page)) {
            $records_per_page = $request->records_per_page;
        }
        if (!empty($request->sort_field)) {
            if ($request->sort_field == 'name' && ($request->sort_action == 'ASC' || $request->sort_action == 'DESC')) {
                $commonService = $commonService->orderBy("name", $request->sort_action);
            } elseif ($request->sort_field == 'Area' && ($request->sort_action == 'ASC' || $request->sort_action == 'DESC')) {
                $commonService = $commonService->orderBy("area", $request->sort_action);
            } elseif ($request->sort_field == 'Pincode' && ($request->sort_action == 'ASC' || $request->sort_action == 'DESC')) {
                $commonService = $commonService->orderBy("pincode", $request->sort_action);
            }
        } else {
            $commonService = $commonService->orderBy("id", "DESC");
        }

        if (isset($request->limit)) {
            $commonService->limit($request->limit);
        }
        if (isset($request->offset)) {
            $commonService->offset($request->offset);
        }
        $data = [];
        $data['total_records'] = $commonService->count();
        $data['common_service_data'] = $commonService->with(['state', 'city'])->get();
        return success($data, "Common Service fetch Succesfully.");
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        //
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        $data = $request->all();
        // dd($data);
        $validator = Validator::make($data, [
            'name' => "required",
            'address1' => "required",
            'address2' => "required",
            'area' => "required",
            'pincode' => "required",
            'city_id' => "required",
            'state_id' => "required",
            'latitude' => "required",
            'longitude' => "required",
            'category_id' => "required",
            'description' => "required",
        ]);

        if ($validator->fails()) {
            return error($validator->errors()->first());
        } else {
            $commonService = new CommonService();
            $commonServiceDetails = new CommonServiceDetails();

            $commonService->name = $request->name;
            $commonService->phone = $request->phone;
            $commonService->mobile = $request->mobile;
            $commonService->email = $request->email;
            $commonService->address1 = $request->address1;
            $commonService->address2 = $request->address2;
            $commonService->area = $request->area;
            $commonService->pincode = $request->pincode;
            $commonService->city_id = $request->city_id;
            $commonService->state_id = $request->state_id;
            $validateLatLong = validateLatLong($request->latitude, $request->longitude);
            if (!empty($validateLatLong)) {
                $commonService->latitude = $request->latitude;
                $commonService->longitude = $request->longitude;
            } else {
                return error("longitude and latitude are not valid.");
            }
            $commonService->discount = !empty($request->discount) ? $request->discount : NULL;
            $commonService->category_id = $request->category_id;
            $commonService->status_id = !empty($request->status_id) ? $request->status_id : STATUS_ACTIVE;

            /*
             * Common Service details
             */
            $commonServiceDetails->cash_booking_allowed = $request->cash_booking_allowed == 'on' ? 1 : 0;
            $commonServiceDetails->cancellation_allowed = $request->cancellation_allowed == 'on' ? 1 : 0;

            if (!empty($request->cancel_policy)) {
                $commonServiceDetails->cancel_policy = $request->cancel_policy;

                // $cancel_policy = [];
                // foreach ($request->cancel_policy as $key => $val) {
                //     if (!empty($val['cancel_policy'])) {
                //         $cancel_policy[] = $val['cancel_policy'];
                //     }
                // }
                // if (!empty($cancel_policy)) {
                //     $commonServiceDetails->cancel_policy = json_encode($cancel_policy);
                // }
            }
            if (!empty($request->cancel_policy_setting)) {
                $commonServiceDetails->cancel_policy_setting = $request->cancel_policy_setting;

                // $cancelPolicySetting = [];
                // foreach ($request->cancel_policy_setting as $value) {
                //     if (!empty($value['hours']) && !empty($value['charge'])) {
                //         $cancelPolicySetting[] = $value;
                //     }
                // }
                // if (!empty($cancelPolicySetting)) {
                //     $commonServiceDetails->cancel_policy_setting = json_encode($cancelPolicySetting);
                // }
            }
            $commonServiceDetails->timing_json = $request->slot_data_obj;
            $commonServiceDetails->description = $request->description;
            $commonServiceDetails->pancard_number = $request->pancard_number;
            $commonServiceDetails->gst_number = $request->gst_number;
            $commonServiceDetails->bank_account_number = $request->bank_account_number;
            $commonServiceDetails->bank_account_name = $request->bank_account_name;
            $commonServiceDetails->bank_name = $request->bank_name;
            $commonServiceDetails->bank_ifsc_code = $request->bank_ifsc_code;

            $multipleLocation = [];
            // if (!empty($request->multiple_location)) {
            //     foreach ($request->multiple_location as $multipeLocation) {
            //         if (!empty($multipeLocation['multiple_location_pincode'])) {
            //             $duplicate = 0;
            //             foreach ($multipleLocation as $checkData) {
            //                 if (
            //                     $checkData['pincode'] == $multipeLocation['multiple_location_pincode'] &&
            //                     $checkData['latitude'] == $multipeLocation['multiple_location_latitude'] &&
            //                     $checkData['longitude'] == $multipeLocation['multiple_location_longitude']
            //                 ) {
            //                     $duplicate = 1;
            //                 }
            //             }
            //             if ($duplicate == 0) {
            //                 $locationArr = [
            //                     'pincode' => $multipeLocation['multiple_location_pincode'],
            //                     'latitude' => null,
            //                     'longitude' => null
            //                 ];
            //                 if (!empty($multipeLocation['multiple_location_latitude']) && !empty($multipeLocation['multiple_location_longitude'])) {
            //                     if (!empty(validateLatLong($multipeLocation['multiple_location_latitude'], $multipeLocation['multiple_location_longitude']))) {
            //                         $locationArr['latitude'] = $multipeLocation['multiple_location_latitude'];
            //                         $locationArr['longitude'] = $multipeLocation['multiple_location_longitude'];
            //                     } else {
            //                         return error("Multiple Location lat : " . $multipeLocation['multiple_location_latitude'] . " or long : " . $multipeLocation['multiple_location_longitude'] . " not valid.");
            //                     }
            //                 }
            //                 $multipleLocation[] = $locationArr;
            //             }
            //         }
            //     }
            // }

            $multipleLocation = json_decode($request->additional_search_json, true);
            if (!empty($validateLatLong)) {
                $multipleLocation[] = [
                    'pincode' => $request->pincode,
                    'latitude' => $request->latitude,
                    'longitude' => $request->longitude
                ];
            }

            // $commonServiceDetails->additional_search_json = !empty($multipleLocation) ? json_encode($multipleLocation) : null;
            $commonServiceDetails->additional_search_json = !empty($request->additional_search_json) ? $request->additional_search_json : null;

            if (!empty($request->photo) && in_array($request->photo->extension(), allow_file_type_uploads)) {
                $image = $request->file('photo');
                $imageName = seo_url("healthism profile {$request->name}") . '.' . $request->photo->extension();
                $image_resize = Image::make($image->getRealPath());
                $image_resize->resize(800, null, function ($constraint) {
                    $constraint->aspectRatio();
                });
                $image_resize->save(public_path('image/common_service/' . $imageName));
                $commonService->photo = $imageName;
            }

            if (!empty($request->images_list)) {
                $gallery_images = [];
                // foreach ($request->images_list as $row) {
                //     $fileName = explode(".", $row);
                //     $imageName = seo_url("healthism  $request->name {$fileName[0]}") . "." . $fileName[1];
                //     $imageName = change_filename("image/common_service/", $imageName);
                //     copy(public_path("/image/temp/{$row}"), public_path('image/common_service_gallery/' . $imageName));
                //     $gallery_images[] = $imageName;
                // }
                // $commonServiceDetails->gallery_json = json_encode(array_values($gallery_images));

                foreach ($request->images_list as $row) {
                    $imageName = seo_url("healthism {$request->name}") . "." . $row->extension();
                    $imageName = change_filename("image/common_service_gallery/", $imageName);
                    if ($row->move(public_path('image/common_service_gallery'), $imageName)) {
                        $gallery_images[] = $imageName;
                    }
                }
                $commonServiceDetails->gallery_json = json_encode(array_values($gallery_images));
            }

            if (!empty($request->pancard_document)) {
                $imageName = seo_url("pan healthism {$request->name}") . '.' . $request->pancard_document->extension();
                $imageName = change_filename("image/common_service/", $imageName);
                if ($request->pancard_document->move(public_path('image/common_service'), $imageName)) {
                    $commonServiceDetails->pancard_document = $imageName;
                }
            }

            if (!empty($request->gst_certificate)) {
                $imageName = seo_url("gst healthism {$request->name}") . '.' . $request->gst_certificate->extension();
                $imageName = change_filename("image/common_service/", $imageName);

                if ($request->gst_certificate->move(public_path('image/common_service'), $imageName)) {
                    if (!empty($request->gst_certificate)) {
                        @unlink('image/common_service/' . $commonService->common_service_details->gst_certificate);
                    }
                }
                $commonServiceDetails->gst_certificate = $imageName;
            }

            $commonService->save();
            $commonServiceDetails->common_service_id = $commonService->id;
            $commonServiceDetails->save();

            if (!empty($commonService)) {
                $this->addSearchData($commonService, $multipleLocation);
            }
            $common_service = CommonService::with(['common_service_details', 'status', 'state', 'city'])->where('id', $commonService->id)->first();
            return success($common_service, "Common Service Details Added Succesfully.");
        }
    }

    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function show($id)
    {
        $common_service = CommonService::with(['common_service_details', 'status', 'state', 'city'])->where('id', $id)->first();
        if ($common_service) {
            return success($common_service, "Common service fetch Succesfully.");
        } else {
            return error("This Common service is not available.");
        }
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function edit($id)
    {
        //
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, $id)
    {
        $commonService = CommonService::findOrFail($id);
        // dd($commonService);
        // $commonService->name = $request->name;
        // $commonService->phone = $request->phone;
        // $commonService->email = $request->email;
        // $commonService->address1 = $request->address1;
        // $commonService->address2 = $request->address2;
        // $commonService->area = $request->area;
        // $commonService->pincode = $request->pincode;
        // $commonService->city_id = $request->city_id;
        // $commonService->state_id = $request->state_id;
        // $commonService->mobile = $request->mobile;
        // $errorMessageLetLong = "";
        // if (!empty($validateLatLong)) {
        //     $commonService->latitude = $request->latitude;
        //     $commonService->longitude = $request->longitude;
        // } else {
        //     $errorMessageLetLong .= 'longitude and latitude are not valid';
        // }
        // $commonService->discount = $request->discount;
        // $commonService->category_id = $request->category_id;
        // $commonService->status_id = !empty($request->status_id) ? $request->status_id : STATUS_ACTIVE;

        /*
         * Common Service details
         */

        if (!empty($request->cash_booking_allowed) || !empty($request->cancellation_allowed)) {
            $commonService->common_service_details->cash_booking_allowed = $request->cash_booking_allowed == 'on' ? 1 : 0;
            $commonService->common_service_details->cancellation_allowed = $request->cancellation_allowed == 'on' ? 1 : 0;
        }
        if (!empty($request->cancel_policy)) {
            $commonService->common_service_details->cancel_policy = $request->cancel_policy;
        }
        if (!empty($request->cancel_policy_setting)) {
            $commonService->common_service_details->cancel_policy_setting = $request->cancel_policy_setting;
        }
        // if (!empty($request->cancel_policy)) {
        //     $cancel_policy = [];
        //     foreach ($request->cancel_policy as $key => $val) {
        //         if (!empty($val['cancel_policy'])) {
        //             $cancel_policy[] = $val['cancel_policy'];
        //         }
        //     }
        //     if (!empty($cancel_policy)) {
        //         $commonService->common_service_details->cancel_policy = json_encode($cancel_policy);
        //     }
        // } else {
        //     $commonService->common_service_details->cancel_policy = null;
        // }
        // if (!empty($request->cancel_policy_setting)) {
        //     $cancelPolicySetting = [];
        //     foreach ($request->cancel_policy_setting as $value) {
        //         if (!empty($value['hours']) && !empty($value['charge'])) {
        //             $cancelPolicySetting[] = $value;
        //         }
        //     }
        //     if (!empty($cancelPolicySetting)) {
        //         $commonService->common_service_details->cancel_policy_setting = json_encode($cancelPolicySetting);
        //     }
        // } else {
        //     $commonService->common_service_details->cancel_policy_setting = null;
        // }

        $multipleLocation = [];
        // if (!empty($request->multiple_location)) {
        //     foreach ($request->multiple_location as $multipeLocation) {
        //         if (!empty($multipeLocation['multiple_location_pincode'])) {
        //             $duplicate = 0;
        //             foreach ($multipleLocation as $checkData) {
        //                 if (
        //                     $checkData['pincode'] == $multipeLocation['multiple_location_pincode'] &&
        //                     $checkData['latitude'] == $multipeLocation['multiple_location_latitude'] &&
        //                     $checkData['longitude'] == $multipeLocation['multiple_location_longitude']
        //                 ) {
        //                     $duplicate = 1;
        //                 }
        //             }
        //             if ($duplicate == 0) {
        //                 $locationArr = [
        //                     'pincode' => $multipeLocation['multiple_location_pincode'],
        //                     'latitude' => null,
        //                     'longitude' => null
        //                 ];
        //                 if (!empty($multipeLocation['multiple_location_latitude']) && !empty($multipeLocation['multiple_location_longitude'])) {
        //                     if (!empty(validateLatLong($multipeLocation['multiple_location_latitude'], $multipeLocation['multiple_location_longitude']))) {
        //                         $locationArr['latitude'] = $multipeLocation['multiple_location_latitude'];
        //                         $locationArr['longitude'] = $multipeLocation['multiple_location_longitude'];
        //                     } else {
        //                         $errorMessageLetLong .= "Multiple Location lat : " . $multipeLocation['multiple_location_latitude'] . " or long : " . $multipeLocation['multiple_location_longitude'] . " not valid.";
        //                     }
        //                 }
        //                 $multipleLocation[] = $locationArr;
        //             }
        //         }
        //     }
        // }

        // $commonService->common_service_details->additional_search_json = !empty($multipleLocation) ? json_encode($multipleLocation) : null;

        if (isset($request->latitude) && isset($request->longitude) && isset($request->pincode) && isset($request->additional_search_json)) {
            $multipleLocation = json_decode($request->additional_search_json, true);
            $validateLatLong = validateLatLong($request->latitude, $request->longitude);
            if (!empty($validateLatLong)) {
                $multipleLocation[] = [
                    'pincode' => $request->pincode,
                    'latitude' => $request->latitude,
                    'longitude' => $request->longitude
                ];
            }
        }
        // $commonService->common_service_details->timing_json = $request->slot_data_obj;
        // $commonService->common_service_details->description = $request->description;
        // $commonService->common_service_details->pancard_number = $request->pancard_number;
        // $commonService->common_service_details->gst_number = $request->gst_number;
        // $commonService->common_service_details->bank_account_number = $request->bank_account_number;
        // $commonService->common_service_details->bank_account_name = $request->bank_account_name;
        // $commonService->common_service_details->bank_name = $request->bank_name;
        // $commonService->common_service_details->bank_ifsc_code = $request->bank_ifsc_code;

        if (!empty($request->photo) && in_array($request->photo->extension(), allow_file_type_uploads)) {
            if (!empty($commonService->photo)) {
                @unlink('image/common_service/' . $commonService->photo);
            }
            $image = $request->file('photo');
            $imageName = seo_url("healthism profile {$request->name}") . '.' . $request->photo->extension();
            $image_resize = Image::make($image->getRealPath());
            $image_resize->resize(800, null, function ($constraint) {
                $constraint->aspectRatio();
            });
            $image_resize->save(public_path('image/common_service/' . $imageName));
            $commonService->photo = $imageName;
        }

        if (!empty($request->pancard_document)) {
            $imageName = seo_url("pan healthism {$request->name}") . '.' . $request->pancard_document->extension();
            $imageName = change_filename("image/common_service/", $imageName);

            if ($request->pancard_document->move(public_path('image/common_service'), $imageName)) {
                if (!empty($commonService->common_service_details->pancard_document)) {
                    @unlink('image/common_service/' . $commonService->common_service_details->pancard_document);
                }
            }
            $commonService->common_service_details->pancard_document = $imageName;
        }

        if (!empty($request->gst_certificate)) {
            $imageName = seo_url("gst healthism {$request->name}") . '.' . $request->gst_certificate->extension();
            $imageName = change_filename("image/common_service/", $imageName);

            if ($request->gst_certificate->move(public_path('image/common_service'), $imageName)) {
                if (!empty($commonService->common_service_details->gst_certificate)) {
                    @unlink('image/common_service/' . $commonService->common_service_details->gst_certificate);
                }
            }
            $commonService->common_service_details->gst_certificate = $imageName;
        }

        // $commonService->save();
        // $commonService->common_service_details->save();
        $commonService->update($request->except('photo'));
        $commonService->common_service_details->update($request->except('pancard_document', 'gst_certificate', 'cash_booking_allowed', 'cancellation_allowed'));

        if (!empty($commonService)) {
            $this->addSearchData($commonService, $multipleLocation);
        }

        return success($commonService, "Comman service Details Updated Successfully!");
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function destroy($id)
    {
        //
    }

    private function addSearchData($commonService, $multipleLocation)
    {
        if (!empty($multipleLocation)) {
            \App\Models\CommonServiceSearch::where('common_service_id', $commonService->id)->delete();
            $searchData = array(
                'common_service_id' => $commonService->id,
                'category_id' => $commonService->category_id,
                'name' => $commonService->name,
                'city_id' => $commonService->city_id,
                'state_id' => $commonService->state_id
            );
            if (!empty($multipleLocation)) {
                foreach ($multipleLocation as $value) {
                    $searchData['pincode'] = $value['pincode'];
                    $searchData['latitude'] = $value['latitude'];
                    $searchData['longitude'] = $value['longitude'];
                    $inputArr[] = $searchData;
                }
                \App\Models\CommonServiceSearch::insert($inputArr);
            }
        }
    }

    public function serviceSearch(Request $request)
    {
        $search = $request->get('search');
        $data = CommonService::where('name', 'LIKE', '%' . $search . '%')->limit(10)->get();
        $result = [];
        if (!empty($data)) {
            foreach ($data as $value) {
                $commonService['label'] = $value['name'] . '(' . $value['area'] . ',' . $value['city']['name'] . ',' . $value['state']['name'] . ')';
                $commonService['id'] = $value['id'];
                $result[] = $commonService;
            }
            return success($result, "Common services Details get Succesfully.");
        } else {
            return error($result, "Common services Details not found.");
        }
    }

    public function getCategories()
    {
        $categoryData = CommonServiceMapping::with('category')->get();
        return success($categoryData, 'get all categories.');
    }

    public function fetchGalleryImages(Request $request, $id)
    {
        $commonService = CommonService::findOrFail($id);
        $gallery_images = json_decode($commonService->common_service_details->gallery_json, true);
        $images = [];
        if (!empty($gallery_images)) {
            foreach ($gallery_images as $row) {
                $size = @filesize("image/common_service_gallery/" . $row);
                $images[] = ['name' => $row, 'size' => $size, 'path' => URL::to('/') . "/image/common_service_gallery/{$row}"];
            }
        }
        return success($images, "Common Service gallery fetch Succesfully.");
    }

    public function galleryImagesDelete(Request $request, $id)
    {
        if (!empty($id)) {
            $commonService = CommonService::findOrFail($id);
            $gallery_images = json_decode($commonService->common_service_details->gallery_json, true);
            $gallery_images = array_filter($gallery_images, fn ($m) => $m != $request->name);
            $gallery_images = array_values($gallery_images);
            $commonService->common_service_details->gallery_json = json_encode($gallery_images);
            @unlink('image/common_service_gallery/' . $request->name);
            $commonService->common_service_details->save();
            return success($commonService, 'remove image success.');
        } else {
            unlink(public_path('/image/temp/') . $request->name);
        }
    }

    public function removeProfile($id)
    {
        $commonService = CommonService::findOrFail($id);
        // $images = [];
        // if ($commonService->common_service_details->gallery_json != 'NULL' && !empty($commonService->common_service_details->gallery_json)) {
        //     $gallery_images = json_decode($commonService->common_service_details->gallery_json, true);
        //     if (!empty($gallery_images)) {
        //         foreach ($gallery_images as $row) {
        //             $images[] = ['name' => $row];
        //         }
        //     }
        // }
        if (!empty($commonService->photo)) {
            if (file_exists(public_path('image/common_service/' . $commonService->photo))) {
                @unlink(public_path('image/common_service/' . $commonService->photo));
            }
            $commonService->photo = null;
            $commonService->save();
        }
        return success([], "Remove common service profile.");
    }

    public function locationSave(Request $request)
    {
        $inputArr['common_service_id'] = $request->common_service_id;
        $inputArr['pincode'] = $request->pincode;
        $inputArr['latitude'] = $request->latitude;
        $inputArr['longitude'] = $request->longitude;
        $duplicate = \App\Models\CommonServiceSearch::where($inputArr)->count();
        if ($duplicate > 0) {
            return error("Duplicate Entry");
        } else {
            $inputArr['category_id'] = $request->category_id;
            $inputArr['name'] = $request->name;
            $result = \App\Models\CommonServiceSearch::Create($inputArr);
            return success($result, "Location has been saved successfully");
        }
    }

    public function locationDelete($id)
    {
        $commonServiceSearch = \App\Models\CommonServiceSearch::findOrFail($id);
        if (!empty($commonServiceSearch))
            $commonServiceSearch->delete();
        return success($id, "Location has been deleted successfully");
    }

    public function getAllLocation($id)
    {
        $commonService = CommonService::where("id", $id)->first();
        if ($commonService) {
            $location = \App\Models\CommonServiceSearch::where('common_service_id', $id)->orderby("id", "DESC")->get()->toArray();
            if (!empty($location)) {
                return success($location, "Get all location.");
            } else {
                return success([], "No any data stored yet.");
            }
        } else {
            return error("This common service is not available.");
        }
    }
}
