<?php

namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Validator;
use App\Models\DoctorHospitalMapping;


class DoctorHospitalMappingController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index(Request $request)
    {
        $mapping = DoctorHospitalMapping::query();
        if (!empty($request->doctor_id)) {
            $mapping->where('doctor_id', $request->doctor_id);
        }
        if (!empty($request->hospital_id)) {
            $mapping->where('hospital_id', $request->hospital_id);
        }
        if (!empty($request->doctor_name)) {
            $mapping->whereRelation('doctor', 'first_name', 'like', '%' . trim($request->doctor_name) . '%')
                ->orwhereRelation('doctor', 'last_name', 'like', '%' . trim($request->doctor_name) . '%');
        }
        if (!empty($request->hospital_name)) {
            $mapping->whereRelation('hospital', 'name', 'like', '%' . trim($request->hospital_name) . '%');
        }
        if (!empty($request->sort_field)) {
            if ($request->sort_field == 'hospital_id' && ($request->sort_action == 'ASC' || $request->sort_action == 'DESC')) {
                $mapping->orderBy("hospital_id", $request->sort_action);
            } elseif ($request->sort_field == 'doctor_id' && ($request->sort_action == 'ASC' || $request->sort_action == 'DESC')) {
                $mapping->orderBy("doctor_id", $request->sort_action);
            }
        } else {
            $mapping = $mapping->orderBy("id", "DESC");
        }
        if (isset($request->limit)) {
            $mapping->limit($request->limit);
        }
        if (isset($request->offset)) {
            $mapping->offset($request->offset);
        }
        $data = [];
        $data['total_records'] = $mapping->count();
        $data['mapping_data'] = $mapping->get();
        return success($data, "Successfully fetched!!");
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        //
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        $data = $request->all();
        $validator = Validator::make($data, [
            'doctor_id' => "required",
            'hospital_id' => "required",
            'slot_data_obj' => "required",
            'fees' => "required",
            // 'discount' => "required",
            'video_consultation_available' => "required",
            'slot_type' => "required|string|in:Day,Date",
        ]);
        if ($validator->fails()) {
            return error($validator->errors()->first());
        } else {
            $mapping = DoctorHospitalMapping::where('doctor_id', $request->doctor_id)->where('hospital_id', $request->hospital_id)->first();
            if (empty($mapping)) {
                $mapping = new DoctorHospitalMapping;
                $mapping->doctor_id = $request->doctor_id;
                $mapping->hospital_id = $request->hospital_id;
                $mapping->timing_json = $request->slot_data_obj;
                $mapping->fees = $request->fees;
                $mapping->discount = $request->discount;
                $mapping->video_consultation_available = $request->video_consultation_available == 'on' ? 1 : 0;
                $mapping->slot_type = $request->slot_type;
                $mapping->save();

                return success($mapping, "Successfully added!!");
            } else {
                return success(null, "Already added!!");
            }
        }
    }

    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function show($id)
    {
        $mapping = DoctorHospitalMapping::where('id', $id)->with('doctor', 'hospital')->first();
        if ($mapping) {
            return success($mapping, "fetch single data");
        } else {
            return error("This data is not availabel.");
        }
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function edit($id)
    {
        //
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, $id)
    {
        $data = $request->all();
        $validator = Validator::make($data, [
            'doctor_id' => "required",
            'hospital_id' => "required",
        ]);

        if ($validator->fails()) {
            return error($validator->errors()->first());
        } else {
            $mapping = DoctorHospitalMapping::where('doctor_id', $request->doctor_id)->where('hospital_id', $request->hospital_id)->first();
            if (empty($mapping) || $mapping->id == $id) {
                $mapping = DoctorHospitalMapping::findOrFail($id);
                // dd($mapping);
                $mapping->doctor_id = $request->doctor_id;
                $mapping->hospital_id = $request->hospital_id;
                $mapping->timing_json = $request->slot_data_obj;
                $mapping->fees = $request->fees;
                $mapping->discount = $request->discount;
                $mapping->video_consultation_available = $request->video_consultation_available == 'on' ? 1 : 0;
                $mapping->slot_type = $request->slot_type;
                $mapping->save();

                return success($mapping, "Successfully updated!!");
            }
        }
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function destroy($id)
    {
        //
    }
}
