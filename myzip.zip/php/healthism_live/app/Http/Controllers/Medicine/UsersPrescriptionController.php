<?php

namespace App\Http\Controllers\Medicine;

use App\Models\UserUpload;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use App\Http\Controllers\Controller;
use Auth;

class UsersPrescriptionController extends Controller {

    public function index(Request $request) {

        $logInUserType = $request->user()->user_type_id;
        $query = UserUpload::query();
        $query->where('service_id', SERVICE_MEDICINE);
        $records_per_page = 5;

        if (!empty($request->user_name)) {
            $query->whereRelation('user', 'first_name', 'like', '%' . trim($request->user_name) . '%');
        }
        if (!empty($request->patient_name)) {
            $query->whereRelation('user', 'first_name', 'like', '%' . trim($request->user_name) . '%');
        }
        if (!empty($request->user_mobile)) {
            $query->whereRelation('user', 'mobile', '=', trim($request->user_mobile));
        }
        if (!empty($request->start_date)) {
            $query = $query->whereDate('created_at', '>=', date('Y-m-d', strtotime($request->start_date)));
        }
        if (!empty($request->end_date)) {
            $query = $query->whereDate('created_at', '<=', date('Y-m-d', strtotime($request->end_date)));
        }
        if (!empty($request->status_id) && is_numeric($request->status_id)) {
            $query = $query->where('status_id', '=', trim($request->status_id));
        }

        $query->orderBy("id", 'DESC');
        if (!empty($request->records_per_page) && is_numeric($request->records_per_page)) {
            $records_per_page = $request->records_per_page;
        }
        $details = $query->paginate($records_per_page);
        $statusList = array(
            ['id' => 1, 'name' => 'ACTIVE'],
            ['id' => 8, 'name' => 'SUCCESS'],
            ['id' => 10, 'name' => 'CANCELLED'],
        );
        $formValues = compact('details', 'statusList');
        if ($request->ajax()) {
            return view('backend.medicine.usersPrescription.ajax_content', $formValues);
        } else {
            return view('backend.medicine.usersPrescription.index', $formValues);
        }
    }

    public function view(Request $request, $id) {
        $detail = UserUpload::findOrFail($id);
        $user = $detail->user;
        return view('backend.medicine.usersPrescription.view', compact('detail', 'user'));
    }

    public function changeStatus(Request $request) {
        DB::beginTransaction();
        try {
            // dd('yes',$request->all());
            $detail = UserUpload::findOrFail($request->id);
            $detail->status_id = $request->status_id;
            $detail->save();
            DB::commit();
            return response()->json(['message' => 'Change Apply Successfully', 'status' => 200]);
        } catch (\Exception $e) {
            DB::rollback();
        }
    }

    public function saveQuotation(Request $request) {
        DB::beginTransaction();
        try {
            $input = $request->all();
            $input['user_upload_id'] = $input['id'];
            $input['medicine_json'] = $input['quotation_data_obj'];
            $input['created_by'] = $request->user()->id;
            $input['created_at'] = date('Y-m-d H:i:s');
            $detail = \App\Models\MedicineQuotation::where('user_upload_id', $input['id'])->first();
            if (!empty($detail)) {
                $detail->fill($input)->save();
            } else {
                \App\Models\MedicineQuotation::Create($input);
            }
            DB::commit();
            $detail = UserUpload::findOrFail($input['id']);
            $user = $detail->user;
            return view('backend.medicine.usersPrescription.view', compact('detail', 'user'));
        } catch (\Exception $e) {
            DB::rollback();
        }
    }

    public function saveComment(Request $request) {
        DB::beginTransaction();
        try {
            $input = $request->all();
            $commentBy = $request->user()->first_name . ' ' . $request->user()->last_name;
            if (!empty($input['comment'])) {
                $input['user_upload_id'] = $input['id'];
                $newdata = ['created_at' => date('d-M-Y h:i:s a'), 'created_by' => $request->user()->id,
                    'created_name' => $commentBy, 'comment' => $input['comment']];

                $detail = \App\Models\MedicineQuotation::where('user_upload_id', $input['id'])->first();
                unset($input['comment']);
                if (!empty($detail)) {
                    if (!empty($detail->comment_json)) {
                        $commentJson = $detail->comment_json;
                        $commentJson[] = $newdata;
                    } else {
                        $commentJson[] = $newdata;
                    }
                    $input['comment_json'] = json_encode($commentJson);
                    $detail->fill($input)->save();
                } else {
                    $commentJson[] = $newdata;
                    $input['comment_json'] = json_encode($commentJson);
                    \App\Models\MedicineQuotation::Create($input);
                }
                DB::commit();
            }
            if (Auth::user()->user_type_id == ADMIN) {
                return redirect()->route('admin.medicine.usersPrescription.view', $input['id'])->with('success', 'Comment saved Successfully!');
            }
            if (Auth::user()->user_type_id == PHARMACY_USER) {
                return redirect()->route('medicine.usersPrescription.view', $input['id'])->with('success', 'Comment saved Successfully!');
            }
        } catch (\Exception $e) {
            DB::rollback();
        }
    }

}
