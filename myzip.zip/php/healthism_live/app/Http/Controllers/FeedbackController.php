<?php

namespace App\Http\Controllers;

use App\Http\Controllers\Controller;
use App\Models\Feedback;
use Illuminate\Http\Request;

class FeedbackController extends Controller {

    public function index(Request $request) {
        $records_per_page = 10;
        $feedback = Feedback::query();
        if (!empty($request->app_id) && is_numeric($request->app_id)) {
            $feedback->where('app_id', '=', trim($request->app_id));
        }
        if (!empty($request->platform_id) && is_numeric($request->platform_id)) {
            $feedback->where('platform_id', '=', trim($request->platform_id));
        }

        $feedback->orderBy("id", 'DESC');
        if (!empty($request->records_per_page) && is_numeric($request->records_per_page)) {
            $records_per_page = $request->records_per_page;
        }
        $feedback = $feedback->paginate($records_per_page);
        $platformList = \App\Models\Platform::all();
        $appList = [["id" => END_USER_APP, 'name' => 'USER APP'], ["id" => MERCHANT_APP, 'name' => 'MERCHANT APP']];
        if ($request->ajax()) {
            return view('backend.feedback.ajax_content', compact('feedback', 'appList', 'platformList'));
        } else {
            return view('backend.feedback.index', compact('feedback', 'appList', 'platformList'));
        }
    }

}
