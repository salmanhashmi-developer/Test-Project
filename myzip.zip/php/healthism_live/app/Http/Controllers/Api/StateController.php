<?php

namespace App\Http\Controllers\API;

use App\Http\Controllers\Controller;
use App\Models\State;
//use App\Http\Resources\StateCollection;
use Illuminate\Http\Request;

class StateController extends Controller {

    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index() {
        $state = State::where('active', 1)->orderBy("name", 'ASC')->get();
        return success($state, 'State list retrieved successfully');
    }

}
