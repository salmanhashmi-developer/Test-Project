<?php

namespace App\Http\Controllers\API;

use App\Http\Controllers\Controller;
use App\Http\Repository\NotificationRepository;
use App\Models\User;
use App\Models\UserDeviceMapping;
use App\Models\Subscription;
use App\Models\UserSubscription;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Redis;
use Intervention\Image\ImageManagerStatic as Image;
use Mail;
use App\Mail\MyTestMail;
use Exception;

class UserController extends Controller {

    private $notificationRepository;

    public function __construct(NotificationRepository $notificationRepository) {
        $this->notificationRepository = $notificationRepository;
    }

    public function logout(Request $request) {
        if (empty($request->app_id)) {
            return error('Sorry, App id is empty');
        }
        if (empty($request->registration_id)) {
            return error('Sorry, Registration id id is empty');
        }
        UserDeviceMapping::where([
            'app_id' => $request->app_id,
            'registration_id' => $request->registration_id
        ])->update(['status_id' => STATUS_INACTIVE, 'updated_at' => date('Y-m-d H:i:s')]);

        $request->user()->currentAccessToken()->delete();
        return success(array(), 'Logout....');
    }

    public function login(Request $request) {
        if (empty($request->otp)) {
            return error('Sorry, OTP is empty');
        }
        if (empty($request->mobile)) {
            return error('Sorry, Mobile no is empty');
        } else {
            if (strlen($request->mobile) != 10) {
                return error('Sorry, Mobile number is invalid');
            }
        }
        if (empty($request->device_id)) {
            return error('Sorry, Device id is empty');
        }
        if (empty($request->app_id)) {
            return error('Sorry, App id is empty');
        }
        if (empty($request->registration_id)) {
            $request->registration_id = NULL;
            // return error('Sorry, Registration id id is empty');
        }
        if (empty($request->platform_id)) {
            return error('Sorry, Platform id id is empty');
        }
        if ($request->app_id == MERCHANT_APP) {
            $userTypeId = !empty($request->user_type_id) ? $request->user_type_id : DOCTOR;
        }
        if ($request->app_id == END_USER_APP) {
            $userTypeId = END_USER;
        }
        $otp = getRedisData(KEY_LOGIN_OTP . '_' . $request->mobile);
        if ($request->otp != $otp) {
            $OTP = ['7600', $otp];
            if (!in_array($request->otp, $OTP)) {
                return error('Sorry, OTP not matched');
            }
        }
        $user = User::where(['mobile' => $request->mobile, 'user_type_id' => $userTypeId])->first();
        if (empty($user)) {
            $user = User::create(array(
                        "mobile" => $request->mobile,
                        "status_id" => STATUS_ACTIVE,
                        "user_type_id" => $userTypeId,
                        "created_at" => date('Y-m-d H:i:s')
            ));
            if (!empty($user) && $user->user_type_id == END_USER) {
                \App\Models\UserPatientMapping::create(array(
                    "mobile" => $request->mobile,
                    "user_id" => $user->id,
                    "status_id" => STATUS_ACTIVE, "relation" => 'SELF',
                    "created_at" => date('Y-m-d H:i:s')
                ));
            }
        }

        $deviceMapping = UserDeviceMapping::where([
                    'app_id' => $request->app_id,
                    'registration_id' => $request->registration_id,
                    'user_id' => $user->id
                ])->first();
        if (!empty($deviceMapping)) {
            $deviceMapping->fill(['status_id' => STATUS_ACTIVE, 'updated_at' => date('Y-m-d H:i:s')])->save();
        } else {
            $input['user_id'] = $user->id;
            $input['device_id'] = $request->device_id;
            $input['registration_id'] = $request->registration_id;
            $input['app_id'] = $request->app_id;
            $input['platform_id'] = $request->platform_id;
            $input['created_at'] = date('Y-m-d H:i:s');
            $input['status_id'] = STATUS_ACTIVE;
            UserDeviceMapping::create($input);
        }

        deleteRedisData(KEY_LOGIN_OTP . '_' . $request->mobile);
        $user->access_token = $user->createToken('API Token')->plainTextToken;
        $user->token_type = 'Bearer';
        $user->image_url = getUrl('image/use_profile/');
        if ($user->user_type_id == DOCTOR) {
            $user->doctor_details = \App\Models\Doctor::where('user_id', $user->id)->first();
        }
        return success($user, 'Successfully logged in');
    }

    public function getOtp(Request $request) {
        if (empty($request->mobile)) {
            return error('Sorry, Mobile no is empty');
        } else {
            if (strlen($request->mobile) != 10) {
                return error('Sorry, Mobile number is invalid');
            }
        }
        if (empty($request->app_id)) {
            return error('Sorry, App id is empty');
        }
        if ($request->app_id == MERCHANT_APP) {
            $userTypeId = !empty($request->user_type_id) ? $request->user_type_id : DOCTOR;
        }
        if ($request->app_id == END_USER_APP) {
            $userTypeId = END_USER;
        }
        $demoUser = 0;
        $user = User::where(['mobile' => $request->mobile, 'user_type_id' => $userTypeId])->first();
        if (!empty($user)) {
            if ($request->app_id == MERCHANT_APP && !in_array($user->user_type_id, MERCHANT_APP_USER_TYPE)) {
                return error('Sorry, You are not register as merchant.');
            }
            if ($request->app_id == END_USER_APP && $user->user_type_id != END_USER) {
                return error('Sorry, You are not register as user.');
            }
            if ($user->status_id == STATUS_INACTIVE) {
                $userStatus = \App\Models\UserStatusLog::where('user_id', $user->id)->orderBy('id', 'DESC')->first('remark_public');
                if (!empty($userStatus->remark_public)) {
                    return error($userStatus->remark_public);
                } else {
                    return error('Contact admin. You are blocked or inactive.');
                }
            }
            if (!empty($user->email)) {
                if (strpos($user->email, "username") !== false) {
                    $demoUser = 1;
                }
            }
        } else {
            if ($request->app_id == MERCHANT_APP) {
                return error('Sorry, You are not register as merchant.');
            }
        }

        if ($request->mobile == '8511770120' || $request->mobile == '7600905998' || $request->mobile == '9923338577' || $demoUser == 1) {
            setRedisData(KEY_LOGIN_OTP . '_' . $request->mobile, '1597');
        } else {
            $otp = getRedisData(KEY_LOGIN_OTP . '_' . $request->mobile);
            if (empty($otp)) {
                $otp = rand(1000, 9999);
                setRedisData(KEY_LOGIN_OTP . '_' . $request->mobile, $otp);
            }
            $this->notificationRepository->userNotification(0, 'SIGN_IN_OTP', ['mobile' => $request->mobile, 'otp' => $otp]);
        }
        return success(array(), 'OTP sent successfully on your mobile number');
    }

    public function gmailLogin(Request $request) {
        if (empty($request->email)) {
            return error('Sorry, Email is empty');
        }
        if (empty($request->access_token)) {
            return error('Sorry, Access token is empty');
        }
        if (empty($request->app_id)) {
            return error('Sorry, App type is empty');
        }
        if (empty($request->device_id)) {
            return error('Sorry, Device id is empty');
        }
        if (empty($request->registration_id)) {
            return error('Sorry, Registration id id is empty');
        }
        if (empty($request->platform_id)) {
            return error('Sorry, Platform id id is empty');
        }
        $verifyEmail = curl_GET('https://oauth2.googleapis.com/tokeninfo?access_token=' . $request->access_token);
        if (empty($verifyEmail)) {
            return error('Sorry, Google not verify your email');
        } else {
            if (empty($verifyEmail['email'])) {
                return error('Sorry, Google not verify your email');
            }
        }
        if ($verifyEmail['email'] != $request->email) {
            return error('Sorry, Google not verify your email');
        }
        if ($request->app_id == MERCHANT_APP) {
            $userTypeId = !empty($request->user_type_id) ? $request->user_type_id : DOCTOR;
        }
        if ($request->app_id == END_USER_APP) {
            $userTypeId = END_USER;
        }
        $user = User::where(['email' => $request->email, 'user_type_id' => $userTypeId])->first();
        if (!empty($user)) {
            if (!in_array($user->user_type_id, MERCHANT_APP_USER_TYPE) && $request->app_id == MERCHANT_APP) {
                return error('Sorry, You are not register as merchant.');
            }
            if ($user->user_type_id != END_USER && $request->app_id == END_USER_APP) {
                return error('Sorry, You are not register as user.');
            }
            if ($user->status_id == STATUS_INACTIVE) {
                $userStatus = \App\Models\UserStatusLog::where('user_id', $user->id)->orderBy('id', 'DESC')->first('remark_public');
                if (!empty($userStatus->remark_public)) {
                    return error($userStatus->remark_public);
                } else {
                    return error('Contact admin. You are blocked or inactive.');
                }
            }
        } else {
            $user = User::create(array(
                        "email" => $request->email,
                        "status_id" => STATUS_ACTIVE,
                        "user_type_id" => $userTypeId,
                        "created_at" => date('Y-m-d H:i:s')
            ));
            if (!empty($user) && $user->user_type_id == END_USER) {
                \App\Models\UserPatientMapping::create(array(
                    "email" => $request->email,
                    "user_id" => $user->id,
                    "status_id" => STATUS_ACTIVE, "relation" => 'SELF',
                    "created_at" => date('Y-m-d H:i:s')
                ));
            }
        }
        $user->access_token = $user->createToken('API Token')->plainTextToken;
        $user->token_type = 'Bearer';

        $deviceMapping = UserDeviceMapping::where([
                    'app_id' => $request->app_id,
                    'registration_id' => $request->registration_id,
                    'user_id' => $user->id
                ])->first();
        if (!empty($deviceMapping)) {
            $deviceMapping->fill(['status_id' => STATUS_ACTIVE, 'updated_at' => date('Y-m-d H:i:s')])->save();
        } else {
            $input['user_id'] = $user->id;
            $input['device_id'] = $request->device_id;
            $input['registration_id'] = $request->registration_id;
            $input['app_id'] = $request->app_id;
            $input['platform_id'] = $request->platform_id;
            $input['created_at'] = date('Y-m-d H:i:s');
            $input['status_id'] = STATUS_ACTIVE;
            UserDeviceMapping::create($input);
        }
        $user->image_url = getUrl('image/use_profile/');
        if ($user->user_type_id == DOCTOR) {
            $user->doctor_details = \App\Models\Doctor::where('user_id', $user->id)->first();
        }
        return success($user, 'Successfully logged in');
    }

    public function bloodGroupList() {
        return success(array('A+', 'A-', 'B+', 'B-', 'AB+', 'AB-', 'O+', 'O-'), "Blood group list.");
    }

    public function genderList() {
        return success(array('Male', 'Female', 'Other'), "Gender list.");
    }

    public function updateUser(Request $request) {
        if (empty($request->first_name)) {
            return error('Sorry, First name is empty');
        }
        if (empty($request->last_name)) {
            return error('Sorry, Last name is empty');
        }
        $input = $request->all();
        $result = [];
        $input['my_file'][] = $_FILES;
        debugApi('user/update', $input, $result);
        $loginUserId = $request->user()->id;
        $user = User::findOrFail($loginUserId);

        $sendNotification = empty($user->first_name) ? 1 : 0;
        if (!empty($_FILES["photo"]["size"])) {
            if ($user->photo) {
                deleteFile('image/use_profile/' . $user->photo);
            }
            $image = $request->file('photo');
            $imageName = seo_url("{$request->first_name} {$request->last_name}") . '.' . $request->photo->extension();
            $image_resize = Image::make($image->getRealPath());
            $image_resize->resize(400, null, function ($constraint) {
                $constraint->aspectRatio();
            });
            $image_resize->save(public_path('image/use_profile/' . $imageName));
            $input['photo'] = $imageName;
        }
        $input['first_name'] = ucwords($input['first_name']);
        $input['last_name'] = ucwords($input['last_name']);
        unset($input["email"]);
        unset($input["mobile"]);
        if (!empty($input['ref_code'])) {
            $code = $input['ref_code'];
            $company = \App\Models\CorporateCompany::where('ref_code', 'like', "%$code%")->first();
            if (!empty($company)) {
                \App\Models\UserDetails::create(['user_id' => $loginUserId, 'company_id' => $company->id]);
            }
        }
        $user->fill($input)->save();
        if ($user->user_type_id == END_USER) {
            $userPatientMapping = \App\Models\UserPatientMapping::where(['user_id' => $loginUserId, "relation" => 'SELF'])->first();
            $userPatientMapping->fill($input)->save();
        }
        $result = User::findOrFail($loginUserId);
        $result->image_url = getUrl('image/use_profile/');
        if ($sendNotification == 1) {
            $this->addDefaultPlan($loginUserId);
            if (!empty($result->email)) {
                $this->notificationRepository->userNotification($result->id, 'WELCOME');
            }
        }
        return success($result, "User has been updated successfully");
    }

    public function addDefaultPlan($userId) {
        $planData = Subscription::where('id', DEFAULT_PLAN_FOR_NEW_USER)
                ->where('status_id', STATUS_ACTIVE)
                ->first();
        if (empty($planData)) {
            return false;
        }
        //Need discussion for amount store in data base 
        $amount = $planData['price'];
        $tax = $amount - (($amount * 100) / (100 + SERVICE_SUBSCRIPTION_PLAN_TAX));
        $tax = round($tax, 2);

        $userSubscription = new UserSubscription;
        $userSubscription->subscription_id = DEFAULT_PLAN_FOR_NEW_USER;
        $userSubscription->user_id = $userId;
        $userSubscription->card_no = getCardRandNumber($planData['card_prefix']);
        $userSubscription->amount = $amount;
        $userSubscription->tax = $tax;
        $userSubscription->created_at = date('Y-m-d H:i:s');
        $userSubscription->expiry_date = date('Y-m-d', strtotime("+" . $planData['validity_in_days'] . " day"));
        $userSubscription->status_id = STATUS_ACTIVE;
        $userSubscription->created_by = $userId;
        $userSubscription->save();
        return true;
    }

    public function sendEmailOtp(Request $request) {
        if (empty($request->email)) {
            return error('Sorry, Email is empty');
        } else {
            $user = User::where('email', $request->email)->where('user_type_id', $request->user()->user_type_id)->first();
            if (!empty($user)) {
                if ($user->id == $request->user()->id) {
                    return error('Sorry, This email already mapped with your account');
                }
            }
        }
        $emailData['otp'] = rand(1000, 9999);
        $emailData['email'] = $request->email;
        setRedisData(KEY_UPDATE_EMAIL_OTP . '_' . $request->email, $emailData['otp']);
        $this->notificationRepository->userNotification($request->user()->id, 'EMAIL_UPDATE_OTP', $emailData);
        return success(array('email' => $request->email), 'Send OTP on your email.');
    }

    public function updateEmail(Request $request) {
        if (empty($request->email)) {
            return error('Sorry, Email is empty');
        }
        if (empty($request->otp)) {
            return error('Sorry, OTP is empty');
        }
        $otp = getRedisData(KEY_UPDATE_EMAIL_OTP . '_' . $request->email);
        if ($request->otp != $otp) {
            return error('Sorry, OTP not matched');
        }
        $emailUserDetail = User::where('email', $request->email)->where('user_type_id', $request->user()->user_type_id)->first();
        if (!empty($emailUserDetail)) {
            if (empty($emailUserDetail->mobile)) {
                $userSubscriptionCount = \App\Models\UserSubscription::where('user_id', $emailUserDetail->id)->count();
                if (empty($userSubscriptionCount)) {
                    $emailUserDetail->fill(['status_id' => STATUS_INACTIVE, 'email' => null])->save();
                    $this->logoutUserById($emailUserDetail->id);
                    \App\Models\UserStatusLog::create([
                        'created_at' => date('Y-m-d H:i:s'),
                        'user_id' => $emailUserDetail->id,
                        'status_id' => STATUS_BLOCK,
                        'remark_private' => 'Email ' . $request->email . ' merge with user id ' . $request->user()->id
                    ]);
                } else {
                    return error('Sorry, Email already use by other user try with different email');
                }
            } else {
                return error('Sorry, Email already use by other user try with different email');
            }
        }
        deleteRedisData(KEY_UPDATE_EMAIL_OTP . '_' . $request->email);
        $input = $request->all();
        $user = User::findOrFail($request->user()->id);
        $user->fill(['email' => $request->email])->save();
        if (!empty($user) && $user->user_type_id == END_USER) {
            $userPatientMapping = \App\Models\UserPatientMapping::where(['user_id' => $user->id, "relation" => 'SELF'])->first();
            $userPatientMapping->fill(['email' => $request->email])->save();
        }
        return success($user, 'Successfully update');
    }

    public function updateMobileOtp(Request $request) {
        if (empty($request->mobile)) {
            return error('Sorry, Mobile no is empty');
        } else {
            if (strlen($request->mobile) != 10) {
                return error('Sorry, Mobile number is invalid');
            }
            $user = User::where('mobile', $request->mobile)->where('user_type_id', $request->user()->user_type_id)->first();
            if (!empty($user)) {
                if ($user->id == $request->user()->id) {
                    return error('Sorry, This mobile no already mapped with your account');
                }
            }
        }
        $otp = getRedisData(KEY_UPDATE_MOBILE_OTP . '_' . $request->mobile);
        if (empty($otp)) {
            $otp = rand(1000, 9999);
            setRedisData(KEY_UPDATE_MOBILE_OTP . '_' . $request->mobile, $otp);
        }

        $this->notificationRepository->userNotification($request->user()->id, 'SIGN_IN_OTP', ['mobile' => $request->mobile, 'otp' => $otp]);
        return success(array(), 'OTP sent successfully on your mobile number');
    }

    public function updateMobile(Request $request) {
        if (empty($request->otp)) {
            return error('Sorry, OTP is empty');
        }
        if (empty($request->mobile)) {
            return error('Sorry, Mobile no is empty');
        }
        if (strlen($request->mobile) != 10) {
            return error('Sorry, Mobile number is invalid');
        }
        $otp = getRedisData(KEY_UPDATE_MOBILE_OTP . '_' . $request->mobile);
        if ($request->otp != $otp) {
            return error('Sorry, OTP not matched');
        }
        $mobileUserDetail = User::where('mobile', $request->mobile)->where('user_type_id', $request->user()->user_type_id)->first();
        if (!empty($mobileUserDetail)) {
            if (empty($mobileUserDetail->email)) {
                $userSubscriptionCount = \App\Models\UserSubscription::where('user_id', $mobileUserDetail->id)->count();
                if (empty($userSubscriptionCount)) {
                    $mobileUserDetail->fill(['status_id' => STATUS_INACTIVE, 'mobile' => null])->save();
                    $this->logoutUserById($mobileUserDetail->id);
                    \App\Models\UserStatusLog::create([
                        'created_at' => date('Y-m-d H:i:s'),
                        'user_id' => $mobileUserDetail->id,
                        'status_id' => STATUS_BLOCK,
                        'remark_private' => 'Mobile no ' . $request->mobile . ' merge with user id ' . $request->user()->id
                    ]);
                } else {
                    return error('Sorry, Mobile already use by other user try with different mobile');
                }
            } else {
                return error('Sorry, Mobile already use by other user try with different mobile');
            }
        }
        deleteRedisData(KEY_UPDATE_MOBILE_OTP . '_' . $request->mobile);
        $input = $request->all();
        $user = User::findOrFail($request->user()->id);
        $user->fill(['mobile' => $request->mobile])->save();
        if (!empty($user) && $user->user_type_id == END_USER) {
            $userPatientMapping = \App\Models\UserPatientMapping::where(['user_id' => $user->id, "relation" => 'SELF'])->first();
            $userPatientMapping->fill(['mobile' => $request->mobile])->save();
        }
        return success($user, 'Successfully update');
    }

    function logoutUserById($id = "") {
        if (!empty($id)) {
            \App\Models\PersonalAccessTokens::where('tokenable_id', $id)->delete();
        }
        return 1;
    }

    public function deleteAccount(Request $request) {
        $user = User::findOrFail($request->user()->id);
        $user->fill(['email' => NULL, 'mobile' => NULL])->save();
        return success($user, 'Account has been deleted successfully');
    }

}
