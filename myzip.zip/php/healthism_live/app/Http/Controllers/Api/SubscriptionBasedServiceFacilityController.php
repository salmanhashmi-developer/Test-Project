<?php

namespace App\Http\Controllers\API;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;

class SubscriptionBasedServiceFacilityController extends Controller {

    public function facilityList(Request $request) {
        $input = $request->all();
        if (!isset($input['self_facility_available'])) {
            return error("Sorry, Self facility available param missing");
        }
        if (empty($input['subscription_based_service_id'])) {
            return error("Sorry, Subscription based service id is empty");
        }

        $page = !empty($input['page']) ? $input['page'] : 1;
        $skip = $page > 1 ? ($page * LIMIT) - LIMIT : 0;
        if (!empty($input['subscription_based_service_id']) && $input['self_facility_available'] == 1) {
            $query = \App\Models\SubscriptionBasedServiceFacility::where('subscription_based_service_id', $input['subscription_based_service_id']);
        } else {
            $query = \App\Models\SubscriptionBasedServiceFacility::where('subscription_based_service_id', $input['parent_id']);
        }
        $query->where('status_id', STATUS_ACTIVE);

        if (!empty($input['name'])) {
            $name = $input['name'];
            $query->where('name', 'like', '%' . $name . '%');
        }
        if (!empty($input['sub_category_id'])) {
            $subCategory = "," . $input['sub_category_id'] . ",";
            $query->where('sub_category_ids', 'like', '%' . $subCategory . '%');
        }
        $query->skip($skip);
        $query->limit(LIMIT);
        $result = $query->get();
        return success($result, 'Subscription based service Facility list');
    }

    public function facilityDetail(Request $request) {
        $input = $request->all();
        if (empty($input['facility_id'])) {
            return error("Sorry, Facility id is empty");
        }
        $result = \App\Models\SubscriptionBasedServiceFacility::where('id', $input['facility_id'])->first();
        return success($result, 'Subscription based service facility');
    }

}
