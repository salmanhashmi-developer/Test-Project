<?php

namespace App\Http\Controllers\API;

use App\Http\Controllers\Controller;
use App\Http\Repository\NotificationRepository;
use App\Models\UserFamilyMember;
use Illuminate\Http\Request;

class UserFamilyMemberController extends Controller {

    private $notificationRepository;

    public function __construct(NotificationRepository $notificationRepository) {
        $this->notificationRepository = $notificationRepository;
    }

    public function index(Request $request) {
        $result = UserFamilyMember::where('user_id', $request->user()->id)
                        ->where('status_id', STATUS_ACTIVE)
                        ->where('expiry_date', '>', date('Y-m-d'))
                        ->orderBy('created_at', 'desc')->get();
        return success($result, "User member list");
    }

    public function remainingMembersCount(Request $request) {
        $remainingMembers = $this->remainingMembers($request->user()->id);
        if ($remainingMembers['code'] == 0) {
            return success(array('count' => 0), $remainingMembers['message']);
        }
        if ($remainingMembers['code'] == 1) {
            return success(array('count' => $remainingMembers['member_count']), 'You can add a maximum of ' . $remainingMembers['userSubscription']['subscription']['member'] - 1 . ' members to your account');
        }
    }

    public function relationshipList() {
        return success(array('GRAND FATHER', 'GRAND MOTHER', 'FATHER', 'MOTHER', 'WIFE', 'HUSBAND', 'SISTER', 'BROTHER', 'SON', 'DAUGHTER', 'COUSIN', 'AUNT', 'UNCLE', 'GUEST', 'OTHER'), "Gender list.");
    }

    private function remainingMembers($userId) {
        $userSubscription = \App\Models\UserSubscription::where('user_id', $userId)
                ->where('status_id', STATUS_ACTIVE)
                ->where('expiry_date', '>', date('Y-m-d'))
                ->with('subscription')
                ->first();
        if (empty($userSubscription)) {
            return array('code' => 0, 'message' => 'You are not allowed to add member');
        } else {
            $avalableMember = UserFamilyMember::where('user_id', $userId)
                    ->where('status_id', STATUS_ACTIVE)
                    ->where('expiry_date', '>', date('Y-m-d'))
                    ->count();
            $result = ($userSubscription->subscription->member - 1) - $avalableMember;
            return array('code' => 1, 'member_count' => $result, 'userSubscription' => $userSubscription);
        }
    }

    public function store(Request $request) {
        $rules = UserFamilyMember::$rules;
        if (sizeof($rules) > 0) {
            $validation = $this->validateRequest($request, $rules);
            if (!empty($validation)) {
                return error($validation);
            }
        }
        $input = $request->all();
        $remainingMembers = $this->remainingMembers($request->user()->id);
        if ($remainingMembers['code'] == 0) {
            return error($remainingMembers['message']);
        }
        if ($remainingMembers['code'] == 1) {
            if ($remainingMembers['member_count'] == 0) {
                return error('You can add a maximum of ' . $remainingMembers['userSubscription']['subscription']['member'] - 1 . ' members to your account.');
            }
        }
        $user = \App\Models\User::where("mobile", $input['mobile'])
                ->where("user_type_id", END_USER)
                ->first();
        if (!empty($user)) {
            $userPlan = getUserSubscription($user->id);
        } else {
            $userPlan = getParentPlan($input['mobile']);
        }
        if (!empty($userPlan)) {
            if ($userPlan['action'] == "Upgrade") {
                return error('Sorry, Mobile no ' . $input['mobile'] . ' have already active plan');
            } else {
                return error('Sorry, Someone already add this mobile no ' . $input['mobile'] . ' as member');
            }
        }

        $input['user_id'] = $request->user()->id;
        $input['status_id'] = STATUS_ACTIVE;
        $input['first_name'] = ucwords($input['first_name']);
        $input['last_name'] = ucwords($input['last_name']);
        $input['user_subscription_id'] = $remainingMembers['userSubscription']['id'];
        $input['expiry_date'] = $remainingMembers['userSubscription']['expiry_date'];
        $input['created_at'] = date('Y-m-d H:i:s');
        $result = UserFamilyMember::create($input);
        if (!empty($result)) {
            if (!empty($result->id)) {
                UserFamilyMember::where('id', '!=', $result->id)
                        ->where('status_id', STATUS_ACTIVE)
                        ->where('mobile', $input['mobile'])
                        ->update(array('status_id' => STATUS_INACTIVE, 'updated_at' => date('Y-m-d H:i:s')));
            }

            $notificationData['member_name'] = $result->first_name . ' ' . $result->last_name;
            $notificationData['left_member_count'] = $remainingMembers['member_count'] - 1;
            $this->notificationRepository->userNotification($request->user()->id, 'MEMBER_ADD', $notificationData);
        }
        return success($result, "Family member added successfully");
    }

    public function delete(Request $request) {
        $input = $request->all();
        if (empty($input['member_id'])) {
            return error('Sorry, Member id is empty');
        }
        $member = UserFamilyMember::where('id', $input['member_id'])->first();
        if (empty($member)) {
            return error('Sorry, Member not found');
        }
        if ($member->user_id != $request->user()->id) {
            return error('Sorry, Access denied');
        }
        $member->update(array('status_id' => STATUS_INACTIVE, 'updated_at' => date('Y-m-d H:i:s')));

        //SMS
        return success(array(), "Family member deleted successfully");
    }

    public function update(Request $request) {
        $input = $request->all();
        if (empty($input['id'])) {
            return error('Sorry, Id is empty');
        }
        $member = UserFamilyMember::where('id', $input['id'])->first();
        if (empty($member)) {
            return error('Sorry, member not found');
        }
        if ($member->relation == 'SELF') {
            return error('Sorry, Access denied for self');
        }
        if ($member->user_id != $request->user()->id) {
            return error('Sorry, Access denied');
        }
        if ($member->status_id != STATUS_ACTIVE) {
            return error('Sorry, member not found');
        }
        if (empty($input['first_name'])) {
            return error('Sorry, first name is empty');
        }
        if (empty($input['last_name'])) {
            return error('Sorry, last name is empty');
        }
        if (empty($input['relation'])) {
            return error('Sorry, relation name is empty');
        }
        $data['first_name'] = ucwords($input['first_name']);
        $data['last_name'] = ucwords($input['last_name']);
        $data['relation'] = ucwords($input['relation']);
        $member = UserFamilyMember::findOrFail($input['id']);
        $member->fill($data)->save();
        return success(UserFamilyMember::findOrFail($input['id']), "User member had been updated successfully");
    }

}
