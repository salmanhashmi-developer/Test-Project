<?php

namespace App\Http\Controllers\API;

use App\Http\Controllers\Controller;
use App\Http\Repository\NotificationRepository;
use App\Models\CommonService;
use App\Models\CommonServiceDetails;
use App\Models\CommonServiceEnquiry;
use App\Models\CommonServiceSearch;
use App\Models\CommonServiceMapping;
use Illuminate\Http\Request;

class CommonServiceController extends Controller {

    private $notificationRepository;

    public function __construct(NotificationRepository $notificationRepository) {
        $this->notificationRepository = $notificationRepository;
    }

    public function getCommonServiceData(Request $request) {
        $latitude = $request->header('latitudeUserLocation');
        $longitude = $request->header('longitudeUserLocation');
        $pincode = $request->header('postalCodeUserLocation');
        $input = $request->all();
        if (empty($input['category_id'])) {
            return error("Sorry, Category id is empty");
        }
        if ($request->user()->id == 74) {
            $latitude = '18.969538920783755';
            $longitude = '72.81932909041643';
            $pincode = '400008';
        } else {
            if (empty($latitude) || empty($longitude)) {
                return error("Sorry, Latitude/Longitude is empty.");
            }
        }
        $mapping = CommonServiceMapping::where('category_id', $input['category_id'])->count();
        if (empty($mapping)) {
            return error("Sorry, Category data not found");
        }
        $page = !empty($input['page']) ? $input['page'] : 1;
        $skip = $page > 1 ? ($page * LIMIT) - LIMIT : 0;
        $query = "SELECT
                    cs.*,
                    haversine ( '" . $latitude . "', '" . $longitude . "', c.latitude, c.longitude ) AS 'service_distance',
                    ( SELECT COUNT(*) FROM review WHERE ref_id = cs.id AND service_id = " . SERVICE_COMMON . " AND status_id = " . STATUS_APPROVED . " ) AS common_service_reviwe_count,
                    ROUND(( SELECT AVG( rating ) FROM review WHERE ref_id = cs.id AND service_id = " . SERVICE_COMMON . " AND status_id = " . STATUS_APPROVED . " ), 1 ) AS common_service_rating 
                FROM
                    ( SELECT c.*, haversine ( '" . $latitude . "', '" . $longitude . "', c.latitude, c.longitude ) AS 'distance' FROM common_service_search c ORDER BY distance ) c,
                    common_service cs 
                WHERE
                    c.common_service_id = cs.id 
                    AND c.category_id = " . $input['category_id'] . " 
                    AND (";
        if (!empty($pincode)) {
            $query .= "c.pincode = '" . $pincode . "' OR ";
        }
        $query .= "c.distance < " . COMMON_SERVICE_DISTANCE . " )";
        if (!empty($input['name'])) {
            $query .= " AND c.`name` like  '%" . $input['name'] . "%' ";
        }
         $query .= " GROUP BY
                        CASE
                                WHEN cs.virtual_location = 1 THEN
                                cs.id ELSE c.id 
                        END";
        $query .= " ORDER BY c.distance";
        $query .= " LIMIT " . LIMIT . " OFFSET " . $skip;
        // pr($query);
        $result['data'] = executeSelectQueryOnMySQLDB($query);
        $result['image_url'] = getUrl('image/common_service');
        return success($result, 'Service data list');
    }

    public function commonServiceDetail(Request $request) {
        if (empty($request->common_service_id)) {
            return error("Sorry, Common service id is empty.");
        }
        if (empty($request->category_id)) {
            return error("Sorry, Category id is empty");
        }
        $result = [];
        $commonServiceData = CommonService::where('id', $request->common_service_id)
                        ->where('category_id', $request->category_id)
                        ->with('common_service_details', 'state', 'city')->first();
        if (!empty($commonServiceData)) {
            if ($commonServiceData->status_id != STATUS_ACTIVE) {
                return error("Sorry, Service not active.");
            }
            $commonServiceData->experience = $commonServiceData->experience . ' years experience overall';
            $commonServiceData->image_url = getUrl('image/common_service');
            $commonServiceData->call_to_book_contact_no = SUPPORT_CONTACT_NO;
            $result = $commonServiceData;
            if (!empty($commonServiceData->common_service_details)) {
                $commonServiceDetail = $commonServiceData->common_service_details;
                $result['common_service_details']['image_url'] = getUrl('image/common_service_gallery');
                $result['common_service_details']['timing_json'] = json_decode($commonServiceDetail->timing_json);
                $result['common_service_details']['gallery_json'] = json_decode($commonServiceDetail->gallery_json);
                $result['common_service_details']['cancel_policy'] = json_decode($commonServiceDetail->cancel_policy);
                $result['common_service_details']['cancel_policy_setting'] = json_decode($commonServiceDetail->cancel_policy_setting);
            }
        }
        return success($result, "Common service detail...");
    }

    public function commonServiceEnquiry(Request $request) {
        $rules = CommonServiceEnquiry::$rules;
        if (sizeof($rules) > 0) {
            $validation = $this->validateRequest($request, $rules);
            if (!empty($validation)) {
                return error($validation);
            }
        }
        $userSubscription = getUserSubscription($request->user()->id);
        if (empty($userSubscription)) {
            return error("Sorry, You have no active subscription plan");
        } else {
            if ($userSubscription['expire'] == 1) {
                return error("Please renew your subscription plan, Your plan is expired");
            }
        }
        $input = $request->all();
        $input['user_id'] = $request->user()->id;
        $input['created_at'] = date('Y-m-d H:i:s');
        $input['status_id'] = STATUS_PENDING;
        $result = CommonServiceEnquiry::create($input);
        if (!empty($result)) {
            $this->notificationRepository->commonServiceEnquiryNotification($result->id, 'DONE');
            return success($result, "Your Request received successfully we will contact you soon");
        } else {
            return error(COMMON_ERROR);
        }
    }

}
