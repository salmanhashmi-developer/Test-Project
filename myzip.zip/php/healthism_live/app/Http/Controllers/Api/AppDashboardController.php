<?php

namespace App\Http\Controllers\API;

use App\Http\Controllers\Controller;
use App\Models\AppDashboard;
use Illuminate\Http\Request;

//use App\Http\Resources\AppDashboardCollection;

class AppDashboardController extends Controller {

    public function index() {
        $banner = AppDashboard::orderBy('type', 'ASC')->orderBy('sort_order', 'ASC')->get();
        $result = [];
        if (!empty($banner)) {
            $result['image_url'] = getUrl('image/dashboard/');
            foreach ($banner as $key => $value) {
                $result[strtolower($value->type)][] = $value;
            }
        }
        return success($result, "Dashboard data");
    }

    public function sliderBanner(Request $request) {
        $banner = AppDashboard::orderBy('type', 'ASC')->orderBy('sort_order', 'ASC')->get();
        $result = [];
        if (!empty($banner)) {
            $result['image_url'] = getUrl('image/dashboard/');
            foreach ($banner as $key => $value) {
                $insert = 1;
                if (!empty($value['data_json'])) {
                    if (!empty($value['data_json']['type']) && $value['data_json']['type'] == 'plan') {
                        if (!empty($value['data_json']['plan_id'])) {
                            $insert = $this->subscriptionList($request->user()->id, $value['data_json']['plan_id']);
                        }
                    }
                }
                if ($insert == 1) {
                    $result[strtolower($value->type)][] = $value;
                }
            }
        }
        return success($result, "Dashboard data");
    }

    public function subscriptionList($userId, $planId) {
        $validation = checkSpecialPlan($userId);
        if ($validation == 0) {
            return 0;
        }
        $userSubscription = \App\Models\UserSubscription::where('user_id', $userId)
                ->where('status_id', STATUS_ACTIVE)
                ->where('expiry_date', '>', date('Y-m-d'))
                ->with('subscription')
                ->first();
        $query = \App\Models\Subscription::where('status_id', STATUS_ACTIVE);
        if (!empty($userSubscription->subscription->validity_in_days)) {
            $query->where('validity_in_days', '>=', $userSubscription->subscription->validity_in_days);
        }
        if (!empty($userSubscription->subscription->member)) {
            $query->where('member', '>', $userSubscription->subscription->member);
        }
        $userTypeId = ',3,';
        $query->where('user_type_id', 'like', '%' . $userTypeId . '%');
        $result = $query->orderBy('display_index', 'ASC')->get();
        if (!empty($result)) {
            foreach ($result as $key => $value) {
                if ($value['id'] == $planId) {
                    return 1;
                }
            }
        }
        return 0;
    }

    public function support() {
        $result['text'] = "You purchase a privilege healthcare card, which entitles you and your family to appealing and discounted medical service prices from a variety of providers.";
        $result['phone'] = SUPPORT_CONTACT_NO;
        $result['email'] = SUPPORT_EMAIL;
        return success($result, "Dashboard data");
    }

    public function uploadCity() {
        // $result = curl_GET('https://raw.githubusercontent.com/dr5hn/countries-states-cities-database/master/countries%2Bstates%2Bcities.json');
        return success(array(), "Dashboard data");
    }

    public function checkVersion(Request $request) {
        $input = $request->all();
        $version = $input;
        $version['force_update'] = 1;
        $version['ask_update'] = 0;
        $version['version_title'] = "Version not found - " . $input['version'];
        $version['message'] = "Update available!";
        $version['version'] = "Version not found";
        if (empty($input['platform_id']) || empty($input['version']) || empty($input['app_id'])) {
            return success($version, 'Data retrieved successfully.');
        }
        $versionData = \App\Models\AppVersion::where(
                        [
                            "platform_id" => $input['platform_id'],
                            "version" => $input['version'],
                            "app_id" => $input['app_id']
                        ]
                )->first();
        if (!empty($versionData->id)) {
            $version = $versionData;
        }
        $version['signup'] = 1;
        $version['platform_id'] = (int) $version['platform_id'];
        return success($version, 'Data retrieved successfully.');
    }

    public function feedback(Request $request) {
        if (empty($request->description)) {
            return error("Sorry, Description is empty");
        }
        if (empty($request->app_id)) {
            return error("Sorry, App id is empty");
        }
        if (empty($request->platform_id)) {
            return error("Sorry, App id is empty");
        }
        $data['app_id'] = $request->app_id;
        $data['platform_id'] = $request->platform_id;
        $data['description'] = $request->description;
        $data['user_id'] = $request->user()->id;
        $data['created_at'] = date('Y-m-d H:i:s');
        $result = \App\Models\Feedback::create($data);
        return success($result, 'Thank you for your valuable feedback.');
    }

    public function corporateEnquiry(Request $request) {
        $rules = \App\Models\CorporateEnquiry::$rules;
        if (sizeof($rules) > 0) {
            $validation = $this->validateRequest($request, $rules);
            if (!empty($validation)) {
                return error($validation);
            }
        }
        $input = $request->all();
        $input['status_id'] = STATUS_PENDING;
        $input['user_id'] = $request->user()->id;
        $input['created_at'] = date('Y-m-d H:i:s');
        $result = \App\Models\CorporateEnquiry::create($input);
        return success($result, 'Thank you for join us. We will shortly contact with you.');
    }

    public function downloadApp() {
        return view('download_app');
    }

    public function validateLatLong(Request $request) {
        if (empty($request->lat)) {
            return error("Sorry, lat is empty");
        }
        if (empty($request->long)) {
            return error("Sorry, long is empty");
        }
        $data = validateLatLong($request->lat, $request->long);
        return success($data, 'validate Lat/Long');
    }

    public function commonTest() {
        $input = ['remark'];
        $data['description'] = substr($input['test'], 0, 10);
        \App\Models\Feedback::create($data);
    }

    public function commonOrderUpdateTest() {
        $order = \App\Models\Orders::where('id', 72)->first();
        $order->update(array('status_id' => STATUS_DONE, 'remark' => 'ORDER 7777', 'remark_color_code' => statusWiseColor(STATUS_DONE), 'updated_at' => date('Y-m-d H:i:s')));
        return success($order, 'validate Lat/Long');
    }

    public function clearCatch() {
        deleteRedisData(KEY_PAYMENT_MODE);
        deleteRedisData(KEY_SERVICE);
        deleteRedisData(KEY_PLATFORM);
        deleteRedisData(KEY_STATUS);
        deleteRedisData(KEY_APPLICATION_CONSTANT);
    }

    public function getPaymentMode() {
        pr(getPaymentMode(SERVICE_LAB_REPORT));
    }

    public function healthTrackSave(Request $request) {
        $rules = \App\Models\HealthTrack::$rules;
        if (sizeof($rules) > 0) {
            $validation = $this->validateRequest($request, $rules);
            if (!empty($validation)) {
                return error($validation);
            }
        }
        $input = $request->all();
        $input['created_at'] = date('Y-m-d H:i:s');
        $input['user_id'] = $request->user()->id;
        $result = \App\Models\HealthTrack::create($input);
        return success($result, 'Your health track has been saved!');
    }

    public function lastHealthTrack(Request $request) {
        $result = \App\Models\HealthTrack::where('user_id', $request->user()->id)->orderBy('id', 'DESC')->first();
        return success($result, 'Your last health track!');
    }

    public function stateIdChanges() {
        $result = \App\Models\Lab::groupBy('city_id')->with('city')->get('city_id');
        foreach ($result as $value) {
            \App\Models\Lab::where('city_id',$value['city_id'])->update(['state_id'=>$value['city']['state_id']]);
        }
    }

}
