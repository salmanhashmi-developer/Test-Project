<?php

namespace App\Http\Controllers\API;

use App\Http\Resources\SubCategoryCollection;
use App\Http\Controllers\Controller;
use App\Models\SubCategory;
use Illuminate\Http\Request;

class SubCategoryController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @param $id
     * @return SubCategoryCollection
     */
    public function index($id)
    {
        return new SubCategoryCollection(SubCategory::where([
            'category_id' => $id,
            "active" => 1
        ])->orderBy('sort_order', 'desc')->get());
    }

}
