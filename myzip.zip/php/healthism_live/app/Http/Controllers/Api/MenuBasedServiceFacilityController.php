<?php

namespace App\Http\Controllers\API;

use App\Http\Controllers\Controller;
use App\Http\Repository\MenuBasedServiceFacilityRepository;
use Illuminate\Http\Request;

class MenuBasedServiceFacilityController extends Controller {

    private $menuBasedServiceFacilityRepository;

    public function __construct(MenuBasedServiceFacilityRepository $menuBasedServiceFacilityRepository) {
        $this->menuBasedServiceFacilityRepository = $menuBasedServiceFacilityRepository;
    }

    public function menuBasedServiceFacilityCategoryV1(Request $request) {
        $input = $request->all();
        if (empty($input['menu_based_service_id'])) {
            return error("Sorry, Menu based service id is empty.");
        }
        if (!isset($input['menu_based_service_parent_id'])) {
            return error("Sorry, Menu based service parent id is empty.");
        }
        $result = [];
        $categoryList = \App\Models\MenuBasedServiceFacility::where('menu_based_service_id', $input['menu_based_service_id'])
                        ->groupBy('category')->get();
        if (empty(count($categoryList))) {
            $categoryList = \App\Models\MenuBasedServiceFacility::where('menu_based_service_id', $input['menu_based_service_parent_id'])
                            ->groupBy('category')->get();
        }
        if (!empty(count($categoryList))) {
            $result[] = "All";
            foreach ($categoryList as $category) {
                if (!empty($category['category'])) {
                    $result[] = $category['category'];
                }
            }
        }
        return success($result, 'Category list');
    }

    public function menuBasedServiceFacilityCategory(Request $request) {
        $input = $request->all();
        if (empty($input['category_id'])) {
            return error("Sorry, Category id is empty.");
        }
        $result = [];
        if ($input['category_id'] == 10) {
            //SPA
            $category = \App\Models\Category::where('parent_id', $input['category_id'])->get();
            if (!empty(count($category))) {
                $result[] = 'All';
                foreach ($category as $key => $value) {
                    $result[] = $value->name;
                }
            }
        }
        return success($result, 'Category list');
    }

    public function menuBasedServiceFacilityList(Request $request) {
        $input = $request->all();
        if (!isset($input['self_facility_available'])) {
            return error("Sorry, self_facility_available param missing");
        }
        if (empty($input['menu_based_service_id'])) {
            return error("Sorry, Menu based service id is empty");
        }
//        if (empty($input['type'])) {
//            return error("Sorry, Type is empty");
//        }
        $page = !empty($input['page']) ? $input['page'] : 1;
        $skip = $page > 1 ? ($page * LIMIT) - LIMIT : 0;
        if (!empty($input['menu_based_service_id']) && $input['self_facility_available'] == 1) {
            $query = \App\Models\MenuBasedServiceFacility::where('menu_based_service_id', $input['menu_based_service_id']);
        } else {
            $query = \App\Models\MenuBasedServiceFacility::where('menu_based_service_id', $input['parent_id']);
        }
        $query->where('status_id', STATUS_ACTIVE);
//        if ($input['type'] == 'PACKAGE') {
//            $query->where('is_package', 1);
//        } else {
//            $query->where('is_package', 0);
//        }
        if (!empty($input['name'])) {
            $name = $input['name'];
            $query->where('name', 'like', '%' . $name . '%');
        }
        if (!empty($input['category'])) {
            if ($input['category'] != 'All') {
                $query->where('category', $input['category']);
            }
        }
        $query->skip($skip);
        $query->limit(LIMIT);
        $result = $query->get();
        return success($result, 'Menu based service Facility list');
    }

    public function topFacilityList(Request $request) {
        try {
            $latitude = $request->header('latitudeUserLocation');
            $longitude = $request->header('longitudeUserLocation');
            $pincode = $request->header('postalCodeUserLocation');
            $input = $request->all();
            if (empty($input['category_id'])) {
                return error("Sorry, Category is empty.");
            }
            if (empty($latitude) || empty($longitude)) {
                return error("Sorry, Latitude/Longitude is empty.");
            }
            $limit = 30;
            $page = !empty($input['page']) ? $input['page'] : 1;
            $skip = $page > 1 ? ($page * $limit) - $limit : 0;
            // mbsf.price-((mbsf.discount*mbsf.price)/100) AS healthisam_price,
            $query = "SELECT
                    count( mbsf.Id ) AS count,
                    mbsf.id,
                    mbsf.`name`,
                    mbsf.facility_count,
                    mbsf.discount,
                    mbsf.price,
                    mbsf.is_package,
                    mbsf.gender,
                    mbsf.time,
                    mbsf.category,
                    temp.*
                FROM
                    menu_based_service_facility mbsf
                    JOIN menu_based_service_booking_details mbsbd ON ( mbsbd.menu_based_service_id = mbsf.id )
                    JOIN (
                    SELECT DISTINCT
                            mbss.menu_based_service_id,
                            mbs.`name` AS menu_based_service_name 
                    FROM
                            (
                            SELECT
                                    mbss.id,
                                    mbss.menu_based_service_id,
                                    mbss.pincode,
                                    mbss.category_id,
                                    haversine ( '" . $latitude . "', '" . $longitude . "', mbss.latitude, mbss.longitude ) AS 'distance' 
                            FROM
                                    menu_based_service_search mbss 
                            ORDER BY
                                    distance 
                            ) mbss
                            JOIN menu_based_service AS mbs ON ( mbss.menu_based_service_id = mbs.id AND mbs.status_id = 1 AND mbss.category_id=" . $input['category_id'] . ") 
                    WHERE
                            ( mbss.pincode = '" . $pincode . "' OR mbss.distance < " . MENU_BASED_SERVICE_DISTANCE . " ) 
                    ORDER BY
                            mbss.menu_based_service_id 
                    ) temp ON ( temp.menu_based_service_id = mbsbd.menu_based_service_id ) 
                WHERE
                    mbsf.is_package = 0";
            if (!empty($input['name'])) {
                $name = $input['name'];
                $query .= " AND mbsf.name like '%" . $name . "%' ";
            }
            $query .= " GROUP BY
                    mbsf.id 
                ORDER BY
                    count DESC 
                    ";
            $query .= " LIMIT " . $limit . " OFFSET " . $skip;
            $result = executeSelectQueryOnMySQLDB($query);
            if (empty($result)) {
                $input['is_package'] = 0;
                $result = $this->menuBasedServiceFacilityRepository->getFacilityFromLocation($latitude, $longitude, $pincode, $input);
            }
            return success($result, 'Menu based service Facility list');
        } catch (Exception $exc) {
            errorLog($exc);
        }
        return error(COMMON_ERROR);
    }

    public function topFacilityPackageList(Request $request) {
        try {
            $latitude = $request->header('latitudeUserLocation');
            $longitude = $request->header('longitudeUserLocation');
            $pincode = $request->header('postalCodeUserLocation');
            $input = $request->all();
            if (empty($input['category_id'])) {
                return error("Sorry, Category is empty.");
            }
            if (empty($latitude) || empty($longitude)) {
                return error("Sorry, Latitude/Longitude is empty.");
            }
            $limit = 30;
            $page = !empty($input['page']) ? $input['page'] : 1;
            $skip = $page > 1 ? ($page * $limit) - $limit : 0;
            // mbsf.price-((mbsf.discount*mbsf.price)/100) AS healthisam_price,
            $query = "SELECT
                    count( mbsf.Id ) AS count,
                    mbsf.id,
                    mbsf.`name`,
                    mbsf.facility_count,
                    mbsf.discount,
                    mbsf.price,
                    mbsf.is_package,
                    mbsf.gender,
                    mbsf.time,
                    mbsf.category,
                    temp.*
                FROM
                    menu_based_service_facility mbsf
                    JOIN menu_based_service_booking_details mbsbd ON ( mbsbd.menu_based_service_id = mbsf.id )
                    JOIN (
                    SELECT DISTINCT
                            mbss.menu_based_service_id,
                            mbs.`name` AS menu_based_service_name 
                    FROM
                            (
                            SELECT
                                    mbss.id,
                                    mbss.menu_based_service_id,
                                    mbss.pincode,
                                    mbss.category_id,
                                    haversine ( '" . $latitude . "', '" . $longitude . "', mbss.latitude, mbss.longitude ) AS 'distance' 
                            FROM
                                    menu_based_service_search mbss 
                            ORDER BY
                                    distance 
                            ) mbss
                            JOIN menu_based_service AS mbs ON ( mbss.menu_based_service_id = mbs.id AND mbs.status_id = 1  AND mbss.category_id=" . $input['category_id'] . ") 
                    WHERE
                            ( mbss.pincode = '" . $pincode . "' OR mbss.distance < " . MENU_BASED_SERVICE_DISTANCE . " ) 
                    ORDER BY
                            mbss.menu_based_service_id 
                    ) temp ON ( temp.menu_based_service_id = mbsbd.menu_based_service_id ) 
                WHERE
                    mbsf.is_package = 1";
            if (!empty($input['package_category'])) {
                $query .= " AND package_category=" . $input['package_category'];
            }
            if (!empty($input['name'])) {
                $name = $input['name'];
                $query .= " AND mbsf.name like '%" . $name . "%' ";
            }
            $query .= " GROUP BY
                    mbsf.id 
                ORDER BY
                    count DESC 
                    ";
            $query .= " LIMIT " . $limit . " OFFSET " . $skip;
            // pr($query);
            $result = executeSelectQueryOnMySQLDB($query);
            if (empty($result)) {
                $input['is_package'] = 1;
                $result = $this->menuBasedServiceFacilityRepository->getFacilityFromLocation($latitude, $longitude, $pincode, $input);
            }
            return success($result, 'Menu based service facility list');
        } catch (Exception $exc) {
            errorLog($exc);
        }
        return error(COMMON_ERROR);
    }

    public function facilityDetail(Request $request) {
        if (empty($request->menu_based_service_facility_id)) {
            return error("Sorry, Menu based service facility id is empty");
        }
        $result = \App\Models\MenuBasedServiceFacility::where('id', $request->menu_based_service_facility_id)->first();
        if (!empty($result)) {
            if ($result->status_id != STATUS_ACTIVE) {
                return error("Sorry, Currently this facility not available");
            }
        }
        return success($result, 'Menu based service facility data');
    }

}
