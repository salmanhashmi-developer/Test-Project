<?php

namespace App\Http\Controllers\API;

use App\Http\Controllers\Controller;
use App\Http\Repository\UserMedicalHistoryRepository;
use App\Http\Repository\NotificationRepository;
use App\Models\UserUpload;
use Illuminate\Http\Request;
use Exception;

class UserUploadController extends Controller {

    private $userMedicalHistoryRepository;
    private $notificationRepository;

    public function __construct(UserMedicalHistoryRepository $userMedicalHistoryRepository, NotificationRepository $notificationRepository) {
        $this->userMedicalHistoryRepository = $userMedicalHistoryRepository;
        $this->notificationRepository = $notificationRepository;
    }

    public function getPharmacyPrescription(Request $request) {
        $input = $request->all();
        $page = !empty($input['page']) ? $input['page'] : 1;
        $skip = $page > 1 ? ($page * LIMIT) - LIMIT : 0;
        unset($input['page']);
        $input['user_id'] = $request->user()->id;
        $result = $this->userMedicalHistoryRepository->getPharmacyPrescription($input, $skip);
        if (!empty($input['id']) && count($result) > 0) {
            $result = $result[0];
        }
        return success($result, "Data found successfully!");
    }

    public function saveCommmentOnPrescription(Request $request) {
        $input = $request->all();
        if (empty($input['id'])) {
            return error("Sorry, Id is empty");
        }
        $result = [];
        $data = UserUpload::findOrFail($input['id']);
        if (empty($data)) {
            return error("Sorry, No data found.");
        }
        if ($data->user_id != $request->user()->id) {
            return error("Access denied");
        }
        $data->user_remark = empty($input['remark']) ? null : $input['remark'];
        $data->save();
       
        $commentBy = $request->user()->first_name . ' ' . $request->user()->last_name;
        if (!empty($input['remark'])) {
            $input['user_upload_id'] = $input['id'];
            $newdata = ['created_at' => date('d-M-Y h:i:s a'), 'created_by' => $request->user()->id,
                'created_name' => $commentBy, 'comment' => $input['remark']];

            $detail = \App\Models\MedicineQuotation::where('user_upload_id', $input['id'])->first();
            unset($input['remark']);
            if (!empty($detail)) {
                if (!empty($detail->comment_json)) {
                    $commentJson = $detail->comment_json;
                    $commentJson[] = $newdata;
                } else {
                    $commentJson[] = $newdata;
                }
                $input['comment_json'] = json_encode($commentJson);
                $detail->fill($input)->save();
            } else {
                $commentJson[] = $newdata;
                $input['comment_json'] = json_encode($commentJson);
                \App\Models\MedicineQuotation::Create($input);
            }
        }
        
        return success($data, "Successfully....");
    }

    public function updatePrescription(Request $request) {
        $input = $request->all();
        if (empty($input['medicine_json'])) {
            return error("Sorry, Medicine json is empty");
        }
        if (empty($input['quotation_id'])) {
            return error("Sorry, Id is empty");
        }
        $data = MedicineQuotation::findOrFail($input['quotation_id']);
        if (empty($data)) {
            return error("Sorry, No data found.");
        }
        $data->medicine_json = json_encode($input['medicine_json']);
        $data->save();
        return success($data, "Add comment successfully!");
    }

    public function getMyPrescription(Request $request) {
        $input = $request->all();
        $page = !empty($request->page) ? $request->page : 1;
        $skip = $page > 1 ? ($page * LIMIT) - LIMIT : 0;
        $result['file_url'] = getUrl('image/user_medical_history/');
        $data = $this->userMedicalHistoryRepository->getMyPrescription(['uploaded_by' => $request->user()->id], $skip);
        $historyArr = [];
        if (!empty($data)) {
            foreach ($data as $key => $value) {
                if (empty(count($value['mapping']))) {
                    $history = \App\Models\UserMedicalHistory::where('id', $value['id'])->first();
                    if (!empty($history)) {
                        $history->delete();
                    }
                } else {
                    $historyArr[] = $value;
                }
            }
        }
        $result['list'] = $historyArr;
        return success($result, "Data found successfully!");
    }

    public function deleteMyPrescription(Request $request) {
        $input = $request->all();
        if (empty($input['ids'])) {
            return error('Sorry, Ids is empty');
        }
        $idArr = explode(',', $input['ids']);
        foreach ($idArr as $key => $id) {
            if (!empty($id)) {
                $this->userMedicalHistoryRepository->deleteMedicalHistoryMapping($id);
            }
        }
        return success([], "Data deleted successfully!");
    }

    public function userUpload(Request $request) {
        $input = $request->all();
        if (empty($input['service_id'])) {
            return error('Sorry, Service id is empty');
        }
        if (empty($input['user_patient_id'])) {
            return error('Sorry, User patient id is empty');
        }
        $result = [];
        $input['my_file'][] = $_FILES;
        debugApi('user/file/upload', $input, $result);

        $input['user_id'] = $request->user()->id;
        $input['uploaded_by'] = $request->user()->id;
        $fileName = "";
        if (!empty($input['new_file'])) {
            $fileName = $this->userMedicalHistoryRepository->uploadPrescription($input);
        }
        $fileList = "";
        if (!empty($input['old_file'])) {
            $fileList .= $input['old_file'] . ',';
        }
        if (empty($fileList) && empty($fileName)) {
            return error('Please select atleast one file.');
        }
        $input['file_json'] = $fileList . $fileName;
        $input['status_id'] = STATUS_ACTIVE;
        $input['created_at'] = date('Y-m-d H:i:s');
        $input['address_id'] = !empty($input['address_id']) ? $input['address_id'] : null;
        $result = UserUpload::create($input);
        $userData['name'] = $request->user()->first_name . ' ' . $request->user()->last_name;
        $userData['mobile'] = $request->user()->mobile;
        $userData['email'] = $request->user()->email;
        $this->notificationRepository->userPrescriptionUpload($userData, 'DONE');
        $result->message = "We have received your request Our team will get in touch with you in 30 minutes to help you with your test booking.";

        debugApi('user/file/upload', $input, $result);
        return success($result, "Upload successfully!");
    }

    public function userPrescriptionList(Request $request) {
        if (empty($request->service_id)) {
            return error('Sorry, Service id is empty');
        }
        if (!empty($request->service_ref_id)) {
            return success($this->userPrescriptionData($request), "User prescription...");
        } else {
            $page = !empty($request->page) ? $request->page : 1;
            $skip = $page > 1 ? ($page * LIMIT) - LIMIT : 0;

            $query = \App\Models\UserMedicalHistory::where(
                            ['service_id' => $request->service_id,
                                'status_id' => STATUS_ACTIVE,
                                'user_id' => $request->user()->id]);
            $query->groupBy('service_ref_id');
            $query->orderBy('id', 'DESC');
            $result = $query->skip($skip)->limit(LIMIT)->get();
            $data = [];
            if (!empty($result)) {
                foreach ($result as $key => $value) {
                    if ($request->service_id == SERVICE_DOCTOR_APPOINTMENT) {
                        $response['image_url'] = getUrl('image/doctor_profile/');
                        $refData = \App\Models\Doctor::where('id', $value['service_ref_id'])->first();
                    }
                    if ($request->service_id == SERVICE_LAB_REPORT) {
                        $response['image_url'] = getUrl('image/lab/');
                        $refData = \App\Models\Lab::where('id', $value['service_ref_id'])->first();
                    }
                    if (!empty($refData)) {
                        $data[] = $refData;
                    }
                }
            }
            $response['data'] = $data;
            return success($response, "User prescription...");
        }
    }

    private function userPrescriptionData($request) {
        $page = !empty($request->page) ? $request->page : 1;
        $skip = $page > 1 ? ($page * LIMIT) - LIMIT : 0;
        $query = \App\Models\UserMedicalHistory::where(
                        [
                            'service_id' => $request->service_id,
                            'status_id' => STATUS_ACTIVE,
                            'user_id' => $request->user()->id
        ]);
        if (!empty($request->service_ref_id)) {
            $query->where('service_ref_id', $request->service_ref_id);
        }
        $query->orderBy('id', 'DESC');
        $query->with('service', 'user', 'mapping');
        $result = $query->skip($skip)->limit(LIMIT)->get();
        $response['prescription_url'] = getUrl('image/user_medical_history/');
        $data = [];
        if (!empty($result)) {
            foreach ($result as $key => $value) {
                if ($request->service_id == SERVICE_DOCTOR_APPOINTMENT) {
                    $refData = \App\Models\DoctorAppointmentBooking::where('id', $value['ref_id'])->with('doctor', 'user_patient', 'hospital')->first();
                }
                if ($request->service_id == SERVICE_LAB_REPORT) {
                    $refData = \App\Models\LabBooking::where('id', $value['ref_id'])->with('lab', 'user_patient')->first();
                }
                if (!empty($refData)) {
                    $value['ref_data'] = $refData;
                }
                $data[$key] = $value;
            }
        }
        $response['data'] = $data;
        return $response;
    }

    public function update(Request $request) {
        if (!empty($request->id)) {
            if (!empty($request->order_id)) {
                if ($request->service_id == SERVICE_LAB_REPORT) {
                    $booking = \App\Models\LabBooking::where('order_id', $request->order_id)->first();
                    if (!empty($booking)) {
                        $data['service_ref_id'] = $booking->lab_id;
                        $data['ref_id'] = $booking->id;
                        $data['status_id'] = STATUS_CLOSED;
                        $data['updated_at'] = date('Y-m-d H:i:s');
                        UserUpload::where('id', $request->id)->update($data);
                    }
                }
            }
        }
        return success([], "User upload updated");
    }

}
