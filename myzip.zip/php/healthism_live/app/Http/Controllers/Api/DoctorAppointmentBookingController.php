<?php

namespace App\Http\Controllers\API;

use App\Http\Resources\HospitalCollection;
use App\Http\Controllers\Controller;
use App\Http\Controllers\Api\OrderPaymentController;
use App\Http\Repository\NotificationRepository;
use App\Models\DoctorAppointmentBooking;
use App\Models\DoctorHospitalBlockSlot;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use Exception;

class DoctorAppointmentBookingController extends Controller {

    private $orderPaymentController;
    private $notificationRepository;

    public function __construct(OrderPaymentController $orderPaymentController, NotificationRepository $notificationRepository) {
        $this->orderPaymentController = $orderPaymentController;
        $this->notificationRepository = $notificationRepository;
    }

    public function nextDoctorAppointment(Request $request) {
        $appoimentList = DoctorAppointmentBooking::where("created_by", $request->user()->id)
                ->where("status_id", STATUS_SUCCESS)
                ->whereDate("appointment_date", '>=', date('Y-m-d'))
                ->whereNull("appointment_start")
                ->orderBy("appointment_date", 'ASC')
                ->with('hospital', 'doctor')
                ->get();
        $result['appoiment_list'] = !empty($appoimentList) ? $appoimentList : null;
        $result['doctor_image'] = getUrl('image/doctor_profile');
        return success($result, "Booking Data...");
    }

    public function bookingPage(Request $request) {
        $input = $request->all();
        $result = [];
        $input['login_user_id'] = $request->user()->id;
        $input['login_user_mobile'] = $request->user()->mobile;
        $input['login_user_type'] = $request->user()->user_type_id;
        $validation = $this->bookingDoctorValidation($input);
        if (isset($validation[0]) && $validation[0] == 0) {
            return error($validation[1]);
        }
        $validation['slot_data']->doctor_hospital_slot_id = $validation['slot_data']->id;
        $orderRefId = KEY_ORDER_REF_ID . "_" . $request->user()->id . '_' . time();
        setRedisData($orderRefId, 0);
        $result['order_ref_id'] = $orderRefId;
        $result['slot_data'] = $validation['slot_data'];
        $result['user_patient'] = $validation['user_patient'];
        $result['calculation'] = $this->bookingCalculation($validation['slot_data']);
        if ($result['calculation']['orderAmount'] <= 0) {
            $result['payment_mode'][] = ['id' => COUPON, 'name' => 'Coupon', 'icon' => '1.jpg'];
        } else {
            $result['payment_mode'] = getPaymentMode(SERVICE_DOCTOR_APPOINTMENT, $validation['cash_booking_allowed']);
        }
        return success($result, "Booking Data...");
    }

    public function orderPayment(Request $request) {
        try {
            $input = $request->all();
            if (empty($input['order_ref_id'])) {
                return error('Sorry, Order ref id is empty');
            } else {
                $orderId = getDataFromRedisKey($input['order_ref_id']);
                if (!empty($orderId)) {
                    return error(COMMON_ERROR, ['order_id' => $orderId, 'message' => 'Order already processed']);
                }
            }
            $input['ip'] = $request->ip();
            if (empty($input['payment_mode_id'])) {
                return error("Sorry, Payment mode id is empty.");
            }
            if (empty($input['platform_id'])) {
                return error("Sorry, Platform id is empty.");
            }

            $input['login_user_id'] = $request->user()->id;
            $input['login_user_email'] = $request->user()->email;
            $input['login_user_mobile'] = $request->user()->mobile;
            $input['login_user_type'] = $request->user()->user_type_id;
            $validation = $this->bookingDoctorValidation($input);
            if (isset($validation[0]) && $validation[0] == 0) {
                return error($validation[1]);
            }
            $slotData = $validation['slot_data'];
            $userPatient = $validation['user_patient'];
            $input['user_subscription_id'] = $validation['userSubscription']->id;
            $hospitalDoctorMapping = \App\Models\DoctorHospitalMapping::where(
                            [
                                'doctor_id' => $slotData->doctor_id,
                                'hospital_id' => $slotData->hospital_id
                    ])->first();
            $discount = ($hospitalDoctorMapping->fees * $hospitalDoctorMapping->discount) / 100;
            //$discount = $hospitalDoctorMapping->discount;
            $grandTotal = (int) $hospitalDoctorMapping->fees - (int) $discount;
            if ($grandTotal <= 0) {
                $paymentMode = ['id' => COUPON, 'name' => 'Coupon', 'icon' => '1.jpg'];
            } else {
                $paymentMode = paymentMethodValidation($input['payment_mode_id']);
                if ($paymentMode['data'] == 0) {
                    return error($paymentMode['message']);
                }
                $paymentMode = $paymentMode['data'];
            }

//        if ($input['payment_mode_id'] == RAZORPAY && empty($grandTotal)) {
//            return error("Zero amount not allowed for this payment mode. Please change payment mode");
//        }
            $statusId = STATUS_PENDING;
            if ($paymentMode['id'] == OFFLINE) {
                if ($hospitalDoctorMapping->hospital->cash_booking_allowed != 1) {
                    return error("Sorry, Hospital not allowed offline(cash) booking");
                }
                $statusId = STATUS_SUCCESS;
            }
            try {
                /* ------------------------------------------
                  --------------------------------------------
                  Start DB Transaction
                  --------------------------------------------
                  -------------------------------------------- */
                DB::beginTransaction();
                $bookingInsertedData = [
                    'hospital_id' => $slotData->hospital_id,
                    'doctor_id' => $slotData->doctor_id,
                    'user_patient_id' => $userPatient->id,
                    'patient_name' => $userPatient->first_name . ' ' . $userPatient->last_name,
                    'patient_mobile' => $userPatient->mobile,
                    'doctor_hospital_slot_id' => $input['doctor_hospital_slot_id'],
                    'appointment_date' => $input['date'],
                    'appointment_time' => $slotData['from_time'],
                    'amount' => $grandTotal,
                    'discount' => $discount,
                    'created_by' => $request->user()->id,
                    'user_id' => $request->user()->id,
                    'is_video' => !empty($input['is_video']) ? 1 : NULL,
                    'status_id' => $statusId,
                    'user_subscription_id' => $input['user_subscription_id'],
                    'created_at' => date('Y-m-d H:i:s'),
                ];
                $appointmentData = DoctorAppointmentBooking::create($bookingInsertedData);
                if (empty($appointmentData->id)) {
                    return error("Sorry, Something went wrong.");
                }
                $result = $this->createOrder($appointmentData, $slotData, $paymentMode, $input);
            } catch (Exception $exc) {
                /* ------------------------------------------
                  --------------------------------------------
                  Rollback Database Entry
                  --------------------------------------------
                  -------------------------------------------- */
                errorLog($exc);
                DB::rollback();
            }
            if (!empty($result)) {
                if (empty($result['error'])) {
                    return success($result, "Thank you");
                } else {
                    return error(COMMON_ERROR, ['order_id' => $result['order_id'], 'message' => $result['error_message']]);
                }
            } else {
                return error(COMMON_ERROR);
            }
        } catch (Exception $exc) {
            errorLog($exc);
        }
        return error(COMMON_ERROR);
    }

    private function createOrder($appointmentData, $slotData, $paymentMode, $input) {
        try {
            $ds1 = $appointmentData->is_video == 1 ? 'video consultation for ' . $appointmentData->patient_name : 'In clinic appointment for ' . $appointmentData->patient_name;
            $ds2 = 'Doctor : ' . $slotData['doctor']['first_name'] . ' ' . $slotData['doctor']['last_name'];
            $ds3 = 'Hospital : ' . $slotData['hospital']['name'] . ',' . $slotData['hospital']['area'];
            $descripationArr = ["desc1" => $ds1, "desc2" => $ds2, "desc3" => $ds3];
            $transactionArr = [
                'doctor' => $slotData['doctor']['first_name'] . ' ' . $slotData['doctor']['last_name'],
                'hospital' => $slotData['hospital']['name'] . ',' . $slotData['hospital']['area'],
                'patient_name' => $appointmentData->patient_name,
                'patient_mobile' => $appointmentData->patient_mobile,
                'appointment_date_time' => $appointmentData->appointment_date . ' ' . $appointmentData->appointment_time,
            ];
            $statusId = STATUS_SENT_ON_PG;
            $status = 'SENT ON PG';
            $remark = "PAYMENT PENDING";
            $paymentRemark = "PAYMENT PENDING";
            $color = statusWiseColor(STATUS_SENT_ON_PG);
            if ($paymentMode['id'] == OFFLINE) {
                $statusId = STATUS_DONE;
                $status = 'DONE';
                $remark = "ORDER CONFIRM PAY AT CLINIC";
                $paymentRemark = "PAYMENT PENDING PAY AT CLINIC";
                $color = statusWiseColor(STATUS_DONE);
            }

            /* ........... CRETAE NEW ORDER............ */
            $orderArr = [
                'order_code' => 'DA' . platformCode($input['platform_id']) . $input['login_user_id'] . time(),
                'user_id' => $input['login_user_id'],
                'user_subscription_id' => $input['user_subscription_id'],
                'service_id' => SERVICE_DOCTOR_APPOINTMENT,
                'amount' => $appointmentData->amount,
                'status_id' => $statusId,
                'remark' => $remark,
                'remark_color_code' => $color,
                'description_json' => json_encode($descripationArr),
                'transaction_json' => json_encode($transactionArr),
            ];
            $order = $this->orderPaymentController->createOrder($orderArr);
            if (!empty($order->id)) {
                setRedisData($input['order_ref_id'], $order->id);

                $doctorAppointmentBookingUpdate = DoctorAppointmentBooking::findOrFail($appointmentData->id);
                $doctorAppointmentBookingUpdate->fill(['order_id' => $order->id])->save();

                /* ........... CRETAE NEW ORDER HISTORY............ */
                $orderHistoryArr = [
                    'order_id' => $order->id,
                    'type' => 'ORDER',
                    'status_id' => $statusId,
                    'remark' => $remark,
                    'updated_by' => $input['login_user_id']
                ];
                $this->orderPaymentController->saveOrderHistory($orderHistoryArr);

                /* ........... CRETAE NEW ORDER DETAIL............ */
                $orderDeatilArr = [
                    'order_id' => $order->id,
                    'service_id' => SERVICE_DOCTOR_APPOINTMENT,
                    'ref_id' => $appointmentData->id,
                    'coupon_id' => null,
                    'coupon_amount' => null,
                    'wallet_amount' => null,
                    'pg_amount' => $appointmentData->amount,
                    'paid_amount' => $appointmentData->amount,
                    'tax' => null,
                    'charges' => null,
                    'status_id' => $statusId,
                    'remark' => $remark,
                    'remark_color_code' => $color,
                ];
                $orderDeatil = $this->orderPaymentController->saveOrderDetail($orderDeatilArr);

                /* ........... CRETAE NEW ORDER DETAIL HISTORY............ */
                $orderDeatilHistoryArr = [
                    'order_id' => $order->id,
                    'order_detail_id' => $orderDeatil->id,
                    'type' => 'ORDER_DETAIL',
                    'status_id' => STATUS_PENDING,
                    'remark' => $remark,
                    'updated_by' => $input['login_user_id']
                ];
                $this->orderPaymentController->saveOrderHistory($orderDeatilHistoryArr);


                /* ........... CRETAE NEW ORDER PAYMENT............ */
                $orderPaymentArr = [
                    'order_id' => $order->id,
                    'user_id' => $input['login_user_id'],
                    'payment_mode_id' => $paymentMode['id'],
                    'pg_amount' => $appointmentData->amount,
                    'status_id' => STATUS_PENDING,
                    'ip_address' => $input['ip'],
                ];
                $orderPayment = $this->orderPaymentController->saveOrderPayment($orderPaymentArr);

                /* ........... CRETAE NEW ORDER PAYMENT HISTORY............ */
                $paymentHistoryArr = [
                    'order_id' => $order->id,
                    'type' => 'PAYMENT',
                    'status_id' => STATUS_PENDING,
                    'remark' => $paymentRemark,
                    'updated_by' => $input['login_user_id']
                ];
                $this->orderPaymentController->saveOrderHistory($paymentHistoryArr);
            }
            /* ------------------------------------------
              --------------------------------------------
              Commit Transaction to Save Data to Database
              --------------------------------------------
              -------------------------------------------- */
            DB::commit();

            $order['description'] = 'Doctor Appointment Booking';
            $order['mobile'] = $input['login_user_mobile'];
            $order['email'] = $input['login_user_email'];
            $order['payment_mode_id'] = $paymentMode['id'];
            $order['amount'] = $appointmentData->amount; //Pass on payment getaway
            $result = $this->orderPaymentController->makePayment($order);
            return $result;
        } catch (Exception $exc) {
            /* ------------------------------------------
              --------------------------------------------
              Rollback Database Entry
              --------------------------------------------
              -------------------------------------------- */
            DB::rollback();
            setRedisData($input['order_ref_id'], 0);
            errorLog($exc);
        }
        return 0;
    }

    public function rescheduleAppointment(Request $request) {
        try {
            $input = $request->all();
            $input['login_user_id'] = $request->user()->id;
            $input['login_user_mobile'] = $request->user()->mobile;
            $input['login_user_type'] = $request->user()->user_type_id;
            if (empty($input['appointment_id'])) {
                return error('Sorry, Appointment id is empty');
            }
            if (empty($input['doctor_hospital_slot_id'])) {
                return error('Sorry, Doctor hospital slot id is empty');
            }
            if (empty($input['date'])) {
                return error('Sorry, Date is empty');
            }
            $appintmentData = DoctorAppointmentBooking::where('id', $input['appointment_id'])->first();
            $oldDate = date_format(date_create($appintmentData->appointment_date), "d/m/Y") . ' ' . $appintmentData->appointment_time;
            if (empty($appintmentData)) {
                return error('Sorry, Invalid appointment id');
            }
            if ($input['login_user_type'] == DOCTOR) {
                if (empty($input['doctor_id'])) {
                    return error("Sorry, Doctor id is empty");
                }
                if ($appintmentData->doctor_id != $input['doctor_id']) {
                    return error('Sorry, You are not authorized to reschedule this appointment');
                }
            } else {
                if ($appintmentData->created_by != $input['login_user_id']) {
                    return error('Sorry, You are not authorized to reschedule this appointment');
                }
            }
            if ($appintmentData->status_id != STATUS_SUCCESS) {
                return error('Sorry, Your appointment has not been confirmed. so you cannot reschedule the appointment');
            }
            $date = $appintmentData->appointment_date . " " . $appintmentData->appointment_time;
            $appointmentDateTime = strtotime($date);
            $dateNow = strtotime(date('Y-m-d H:i:s'));
//current timestamp
            if ($input['login_user_type'] == DOCTOR) {
                if ($dateNow > $appointmentDateTime) {
                    return array('code' => 0, 'message' => "Sorry, Reschedule time has been over");
                }
            } else {
                $rescheduleTime = strtotime(date('Y-m-d H:i:s', strtotime($date . ' -2 hours')));
                if ($dateNow > $rescheduleTime) {
                    return array('code' => 0, 'message' => "Sorry, Reschedule time has been over");
                }
            }

            $slotData = \App\Models\DoctorHospitalSlot::where('id', $input['doctor_hospital_slot_id'])->first();
            if (empty($slotData)) {
                return error('Sorry, Invalid doctor hospital slot id');
            }
            if ($appintmentData->doctor_id != $slotData->doctor_id) {
                return error("Sorry, Can't select other doctor slot.");
            }
            if ($appintmentData->hospital_id != $slotData->hospital_id) {
                return error("Sorry, Can't select other hospital slot.");
            }

            $result = [];
            $input['user_patient_id'] = $appintmentData->user_patient_id;
            $validation = $this->bookingDoctorValidation($input);
            if (isset($validation[0]) && $validation[0] == 0) {
                return error($validation[1]);
            }
            $hospitalDoctorMapping = \App\Models\DoctorHospitalMapping::where(
                            [
                                'doctor_id' => $slotData->doctor_id,
                                'hospital_id' => $slotData->hospital_id
                    ])->first();
            $discount = ($hospitalDoctorMapping->fees * $hospitalDoctorMapping->discount) / 100;
           // $discount = $hospitalDoctorMapping->discount;
            $grandTotal = (int) $hospitalDoctorMapping->fees - (int) $discount;
            if ($grandTotal != $appintmentData->amount) {
                return error('Sorry, Amount mismatch between old and reschedule appointment. Cancel appointment and rebook.');
            }
            $result = $appintmentData->fill([
                        'doctor_hospital_slot_id' => $input['doctor_hospital_slot_id'],
                        'appointment_date' => $input['date'],
                        'appointment_time' => $slotData->from_time,
                    ])->save();
            if ($input['login_user_type'] == DOCTOR) {
                $remark = "Reschedule Appointment By Doctor : Old  Appointment - " . $oldDate
                        . ' New  Appointment - ' . $input['date'] . ' ' . $slotData->from_time;
            } else {
                $remark = "Reschedule Appointment : Old  Appointment - " . $oldDate
                        . ' New  Appointment - ' . $input['date'] . ' ' . $slotData->from_time;
            }
            $this->orderPaymentController->saveOrderHistory([
                'order_id' => $appintmentData->order_id,
                'type' => 'TRACKING', 'status_id' => STATUS_SUCCESS,
                'remark' => $remark,
                'updated_by' => $input['login_user_id']
            ]);
            $this->notificationRepository->doctorAppointmentNotification($appintmentData->order_id, 'RESCHEDULE', ['old_date' => $oldDate]);
            return success($result, "Appointment rescheduled successfully!");
        } catch (Exception $exc) {
            errorLog($exc);
        }
        return error(COMMON_ERROR);
    }

    /* Use booking doctor validation function for booking and payment time */

    private function bookingDoctorValidation($input) {
        if (empty($input['doctor_hospital_slot_id'])) {
            return array(0, "Sorry, Doctor hospital slot id is empty");
        }
        if (empty($input['user_patient_id'])) {
            return array(0, "Sorry, User patient id is empty");
        }
        if (empty($input['date'])) {
            return array(0, "Sorry, Date is empty");
        }

        $userSubscription = getUserSubscription($input['login_user_id']);
        if (empty($userSubscription)) {
            return array(0, "Sorry, No activate plan available");
        } else {
            if ($userSubscription['expire'] == 1) {
                return array(0, "Please renew plan, Your plan is expired");
            }
        }
        $slot = \App\Models\DoctorHospitalSlot::where('id', $input['doctor_hospital_slot_id'])->with('hospital', 'doctor')->first();
        if (empty($slot)) {
            return array(0, "Sorry, Slot data not found.");
        }
        if (empty($slot->hospital) && $slot->hospital->status_id != STATUS_ACTIVE) {
            return array(0, "Sorry, hospital service has been disabled");
        } else {
            if ($slot->hospital->cancel_policy) {
                $slot->hospital->cancel_policy = json_decode($slot->hospital->cancel_policy);
            } else {
                $slot->hospital->cancel_policy = HOSPITAL_CANCEL_POLICY;
            }
        }
        if (empty($slot->doctor) && $slot->doctor->status_id != STATUS_ACTIVE) {
            return array(0, "Sorry, doctor service has been disabled");
        }
        $checkSlotBooked = DoctorAppointmentBooking::where(
                        [
                            'doctor_hospital_slot_id' => $input['doctor_hospital_slot_id'],
                            'appointment_date' => $input['date'],
                            'status_id' => STATUS_SUCCESS
                ])->count();
        if ($checkSlotBooked > 0) {
            return array(0, "Sorry, Someone already booked the slot");
        }
        $checkSlotBlocked = DoctorHospitalBlockSlot::where(
                        [
                            'doctor_hospital_slot_id' => $input['doctor_hospital_slot_id'],
                            'date' => $input['date']
                ])->count();
        if ($checkSlotBlocked > 0) {
            return array(0, "Sorry, Slot has been blocked");
        }
        $patientData = \App\Models\UserPatientMapping::where('id', $input['user_patient_id'])->first();
        if (empty($patientData)) {
            return array(0, 'Sorry,Patient data not found');
        } else {

            if ($patientData->user_id != $input['login_user_id']) {
                return array(0, 'Sorry,You have not mapped with Patient');
            }

            if ($patientData->status_id != STATUS_ACTIVE) {
                return array(0, 'Sorry,Patient is blocked.');
            }
            if ($patientData->is_deleted == 1) {
                return array(0, 'Sorry,Patient was deleted.');
            }
        }
        $result['cash_booking_allowed'] = $slot->hospital->cash_booking_allowed;
        $result['slot_data'] = $slot;
        $result['user_patient'] = $patientData;
        $result['userSubscription'] = $userSubscription;
        return $result;
    }

    /* Calculation Of Booking */

    private function bookingCalculation($validation) {
        $hospitalDoctorMapping = \App\Models\DoctorHospitalMapping::where(
                        [
                            'doctor_id' => $validation->doctor_id,
                            'hospital_id' => $validation->hospital_id
                ])->first();

        $discount = ($hospitalDoctorMapping->fees * $hospitalDoctorMapping->discount) / 100;
        //$discount = $hospitalDoctorMapping->discount;
        $result['charges'] = array(
            ['title' => 'Amount', 'value' => numberFormat($hospitalDoctorMapping->fees), 'symbol' => '+'],
            ['title' => 'Booking Charge(Rs.' . BOOKING_CHARGES . ')', 'value' => 'Free', 'symbol' => '+', 'color' => '#209f7b'],
            ['title' => 'Discount(RS.' . numberFormat($discount) . ' Off)', 'value' => numberFormat($discount), 'symbol' => '-']
        );
        $grandTotal = (int) $hospitalDoctorMapping->fees - (int) $discount;
        $result['orderAmount'] = $grandTotal;
        $result['grandTotal'] = ['title' => 'Total Payable', 'value' => numberFormat($grandTotal)];
        if (!empty($discount)) {
            $result['discountMessage'] = 'You will save RS. ' . numberFormat($discount) . ' on this appointment';
        }
        return $result;
    }

    public function cancellationReason(Request $request) {
        if (empty($request->appointment_id)) {
            return error("Sorry, appointment id is empty");
        }
        $validation = $this->cancelationTimeValidation($request);
        if ($validation['code'] == 0) {
            return error($validation['message']);
        }
        $appintmentData = $validation['data'];
        $result['doctor_name'] = $appintmentData->doctor->first_name . " " . $appintmentData->doctor->last_name;
        $result['hospital_name'] = $appintmentData->hospital->name;
        $result['hospital_area'] = $appintmentData->hospital->area;
        $result['date'] = $appintmentData->appointment_date;
        $result['time'] = $appintmentData->appointment_time;
        $result['appointment_id'] = $appintmentData->id;
        if ($request->user()->login_user_type == DOCTOR) {
            $result['cancellation_reason'] = [
                'I am Unavailable',
                'I am busy',
                'I have another appointment',
                'Other'
            ];
        } else {
            $result['cancellation_reason'] = [
                'I am busy',
                'Forget about the appointment',
                'Changed my mind',
                'Visited another doctor',
                'Doctor asked me to cancel',
                'Other',
            ];
        }
        return success($result, "Booking Data...");
    }

    public function cancellationDetail(Request $request) {
        if (empty($request->appointment_id)) {
            return error("Sorry, Appointment id is empty");
        }
        $validation = $this->cancelationTimeValidation($request);
        if ($validation['code'] == 0) {
            return error($validation['message']);
        }
        $appintmentData = $validation['data'];
        $orderDetail = \App\Models\OrderDetail::where('order_id', $appintmentData->order_id)
                        ->where('ref_id', $request->appointment_id)->first();
        if (empty($orderDetail)) {
            return error("Sorry, Order data not found");
        }
        $paymentModeId = \App\Models\OrderPayment::where('order_id', $appintmentData->order_id)->first()->payment_mode_id;
        $totalAmount = $orderDetail->coupon_amount + $orderDetail->wallet_amount + $orderDetail->pg_amount;
        $result['calculation']['charges'][] = ['title' => 'Amount', 'symbol' => '', 'value' => numberFormat($totalAmount)];

        if ($paymentModeId == OFFLINE) {
            $result['calculation']['grandTotal'] = ['title' => 'Amount Paid', 'value' => '0.00'];
        } else {
            if (!empty($orderDetail->coupon_amount)) {
                $result['calculation']['charges'][] = ['title' => 'Coupon Amount', 'symbol' => '-', 'value' => numberFormat($orderDetail->coupon_amount)];
            }
            if (!empty($orderDetail->wallet_amount)) {
                $result['calculation']['charges'][] = ['title' => 'Wallet Amount', 'symbol' => '-', 'value' => numberFormat($orderDetail->wallet_amount)];
            }
            $result['calculation']['grandTotal'] = ['title' => 'Amount Paid', 'value' => numberFormat($orderDetail->pg_amount)];
        }
        $cancelationCharges = $this->cancelationCharges($appintmentData);
        if ($paymentModeId == OFFLINE) {
            $result['refund_calculation']['charges'][] = ['title' => 'Amount Paid', 'value' => '0.00'];
            $result['refund_calculation']['charges'][] = ['title' => 'Cancellation Charges', 'symbol' => '-', 'value' => '0.00'];
            $result['refund_calculation']['grandTotal'] = ['title' => 'Amount Paid', 'value' => '0.00'];
        } else {
            $result['refund_calculation']['charges'][] = ['title' => 'Amount Paid', 'value' => numberFormat($orderDetail->pg_amount)];
            $result['refund_calculation']['charges'][] = ['title' => 'Cancellation Charges', 'symbol' => '-', 'value' => numberFormat($cancelationCharges)];
            $result['refund_calculation']['grandTotal'] = ['title' => 'Amount Paid', 'value' => numberFormat($orderDetail->pg_amount - $cancelationCharges)];
        }

        $result['payment_method'] = ['title' => 'Paid Via', 'symbol' => '', 'value' => $paymentModeId];
        $result['cancel_policy'] = !empty($appintmentData->hospital->cancel_policy) ? json_decode($appintmentData->hospital->cancel_policy, true) : HOSPITAL_CANCEL_POLICY;
        $result['reason'] = $request->reason;
        return success($result, "Booking Data...");
    }

    public function cancelOrder(Request $request) {
        try {
            if (empty($request->appointment_id)) {
                return error("Sorry, Appointment id is empty");
            }
            if (empty($request->reason)) {
                return error("Sorry, Reason is empty");
            }
            $validation = $this->cancelationTimeValidation($request);
            if ($validation['code'] == 0) {
                return error($validation['message']);
            }
            $appintmentData = $validation['data'];
            $orderDetail = \App\Models\OrderDetail::where('order_id', $appintmentData->order_id)
                            ->where('ref_id', $request->appointment_id)->first();
            if (empty($orderDetail)) {
                return error("Sorry, Order data not found");
            }
            $orderPayment = \App\Models\OrderPayment::where('order_id', $appintmentData->order_id)->first();
            $cancelationData['cancelationCharges'] = $request->user()->user_type_id == END_USER ? $this->cancelationCharges($appintmentData) : 0;
            if (!empty($orderPayment)) {
                if ($orderPayment->status_id == STATUS_DONE && $orderPayment->payment_mode_id == RAZORPAY) {
                    $cancelationData['refundAmount'] = $orderDetail->pg_amount - $cancelationData['cancelationCharges'];
                }
            }
            $cancelationData['reason'] = $request->reason;
            $cancelationData['order_id'] = $appintmentData->order_id;
            $cancelationData['order_detail_id'] = $orderDetail->id;
            $cancelationData['ref_id'] = $appintmentData->id;
            $cancelationData['login_user_id'] = $request->user()->id;
            $cancelationData['login_user_type'] = $request->user()->user_type_id;
            $cancelationData['login_user_name'] = $request->user()->first_name . ' ' . $request->user()->last_name;
            $this->orderPaymentController->orderCancel($cancelationData);
            $appintmentData->fill(array('status_id' => STATUS_CANCELLED, 'updated_at' => date('Y-m-d H:i:s'),
                'refund_amount' => !empty($cancelationData['refundAmount']) ? $cancelationData['refundAmount'] : null))->save();
            $remark = "Cancel by user - reason: " . $request->reason;
            $this->orderPaymentController->saveOrderHistory(['order_id' => $appintmentData->order_id, 'type' => 'TRACKING', 'status_id' => STATUS_CANCELLED, 'remark' => $remark, 'updated_by' => $request->user()->id]);

            $mainOrder = \App\Models\Orders::where('id', $appintmentData->order_id)->with('detail', 'payment', 'payment.paymentmode', 'user')->first();

            $this->notificationRepository->doctorAppointmentNotification($appintmentData->order_id, 'CANCELLED');

            return success(array(), "Appointment cancelled!");
        } catch (Exception $exc) {
            errorLog($exc);
        }
        return error(COMMON_ERROR);
    }

    private function cancelationCharges($appintmentData) {
        $cancelSetting = CANCEL_POLICY_SETTING;
        if (!empty($appintmentData->hospital->cancel_policy_setting)) {
            $cancelSetting = json_decode($appintmentData->hospital->cancel_policy_setting, true);
            $hours = array();
            foreach ($cancelSetting as $key => $val) {
                $hours[$key] = $val['hours'];
            }
            array_multisort($hours, SORT_ASC, $cancelSetting);
        }
        $appoimentDate = $appintmentData->appointment_date . ' ' . $appintmentData->appointment_time;
        $now = date('Y-m-d H:i:s');
        $timestamp2 = strtotime($appoimentDate);
        $timestamp1 = strtotime($now);
        $timeDiff = abs($timestamp2 - $timestamp1) / (60 * 60);
        $cancelationCharges = 0;
        foreach ($cancelSetting as $key => $val) {
            if ($timeDiff < $val['hours']) {
                $cancelationCharges = ($appintmentData->amount * $val['charge']) / 100;
                break;
            }
        }
        return $cancelationCharges;
    }

    private function cancelationTimeValidation($request) {
        $appointmentId = $request->appointment_id;
        $loginUserId = $request->user()->id;
        $appintmentData = DoctorAppointmentBooking::where('id', $appointmentId)->with('hospital', 'hospital.state', 'hospital.city', 'doctor')->first();
        if (empty($appintmentData)) {
            return array('code' => 0, 'message' => "Sorry, Appointment data not found");
        }
        if ($request->user()->login_user_type == DOCTOR) {
            if (empty($request->doctor_id)) {
                return array('code' => 0, 'message' => "Sorry, Doctor id is empty");
            }
            if ($appintmentData->doctor_id != $request->doctor_id) {
                return array('code' => 0, 'message' => "Sorry, You don't cancel other doctor's appointment");
            }
        } else {
            if ($appintmentData->created_by != $loginUserId) {
                return array('code' => 0, 'message' => "Sorry, You don't cancel other user's appointment");
            }
        }
        if ($appintmentData->status_id == STATUS_CANCELLED) {
            return array('code' => 0, 'message' => "Sorry, Appointment already cancelled");
        }
        if (empty($appintmentData->hospital->cancellation_allowed)) {
            return array('code' => 0, 'message' => "Sorry, This hospital has not allowed to appointment cancellation");
        }
        $date = $appintmentData->appointment_date . " " . $appintmentData->appointment_time;
        $appointmentDateTime = strtotime($date);
        $dateNow = strtotime(date('Y-m-d H:i:s')); //current timestamp
        if ($dateNow > $appointmentDateTime) {
            return array('code' => 0, 'message' => "Sorry, Cancellation time has been over");
        } else {
            return array('code' => 1, 'data' => $appintmentData);
        }
    }

    public function testNotification(Request $request) {
        $this->notificationRepository->doctorAppointmentNotification($request->id, 'DONE');
    }

    public function morningBookingPush() {
        $booking = DoctorAppointmentBooking::where('appointment_date', date('Y-m-d'))->where('status_id', STATUS_SUCCESS)->get();
        if (!empty($booking)) {
            foreach ($booking as $key => $data) {
                if (!empty($data)) {
                    $this->notificationRepository->doctorAppointmentNotification($data['order_id'], 'REMINDER');
                }
            }
        }
    }

    public function remainderBookingPush() {
        $time = date('H:i', strtotime('+2 hours')) . ':00';
        $booking = DoctorAppointmentBooking::where('appointment_date', date('Y-m-d'))
                ->where('appointment_time', $time)
                ->where('status_id', STATUS_SUCCESS)
                ->get();
        if (!empty($booking)) {
            foreach ($booking as $key => $data) {
                if (!empty($data)) {
                    $this->notificationRepository->doctorAppointmentNotification($data['order_id'], 'REMINDER');
                }
            }
        }
    }

}
