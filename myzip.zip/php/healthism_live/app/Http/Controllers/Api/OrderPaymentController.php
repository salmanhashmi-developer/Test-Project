<?php

namespace App\Http\Controllers\API;

use App\Http\Controllers\Controller;
use App\Http\Repository\NotificationRepository;
use App\Http\Repository\ServiceRepository;
use App\Http\Repository\OfferRepository;
use App\Models\OrderCharges;
use App\Models\OrderDetail;
use App\Models\OrderHistories;
use App\Models\OrderPayment;
use App\Models\Orders;
use Illuminate\Http\Request;
use Exception;

class OrderPaymentController extends Controller {

    private $notificationRepository;
    private $serviceRepository;
    private $offerRepository;

    public function __construct(NotificationRepository $notificationRepository, ServiceRepository $serviceRepository, OfferRepository $offerRepository) {
        $this->notificationRepository = $notificationRepository;
        $this->serviceRepository = $serviceRepository;
        $this->offerRepository = $offerRepository;
    }

    public function createOrder($input) {
        $input['created_at'] = date('Y-m-d H:i:s');
        $result = Orders::create($input);
        return $result;
    }

    public function saveOrderDetail($input) {
        $input['created_at'] = date('Y-m-d H:i:s');
        $result = OrderDetail::create($input);
        return $result;
    }

    public function saveOrderHistory($input) {
        $input['created_at'] = date('Y-m-d H:i:s');
        $input['remark'] = !empty($input['remark']) ? substr($input['remark'], 0, 240) : null;
        $result = OrderHistories::create($input);
        return $result;
    }

    public function saveOrderPayment($input) {
        $input['created_at'] = date('Y-m-d H:i:s');
        $result = OrderPayment::create($input);
        return $result;
    }

    public function updateServiceData($orderId, $remark = "") {
        try {
            $mainOrder = Orders::where('id', $orderId)->with('detail', 'payment', 'payment.paymentmode', 'user')->first();
            $orderDetail = $mainOrder->detail;
            if (!empty($orderDetail)) {
                if ($orderDetail[0]->service_id == SERVICE_DOCTOR_APPOINTMENT) {
                    //Single record mapped : get data from '0' index
                    $orderDetailData = $orderDetail[0];
                    $this->serviceRepository->updateDoctorAppointmentBooking($orderDetailData);
                    if ($orderDetailData->status_id == STATUS_DONE) {
                        $this->notificationRepository->doctorAppointmentNotification($orderId, 'DONE');
                    }
                }
                if ($orderDetail[0]->service_id == SERVICE_SUBSCRIPTION_PLAN) {
                    //Single record mapped : get data from '0' index
                    $orderDetailData = $orderDetail[0];
                    $this->serviceRepository->updateUserSubscription($orderDetailData);
                    if ($orderDetailData->status_id == STATUS_DONE) {
                        $this->notificationRepository->subscriptionNotification($orderId, 'DONE');
                    }
                }
                if ($orderDetail[0]->service_id == SERVICE_LAB_REPORT) {
                    //Single record mapped : get data from '0' index
                    $orderDetailData = $orderDetail[0];
                    $this->serviceRepository->updateLabAppointmentBooking($orderDetailData);
                    if ($orderDetailData->status_id == STATUS_DONE) {
                        $this->notificationRepository->labAppointmentNotification($orderId, 'DONE');
                    }
                }
                if ($orderDetail[0]->service_id == MENU_BASED_SERVICE) {
                    //Single record mapped : get data from '0' index
                    $orderDetailData = $orderDetail[0];
                    $this->serviceRepository->updateMBSAppointmentBooking($orderDetailData);
                    if ($orderDetailData->status_id == STATUS_DONE) {
                        $this->notificationRepository->MBSAppointmentNotification($orderId, 'DONE');
                    }
                }
                if ($orderDetail[0]->service_id == SUBSCRIPTION_BASED_SERVICE) {
                    //Single record mapped : get data from '0' index
                    $orderDetailData = $orderDetail[0];
                    $this->serviceRepository->updateSBSAppointmentBooking($orderDetailData);
                    if ($orderDetailData->status_id == STATUS_DONE) {
                        $this->notificationRepository->SBSAppointmentNotification($orderId, 'DONE');
                    }
                }
                //Multi record mapped : foreach set $orderDetail
            }
        } catch (Exception $exc) {
            errorLog($exc);
        }
    }

    private function offlinePayment($order) {
        if ($order['service_id'] == SERVICE_DOCTOR_APPOINTMENT) {
            $this->notificationRepository->doctorAppointmentNotification($order['id'], 'DONE');
        }
        if ($order['service_id'] == SERVICE_LAB_REPORT) {
            $this->notificationRepository->labAppointmentNotification($order['id'], 'DONE');
        }
        if ($order['service_id'] == MENU_BASED_SERVICE) {
            $this->notificationRepository->MBSAppointmentNotification($order['id'], 'DONE');
        }
        if ($order['service_id'] == SUBSCRIPTION_BASED_SERVICE) {
            $this->notificationRepository->SBSAppointmentNotification($order['id'], 'DONE');
        }
    }

    public function makePayment($input) {
        try {

            //IF PAYMENY AMOUNT ZERO ORDER SUCCESS
            if ($input['payment_mode_id'] == COUPON || empty($input['amount'])) {
                $promoCodeResponse = $this->offerRepository->checkPromoCodeApply($input['id'], STATUS_DONE);
                if ($promoCodeResponse['code'] == 0) {
                    $this->promoCodeOrderFailed($input['id'], $promoCodeResponse['message']);
                } else {
                    $this->orderSuccess($input['id']);
                    OrderPayment::where('order_id', $input['id'])->update(['payment_mode_id' => COUPON, 'pg_amount' => $input['promo_code_discount']]);
                    $this->updateServiceData($input['id']);
                }
                return $input;
            }

            if ($input['payment_mode_id'] == OFFLINE) {
                if ($input['platform_id'] == WEB) {
                    $this->offlinePayment($input);
                } else {
                    $promoCodeResponse = $this->offerRepository->checkPromoCodeApply($input['id'], STATUS_DONE);
                    if ($promoCodeResponse['code'] == 0) {
                        $this->promoCodeOrderFailed($input['id'], $promoCodeResponse['message']);
                    } else {
                        $this->offlinePayment($input);
                    }
                }
                return $input;
            }

            if ($input['payment_mode_id'] == RAZORPAY) {
                if ($input['platform_id'] == WEB) {
                    $appResponse = $this->maKePaymentLink($input);
                    $orderStatus = STATUS_DONE;
                    $orderRemark = "ORDER DONE - PAYMENT AWAITED";
                } else {
                    $appResponse = $this->makeOrderOnRazorpay($input);
                    $orderStatus = STATUS_RETURN_FROM_PG;
                    $orderRemark = "PAYMENT AWAITED";
                }
                if (!empty($appResponse)) {
                    if (!empty($appResponse['id']) && $appResponse['status'] == 'created') {

                        /** UPDATE RECORDE************** */
                        $order = Orders::where('id', $input['id'])->limit(1)->update(array('status_id' => $orderStatus, 'remark' => $orderRemark, 'remark_color_code' => statusWiseColor($orderStatus), 'updated_at' => date('Y-m-d H:i:s')));
                        $this->saveOrderHistory(['order_id' => $input['id'], 'type' => 'ORDER', 'status_id' => $orderStatus, 'remark' => 'Create payment on razorpay']);

                        //changes STATUS_INPROGRESS=>STATUS_PENDING
                        $this->saveOrderHistory(['order_id' => $input['id'], 'type' => 'PAYMENT', 'status_id' => STATUS_PENDING, 'remark' => 'Create payment on razorpay']);
                        OrderPayment::where('order_id', $input['id'])->limit(1)->update(array('pg_reference_id' => $appResponse['id'], 'pg_response' => json_encode($appResponse), 'status_id' => STATUS_PENDING, 'updated_at' => date('Y-m-d H:i:s')));

                        $orderDetail = OrderDetail::where('order_id', $input['id'])->update(array('status_id' => STATUS_RETURN_FROM_PG, 'remark' => 'PAYMENT AWAITED', 'remark_color_code' => statusWiseColor(STATUS_RETURN_FROM_PG), 'updated_at' => date('Y-m-d H:i:s')));

                        /**                         * ******************* */
                        if ($input['platform_id'] == WEB) {
                            $response = $input;
                            $response['pg_response'] = $appResponse;
                        } else {
                            $response['key'] = env('RAZORPAY_KEY_ID');
                            $response['amount'] = $input['amount'] * 100;
                            $response['order_id'] = $appResponse['id'];
                            $response['booking_id'] = $input['id'];
                            $response['description'] = $input['description'];
                            $response['retry']['enabled'] = true;
                            $response['retry']['max_count'] = 1;
                            $response['send_sms_hash'] = true;
                            $response['profile']['contact'] = $input['mobile'];
                            $response['profile']['email'] = $input['email'];
                        }
                        return $response;
                    } else {
                        $error = "Payment Failed";
                        if (!empty($appResponse)) {
                            $error = $appResponse['error']['description'];
                            OrderPayment::where('order_id', $input['id'])->limit(1)->update(array('pg_response' => json_encode($appResponse)));
                        }
                        $input['order_remark'] = "PAYMENT FAILED";
                        $input['order_id'] = $input['id'];
                        $this->orderFailed($input);
                        return array('error' => 1, 'error_message' => $error, 'order_id' => $input['id']);
                    }
                }
            }
        } catch (Exception $exc) {
            errorLog($exc);
        }
        return array('error' => 1, 'error_message' => "Payment not generated on PG", 'order_id' => $input['id']);
    }

    private function maKePaymentLink($input) {
        $data = array(
            'amount' => $input['amount'] * 100, //amount in paisa form
            'currency' => 'INR',
            'accept_partial' => false,
            'first_min_partial_amount' => $input['amount'] * 100, //amount in paisa form
            'description' => 'healthismplus payment',
            'reference_id' => strval($input['id']), //order id or code
            'customer' => array(
                'name' => $input['name'],
                'email' => $input['email'],
                'contact' => '+91' . $input['mobile']
            ),
            'notify' => array(
                'sms' => true,
                'email' => true,
                'whatsapp' => true
            ),
            'reminder_enable' => true,
            'notes' => array(
                'policy_name' => 'Healthismplus Lab Appointment Booking Payment'
            ),
            'callback_url' => env('APP_URL') . 'api/razorpay/callback',
            'callback_method' => 'get'
        );
        $ch = curl_init();
        $url = 'https://api.razorpay.com/v1/payment_links';
        curl_setopt($ch, CURLOPT_URL, $url);
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
        curl_setopt($ch, CURLOPT_POST, 1);
        curl_setopt($ch, CURLOPT_POSTFIELDS, json_encode($data));
        curl_setopt($ch, CURLOPT_USERPWD, env('RAZORPAY_KEY_ID') . ":" . env('RAZORPAY_SECRET_KEY'));
        curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
        $headers = array();
        $headers[] = 'Content-Type: application/json';
        curl_setopt($ch, CURLOPT_HTTPHEADER, $headers);
        $response = curl_exec($ch);
        curl_close($ch);
        paymentLog("ORDER ID => " . $input['id'] . " : " . $url, json_encode($data), $response);
        return json_decode($response, true);
    }

    public function razorpayCallbackUrl(Request $request) {
        paymentLog("razorpayCallbackUrl", json_encode(array()), json_encode($request->all()));
        $linkPaymentResponse = $request->all();
        $result = [];
        if (!empty($linkPaymentResponse['razorpay_payment_id']) && !empty($linkPaymentResponse['razorpay_payment_link_reference_id'])) {
            $result = $this->razorpayFetchPayment($linkPaymentResponse['razorpay_payment_link_reference_id'], $linkPaymentResponse['razorpay_payment_id'], 'payment_link');
        } else {

            /* Recheck link status
             * ======================================== */
            $ch = curl_init();
            $url = 'https://api.razorpay.com/v1/payment_links/' . $linkPaymentResponse['razorpay_payment_link_id'];
            curl_setopt($ch, CURLOPT_URL, $url);
            curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
            curl_setopt($ch, CURLOPT_USERPWD, env('RAZORPAY_KEY_ID') . ":" . env('RAZORPAY_SECRET_KEY'));
            curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
            $headers = array();
            $headers[] = 'Content-Type: application/json';
            curl_setopt($ch, CURLOPT_HTTPHEADER, $headers);
            $response = curl_exec($ch);
            curl_close($ch);
            paymentLog($url, json_encode($request->all()), $response);
            if (!empty($response)) {
                $paymentResponse = json_decode($response, true);
                if (!empty($paymentResponse['payments'])) {
                    if (!empty($paymentResponse['payments'][0])) {
                        if (!empty($paymentResponse['payments'][0]['payment_id'])) {
                            $result = $this->razorpayFetchPayment($paymentResponse['reference_id'], $paymentResponse['payments'][0]['payment_id'], 'payment_link');
                        }
                    }
                }
            }
        }
        return $result;
    }

    private function makeOrderOnRazorpay($param) {
        $ch = curl_init();
        $fields = array();
        $fields["amount"] = $param['amount'] * 100;
        $fields["currency"] = 'INR';
        $fields["receipt"] = (string) $param['id'];
        $fields["payment"]['capture'] = 'manual';
        $fields["payment"]['capture_options']['manual_expiry_period'] = 12;
        $fields["payment"]['capture_options']['refund_speed'] = 'optimum';
        $url = 'https://api.razorpay.com/v1/orders';

        curl_setopt($ch, CURLOPT_URL, $url);
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
        curl_setopt($ch, CURLOPT_POST, 1);
        curl_setopt($ch, CURLOPT_POSTFIELDS, json_encode($fields));
        curl_setopt($ch, CURLOPT_USERPWD, env('RAZORPAY_KEY_ID') . ":" . env('RAZORPAY_SECRET_KEY'));
        curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
        $headers = array();
        $headers[] = 'Content-Type: application/json';
        curl_setopt($ch, CURLOPT_HTTPHEADER, $headers);
        $data = curl_exec($ch);

        paymentLog($url, json_encode($fields), $data);
        if (empty($data) OR ( curl_getinfo($ch, CURLINFO_HTTP_CODE != 200))) {
            return FALSE;
        } else {
            return json_decode($data, TRUE);
        }
        curl_close($ch);
    }

    public function razorpayRecheck(Request $request) {
        try {
            $input = $request->all();
            $loginID = $request->user()->id;
            if (!isset($input['whatsapp_notification'])) {
                return error('Sorry, Whatsapp notification is empty.');
            }
            if (empty($input['order_id'])) {
                return error('Sorry, Order id is empty.');
            } else {
                $orderData = OrderPayment::where('order_id', $input['order_id'])->first();
                if (empty($orderData)) {
                    return error('Sorry, Razorpay order not found.');
                } else {
                    if ($orderData->status_id == STATUS_FAILED) {
                        return error('Sorry, Payment alredy failed');
                    }
                    if ($orderData->status_id == STATUS_DONE) {
                        return error('Sorry, Payment alredy done');
                    }
                }
            }
            if (empty($input['rzp_response'])) {
                return error(COMMON_ERROR);
            } else {
                OrderPayment::where('order_id', $input['order_id'])->limit(1)->update(array('pg_response' => $input['rzp_response']));
                $paymentResponse = $input['rzp_response'];
                $input['rzp_response'] = json_decode($input['rzp_response'], true);
                if (!empty($input['rzp_response']['error'])) {
                    $input['order_remark'] = $input['rzp_response']['error']['description'];
                    $this->orderFailed($input);
                    return error($input['rzp_response']['error']['description'], ['order_id' => $input['order_id']]);
                }
            }

            if (empty($input['rzp_response']['paymentId'])) {
                $input['order_remark'] = 'RZP payment id is empty.';
                $this->orderFailed($input);
                return error('Sorry, RZP payment id is empty.', ['order_id' => $input['order_id']]);
            } else {
                $rzpPaymentId = $input['rzp_response']['paymentId'];
            }

            if (empty($input['rzp_response']['orderId'])) {
                $input['order_remark'] = 'RZP order id is empty.';
                $this->orderFailed($input);
                return error(COMMON_ERROR, ['order_id' => $input['order_id']]);
            }

            //Compair RZP order_id and system pg_ref_id
            if ($orderData->pg_reference_id != $input['rzp_response']['orderId']) {
                return error('Sorry,System pg_reference_id and razorpay payment order_id are not same.', ['order_id' => $input['order_id']]);
            }

            $amountInPaisa = $orderData->pg_amount * 100;
            $fields['amount'] = (string) $amountInPaisa;
            $fields['currency'] = "INR";
            $ch = curl_init();
            $url = 'https://api.razorpay.com/v1/payments/' . $rzpPaymentId . '/capture';
            curl_setopt($ch, CURLOPT_URL, $url);
            curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
            curl_setopt($ch, CURLOPT_POST, 1);
            curl_setopt($ch, CURLOPT_POSTFIELDS, json_encode($fields));
            curl_setopt($ch, CURLOPT_USERPWD, env('RAZORPAY_KEY_ID') . ":" . env('RAZORPAY_SECRET_KEY'));
            curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
            $headers = array();
            $headers[] = 'Content-Type: application/json';
            curl_setopt($ch, CURLOPT_HTTPHEADER, $headers);
            $data = curl_exec($ch);
            curl_close($ch);

            $fields["receipt"] = $input['order_id'];
            paymentLog($url, json_encode($fields), $data);
            return $this->razorpayFetchPayment($input['order_id'], $rzpPaymentId, 'payment_direct');
        } catch (Exception $exc) {
            errorLog($exc);
        }
        return success(['order_id' => $input['order_id']], COMMON_ERROR);
    }

    public function razorpayFetchPayment($orderId, $rzpPaymentId, $paymentType) {
        try {
            $orderData = OrderPayment::where('order_id', $orderId)->first();
            if (empty($orderData)) {
                return error('Sorry, Razorpay order not found.');
            }
            $amountInPaisa = $orderData->pg_amount * 100;
            $ch = curl_init();
            $url = 'https://api.razorpay.com/v1/payments/' . $rzpPaymentId;
            curl_setopt($ch, CURLOPT_URL, $url);
            curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
            curl_setopt($ch, CURLOPT_USERPWD, env('RAZORPAY_KEY_ID') . ":" . env('RAZORPAY_SECRET_KEY'));
            curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
            $headers = array();
            $headers[] = 'Content-Type: application/json';
            curl_setopt($ch, CURLOPT_HTTPHEADER, $headers);
            $data = curl_exec($ch);
            curl_close($ch);
            $fields["receipt"] = $orderId;
            paymentLog($url, json_encode($fields), $data);
            if (empty($data)) {
                return error('Sorry, No response from razorpay.', ['order_id' => $orderId]);
            } else {
                OrderPayment::where('order_id', $orderId)->limit(1)->update(array('pg_response' => $data));
                $result = json_decode($data, TRUE);

                if ($result['status'] != "captured") {
                    return error('please wait your payment is being processed.', ['order_id' => $orderId]);
                }
                if ($paymentType == 'payment_direct') {
                    if ($orderData->pg_reference_id != $result['order_id']) {
                        return error('please wait your payment is being processed..', ['order_id' => $orderId]);
                    }
                }
                if ($result['amount'] != $amountInPaisa) {
                    return error('please wait your payment is being processed...', ['order_id' => $orderId]);
                }

                /* ........CHECK ANY PROMOCODE APPLY............... */
                $promoCodeResponse = $this->offerRepository->checkPromoCodeApply($orderId, STATUS_DONE);
                if (isset($promoCodeResponse['code']) && $promoCodeResponse['code'] == 0) {
                    $this->promoCodeOrderFailed($orderId, $promoCodeResponse['message']);
//                    $errorMSG = 'sorry your request cannot process due promo code error';
                    $errorMSG = $promoCodeResponse['message'];
                } else {
                    $this->orderSuccess($orderId);
                    $succsessMSG = 'Thank you.';
                }
             
                $this->updateServiceData($orderId);
                /*                 * ******** */
            }
            if (!empty($succsessMSG)) {
                return success(['order_id' => $orderId], $succsessMSG);
            }
            if (!empty($errorMSG)) {
                return error(['order_id' => $orderId], $errorMSG);
            }
        } catch (Exception $exc) {
            errorLog($exc);
        }
        return success(['order_id' => $orderId], COMMON_ERROR);
    }

    public function orderSuccess($orderId) {
        try {
            $order = Orders::where('id', $orderId)->first();
            $order->update(array('status_id' => STATUS_DONE, 'remark' => 'ORDER CONFIRM', 'remark_color_code' => statusWiseColor(STATUS_DONE), 'updated_at' => date('Y-m-d H:i:s')));
            $this->saveOrderHistory(['order_id' => $orderId, 'type' => 'ORDER', 'status_id' => STATUS_DONE, 'remark' => 'ORDER CONFIRM']);

            OrderPayment::where('order_id', $orderId)->limit(1)->update(array('status_id' => STATUS_DONE, 'updated_at' => date('Y-m-d H:i:s')));
            $this->saveOrderHistory(['order_id' => $orderId, 'type' => 'PAYMENT', 'status_id' => STATUS_DONE, 'remark' => 'PAYMENT DONE SUCCESSFULLY']);

            $orderDetail = OrderDetail::where('order_id', $orderId)->get();
            if (!empty($orderDetail)) {
                $data = array('status_id' => STATUS_DONE, 'remark' => 'ORDER CONFIRM', 'remark_color_code' => statusWiseColor(STATUS_DONE), 'updated_at' => date('Y-m-d H:i:s'));
                foreach ($orderDetail as $key => $order) {
                    $order->fill($data)->save();
                    $this->saveOrderHistory(['order_id' => $order->order_id, 'order_detail_id' => $order->id, 'type' => 'ORDER_DETAIL', 'status_id' => STATUS_DONE, 'remark' => 'ORDER CONFIRM']);
                }
            }
            return $order;
        } catch (Exception $exc) {
            errorLog($exc);
        }
    }

    public function orderFailed($input) {
        try {
            Orders::where('id', $input['order_id'])->limit(1)->update(array('status_id' => STATUS_FAILED, 'remark' => 'PAYMENT FAILED', 'remark_color_code' => statusWiseColor(STATUS_FAILED), 'updated_at' => date('Y-m-d H:i:s')));
            $this->saveOrderHistory(['order_id' => $input['order_id'], 'type' => 'ORDER', 'status_id' => STATUS_FAILED, 'remark' => $input['order_remark']]);
            OrderPayment::where('order_id', $input['order_id'])->limit(1)->update(array('status_id' => STATUS_FAILED, 'updated_at' => date('Y-m-d H:i:s')));
            $this->saveOrderHistory(['order_id' => $input['order_id'], 'type' => 'PAYMENT', 'status_id' => STATUS_FAILED, 'remark' => $input['order_remark']]);

            $orderDetail = OrderDetail::where('order_id', $input['order_id'])->get();
            if (!empty($orderDetail)) {
                $data = array('status_id' => STATUS_FAILED, 'remark' => 'PAYMENT FAILED', 'remark_color_code' => statusWiseColor(STATUS_FAILED), 'updated_at' => date('Y-m-d H:i:s'));
                foreach ($orderDetail as $key => $order) {
                    $order->fill($data)->save();
                    $this->saveOrderHistory(['order_id' => $order->order_id, 'order_detail_id' => $order->id, 'type' => 'ORDER_DETAIL', 'status_id' => STATUS_FAILED, 'remark' => 'PAYMENT FAILED']);
                }
            }
            $this->offerRepository->checkPromoCodeApply($input['order_id'], STATUS_FAILED);
            $this->updateServiceData($input['order_id'], 'APPOINTMENT BOOKING FAILED');
        } catch (Exception $exc) {
            errorLog($exc);
        }
    }

    public function promoCodeOrderFailed($orderId, $promoCodeResponseMessage) {
        try {
            Orders::where('id', $orderId)->limit(1)->update(array('status_id' => STATUS_FAILED, 'remark' => 'ORDER FAILED', 'remark_color_code' => statusWiseColor(STATUS_FAILED), 'updated_at' => date('Y-m-d H:i:s')));
            $this->saveOrderHistory(['order_id' => $orderId, 'type' => 'ORDER', 'status_id' => STATUS_FAILED, 'remark' => $promoCodeResponseMessage]);
            OrderPayment::where('order_id', $orderId)->limit(1)->update(array('status_id' => STATUS_DONE, 'updated_at' => date('Y-m-d H:i:s')));
            $this->saveOrderHistory(['order_id' => $orderId, 'type' => 'PAYMENT', 'status_id' => STATUS_DONE, 'remark' => 'PAYMENT DONE SUCCESSFULLY']);

            $orderDetail = OrderDetail::where('order_id', $orderId)->get();
            if (!empty($orderDetail)) {
                $data = array('status_id' => STATUS_FAILED, 'remark' => 'ORDER FAILED', 'remark_color_code' => statusWiseColor(STATUS_FAILED), 'updated_at' => date('Y-m-d H:i:s'));
                foreach ($orderDetail as $key => $order) {
                    $order->fill($data)->save();
                    $this->saveOrderHistory(['order_id' => $order->order_id, 'order_detail_id' => $order->id, 'type' => 'ORDER_DETAIL', 'status_id' => STATUS_FAILED, 'remark' => $promoCodeResponseMessage]);
                }
            }
        } catch (Exception $exc) {
            errorLog($exc);
        }
    }

    public function orderCancel($cancelationData) {
        $remark = "ORDER CANCELLED";
        $orderPayment = OrderPayment::where('order_id', $cancelationData['order_id'])->first();
        if (!empty($orderPayment)) {
            if ($orderPayment->status_id == STATUS_DONE && $orderPayment->payment_mode_id == RAZORPAY && !empty($cancelationData['refundAmount'])) {
                $remark = "ORDER CANCELLED : The refund is credited in your original payment method with in 6-7 days";
                $razorpayRespons = $this->refundRequestToRazorpay($orderPayment, $cancelationData);
                if (!empty($razorpayRespons['error'])) {
                    $statusId = STATUS_REFUNDED_INPROGRESS;
                } else {
                    $statusId = STATUS_FULLY_REFUNDED;
                    $remark = "REFUND SUCCESSFULLY";
                }
                $orderPayment->update(
                        array(
                            //'status_id' => $orderPayment->status_id,
                            'status_id' => $statusId,
                            'updated_at' => date('Y-m-d H:i:s'),
                            'refund_amount' => $orderPayment->refund_amount + $cancelationData['refundAmount'],
                            'cancellation_amount' => $cancelationData['cancelationCharges'],
                            'pg_refund_response' => json_encode($razorpayRespons),
                        )
                );
                $this->saveOrderHistory(
                        [
                            //'status_id' => $orderPayment->status_id,
                            'status_id' => $statusId,
                            'order_id' => $cancelationData['order_id'],
                            'type' => 'PAYMENT',
                            'remark' => 'Reason : ' . $remark,
                            'updated_by' => $cancelationData['login_user_id']
                        ]
                );
            } else {
                $orderPayment->update(
                        array(
                            'status_id' => STATUS_CANCELLED,
                            'updated_at' => date('Y-m-d H:i:s')
                        )
                );
                $this->saveOrderHistory(
                        [
                            'order_id' => $cancelationData['order_id'],
                            'type' => 'PAYMENT',
                            'status_id' => STATUS_CANCELLED,
                            'remark' => 'Reason : ' . $cancelationData['reason'],
                            'updated_by' => $cancelationData['login_user_id']
                        ]
                );
            }
        }

        $orderDetail = OrderDetail::where('order_id', $cancelationData['order_id'])
                        ->where('ref_id', $cancelationData['ref_id'])->get();
        if (!empty($orderDetail)) {
            // $orderDetailStatusId = !empty($statusId) ? $statusId : STATUS_FULLY_CANCELLED;
            $orderDetailStatusId = STATUS_FULLY_CANCELLED;
            $data = array(
                'status_id' => $orderDetailStatusId,
                'remark' => $remark,
                'refund_amount' => !empty($cancelationData['refundAmount']) ? $cancelationData['refundAmount'] : null,
                'cancellation_charge' => !empty($cancelationData['cancelationCharges']) ? $cancelationData['cancelationCharges'] : null,
                'remark_color_code' => statusWiseColor($orderDetailStatusId),
                'updated_at' => date('Y-m-d H:i:s')
            );
            foreach ($orderDetail as $key => $order) {
                $order->fill($data)->save();
                $this->saveOrderHistory(['order_id' => $order->order_id, 'order_detail_id' => $order->id, 'type' => 'ORDER_DETAIL', 'status_id' => $orderDetailStatusId, 'remark' => $remark]);
            }
        }

        // $checkStatus = !empty($statusId) ? STATUS_FULLY_REFUNDED : STATUS_FULLY_CANCELLED;
        // $orderStatus = getOrderStatus($cancelationData['order_id'], $checkStatus);
        $orderStatus = STATUS_FULLY_CANCELLED;
        $orderUpdatedata['status_id'] = $orderStatus;
        $orderUpdatedata['updated_at'] = date('Y-m-d H:i:s');
        if (in_array($orderStatus, [STATUS_FULLY_REFUNDED, STATUS_FULLY_CANCELLED])) {
            $orderUpdatedata['remark'] = $remark;
            $orderUpdatedata['remark_color_code'] = statusWiseColor($orderStatus);
        }
        Orders::where('id', $cancelationData['order_id'])
                ->limit(1)
                ->update($orderUpdatedata);
        $this->saveOrderHistory(
                [
                    'order_id' => $cancelationData['order_id'],
                    'type' => 'ORDER',
                    'status_id' => $orderStatus,
                    'remark' => 'Cancelled : ' . $cancelationData['reason'],
                    'updated_by' => $cancelationData['login_user_id']
                ]
        );
    }

    private function refundRequestToRazorpay($orderPayment, $cancelationData) {
        $amountInPaisa = $cancelationData['refundAmount'] * 100;
        $fields['amount'] = (string) $amountInPaisa;
        $fields['speed'] = "normal";
        $fields['receipt'] = (string) $orderPayment->order_id;
        $razorpayPamentResponse = json_decode($orderPayment->pg_response, true);
        $rzpPaymentId = $razorpayPamentResponse['id'];
        $ch = curl_init();
        $url = 'https://api.razorpay.com/v1/payments/' . $rzpPaymentId . '/refund';
        curl_setopt($ch, CURLOPT_URL, $url);
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
        curl_setopt($ch, CURLOPT_POST, 1);
        curl_setopt($ch, CURLOPT_POSTFIELDS, json_encode($fields));
        curl_setopt($ch, CURLOPT_USERPWD, env('RAZORPAY_KEY_ID') . ":" . env('RAZORPAY_SECRET_KEY'));
        curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
        $headers = array();
        $headers[] = 'Content-Type: application/json';
        curl_setopt($ch, CURLOPT_HTTPHEADER, $headers);
        $data = curl_exec($ch);
        curl_close($ch);
        paymentLog($url, json_encode($fields), $data);
        return json_decode($data, true);
    }

}
