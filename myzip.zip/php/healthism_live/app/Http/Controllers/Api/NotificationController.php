<?php

namespace App\Http\Controllers\API;

use App\Http\Controllers\Controller;
use App\Models\NotificationReadLog;
use App\Models\Notification;
use Illuminate\Http\Request;

class NotificationController extends Controller {

    public function getNotificationCount(Request $request) {
        $input = $request->all();
        if (empty($input['app_id'])) {
            return error("Sorry, App id is empty");
        }
        $query = "SELECT
                    COUNT( n.id ) AS notification_count,
                    COUNT( nrl.notification_id ) AS read_count 
                FROM
                    `notification` AS n
                    LEFT JOIN notification_read_log AS nrl ON nrl.notification_id=n.id
                WHERE n.user_id=" . $request->user()->id . "
                    AND app_id=" . $input['app_id'];
        $result = executeSelectQueryOnMySQLDB($query);
        $response = [];
        if (!empty($result)) {
            $response['unread_count'] = $result[0]['notification_count'] - $result[0]['read_count'];
        }
        return success($response, "Notification Count");
    }

    public function getNotification(Request $request) {
        $input = $request->all();
        if (empty($input['app_id'])) {
            return error("Sorry, App id is empty");
        }
        $limit = 20;
        $page = !empty($request->page) ? $request->page : 1;
        $skip = $page > 1 ? ($page * $limit) - $limit : 0;
        $query = Notification::where('user_id', $request->user()->id);
        $query->where('app_id', $input['app_id']);
        $query->orderBy('id', 'DESC');
        $query->skip($skip)->limit($limit);
        $result = $query->with('readlog')->get();
        return success($result, "Notification list");
    }

    public function notificationRead(Request $request) {
        if (empty($request->notification_id)) {
            return error("Sorry, Notification id is empty");
        }
        $data = ['user_id' => $request->user()->id, 'notification_id' => $request->notification_id];
        $readLog = NotificationReadLog::where($data)->count();
        if (empty($readLog)) {
            $data['read_at'] = date('Y-m-d H:i:s');
            $readLog = NotificationReadLog::create($data);
        }
        return success($readLog, "Notification read successfully");
    }

}
