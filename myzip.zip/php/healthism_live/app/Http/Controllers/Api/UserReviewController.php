<?php

namespace App\Http\Controllers\API;

use App\Http\Resources\UserCollection;
use App\Http\Controllers\Controller;
use App\Models\UserReview;
use Illuminate\Http\Request;

class UserReviewController extends Controller {

    public function addReview(Request $request) {
        $rules = UserReview::$rules;
        if (sizeof($rules) > 0) {
            $validation = $this->validateRequest($request, $rules);
            if (!empty($validation)) {
                return error($validation);
            }
        }
        $input = $request->all();
        $userReview = UserReview::where([
                    'user_id' => $request->user()->id, 'service_id' => $input['service_id'], 'ref_id' => $input['ref_id']
                ])->first();
        if (!empty($userReview)) {
            $userReview->fill($input)->save();
            $result = $userReview;
        } else {
            $input['created_at'] = date('Y-m-d H:i:s');
            $input['user_id'] = $request->user()->id;
            $input['status_id'] = STATUS_APPROVED;
            $result = UserReview::create($input);
        }
        return success($result, "Review has been submitted");
    }

    public function editReview(Request $request) {
        $rules = UserReview::$rules;
        if (sizeof($rules) > 0) {
            $validation = $this->validateRequest($request, $rules);
            if (!empty($validation)) {
                return error($validation);
            }
        }
        $input = $request->all();
        $userReview = UserReview::where([
                    'user_id' => $request->user()->id, 'service_id' => $input['service_id'], 'ref_id' => $input['ref_id']
                ])->first();
        if (empty($userReview)) {
            return error('Sorry, You do not edit other user review');
        }
        $result = $userReview->fill($input)->save();
        return success($userReview, "Review has been saved successfully");
    }

    public function userReviewList(Request $request) {
        if (empty($request->ref_id)) {
            return error('Sorry, Ref id is empty');
        }
        if (empty($request->service_id)) {
            return error('Sorry, Category id is empty');
        }
        return success($this->userReviewData($request, 2), "User review...");
    }

    public function userReviewSummary(Request $request) {
        if (empty($request->ref_id)) {
            return error('Sorry, Ref id is empty');
        }
        if (empty($request->service_id)) {
            return error('Sorry, Service id is empty');
        }
        return success($this->userReviewData($request, 1), "User review summary...");
    }

    private function userReviewData($request, $dataType) {
        if ($dataType == 1) {
            $query = UserReview::where(['ref_id' => $request->ref_id, 'service_id' => $request->service_id, 'status_id' => STATUS_APPROVED]);
            $result['total_votes'] = $query->count();
            $result['rate_avg'] = number_format($query->avg('rating'), 1);
            $query = "SELECT
                            count(*) as count,
                            rating 
                        FROM
                            `review` 
                        WHERE
                            ref_id = " . $request->ref_id . " 
                            AND service_id = " . $request->service_id . " 
                            AND status_id = " . STATUS_APPROVED . " 
                        GROUP BY
                            rating
                        ORDER BY
                            rating DESC";
            $ratingData = executeSelectQueryOnMySQLDB($query);
            for ($i = 1; $i <= 5; $i++) {
                $result['rating_count'][$i] = 0;
                if (!empty($ratingData)) {
                    foreach ($ratingData as $value) {
                        if ($i == $value['rating']) {
                            $result['rating_count'][$i] = $value['count'];
                        }
                    }
                }
            }
        }
        if ($dataType == 2) {
            $page = !empty($request->page) ? $request->page : 1;
            $skip = $page > 1 ? ($page * LIMIT) - LIMIT : 0;
            $result = UserReview::where(['ref_id' => $request->ref_id, 'service_id' => $request->service_id, 'status_id' => STATUS_APPROVED])
                            ->orderBy('id', 'DESC')->with('service', 'user')->skip($skip)->limit(LIMIT)->get();
            if (!empty($result)) {
                foreach ($result as $key => $value) {
                    if ($request->service_id == SERVICE_DOCTOR_APPOINTMENT) {
                        $result[$key]['replied_user'] = \App\Models\Doctor::where('id', $request->ref_id)->first(array('id', 'first_name', 'last_name', 'photo'));
                    }
                    if ($request->service_id == SERVICE_LAB_REPORT) {
                        $lab = \App\Models\Lab::where('id', $request->ref_id)->first();
                        $repliedUser['first_name'] = !empty($lab->user) && $lab->user->first_name ? $lab->user->first_name : 'Healthisam';
                        $repliedUser['last_name'] = !empty($lab->user) && $lab->user->last_name ? $lab->user->last_name : 'Lab';
                        $result[$key]['replied_user'] = $repliedUser;
                    }
                    if ($request->service_id == MENU_BASED_SERVICE) {
                        $mbs = \App\Models\MenuBasedService::where('id', $request->ref_id)->first();
                        $repliedUser['first_name'] = !empty($mbs->user) && $mbs->user->first_name ? $mbs->user->first_name : 'Healthisam';
                        $repliedUser['last_name'] = !empty($mbs->user) && $mbs->user->last_name ? $mbs->user->last_name : 'Service';
                        $result[$key]['replied_user'] = $repliedUser;
                    }
                    if ($request->service_id == SUBSCRIPTION_BASED_SERVICE) {
                        $sbs = \App\Models\SubscriptionBasedService::where('id', $request->ref_id)->first();
                        $repliedUser['first_name'] = !empty($sbs->user) && $sbs->user->first_name ? $sbs->user->first_name : 'Healthisam';
                        $repliedUser['last_name'] = !empty($sbs->user) && $sbs->user->last_name ? $sbs->user->last_name : 'Service';
                        $result[$key]['replied_user'] = $repliedUser;
                    }
                    $timeInterval = timeInterval(dateFormat($value['created_at']));
                    $result[$key]['created_time_interval'] = empty($timeInterval) ? 'Today' : $timeInterval;
                    if (!empty($value['replied_at'])) {
                        $timeInterval = timeInterval($value['replied_at']);
                        $result[$key]['replied_time_interval'] = empty($timeInterval) ? 'Today' : $timeInterval;
                    }
                }
            }
        }
        return $result;
    }

    public function userReviewReply(Request $request) {
        if (empty($request->review_id)) {
            return error('Sorry, Review id is empty');
        }
        if (empty($request->action)) {
            return error('Sorry, Action is empty');
        }
        if ($request->action == 1) {//ADD-EDIT TIME
            if (empty($request->reply)) {
                return error('Sorry, Reply is empty');
            }
        }
        $userReview = UserReview::where(['id' => $request->review_id])->first();
        if (empty($userReview)) {
            return error('Sorry, Review is not found');
        } else {
            if ($userReview->service_id == SERVICE_DOCTOR_APPOINTMENT) {
                //Get doctot user id
                $refData = \App\Models\Doctor::where('id', $userReview->ref_id)->first();
            }
            if ($userReview->service_id == SERVICE_LAB_REPORT) {
                //Get lab user id
                $refData = \App\Models\Lab::where('id', $userReview->ref_id)->first();
            }
            if ($userReview->service_id == MENU_BASED_SERVICE) {
                //Get menu base service user id
                $refData = \App\Models\MenuBasedService::where('id', $userReview->ref_id)->first();
            }
            if ($userReview->service_id == SUBSCRIPTION_BASED_SERVICE) {
                //Get subscription base service user id
                $refData = \App\Models\SubscriptionBasedService::where('id', $userReview->ref_id)->first();
            }
            //Compair doctor id and login user id
            if ($refData->user_id != $request->user()->id) {
                return error('Sorry, Access denied.');
            }
        }
        if ($request->action == 2) {//DELETE TIME
            $input['reply'] = null;
            $input['replied_at'] = null;
        } else {
            $input['reply'] = $request->reply;
            $input['replied_at'] = date('Y-m-d H:i:s');
        }
        $result = $userReview->fill($input)->save();
        return success($userReview, "Reply has been saved successfully");
    }

}
