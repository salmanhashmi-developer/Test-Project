<?php

namespace App\Http\Controllers\API;

use App\Http\Controllers\Controller;
use App\Http\Controllers\Api\OrderPaymentController;
use App\Models\Subscription;
use App\Models\UserSubscription;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use App\Http\Repository\OfferRepository;
use Exception;

class SubscriptionController extends Controller {

    private $orderPaymentController;
    private $offerRepository;

    public function __construct(OrderPaymentController $orderPaymentController, OfferRepository $offerRepository) {
        $this->orderPaymentController = $orderPaymentController;
        $this->offerRepository = $offerRepository;
    }

    public function specialSubscriptionList(Request $request) {
        $specialPlanBenefits = getSpecialPlanBenefits($request->user()->id);
        $data = null;
        if (!empty($specialPlanBenefits)) {
            $data['plan_benefits'] = $specialPlanBenefits;
        }
        $userTypeId = ',3,';
        $userSubscription = UserSubscription::where('user_id', $request->user()->id)
                ->where('status_id', STATUS_ACTIVE)
                ->where('expiry_date', '>', date('Y-m-d'))
                // ->where('user_type_id', 'like', '%' . $userTypeId . '%')
                ->first();
        if (!empty($userSubscription)) {
            return success($data, "Special Subscription plan list");
            // return error("Sorry, You have already active subscription plan");
        }
        $plan = \App\Models\ApplicationConstant::where('id', APP_CONSTANTS_SPECIAL_SUBSCRIPTION_PLAN)->first();
        if (empty($plan) || empty($plan->value)) {
            // return error("Sorry, Special plan offer not activated now.");
            return success($data, "Special Subscription plan list");
        }
        $planIds = explode(',', $plan->value);
        $query = Subscription::where('status_id', STATUS_ACTIVE)->whereIn('id', $planIds)->where('user_type_id', 'like', '%' . $userTypeId . '%');
        $result = $query->orderBy('display_index', 'ASC')->get();

        if (!empty($result)) {
            $subscriptionList = [];
            foreach ($result as $key => $value) {
                $subscriptionList[$key]['plan'] = $value;
                $subscriptionList[$key]['plan']['terms'] = json_decode($value['terms']);
                if ($value->id == 8) {
                    $subscriptionList[$key]['main_image'] = getUrl('image/plan/') . 'special-plan-1-main.png';
                    $subscriptionList[$key]['sub_image'][] = getUrl('image/plan/') . 'special-plan-1-sub-1.png';
                    $subscriptionList[$key]['sub_image'][] = getUrl('image/plan/') . 'special-plan-1-sub-2.png';
                    $subscriptionList[$key]['sub_image'][] = getUrl('image/plan/') . 'special-plan-1-sub-3.png';
                }
            }
        }
        if (empty($subscriptionList)) {
            return success($data, "Special Subscription plan list");
            //  return error("Sorry, Special plan offer not activated now.");
        } else {
            $data['plan_list'] = $subscriptionList;
        }

        return success($data, "Special Subscription plan list");
    }

    public function subscriptionDetail(Request $request) {
        $result = Subscription::where('id', $request->id)->where('status_id', STATUS_ACTIVE)->first();
        if(!empty($result)){
            $result['terms'] = json_decode($result['terms']);
        }
        return success($result, "Subscription plan detail");
    }

    public function subscriptionList(Request $request) {
        $userSubscription = UserSubscription::where('user_id', $request->user()->id)
                ->where('status_id', STATUS_ACTIVE)
                ->where('expiry_date', '>', date('Y-m-d'))
                ->with('subscription')
                ->first();
        $query = Subscription::where('status_id', STATUS_ACTIVE);
        if (!empty($userSubscription->subscription->price)) {
            $query->where('price', '>', $userSubscription->subscription->price);
        }
//        if (!empty($userSubscription->subscription->member)) {
//            $query->where('member', '>', $userSubscription->subscription->member);
//        }
        $userTypeId = ',3,';
        $query->where('user_type_id', 'like', '%' . $userTypeId . '%');
        $result = $query->orderBy('display_index', 'ASC')->get();
        if (!empty($result)) {
            foreach ($result as $key => $value) {
                $result[$key]['terms'] = json_decode($value['terms']);
            }
        }
        return success($result, "Subscription plan list");
    }

    public function userSubscription(Request $request) {
        $result = getUserSubscription($request->user()->id);
        return success($result, "Subscription plan list");
    }

    public function userSubscriptionV2(Request $request) {
        if (!empty($request->service_id)) {
            if (in_array($request->service_id, [])) {
                return success(['subscription_required' => 0], "API Call successfully");
            }
        }
        $result = getUserSubscription($request->user()->id);
        $response['subscription_required'] = 1;
        $response['title'] = "We are glad to assist you in your booking.";
        $response['sub_title'] = "Choose the Subscription Plan best suited for your well being needs and we will ensure that you get the best services.";
        if (empty($result)) {
            return success($response, "API Call successfully");
        } else {
            if (!empty($result['expire']) && $result['expire'] == 1) {
                return success($response, "API Call successfully");
            }
        }
        $response['subscription_required'] = 0;
        return success($response, "API Call successfully");
    }

    public function paymentPage(Request $request) {
        $input = $request->all();
        if (empty($input['plan_id'])) {
            return error('Sorry, Plan id is empty');
        }
        $validation = checkSpecialPlan($request->user()->id);
        if ($validation == 0) {
            return error('You are not allowed to upgrade subscription plan.');
        }
        $planData = Subscription::where('id', $input['plan_id'])
                ->where('status_id', STATUS_ACTIVE)
                ->first();
        if (empty($planData)) {
            return error('Sorry, Plan data not found');
        }
        $orderRefId = KEY_ORDER_REF_ID . "_" . $request->user()->id . '_' . time();
        setRedisData($orderRefId, 0);
        $result['order_ref_id'] = $orderRefId;
        $grandTotal = $planData['price'];
        $result['calculation']['charges'] = [
            array('title' => 'Amount', 'symbol' => '', 'value' => numberFormat($planData['price'])),
        ];
        if (!empty($input['promo_code'])) {
            $promoCodeData = $this->offerRepository->applyOfferCode($input['promo_code'], SERVICE_SUBSCRIPTION_PLAN, $request->user()->id, $grandTotal);
            if ($promoCodeData['code'] == 0) {
                $result['promo_code_error'] = $promoCodeData['message'];
            } else {
                $result['calculation']['charges'][] = ['title' => 'Coupon Discount', 'value' => numberFormat($promoCodeData['promo_code_discount']), 'symbol' => '-', 'color' => '#209f7b'];
                $grandTotal = $grandTotal - $promoCodeData['promo_code_discount'];
                $result['promo_code_success'] = "You saved additional RS." . $promoCodeData['promo_code_discount'];
            }
        }
        $result['calculation']['total'] = array('title' => 'Paid Amount', 'symbol' => '', 'value' => numberFormat($grandTotal));
        if ($grandTotal <= 0) {
            $result['payment_mode'][] = ['id' => COUPON, 'name' => 'Coupon', 'icon' => '1.jpg'];
        } else {
            $result['payment_mode'] = getPaymentMode(SERVICE_SUBSCRIPTION_PLAN);
        }
        return success($result, "Subscription plan list");
    }

    public function orderPayment(Request $request) {
        try {
            $input = $request->all();
            if (empty($input['order_ref_id'])) {
                return error('Sorry, Order ref id is empty');
            } else {
//                $orderId = getDataFromRedisKey($input['order_ref_id']);
//                if (!empty($orderId)) {
//                    return error(COMMON_ERROR, ['order_id' => $orderId, 'message' => 'Order already processed']);
//                }
            }
            if (empty($input['plan_id'])) {
                return error('Sorry, Plan id is empty');
            }
            if (empty($input['payment_mode_id'])) {
                return error('Sorry, Payment mode id is empty.');
            }
            if (empty($input['platform_id'])) {
                return error("Sorry, Platform id is empty.");
            }
            $planData = Subscription::where('id', $input['plan_id'])
                    ->where('status_id', STATUS_ACTIVE)
                    ->first();

            if (empty($planData)) {
                return error('Sorry, Plan data not found');
            }
            $input['login_user_id'] = $request->user()->id;
            $input['login_user_email'] = $request->user()->email;
            $input['login_user_mobile'] = $request->user()->mobile;
            $input['ip'] = $request->ip();
            $tax = $planData['price'] - (($planData['price'] * 100) / (100 + SERVICE_SUBSCRIPTION_PLAN_TAX));
            $input['tax'] = round($tax, 2);
            $input['amount'] = $planData['price'];
            $input['grand_total'] = $planData['price'];
            if (!empty($input['promo_code'])) {
                $promoCodeData = $this->offerRepository->applyOfferCode($input['promo_code'], SERVICE_SUBSCRIPTION_PLAN, $input['login_user_id'], $input['grand_total']);
                if ($promoCodeData['code'] == 0) {
                    return error($promoCodeData['message']);
                } else {
                    $input['promo_code_discount'] = !empty($promoCodeData['promo_code_discount']) ? $promoCodeData['promo_code_discount'] : null;
                    $input['promo_code_id'] = !empty($promoCodeData['promo_code_data']['id']) ? $promoCodeData['promo_code_id']['id'] : null;
                    $input['grand_total'] = $input['grand_total'] - $input['promo_code_discount'];
                }
            }
            if ($input['grand_total'] > 0 && $input['payment_mode_id'] == COUPON) {
                return error("Sorry, Invalid payment mode");
            }
            if ($input['grand_total'] <= 0) {
                $paymentMode = ['id' => COUPON, 'name' => 'Coupon', 'icon' => '1.jpg'];
            } else {
                $paymentMode = paymentMethodValidation($input['payment_mode_id']);
                if ($paymentMode['data'] == 0) {
                    return error($paymentMode['message']);
                }
                $paymentMode = $paymentMode['data'];
            }

            try {
                /* ------------------------------------------
                  --------------------------------------------
                  Start DB Transaction
                  --------------------------------------------
                  -------------------------------------------- */
                DB::beginTransaction();
                $insertedData = array(
                    'subscription_id' => $planData['id'],
                    'user_id' => $request->user()->id,
                    'card_no' => getCardRandNumber($planData['card_prefix']),
                    'created_at' => date('Y-m-d H:i:s'),
                    'expiry_date' => date('Y-m-d', strtotime("+" . $planData['validity_in_days'] . " day")),
                    'status_id' => STATUS_PENDING,
                    'amount' => $input['amount'],
                    'tax' => $input['tax'],
                    'created_by' => $request->user()->id,
                );
                $userSubscriptionData = UserSubscription::create($insertedData);

                if (empty($userSubscriptionData->id)) {
                    return error("Sorry, Something went wrong.");
                }
                $userSubscriptionData->validity_in_days = $planData['validity_in_days'];
                $userSubscriptionData->name = $planData['name'];
                $userSubscriptionData->member = $planData['member'];
                $result = $this->createOrder($userSubscriptionData, $paymentMode, $input);
            } catch (Exception $exc) {
                /* ------------------------------------------
                  --------------------------------------------
                  Rollback Database Entry
                  --------------------------------------------
                  -------------------------------------------- */
                errorLog($exc);
                DB::rollback();
            }
//            if (!empty($result)) {
//                return success($result, "Thank you");
//            } else {
//                return error(COMMON_ERROR);
//            }
            if (!empty($result)) {
                if (empty($result['error'])) {
                    return success($result, "Thank you");
                } else {
                    return error(COMMON_ERROR, ['order_id' => $result['order_id'], 'message' => $result['error_message']]);
                }
            } else {
                return error(COMMON_ERROR);
            }
        } catch (Exception $exc) {
            errorLog($exc);
        }
        return error(COMMON_ERROR);
    }

    private function createOrder($userSubscriptionData, $paymentMode, $input) {
        try {
            $ds1 = 'Buy Subscription Plan';
            $ds2 = $userSubscriptionData->name;
            $ds3 = 'Expire after ' . $userSubscriptionData->validity_in_days . ' days';
            $descripationArr = ["desc1" => $ds1, "desc2" => $ds2, "desc3" => $ds3];
            $transactionArr = [
                'name' => $userSubscriptionData->name,
                'member' => $userSubscriptionData->member,
                'validity_in_days' => $userSubscriptionData->validity_in_days,
                'expiry_date' => $userSubscriptionData->expiry_date,
                'card_no' => $userSubscriptionData->card_no,
            ];
            $statusId = STATUS_SENT_ON_PG;
            $status = 'SENT ON PG';
            $remark = "PAYMENT PENDING";
            $color = statusWiseColor(STATUS_SENT_ON_PG);

            /* ........... CRETAE NEW ORDER............ */
            $orderArr = [
                'order_code' => 'SP' . platformCode($input['platform_id']) . $input['login_user_id'] . time(),
                'user_id' => $input['login_user_id'],
                'service_id' => SERVICE_SUBSCRIPTION_PLAN,
                'amount' => $input['amount'],
                'status_id' => $statusId,
                'remark' => $remark,
                'remark_color_code' => $color,
                'description_json' => json_encode($descripationArr),
                'transaction_json' => json_encode($transactionArr),
            ];
            $order = $this->orderPaymentController->createOrder($orderArr);
            if (!empty($order->id)) {
                setRedisData($input['order_ref_id'], $order->id);

                /* ................OFFER CODE.............. */
                if (!empty($input['promo_code'])) {
                    setRedisData(KEY_PROMO_CODE_ORDER . "_" . $order->id, [
                        'order_id' => $order['id'],
                        'order_code' => $order['order_code'],
                        'service_id' => SERVICE_SUBSCRIPTION_PLAN,
                        'order_sub_total' => $input['amount'],
                        'promo_code_discount' => $input['promo_code_discount'],
                        'promo_code' => $input['promo_code'],
                        'promo_code_id' => $input['promo_code_id'],
                        'user_id' => $input['login_user_id'],
                            ]
                    );
                }

                $userSubscriptionDataUpdate = UserSubscription::findOrFail($userSubscriptionData->id);
                $userSubscriptionDataUpdate->fill(['order_id' => $order->id])->save();

                /* ........... CRETAE NEW ORDER HISTORY............ */
                $orderHistoryArr = [
                    'order_id' => $order->id,
                    'type' => 'ORDER',
                    'status_id' => $statusId,
                    'remark' => $remark,
                    'updated_by' => $input['login_user_id']
                ];
                $this->orderPaymentController->saveOrderHistory($orderHistoryArr);

                /* ........... CRETAE NEW ORDER DETAIL............ */
                $orderDeatilArr = [
                    'order_id' => $order->id,
                    'service_id' => SERVICE_SUBSCRIPTION_PLAN,
                    'ref_id' => $userSubscriptionData->id,
                    'coupon_id' => null,
                    'coupon_amount' => !empty($input['promo_code_discount']) ? $input['promo_code_discount'] : null,
                    'wallet_amount' => null,
                    'pg_amount' => $input['grand_total'],
                    'paid_amount' => $input['amount'],
                    'tax' => $input['tax'],
                    'charges' => null,
                    'status_id' => $statusId,
                    'remark' => $remark,
                    'remark_color_code' => $color,
                ];
                $orderDeatil = $this->orderPaymentController->saveOrderDetail($orderDeatilArr);

                /* ........... CRETAE NEW ORDER DETAIL HISTORY............ */
                $orderDeatilHistoryArr = [
                    'order_id' => $order->id,
                    'order_detail_id' => $orderDeatil->id,
                    'type' => 'ORDER_DETAIL',
                    'status_id' => STATUS_PENDING,
                    'remark' => $remark,
                    'updated_by' => $input['login_user_id']
                ];
                $this->orderPaymentController->saveOrderHistory($orderDeatilHistoryArr);

                /* ........... CRETAE NEW ORDER PAYMENT............ */
                $orderPaymentArr = [
                    'order_id' => $order->id,
                    'user_id' => $input['login_user_id'],
                    'payment_mode_id' => $paymentMode['id'],
                    'pg_amount' => $input['grand_total'],
                    'status_id' => STATUS_PENDING,
                    'ip_address' => $input['ip'],
                ];
                $orderPayment = $this->orderPaymentController->saveOrderPayment($orderPaymentArr);

                /* ........... CRETAE NEW ORDER PAYMENT HISTORY............ */
                $paymentHistoryArr = [
                    'order_id' => $order->id,
                    'type' => 'PAYMENT',
                    'status_id' => STATUS_PENDING,
                    'remark' => 'PAYMENT PENDING',
                    'updated_by' => $input['login_user_id']
                ];
                $this->orderPaymentController->saveOrderHistory($paymentHistoryArr);
            }
            /* ------------------------------------------
              --------------------------------------------
              Commit Transaction to Save Data to Database
              --------------------------------------------
              -------------------------------------------- */
            DB::commit();

            $order['description'] = 'Buy Subscription Plan';
            $order['mobile'] = $input['login_user_mobile'];
            $order['email'] = $input['login_user_email'];
            $order['payment_mode_id'] = $paymentMode['id'];
            $order['amount'] = $input['grand_total'];
            $order['platform_id'] = $input['platform_id']; //For identify APP/WEB
            $order['promo_code_discount'] = !empty($input['promo_code_discount']) ? $input['promo_code_discount'] : 0;
            $result = $this->orderPaymentController->makePayment($order);
            return $result;
        } catch (Exception $exc) {
            /* ------------------------------------------
              --------------------------------------------
              Rollback Database Entry
              --------------------------------------------
              -------------------------------------------- */
            DB::rollback();
            setRedisData($input['order_ref_id'], 0);
            errorLog($exc);
        }
        return 0;
    }

}
