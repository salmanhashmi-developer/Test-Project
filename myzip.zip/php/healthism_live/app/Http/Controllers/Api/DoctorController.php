<?php

namespace App\Http\Controllers\API;

use App\Http\Resources\DoctorCollection;
use App\Http\Controllers\Controller;
use App\Models\Doctor;
use App\Models\DoctorDetails;
use Illuminate\Http\Request;

class DoctorController extends Controller {

    public function doctorCategory(Request $request) {
        $result = \App\Models\Category::where('parent_id', 3)->orderBy('name', 'ASC')->get();
        return success($result, "Doctor category list.");
    }

    public function councilList(Request $request) {
        $result = array('Andhra Pradesh Medical Council', 'Arunachal Pradesh Medical Council', 'Assam Medical Council', 'Bhopal Medical Council', 'Bihar Medical Council', 'Bombay Medical Council', 'Chandigarh Medical Council', 'Chhattisgarh Medical Council', 'Delhi Medical Council', 'Goa Medical Council', 'Gujarat Medical Council', 'Haryana Medical Council', 'Himachal Pradesh Medical Council', 'Hyderabad Medical Council', 'Jharkhand Medical Council', 'Karnataka Medical Council', 'Madhya Pradesh Medical Council', 'Madras Medical Council', 'Mahakoshal Medical Council', 'Maharashtra Medical Council', 'Medical Council of India', 'Medical Council of Tanganyika', 'Mizoram Medical Council', 'Mysore Medical Council', 'Nagaland Medical Council', 'Orissa Council of Medical Registration', 'Pondicherry Medical Council', 'Punjab Medical Council', 'Rajasthan Medical Council', 'Sikkim Medical Council', 'Tamil Nadu Medical Council', 'Telangana Medical Council', 'Uttar Pradesh Medical Council', 'Uttarakhand Medical Council', 'Vidharba Medical Council', 'West Bengal Medical Council');
        return success($result, "Council list.");
    }

    public function doctorDetailAddEdit(Request $request) {
        if (empty($request->step)) {
            return error('Sorry, Step is empty.');
        }
        if ($request->user()->user_type_id != DOCTOR) {
            return error('Sorry, Only for doctor.');
        }
        $result = [];
        $input = $request->all();
        if (!empty($input['doctor_id'])) {
            $doctorId = $input['doctor_id'];
            $doctorDetail = DoctorDetails::where('doctor_id', $input['doctor_id'])->first();
        }
        if ($request->step == 1) {
            $rules = Doctor::$rules;
            if (sizeof($rules) > 0) {
                $validation = $this->validateRequest($request, $rules);
                if (!empty($validation)) {
                    return error($validation);
                }
            }
            $input['user_id'] = $request->user()->id;
            $input['status_id'] = STATUS_ACTIVE;
            $input['first_name'] = ucwords($input['first_name']);
            $input['last_name'] = ucwords($input['last_name']);
            $input['middle_name'] = ucwords($input['middle_name']);
            if (empty($input['doctor_id'])) {
                $input['created_at'] = date('Y-m-d H:i:s');
                $result = Doctor::create($input);
                $doctorId = $result->id;
            } else {
                $result = Doctor::findOrFail($input['doctor_id']);
                $result->fill($input)->save();
            }
        }
        if ($request->step == 2) {
            if (empty($input['doctor_id'])) {
                return error('Sorry, Doctor id is empty.');
            }
            if (empty($input['registration_number'])) {
                return error('Sorry, Registration number id is empty.');
            }
            if (empty($input['registration_council'])) {
                return error('Sorry, Registration council id is empty.');
            }
            if (empty($input['registration_date'])) {
                return error('Sorry, Registration date is empty.');
            }
            if (empty($input['registration_proof'])) {
                return error('Sorry, Registration proof is empty.');
            }
            if (empty($input['experience'])) {
                return error('Sorry, Experience is empty.');
            } else {
                $doctor = Doctor::findOrFail($input['doctor_id']);
                $doctor->fill(array('experience' => $input['experience']))->save();
            }
            if (!empty($_FILES["registration_proof"]["size"])) {
                $fileDetails = pathinfo($_FILES["registration_proof"]["name"]);
                $input['registration_proof'] = time() . '.' . $fileDetails['extension'];
                uploadFile($_FILES['registration_proof']['tmp_name'], 'doctordocument/registrationproof/' . $input['registration_proof']);
            }
            if (!empty($doctorDetail)) {
                if ($doctorDetail->registration_proof) {
                    deleteFile('doctordocument/registrationproof/' . $doctorDetail->registration_proof);
                }
                unset($input['step']);
                unset($input['experience']);
                DoctorDetails::where(['doctor_id' => $input['doctor_id']])->update($input);
            } else {
                $doctorDetail = DoctorDetails::create($input);
            }
        }
        if ($request->step == 3) {
            if (empty($input['last_degree_obtained'])) {
                return error('Sorry, Last degree obtained is empty.');
            }
            if (empty($input['date_of_completion'])) {
                return error('Sorry, Date of completion is empty.');
            }
            if (empty($input['college_institute_name'])) {
                return error('Sorry, College institute name is empty.');
            }
            if (empty($input['qualification_certificates'])) {
                return error('Sorry, Qualification certificates is empty.');
            }
            if (!empty($_FILES["qualification_certificates"]["size"])) {
                $fileDetails = pathinfo($_FILES["qualification_certificates"]["name"]);
                $input['qualification_certificates'] = time() . '.' . $fileDetails['extension'];
                uploadFile($_FILES['qualification_certificates']['tmp_name'], 'doctordocument/degree/' . $input['qualification_certificates']);
            }
            if ($doctorDetail->qualification_certificates) {
                deleteFile('doctordocument/degree/' . $doctorDetail->qualification_certificates);
            }
            unset($input['step']);
            DoctorDetails::where(['doctor_id' => $input['doctor_id']])->update($input);
        }
        if ($request->step == 4) {
            if (empty($input['aadhar_card_no'])) {
                return error('Sorry, Aadhar card no is empty.');
            }
            if (empty($input['aadhar_card_document'])) {
                return error('Sorry, Aadhar card document is empty.');
            }
            if (empty($input['pan_card_no'])) {
                return error('Sorry, Pan card no is empty.');
            }
            if (empty($input['pan_card_document'])) {
                return error('Sorry, Pan card document is empty.');
            }
            if (!empty($_FILES["aadhar_card_document"]["size"])) {
                $fileDetails = pathinfo($_FILES["aadhar_card_document"]["name"]);
                $input['aadhar_card_document'] = time() . '.' . $fileDetails['extension'];
                uploadFile($_FILES['aadhar_card_document']['tmp_name'], 'doctordocument/aadhar/' . $input['aadhar_card_document']);
            }
            if ($doctorDetail->aadhar_card_document) {
                deleteFile('doctordocument/aadhar/' . $doctorDetail->aadhar_card_document);
            }
            if (!empty($_FILES["pan_card_document"]["size"])) {
                $fileDetails = pathinfo($_FILES["pan_card_document"]["name"]);
                $input['pan_card_document'] = time() . '.' . $fileDetails['extension'];
                uploadFile($_FILES['pan_card_document']['tmp_name'], 'doctordocument/pan/' . $input['pan_card_document']);
            }
            if ($doctorDetail->pan_card_document) {
                deleteFile('doctordocument/pan/' . $doctorDetail->pan_card_document);
            }
            unset($input['step']);
            DoctorDetails::where(['doctor_id' => $input['doctor_id']])->update($input);
        }
        $result['doctor_id'] = $doctorId;
        return success($result, "Docter data has been saved successfully");
    }

    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index(Request $request) {
        $doctor = Doctor::where('status_id', 1);
        if ($request->first_name != null) {
            $doctor = $doctor
                    ->where('first_name', 'like', '%' . $request->first_name . '%');
        }
        if ($request->last_name != null) {
            $doctor = $doctor
                    ->where('last_name', 'like', '%' . $request->last_name . '%');
        }
        return new DoctorCollection($doctor->paginate(20));
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request) {
        //
    }

    /**
     * Display the specified resource.
     *
     * @param  \App\Models\Doctor  $doctor
     * @return \Illuminate\Http\Response
     */
    public function show(Doctor $doctor) {
        //
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  \App\Models\Doctor  $doctor
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, Doctor $doctor) {
        //
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  \App\Models\Doctor  $doctor
     * @return \Illuminate\Http\Response
     */
    public function destroy(Doctor $doctor) {
        //
    }

    public function doctorTypeList() {
        $result['type'] = array('Orthopaedics', 'Dietician', 'Gynaecologist', 'Pulmonologist', 'ENT', 'General Physician', 'Ophthalmologist', 'Oncologist', 'Dermatologist', 'Pediatrician', 'Dentist', 'Neurologist', 'Urologist', 'Physiotherapist', 'Cardiologist', 'Psychiatrist', 'Radiologist', 'Anesthisia', 'Internal Medicine', 'Sexologist', 'Gastroenterologist', 'Ayurveda', 'Homeopathy');
        $result['image_url'] = getUrl('image/doctore_type/');
        return success($result, "Doctor type list.");
    }

    public function doctoteListFilter() {
        $result[] = array(
            'title' => 'Now or later',
            'key' => 'available',
            'type' => 'RADIO',
            'values' => array(
                array("value" => '1', "label" => 'Any Time'),
                array("value" => '2', "label" => 'Next 2 Hours'),
                array("value" => '3', "label" => 'Today'),
                array("value" => '4', "label" => 'Tommorow')
            )
        );
        $result[] = array(
            'title' => 'Gender',
            'key' => 'gender',
            'type' => 'CHECKBOX',
            'values' => array(
                array("value" => 'Male', "label" => 'Male'),
                array("value" => 'Female', "label" => 'Female'),
            )
        );
        $result[] = array(
            'title' => 'Years of experience',
            'key' => 'experience',
            'type' => 'RANGE',
            'min' => 1,
            'max' => 50
        );
        $result[] = array(
            'title' => 'Consultant fees',
            'key' => 'fees',
            'type' => 'RANGE',
            'min' => 200,
            'max' => 10000
        );
        $result[] = array(
            'title' => 'Only Video Consultation Available',
            'key' => 'video_consultation_available',
            'type' => 'CHECKBOX',
            'values' => array(
                array("value" => "1", "label" => 'Yes')
            )
        );
        return success($result, "Doctor filter list");
    }

    public function doctorList(Request $request) {
        $latitude = $request->header('latitudeUserLocation');
        $longitude = $request->header('longitudeUserLocation');
        $pincode = $request->header('postalCodeUserLocation');

        if (empty($request->sub_category_id)) {
            return error("Sorry, Sub category id is empty.");
        }
        if ($request->user()->id == 74) {
            $latitude = '18.969538920783755';
            $longitude = '72.81932909041643';
            $pincode = '400008';
        } else {
            if (empty($latitude) || empty($longitude)) {
                return error("Sorry, Latitude/Longitude is empty.");
            }
        }
        $query = "SELECT
                    h.id AS hospital_id,
                    h.`name` AS hospital_name,
                    h.type AS hospital_type,
                    h.area AS hospital_area,
                    d.id AS doctor_id,
                    d.gender,
                    (select COUNT(*) FROM review WHERE ref_id=d.id AND service_id=" . SERVICE_DOCTOR_APPOINTMENT . " AND status_id=" . STATUS_APPROVED . ") AS doctor_reviwe_count,
                    ROUND((select AVG(rating) FROM review WHERE ref_id=d.id AND service_id=" . SERVICE_DOCTOR_APPOINTMENT . " AND status_id=" . STATUS_APPROVED . "),1) AS doctor_rating,
                    CONCAT( d.first_name, ' ', d.last_name ) AS doctor_name,
                    haversine ( '" . $latitude . "', '" . $longitude . "', h.latitude, h.longitude ) AS 'distance',
                    d.photo,
                    d.specialization,
                    CONCAT(d.experience, ' ', 'years experience overall') AS doctor_experience,
                    dhm.fees,
                    dhm.discount,
                    dhm.video_consultation_available,
                    dhm.id AS doctor_hospital_mapping_id 
                FROM
                    `hospital` AS h
                    JOIN doctor_hospital_mapping AS dhm ON dhm.hospital_id = h.id
                    JOIN doctor AS d ON d.id = dhm.doctor_id 
                WHERE
                    h.status_id = " . STATUS_ACTIVE;
//        if (!empty($request->city_id)) {
//            $query .= " AND h.city_id = " . $request->city_id;
//        }
        $query .= " AND (";
        if (!empty($pincode)) {
            $query .= "h.pincode = '" . $pincode . "' OR ";
        }
        $query .= "haversine ( '" . $latitude . "', '" . $longitude . "', h.latitude, h.longitude ) < " . HOSPITAL_DISTANCE . " )";
        $query .= " AND d.sub_category_id LIKE '%" . $request->sub_category_id . "%' ";
        if (!empty($request->search_hint)) {
            $query .= " AND ( d.first_name LIKE '%" . $request->search_hint . "%' "
                    . "OR d.last_name LIKE '%" . $request->search_hint . "%'"
                    . "OR h.area LIKE '%" . $request->search_hint . "%'"
                    . "OR h.`name` LIKE '%" . $request->search_hint . "%'"
                    . ")";
        } else {
            if (!empty($request->gender)) {
                $genderArr = explode(',', $request->gender);
                if (!empty($genderArr)) {
                    $genderStr = '';
                    foreach ($genderArr as $key => $value) {
                        if (!empty($value)) {
                            $genderStr .= "'" . $value . "',";
                        }
                    }
                    if (!empty($genderStr)) {
                        $genderStr = substr_replace($genderStr, "", -1);
                        $query .= " AND d.gender IN (" . $genderStr . ")";
                    }
                }
            }
            if (!empty($request->experience)) {
                $query .= " AND d.experience >=" . $request->experience;
            }
            $query .= " AND d.status_id = " . STATUS_ACTIVE;
            if (!empty($request->fees)) {
                $query .= " AND dhm.fees <=" . $request->fees;
            }
            if (!empty($request->video_consultation_available)) {
                $query .= " AND video_consultation_available = 1";
            }
        }
        $query .= " ORDER BY distance";
        $request->page = !empty($request->page) ? $request->page : 1;
        $skip = $request->page > 1 ? ($request->page * LIMIT) - LIMIT : 0;
        $query .= ' LIMIT ' . LIMIT . ' OFFSET ' . $skip;
        $result['doctor_list'] = executeSelectQueryOnMySQLDB($query);
        $result['image_url'] = getUrl('image/doctor_profile');
        return success($result, "Doctor list.");
    }

    public function doctorHospitalSlotList(Request $request) {
        if (empty($request->doctor_id)) {
            return error("Sorry, Doctor id is empty.");
        }
        if (empty($request->hospital_id)) {
            return error("Sorry, Hospital id is empty.");
        }
        $result = [];
        $hospitalMapping = \App\Models\DoctorHospitalMapping::where(['doctor_id' => $request->doctor_id, 'hospital_id' => $request->hospital_id])->with('hospital')->first();
        if (!empty($hospitalMapping)) {
            if (!empty($hospitalMapping->hospital->cancel_policy)) {
                $result['hospital_cancel_policy'] = json_decode($hospitalMapping->hospital->cancel_policy);
            } else {
                $result['hospital_cancel_policy'] = HOSPITAL_CANCEL_POLICY;
            }
            if ($hospitalMapping->hospital->status_id == STATUS_ACTIVE) {
                if ($hospitalMapping->slot_type == "Day") {
                    $result['slot_list'] = $this->getDoctorSlotByDay($request->doctor_id, $request->hospital_id);
                }
                if ($hospitalMapping->slot_type == "Date") {
                    $result['slot_list'] = $this->getDoctorSlotDate($request->doctor_id, $request->hospital_id);
                }
            }
        }
        return success($result, "Doctor slot list...");
    }

    public function doctorDetail(Request $request) {
        $result = null;
        //For customer app
        if (empty($request->doctor_id)) {
            return error("Sorry, Doctor id is empty.");
        }
        if (empty($request->doctor_hospital_mapping_id)) {
            return error("Sorry, Doctor hospital mapping id is empty.");
        }
        $doctorData = Doctor::where('id', $request->doctor_id)->with('doctor_details')->first();
        if (!empty($doctorData)) {
            if ($doctorData->status_id != STATUS_ACTIVE) {
                return error("Sorry, Doctor has been blocked.");
            }
            $doctorData->experience = $doctorData->experience . ' years experience overall';
            $doctorData->image_url = getUrl('image/doctor_profile');
            $result['doctor_detail'] = $doctorData;
            if (!empty($doctorData->doctor_details)) {
                $doctoreDetail = $doctorData->doctor_details;
                $result['doctor_detail']['doctor_details']['service_json'] = json_decode($doctoreDetail->service_json);
                $result['doctor_detail']['doctor_details']['specialization_json'] = json_decode($doctoreDetail->specialization_json);
                $result['doctor_detail']['doctor_details']['education_json'] = json_decode($doctoreDetail->education_json);
                $result['doctor_detail']['doctor_details']['membership_json'] = json_decode($doctoreDetail->membership_json);
                $result['doctor_detail']['doctor_details']['experience_json'] = json_decode($doctoreDetail->experience_json);
                $result['doctor_detail']['doctor_details']['registration_json'] = json_decode($doctoreDetail->registration_json);
            }
            if (!empty($request->doctor_hospital_mapping_id)) {
                $hospitalMapping = \App\Models\DoctorHospitalMapping::where('doctor_id', $request->doctor_id)->with('hospital')->get();
                if (!empty($hospitalMapping)) {
                    $result['hospital_image_url']['image_url'] = getUrl('image/hospital');
                    foreach ($hospitalMapping as $key => $value) {
                        if (!empty($value->hospital)) {
                            if ($value->hospital->status_id == STATUS_ACTIVE) {
                                $value['cancel_policy'] = json_decode($value->cancel_policy);
                                $value['cancel_policy_setting'] = json_decode($value->cancel_policy_setting);
                                $result['hospital_list'][] = $value->hospital;
                                if ($value['id'] == $request->doctor_hospital_mapping_id) {
                                    if ($value['slot_type'] == "Day") {
                                        $result['slot_list'] = $this->getDoctorSlotByDay($value['doctor_id'], $value['hospital_id']);
                                    }
                                    if ($value['slot_type'] == "Date") {
                                        $result['slot_list'] = $this->getDoctorSlotDate($value['doctor_id'], $value['hospital_id']);
                                    }
                                }
                            }
                        }
                    }
                }
                $result['cancellation_note'] = "Free cancellation before 3 hours";
            }
        }
        return success($result, "Doctor detail...");
    }

    public function doctorUserDetail(Request $request) {
        $result = null;
        $doctorData = Doctor::where('user_id', $request->user()->id)->with('doctor_details')->first();

        if (!empty($doctorData)) {
            if ($doctorData->status_id != STATUS_ACTIVE) {
                return error("Sorry, Doctor has been blocked.");
            }
            $doctorData->experience = $doctorData->experience . ' years experience overall';
            $doctorData->image_url = getUrl('image/doctor_profile');
            $result['doctor_detail'] = $doctorData;
            $result['doctor_detail']['doctor_details']['registration_proof'] = getUrl('doctordocument/registrationproof') . $result['doctor_detail']['doctor_details']['registration_proof'];
            $result['doctor_detail']['doctor_details']['qualification_certificates'] = getUrl('doctordocument/degree') . $result['doctor_detail']['doctor_details']['qualification_certificates'];
            $result['doctor_detail']['doctor_details']['aadhar_card_document'] = getUrl('doctordocument/aadhar') . $result['doctor_detail']['doctor_details']['aadhar_card_document'];
            $result['doctor_detail']['doctor_details']['pan_card_document'] = getUrl('doctordocument/pan') . $result['doctor_detail']['doctor_details']['pan_card_document'];
            if (!empty($doctorData->doctor_details)) {
                $doctoreDetail = $doctorData->doctor_details;
                $result['doctor_detail']['doctor_details']['service_json'] = json_decode($doctoreDetail->service_json);
                $result['doctor_detail']['doctor_details']['specialization_json'] = json_decode($doctoreDetail->specialization_json);
                $result['doctor_detail']['doctor_details']['education_json'] = json_decode($doctoreDetail->education_json);
                $result['doctor_detail']['doctor_details']['membership_json'] = json_decode($doctoreDetail->membership_json);
                $result['doctor_detail']['doctor_details']['experience_json'] = json_decode($doctoreDetail->experience_json);
                $result['doctor_detail']['doctor_details']['registration_json'] = json_decode($doctoreDetail->registration_json);
            }
            $hospitalMapping = \App\Models\DoctorHospitalMapping::where('doctor_id', $doctorData->id)->with('hospital')->get();
            if (!empty($hospitalMapping)) {
                $result['hospital_image_url']['image_url'] = getUrl('image/hospital');
                foreach ($hospitalMapping as $key => $value) {
                    if (!empty($value->hospital)) {
                        if ($value->hospital->status_id == STATUS_ACTIVE) {
                            $value['cancel_policy'] = json_decode($value->cancel_policy);
                            $value['cancel_policy_setting'] = json_decode($value->cancel_policy_setting);
                            $result['hospital_list'][] = $value->hospital;
                        }
                    }
                }
            }
        }
        return success($result, "Doctor detail...");
    }

    private function getDoctorSlotDate($doctorId, $hospitalId) {
        $result = [];
        $query = "SELECT
                            s.*,
                            s.id AS doctor_hospital_slot_id
                    FROM
                            doctor_hospital_slot s,
                            ( 
                            SELECT 
                                date 
                            FROM 
                                `doctor_hospital_slot` 
                            WHERE 
                                `hospital_id` = " . $hospitalId . " 
                                 AND `doctor_id` = " . $doctorId . " 
                                 AND `date` >= '" . date('Y-m-d') . "'
                            GROUP BY 
                                `date` LIMIT 7
                            ) temp 
                    WHERE
                            s.date = temp.date 
                            AND s.status_id = " . STATUS_ACTIVE . "
                            AND (
                                s.id NOT IN ( 
                                    SELECT 
                                        doctor_hospital_slot_id 
                                    FROM 
                                        doctor_appointment_booking 
                                    WHERE 
                                        `appointment_date` = temp.date 
                                         AND status_id=" . STATUS_SUCCESS . "
                                         ) 
                                AND s.id NOT IN ( 
                                    SELECT 
                                        doctor_hospital_slot_id 
                                    FROM 
                                        doctor_hospital_block_slot 
                                    WHERE 
                                        date = temp.date
                                                )
                                )
                                ORDER BY 
                                    s.from_time ASC";
        //For to time to greter : AND dhs.from_time >= '" . date('H:i:s') . "'
        $nextSevenDate = executeSelectQueryOnMySQLDB($query);
        if (!empty($nextSevenDate)) {
            $slotArr = [];
            $slotDate = "";
            foreach ($nextSevenDate as $key => $slot) {
                if ($slotDate == $slot['date']) {
                    $slotArr[$slot['date']]['day'] = date('D', strtotime($slotDate));
                    $slotArr[$slot['date']]['date'] = $slotDate;
                    $slotArr[$slot['date']]['slot_list'][] = $slot;
                    $slotArr[$slot['date']]['slot_count'] = count($slotArr[$slot['date']]['slot_list']);
                } else {
                    $slotDate = $slot['date'];
                    $slotArr[$slot['date']]['day'] = date('D', strtotime($slotDate));
                    $slotArr[$slot['date']]['date'] = $slotDate;
                    $slotArr[$slot['date']]['slot_list'][] = $slot;
                    $slotArr[$slot['date']]['slot_count'] = count($slotArr[$slot['date']]['slot_list']);
                }
            }
            if (!empty($slotArr)) {
                foreach ($slotArr as $value) {
                    $result[] = $value;
                }
            }
        }
        return $result;
    }

    private function getDoctorSlotByDay($doctorId, $hospitalId) {
        $weekOfdays = array();
        for ($i = 0; $i <= 6; $i++) {
            $date = date('Y-m-d'); //today date
            $date = date('Y-m-d', strtotime('+' . $i . ' day', strtotime($date)));

            $day = date('D', strtotime($date));
            $date = date('Y-m-d', strtotime($date));
            $checkDateBlock = \App\Models\DoctorHospitalBlockSlot::where('doctor_id', $doctorId)
                    ->where('hospital_id', $hospitalId)
                    ->where('date', $date)
                    ->whereNull('doctor_hospital_slot_id')
                    ->count();
            if (empty($checkDateBlock)) {
                $slot = $this->getSlotByDay($doctorId, $hospitalId, $day, $date);
                $slotCount = count($slot) > 0 ? count($slot) : 0;
                if ($slotCount != 0) {
                    $weekOfdays[] = array(
                        "day" => $day,
                        "date" => $date,
                        "slot_count" => $slotCount,
                        "slot" => $slot,
                    );
                }
            }
        }
        return $weekOfdays;
    }

    private function getSlotByDay($doctorId, $hospitalId, $day, $date) {
        $query = "SELECT
                        dhs.*,
                        dhs.id AS doctor_hospital_slot_id
                FROM
                        doctor_hospital_slot AS dhs 
                WHERE
                        dhs.doctor_id = " . $doctorId . " 
                        AND dhs.hospital_id = " . $hospitalId . "
                        AND dhs.status_id = " . STATUS_ACTIVE . "
                        AND dhs.`day` = '" . $day . "' 
                        AND (
                            dhs.id NOT IN ( 
                                SELECT doctor_hospital_slot_id FROM doctor_appointment_booking 
                                 WHERE `appointment_date` = '" . $date . "' 
                                 AND status_id=" . STATUS_SUCCESS . "    
                             ) 
                            AND dhs.id NOT IN ( 
                                SELECT doctor_hospital_slot_id FROM doctor_hospital_block_slot
                                WHERE date = '" . $date . "'
                            )
                        )";
        if ($date == date('Y-m-d')) {
            $query .= " AND dhs.from_time >= '" . date('H:i:s') . "'";
        }
        $query .= " ORDER BY 
                            dhs.from_time ASC";

        //For to time to greter : AND dhs.from_time >= '" . date('H:i:s') . "'
        return executeSelectQueryOnMySQLDB($query);
    }

}
