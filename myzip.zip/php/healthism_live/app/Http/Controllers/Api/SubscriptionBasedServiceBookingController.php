<?php

namespace App\Http\Controllers\API;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use App\Models\SubscriptionBasedServiceBooking;
use App\Http\Controllers\Api\OrderPaymentController;
use App\Http\Repository\NotificationRepository;
use App\Http\Repository\OfferRepository;
use Illuminate\Support\Facades\DB;
use Exception;

class SubscriptionBasedServiceBookingController extends Controller {

    private $orderPaymentController;
    private $notificationRepository;
    private $offerRepository;

    public function __construct(OrderPaymentController $orderPaymentController, OfferRepository $offerRepository, NotificationRepository $notificationRepository) {
        $this->orderPaymentController = $orderPaymentController;
        $this->notificationRepository = $notificationRepository;
        $this->offerRepository = $offerRepository;
    }

    public function promocodeTest() {
        $result = [];
        $response = $this->offerRepository->applyOfferCode('DEV-TEST', SUBSCRIPTION_BASED_SERVICE, 2, 1500);
        return success($response, "Test...");
    }

    public function subscriptionBasedServiceCart(Request $request) {
        try {
            $input = $request->all();
            if (empty($input['subscription_based_service_id'])) {
                return error("Sorry, Subscription based service id is empty");
            }
            if (empty($input['facility_ids'])) {
                return error("Sorry, Facility ids is empty");
            }
            $result = $this->cartValidation($input);
            if ($result['code'] == 0) {
                return error($result['message'], $result['data']);
            }
            return success($result['data'], "Yor cart is ready!");
        } catch (Exception $exc) {
            errorLog($exc);
        }
        return error(COMMON_ERROR);
    }

    public function cartValidation($input) {
        try {
            $response = ['code' => 0, 'data' => [], 'message' => COMMON_ERROR];
            $subscriptionBasedService = \App\Models\SubscriptionBasedService::where('id', $input['subscription_based_service_id'])->with('state', 'city','subscriptionBasedServiceDetails')->first();
            if (empty($subscriptionBasedService)) {
                $response['message'] = "Sorry, Service data not found";
                return $response;
            }
            if ($subscriptionBasedService['status_id'] != STATUS_ACTIVE) {
                $response['message'] = "Sorry, This service currently not available for service.";
                return $response;
            }
            $facilityIdArr = explode(',', $input['facility_ids']);
            $facilityList = \App\Models\SubscriptionBasedServiceFacility::whereIn('id', $facilityIdArr)->get();
            $facilityCount = count($facilityList);
            $error = 0;
            $facilityData = [];
            foreach ($facilityList as $key => $facility) {
                $facilityData[$key] = $facility;
                if ($facility['status_id'] != STATUS_ACTIVE) {
                    $response['message'] = $facility['name'] . " currently not available!";
                    return $response;
                }
                //check facility in branch or Subscription Based Service
                if (!in_array($facility['subscription_based_service_id'], [$subscriptionBasedService['id'], $subscriptionBasedService['parent_id']])) {
                    $response['message'] = $facility['name'] . "  not serve by service";
                    return $response;
                }
            }
            if ($error == 0) {
                $response['code'] = 1;
            } else {
                $response['code'] = 0;
            }
            $response['data']['facility_list'] = $facilityData;
            $response['data']['subscription_based_service'] = $subscriptionBasedService;
            return $response;
        } catch (Exception $exc) {
            errorLog($exc);
        }
        return error(COMMON_ERROR);
    }

    public function bookingPage(Request $request) {
        $input = $request->all();
        $result = [];
        $input['login_user_id'] = $request->user()->id;
        $input['login_user_mobile'] = $request->user()->mobile;
        $input['login_user_type'] = $request->user()->user_type_id;
        $bookingValidation = $this->bookingValidation($input);
        if (isset($bookingValidation[0]) && $bookingValidation[0] == 0) {
            return error($bookingValidation[1]);
        }
        $result['user_member'] = $bookingValidation['user_member'];
        $cartValidation = $this->cartValidation($input);
        $result['cart_data'] = $cartValidation['data']['facility_list'];
        $result['subscription_based_service'] = $cartValidation['data']['subscription_based_service'];
        $cartCalculation = $this->bookingCalculation($result, $input);
        $result['calculation'] = $cartCalculation;
        if ($cartCalculation['amount'] <= 0) {
           $result['payment_mode'][] = ['id' => COUPON, 'name' => 'Coupon', 'icon' => '1.jpg'];
        } else {
            $result['payment_mode'] = getPaymentMode(SUBSCRIPTION_BASED_SERVICE,$result['subscription_based_service']['cash_booking_allowed']);
        }
        $orderRefId = KEY_ORDER_REF_ID . "_" . $request->user()->id . '_' . time();
        setRedisData($orderRefId, 0);
        $result['order_ref_id'] = $orderRefId;
        if (isset($cartCalculation['code']) && $cartCalculation['code'] == 0) {
            //for promocode related
            return error($cartCalculation['message'], $result);
        }
        if ($cartValidation['code'] == 0) {
            //for cart related
            return error($cartValidation['message'], $result);
        }
        return success($result, "Booking Data...");
    }

    /* Calculation Of Booking */

    private function bookingCalculation($data, $input) {
        $amount = 0;
        $discount = 0;
        foreach ($data['cart_data'] as $key => $facility) {
            $amount = $amount + $facility['price'];
            $discount = $discount + (($facility['price'] * $facility['discount']) / 100);
        }
        $grandTotal = ((int) $amount - (int) $discount);
        $bookingCharges = 0.00;
        $result['charges'] = array(
            ['title' => 'Amount', 'value' => numberFormat($amount), 'symbol' => '+'],
            ['title' => 'Booking Charge', 'value' => numberFormat($bookingCharges), 'symbol' => '+'],
            ['title' => 'Healthismplus Discount', 'value' => numberFormat($discount), 'symbol' => '-', 'color' => '#209f7b']
        );
        $result['order_sub_total'] = $grandTotal;
        if (!empty($input['promo_code'])) {
            $promoCodeData = $this->offerRepository->applyOfferCode($input['promo_code'], SUBSCRIPTION_BASED_SERVICE, $input['login_user_id'], $grandTotal);
            if ($promoCodeData['code'] == 0) {
                $result['code'] = $promoCodeData['code'];
                $result['message'] = $promoCodeData['message'];
            } else {
                $result['charges'][] = ['title' => 'Coupon Discount', 'value' => numberFormat($promoCodeData['promo_code_discount']), 'symbol' => '-'];
                $result['promo_code_discount'] = $promoCodeData['promo_code_discount'];
                $result['promo_code_data'] = $promoCodeData['code_data'];
                $grandTotal = $grandTotal - $promoCodeData['promo_code_discount'];
            }
        }
        $result['grandTotal'] = ['title' => 'Total Payable', 'value' => numberFormat($grandTotal)];
        if (!empty($discount)) {
            $result['discountMessage'] = 'You will save RS. ' . numberFormat($discount) . ' on this';
        }
        $result['amount'] = $grandTotal;
        $result['discount'] = $discount;
        $result['charge'] = $bookingCharges;
        return $result;
    }

    /* Use booking subscription based service validation function for booking and payment time */

    private function bookingValidation($input) {
        $result = null;
        if (empty($input['user_patient_id'])) {
            return array(0, "Sorry, User patient id is empty");
        }
        if (empty($input['date'])) {
            return array(0, "Sorry, Date is empty");
        }
        if (empty($input['subscription_based_service_id'])) {
            return array(0, "Sorry, Subscription based service id is empty");
        }
        if (empty($input['facility_ids'])) {
            return array(0, "Sorry, Facility ids is empty");
        }
        if (empty($input['platform_id'])) {
            return array(0, "Sorry, Platform id is empty");
        }
        $userSubscription = getUserSubscription($input['login_user_id']);
        if (empty($userSubscription)) {
            return array(0, "Sorry, No activate plan available");
        } else {
            if ($userSubscription['expire'] == 1) {
                return array(0, "Please renew plan, Your plan is expired");
            }
        }
        $memberData = \App\Models\UserPatientMapping::where('id', $input['user_patient_id'])->first();
        if (empty($memberData)) {
            return array(0, 'Sorry, Patient data not found');
        } else {

            if ($memberData->user_id != $input['login_user_id']) {
                return array(0, 'Sorry, You have not mapped with Patient');
            }

            if ($memberData->status_id != STATUS_ACTIVE) {
                return array(0, 'Sorry, Patient is blocked.');
            }
            if ($memberData->is_deleted == 1) {
                return array(0, 'Sorry, Patient was deleted.');
            }
        }
        $result['user_member'] = $memberData;
        $result['user_subscription'] = $userSubscription;
        return $result;
    }

    public function orderPayment(Request $request) {
        try {
            $input = $request->all();
            if (empty($input['payment_mode_id'])) {
                return error("Sorry, Payment mode id is empty.");
            }
            if (empty($input['date'])) {
                return error("Sorry, Date is empty.");
            }
            if (empty($input['platform_id'])) {
                return error("Sorry, Platform id is empty.");
            } else {
                if (empty($input['order_ref_id'])) {
                    return error('Sorry, Order ref id is empty');
                } else {
                    $orderId = getDataFromRedisKey($input['order_ref_id']);
                    if (!empty($orderId)) {
                        return error(COMMON_ERROR, ['order_id' => $orderId, 'message' => 'Order already processed']);
                    }
                }
                $paymentMode = paymentMethodValidation($input['payment_mode_id']);
                if ($paymentMode['data'] == 0) {
                    return error($paymentMode['message']);
                }
                $paymentMode = $paymentMode['data'];
                $input['login_user_id'] = $request->user()->id;
                $input['login_user_name'] = $request->user()->first_name . ' ' . $request->user()->last_name;
                $input['login_user_email'] = $request->user()->email;
                $input['login_user_mobile'] = $request->user()->mobile;
                $input['login_user_type'] = $request->user()->user_type_id;
            }
            $input['created_by'] = $request->user()->id;
            $input['ip'] = $request->ip();

            $validation = $this->bookingValidation($input);
            if (isset($validation[0]) && $validation[0] == 0) {
                return error($validation[1]);
            }
            $userMember = $validation['user_member'];

            $cartValidation = $this->cartValidation($input);
            if ($cartValidation['code'] == 0) {
                return error($cartValidation['message']);
            }
            $SBSData = $cartValidation['data']['subscription_based_service'];
            $facilityData = $cartValidation['data']['facility_list'];

            $input['user_subscription_id'] = $validation['user_subscription']['id'];
            $statusId = STATUS_PENDING;
            $cartCalculation = $this->bookingCalculation(array('cart_data' => $cartValidation['data']['facility_list']), $input);
            if (isset($cartCalculation['code']) && $cartCalculation['code'] == 0) {
                //for promocode related
                return error($cartCalculation['message']);
            }
            if ($paymentMode['id'] == OFFLINE) {
                if ($cartCalculation['grandTotal'] > 0) {
                    if ($SBSData['cash_booking_allowed'] != 1) {
                        return error("Sorry, Service not allowed offline(cash) booking");
                    }
                }
                $statusId = STATUS_SUCCESS;
            }

            $input['promo_code_discount'] = !empty($cartCalculation['promo_code_discount']) ? $cartCalculation['promo_code_discount'] : null;
            $input['promo_code_id'] = !empty($cartCalculation['promo_code_data']['id']) ? $cartCalculation['promo_code_id']['id'] : null;
            $input['order_sub_total'] = $cartCalculation['order_sub_total'];
            $input['grand_total'] = $cartCalculation['amount'];
            try {
                /* ------------------------------------------
                  --------------------------------------------
                  Start DB Transaction
                  --------------------------------------------
                  -------------------------------------------- */
                DB::beginTransaction();
                $bookingInsertedData = [
                    'user_id' => $input['login_user_id'],
                    'user_subscription_id' => $input['user_subscription_id'],
                    'subscription_based_service_id' => $SBSData['id'],
                    'subscription_based_service_parent_id' => $SBSData['parent_id'],
                    'user_member_id' => $userMember['id'],
                    'member_name' => $userMember['first_name'] . ' ' . $userMember['last_name'],
                    'member_mobile' => $userMember['mobile'],
                    'appointment_date' => $input['date'],
                    'amount' => $cartCalculation['order_sub_total'],
                    'discount' => $cartCalculation['discount'],
                    'created_by' => $input['created_by'],
                    'status_id' => $statusId,
                    'created_at' => date('Y-m-d H:i:s'),
                ];
                $bookingData = SubscriptionBasedServiceBooking::create($bookingInsertedData);
                if (empty($bookingData['id'])) {
                    return error("Sorry, Something went wrong.");
                } else {
                    foreach ($facilityData as $key => $facility) {
                        $discount = ($facility['price'] * $facility['discount']) / 100;
                        $bookingDetailData = [
                            'subscription_based_service_booking_id' => $bookingData['id'],
                            'subscription_based_service_id' => $bookingData['subscription_based_service_id'],
                            'subscription_based_service_parent_id' => $bookingData['subscription_based_service_parent_id'],
                            'subscription_based_service_facility_id' => $facility['id'],
                            'amount' => $facility['price'] - $discount,
                            'discount' => $discount,
                            'created_at' => date('Y-m-d H:i:s')
                        ];
                        \App\Models\SubscriptionBasedServiceBookingDetails::create($bookingDetailData);
                    }
                }
                $result = $this->createOrder($bookingData, $SBSData, $paymentMode, $input);
            } catch (Exception $exc) {
                /* ------------------------------------------
                  --------------------------------------------
                  Rollback Database Entry
                  --------------------------------------------
                  -------------------------------------------- */
                errorLog($exc);
                DB::rollback();
            }
            if (!empty($result)) {
                if (empty($result['error'])) {
                    return success($result, "Thank you");
                } else {
                    return error(COMMON_ERROR, ['order_id' => $result['order_id'], 'message' => $result['error_message']]);
                }
            } else {
                return error(COMMON_ERROR);
            }
        } catch (Exception $exc) {
            errorLog($exc);
        }
        return error(COMMON_ERROR);
    }

    private function createOrder($bookingData, $SBSData, $paymentMode, $input) {
        try {
            $ds1 = 'Booking for ' . $bookingData['member_name'];
            $ds2 = 'Service Provider : ' . $SBSData['name'];
            $time = strtotime($bookingData['appointment_date']);
            $ds3 = 'Time : ' . date('d/M/Y h:i A', $time);
            $descripationArr = ["desc1" => $ds1, "desc2" => $ds2, "desc3" => $ds3];
            $transactionArr = [
                'Service Name' => $SBSData['name'],
                'member_name' => $bookingData['member_name'],
                'member_mobile' => $bookingData['member_mobile'],
                'appointment_date_time' => $bookingData['appointment_date'],
            ];
            $statusId = STATUS_SENT_ON_PG;
            $status = 'SENT ON PG';
            $remark = "PAYMENT PENDING";
            $paymentRemark = "PAYMENT PENDING";
            $color = statusWiseColor(STATUS_SENT_ON_PG);
            if ($paymentMode['id'] == OFFLINE) {
                $statusId = STATUS_DONE;
                $status = 'DONE';
                $remark = "ORDER CONFIRM PAY AT SERVICE LOCATION";
                $paymentRemark = "PAYMENT PENDING PAY AT SERVICE LOCATION";
                $color = statusWiseColor(STATUS_DONE);
            }

            /* ........... CRETAE NEW ORDER............ */
            $orderArr = [
                'order_code' => 'SBS' . platformCode($input['platform_id']) . $input['login_user_id'] . time(),
                'user_id' => $input['login_user_id'],
                'user_subscription_id' => $input['user_subscription_id'],
                'service_id' => SUBSCRIPTION_BASED_SERVICE,
                'amount' => $bookingData['amount'],
                'status_id' => $statusId,
                'remark' => $remark,
                'charges' => null,
                'remark_color_code' => $color,
                'description_json' => json_encode($descripationArr),
                'transaction_json' => json_encode($transactionArr),
            ];
            $order = $this->orderPaymentController->createOrder($orderArr);
            if (!empty($order['id'])) {
                if ($input['platform_id'] != WEB) {
                    setRedisData($input['order_ref_id'], $order['id']);
                }

                /*                 * ................OFFER CODE.............. */
                if (!empty($input['promo_code'])) {
                    setRedisData(KEY_PROMO_CODE_ORDER . "_" . $order['id'], [
                        'order_id' => $order['id'],
                        'order_code' => $order['order_code'],
                        'service_id' => SUBSCRIPTION_BASED_SERVICE,
                        'order_sub_total' => $input['order_sub_total'],
                        'promo_code_discount' => $input['promo_code_discount'],
                        'promo_code' => $input['promo_code'],
                        'promo_code_id' => $input['promo_code_id'],
                        'user_id' => $input['login_user_id'],
                            ]
                    );
                }

                $SBSBookingUpdate = \App\Models\SubscriptionBasedServiceBooking::findOrFail($bookingData['id']);
                $SBSBookingUpdate->fill(['order_id' => $order['id']])->save();

                /* ........... CRETAE NEW ORDER HISTORY............ */
                $orderHistoryArr = [
                    'order_id' => $order['id'],
                    'type' => 'ORDER',
                    'status_id' => $statusId,
                    'remark' => $remark,
                    'updated_by' => $input['created_by']
                ];
                $this->orderPaymentController->saveOrderHistory($orderHistoryArr);

                /* ........... CRETAE NEW ORDER DETAIL............ */
                $orderDeatilArr = [
                    'order_id' => $order['id'],
                    'service_id' => SUBSCRIPTION_BASED_SERVICE,
                    'ref_id' => $bookingData['id'],
                    'coupon_id' => $input['promo_code_id'],
                    'coupon_amount' => $input['promo_code_discount'],
                    'wallet_amount' => null,
                    'pg_amount' => $input['grand_total'],
                    'paid_amount' => $bookingData['amount'],
                    'tax' => null,
                    'charges' => null,
                    'status_id' => $statusId,
                    'remark' => $remark,
                    'remark_color_code' => $color,
                ];
                $orderDeatil = $this->orderPaymentController->saveOrderDetail($orderDeatilArr);
                /* ........... CRETAE NEW ORDER DETAIL HISTORY............ */
                $orderDeatilHistoryArr = [
                    'order_id' => $order['id'],
                    'order_detail_id' => $orderDeatil['id'],
                    'type' => 'ORDER_DETAIL',
                    'status_id' => STATUS_PENDING,
                    'remark' => $remark,
                    'updated_by' => $input['created_by']
                ];
                $this->orderPaymentController->saveOrderHistory($orderDeatilHistoryArr);


                /* ........... CRETAE NEW ORDER PAYMENT............ */
                $orderPaymentArr = [
                    'order_id' => $order['id'],
                    'user_id' => $input['login_user_id'],
                    'payment_mode_id' => $paymentMode['id'],
                    'pg_amount' => $input['grand_total'],
                    'status_id' => STATUS_PENDING,
                    'ip_address' => $input['ip'],
                ];
                $orderPayment = $this->orderPaymentController->saveOrderPayment($orderPaymentArr);
                /* ........... CRETAE NEW ORDER PAYMENT HISTORY............ */
                $paymentHistoryArr = [
                    'order_id' => $order['id'],
                    'type' => 'PAYMENT',
                    'status_id' => STATUS_PENDING,
                    'remark' => $paymentRemark,
                    'updated_by' => $input['created_by']
                ];
                $this->orderPaymentController->saveOrderHistory($paymentHistoryArr);
            }
            /* ------------------------------------------
              --------------------------------------------
              Commit Transaction to Save Data to Database
              --------------------------------------------
              -------------------------------------------- */
            DB::commit();

            $order['description'] = 'Subscription base service booking';
            $order['name'] = $input['login_user_name'];
            $order['mobile'] = $input['login_user_mobile'];
            $order['email'] = $input['login_user_email'];
            $order['payment_mode_id'] = $paymentMode['id'];
            $order['amount'] = $input['grand_total']; //Pass on payment getaway
            $order['platform_id'] = $input['platform_id']; //For identify APP/WEB
            $order['promo_code_discount'] = !empty($input['promo_code_discount']) ? $input['promo_code_discount'] : 0;
            $result = $this->orderPaymentController->makePayment($order);
            return $result;
        } catch (Exception $exc) {
            /* ------------------------------------------
              --------------------------------------------
              Rollback Database Entry
              --------------------------------------------
              -------------------------------------------- */
            DB::rollback();
            setRedisData($input['order_ref_id'], 0);
            errorLog($exc);
        }
        return 0;
    }

    public function rescheduleAppointment(Request $request) {
        try {
            $input = $request->all();
            $input['login_user_id'] = $request->user()->id;
            $input['login_user_mobile'] = $request->user()->mobile;
            $input['login_user_type'] = $request->user()->user_type_id;
            if (empty($input['appointment_id'])) {
                return error('Sorry, Appointment id is empty');
            }
            if (empty($input['date'])) {
                return error('Sorry, Date is empty');
            }
            $appintmentData = \App\Models\SubscriptionBasedServiceBooking::where('id', $input['appointment_id'])->first();
            $oldDate = date_format(date_create($appintmentData->appointment_date), "d/m/Y") . ' ' . $appintmentData->appointment_time;
            if (empty($appintmentData)) {
                return error('Sorry, Invalid appointment id');
            }

            if ($appintmentData->created_by != $input['login_user_id']) {
                return error('Sorry, You are not authorized to reschedule this appointment');
            }
            if ($appintmentData->status_id != STATUS_SUCCESS) {
                return error('Sorry, Your appointment has not been confirmed. so you cannot reschedule the appointment');
            }
            $date = $appintmentData->appointment_date . " " . $appintmentData->appointment_time;
            $dateNow = strtotime(date('Y-m-d H:i:s'));
            $rescheduleTime = strtotime(date('Y-m-d H:i:s', strtotime($date . ' -2 hours')));

            if ($dateNow > $rescheduleTime) {
                return array('code' => 0, 'message' => "Sorry, Reschedule time has been over");
            }
            $result = $appintmentData->fill([
                        'appointment_date' => $input['date'],
                    ])->save();

            $remark = "Reschedule Appointment : Old  Appointment - " . $oldDate
                    . ' New  Appointment - ' . $input['date'] . ' ' . $slotData->from_time;
            $this->orderPaymentController->saveOrderHistory([
                'order_id' => $appintmentData->order_id,
                'type' => 'TRACKING', 'status_id' => STATUS_SUCCESS,
                'remark' => $remark,
                'updated_by' => $input['login_user_id']
            ]);
            $this->notificationRepository->MBSAppointmentNotification($appintmentData->order_id, 'RESCHEDULE', ['old_date' => $oldDate]);
            return success($result, "Appointment rescheduled successfully!");
        } catch (Exception $exc) {
            errorLog($exc);
        }
        return error(COMMON_ERROR);
    }

    public function cancellationReason(Request $request) {
        if (empty($request->appointment_id)) {
            return error("Sorry, appointment id is empty");
        }
        $validation = $this->cancelationTimeValidation($request);
        if ($validation['code'] == 0) {
            return error($validation['message']);
        }
        $appintmentData = $validation['data'];
        $result['subscription_based_service_name'] = $appintmentData->subscriptionBasedService->name;
        $result['subscription_based_service_area'] = $appintmentData->subscriptionBasedService->area;
        $result['date'] = $appintmentData->appointment_date;
        $result['time'] = $appintmentData->appointment_time;
        $result['appointment_id'] = $appintmentData->id;
        $result['cancellation_reason'] = [
            'I am busy',
            'Forget about the appointment',
            'Changed my mind',
            'Visited another service provider',
            'Service provider asked me to cancel',
        ];
        return success($result, "Booking Data...");
    }

    public function cancellationDetail(Request $request) {
        if (empty($request->appointment_id)) {
            return error("Sorry, Appointment id is empty");
        }
        $validation = $this->cancelationTimeValidation($request);
        if ($validation['code'] == 0) {
            return error($validation['message']);
        }
        $appintmentData = $validation['data'];
        $orderDetail = \App\Models\OrderDetail::where('order_id', $appintmentData->order_id)
                        ->where('ref_id', $request->appointment_id)->first();
        if (empty($orderDetail)) {
            return error("Sorry, Order data not found");
        }
        $paymentModeId = \App\Models\OrderPayment::where('order_id', $appintmentData->order_id)->first()->payment_mode_id;
        $totalAmount = $orderDetail->coupon_amount + $orderDetail->wallet_amount + $orderDetail->pg_amount;
        $result['calculation']['charges'][] = ['title' => 'Amount', 'symbol' => '', 'value' => numberFormat($totalAmount - $orderDetail->charges)];
        $result['calculation']['charges'][] = ['title' => 'Charges', 'symbol' => '+', 'value' => numberFormat($orderDetail->charges)];

        if ($paymentModeId == OFFLINE) {
            $result['calculation']['grandTotal'] = ['title' => 'Amount Paid', 'value' => '0.00'];
        } else {
            if (!empty($orderDetail->coupon_amount)) {
                $result['calculation']['charges'][] = ['title' => 'Coupon Amount', 'symbol' => '-', 'value' => numberFormat($orderDetail->coupon_amount)];
            }
            if (!empty($orderDetail->wallet_amount)) {
                $result['calculation']['charges'][] = ['title' => 'Wallet Amount', 'symbol' => '-', 'value' => numberFormat($orderDetail->wallet_amount)];
            }
            $result['calculation']['grandTotal'] = ['title' => 'Amount Paid', 'value' => numberFormat($orderDetail->pg_amount)];
        }
        $cancelationCharges = $this->cancelationCharges($appintmentData);
        if ($paymentModeId == OFFLINE) {
            $result['refund_calculation']['charges'][] = ['title' => 'Amount Paid', 'value' => '0.00'];
            $result['refund_calculation']['charges'][] = ['title' => 'Cancellation Charges', 'symbol' => '-', 'value' => '0.00'];
            $result['refund_calculation']['grandTotal'] = ['title' => 'Amount Paid', 'value' => '0.00'];
        } else {
            $result['refund_calculation']['charges'][] = ['title' => 'Amount Paid', 'value' => numberFormat($orderDetail->pg_amount)];
            $result['refund_calculation']['charges'][] = ['title' => 'Cancellation Charges', 'symbol' => '-', 'value' => numberFormat($cancelationCharges)];
            $result['refund_calculation']['grandTotal'] = ['title' => 'Amount Paid', 'value' => numberFormat($orderDetail->pg_amount - $cancelationCharges)];
        }

        $result['payment_method'] = ['title' => 'Paid Via', 'symbol' => '', 'value' => $paymentModeId];
        $result['cancel_policy'] = !empty($appintmentData->subscriptionBasedService->cancel_policy) ? json_decode($appintmentData->subscriptionBasedService->cancel_policy, true) : SUBSCRIPTION_BASED_SERVICE_CANCEL_POLICY;
        $result['reason'] = $request->reason;
        return success($result, "Booking Data...");
    }

    public function cancelOrder(Request $request) {
        try {
            if (empty($request->appointment_id)) {
                return error("Sorry, Appointment id is empty");
            }
            if (empty($request->reason)) {
                return error("Sorry, Reason is empty");
            }
            $validation = $this->cancelationTimeValidation($request);
            if ($validation['code'] == 0) {
                return error($validation['message']);
            }
            $appintmentData = $validation['data'];
            $orderDetail = \App\Models\OrderDetail::where('order_id', $appintmentData->order_id)
                            ->where('ref_id', $request->appointment_id)->first();
            if (empty($orderDetail)) {
                return error("Sorry, Order data not found");
            }
            $orderPayment = \App\Models\OrderPayment::where('order_id', $appintmentData->order_id)->first();
            $cancelationData['cancelationCharges'] = $request->user()->user_type_id == END_USER ? $this->cancelationCharges($appintmentData) : 0;
            if (!empty($orderPayment)) {
                if ($orderPayment->status_id == STATUS_DONE && $orderPayment->payment_mode_id == RAZORPAY) {
                    $cancelationData['refundAmount'] = $orderDetail->pg_amount - $cancelationData['cancelationCharges'];
                }
            }
            $cancelationData['reason'] = $request->reason;
            $cancelationData['order_id'] = $appintmentData->order_id;
            $cancelationData['order_detail_id'] = $orderDetail->id;
            $cancelationData['ref_id'] = $appintmentData->id;
            $cancelationData['login_user_id'] = $request->user()->id;
            $cancelationData['login_user_type'] = $request->user()->user_type_id;
            $cancelationData['login_user_name'] = $request->user()->first_name . ' ' . $request->user()->last_name;
            $this->orderPaymentController->orderCancel($cancelationData);
            $appintmentData->fill(array('status_id' => STATUS_CANCELLED, 'updated_at' => date('Y-m-d H:i:s'),
                'refund_amount' => !empty($cancelationData['refundAmount']) ? $cancelationData['refundAmount'] : null))->save();
            $remark = "Cancel by user - reason: " . $request->reason;
            $this->orderPaymentController->saveOrderHistory(['order_id' => $appintmentData->order_id, 'type' => 'TRACKING', 'status_id' => STATUS_CANCELLED, 'remark' => $remark, 'updated_by' => $request->user()->id]);

            $mainOrder = \App\Models\Orders::where('id', $appintmentData->order_id)->with('detail', 'payment', 'payment.paymentmode', 'user')->first();

            $this->notificationRepository->MBSAppointmentNotification($appintmentData->order_id, 'CANCELLED');

            return success(array(), "Appointment cancelled!");
        } catch (Exception $exc) {
            errorLog($exc);
        }
        return error(COMMON_ERROR);
    }

    private function cancelationCharges($appintmentData) {
        $cancelSetting = SUBSCRIPTION_BASED_SERVICE_CANCEL_POLICY_SETTING;
        if (!empty($appintmentData->subscriptionBasedService->cancel_policy_setting)) {
            $hours = array();
            foreach ($appintmentData->subscriptionBasedService->cancel_policy_setting as $key => $val) {
                $hours[$key] = $val['hours'];
            }
            array_multisort($hours, SORT_ASC, $cancelSetting);
        }
        $appoimentDate = $appintmentData->appointment_date . ' ' . $appintmentData->appointment_time;
        $now = date('Y-m-d H:i:s');
        $timestamp2 = strtotime($appoimentDate);
        $timestamp1 = strtotime($now);
        $timeDiff = abs($timestamp2 - $timestamp1) / (60 * 60);
        $cancelationCharges = 0;
        foreach ($cancelSetting as $key => $val) {
            if ($timeDiff < $val['hours']) {
                $cancelationCharges = ($appintmentData->amount * $val['charge']) / 100;
                break;
            }
        }
        return $cancelationCharges;
    }

    private function cancelationTimeValidation($request) {
        $appointmentId = $request->appointment_id;
        $loginUserId = $request->user()->id;
        $appintmentData = \App\Models\SubscriptionBasedServiceBooking::where('id', $appointmentId)->with('subscriptionBasedService')->first();
        if (empty($appintmentData)) {
            return array('code' => 0, 'message' => "Sorry, Appointment data not found");
        }
        if ($appintmentData->created_by != $loginUserId) {
            return array('code' => 0, 'message' => "Sorry, You don't cancel other user's appointment");
        }
        if ($appintmentData->status_id == STATUS_CANCELLED) {
            return array('code' => 0, 'message' => "Sorry, Appointment already cancelled");
        }
        if (empty($appintmentData->subscriptionBasedService->cancellation_allowed)) {
            return array('code' => 0, 'message' => "Sorry, This service has not allowed to appointment cancellation");
        }
        return array('code' => 1, 'data' => $appintmentData);
    }

    public function facilityNotification() {
        $this->notificationRepository->MBSAppointmentNotification(424, 'CANCELLED');
    }

}
