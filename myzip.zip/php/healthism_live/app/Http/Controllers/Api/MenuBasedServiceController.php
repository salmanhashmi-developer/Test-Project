<?php

namespace App\Http\Controllers\API;

use App\Http\Controllers\Controller;
use App\Http\Repository\MenuBasedServiceFacilityRepository;
use Illuminate\Http\Request;

class MenuBasedServiceController extends Controller {

    private $menuBasedServiceFacilityRepository;

    public function __construct(MenuBasedServiceFacilityRepository $menuBasedServiceFacilityRepository) {
        $this->menuBasedServiceFacilityRepository = $menuBasedServiceFacilityRepository;
    }

    public function search(Request $request) {
        $latitude = $request->header('latitudeUserLocation');
        $longitude = $request->header('longitudeUserLocation');
        $pincode = $request->header('postalCodeUserLocation');
        $input = $request->all();
        if (empty($latitude) || empty($longitude)) {
            return error("Sorry, Latitude/Longitude is empty.");
        }
        if (empty($input['name'])) {
            return error("Sorry, Name is empty");
        }
        $type = !empty($input['type']) ? $input['type'] : 'Facility';
        if ($type == 'Facility') {
            $result = $this->menuBasedServiceFacilityRepository->getFacilityFromLocation($latitude, $longitude, $pincode, $input);
        } else {
            $result = $this->getMenuBasedServiceData($latitude, $longitude, $pincode, $input);
        }
        return success($result, 'Search data');
    }

    public function clicktoCall(Request $request) {
        $input = $request->all();
        if (empty($input['category_id'])) {
            return error("Sorry, Category id is empty.");
        }
        return success([
            'mobile' => MENU_BASED_SERVICE_CLICK_TO_CALL,
            'mobile2' => COMMON_MOBILE_NO
                ], 'Done...');
    }

    public function menuBasedServiceListing(Request $request) {
        try {
            $latitude = $request->header('latitudeUserLocation');
            $longitude = $request->header('longitudeUserLocation');
            $pincode = $request->header('postalCodeUserLocation');
            $input = $request->all();
            if (empty($input['category_id'])) {
                return error("Sorry, Category id is empty.");
            }
            if ($request->user()->id == 74) {
                $latitude = '18.969538920783755';
                $longitude = '72.81932909041643';
                $pincode = '400008';
            } else {
                if (empty($latitude) || empty($longitude)) {
                    return error("Sorry, Latitude/Longitude is empty.");
                }
            }
            $result = $this->getMenuBasedServiceData($latitude, $longitude, $pincode, $input);
            return success($result, 'Service data list');
        } catch (Exception $exc) {
            errorLog($exc);
        }
        return error(COMMON_ERROR);
    }

    private function getMenuBasedServiceData($latitude, $longitude, $pincode, $input) {
        $limit = 25;
        $page = !empty($input['page']) ? $input['page'] : 1;
        $skip = $page > 1 ? ($page * $limit) - $limit : 0;
        $query = "SELECT
                        mbs.id AS menu_based_service_id,
                        mbs.parent_id AS menu_based_service_parent_id,
                        mbs.self_facility_available,
                        mbs.name AS menu_based_service_name,
                        concat('" . getUrl('image/menu_base_service') . "',mbs.photo) AS menu_based_service_photo,
                        mbs.address1 AS menu_based_service_address1,
                        mbs.address2 AS menu_based_service_addres2,
                        mbs.area AS menu_based_service_area,
                        mbs.pincode AS menu_based_service_pincode,
                        mbs.discount AS discount,
                        mbs.category_id AS category_id,
                        s.`name` AS state_name,
                        c.`name` AS city_name,
                        haversine ( '" . $latitude . "', '" . $longitude . "', mbss.latitude, mbss.longitude ) AS menu_based_service_distance,
                        ( SELECT COUNT(*) FROM review WHERE ref_id = mbss.menu_based_service_id AND service_id = " . MENU_BASED_SERVICE . " AND status_id = " . STATUS_APPROVED . " ) AS review_count,
                        ROUND(( SELECT AVG( rating ) FROM review WHERE ref_id = mbss.menu_based_service_id AND service_id =" . MENU_BASED_SERVICE . " AND status_id = " . STATUS_APPROVED . "), 1 ) AS menu_based_service_rating 
                FROM
                        ( SELECT mbss.*, haversine ( '" . $latitude . "', '" . $longitude . "', mbss.latitude, mbss.longitude ) AS 'distance' FROM menu_based_service_search mbss ORDER BY distance ) mbss
                        JOIN menu_based_service AS mbs ON (mbss.menu_based_service_id = mbs.id AND mbs.status_id = 1)
                        LEFT JOIN state AS s ON mbss.state_id = s.id
                        LEFT JOIN city AS c ON mbss.city_id = c.id 
                WHERE  
                        mbss.category_id=" . $input['category_id'] . "
                        AND (";
        if (!empty($pincode)) {
            $query .= "mbss.pincode = '" . $pincode . "' OR ";
        }
        $query .= "mbss.distance < " . MENU_BASED_SERVICE_DISTANCE . " )";
        if (!empty($input['name'])) {
            $query .= " AND mbss.`name` like  '%" . $input['name'] . "%' ";
        }
        $query .= " ORDER BY mbss.distance";
        $query .= " LIMIT " . $limit . " OFFSET " . $skip;
        //pr($query);
        $result = executeSelectQueryOnMySQLDB($query);
        return $result;
    }

    public function menuBaseServiceDetail(Request $request) {
        $input = $request->all();
        if (empty($input['menu_based_service_id'])) {
            return error("Sorry, Menu base service id is empty");
        }
        $result = \App\Models\MenuBasedService::where('id', $input['menu_based_service_id'])->with('menuBasedServiceDetails', 'state', 'city')->first();
        if ($result->status_id != STATUS_ACTIVE) {
            return error("Sorry, This service currently not available for service.");
        }
        return success($result, 'Service data');
    }

    public function menuBaseServiceSlotList(Request $request) {
        try {
            $input = $request->all();
            if (empty($input['menu_based_service_id'])) {
                return error("Sorry, Menu base service id is empty.");
            }
            $result = $this->getMenuBasedServiceSlotByDay($input);
            return success($result, "Service slot list...");
        } catch (Exception $exc) {
            errorLog($exc);
        }
        return error(COMMON_ERROR);
    }

    private function getMenuBasedServiceSlotByDay($input) {
        $weekOfdays = array();
        for ($i = 0; $i <= 6; $i++) {
            $date = date('Y-m-d'); //today date
            $date = date('Y-m-d', strtotime('+' . $i . ' day', strtotime($date)));

            $day = date('D', strtotime($date));
            $date = date('Y-m-d', strtotime($date));
            $checkDateBlock = \App\Models\MenuBasedServiceBlockSlot::where('menu_based_service_id', $input['menu_based_service_id'])
                    ->where('date', $date)
                    ->whereNull('menu_based_service_slot_id')
                    ->count();
            if (empty($checkDateBlock)) {
                $slot = $this->getSlotByDay($input, $day, $date);
                $slotCount = count($slot) > 0 ? count($slot) : 0;
                if ($slotCount != 0) {
                    $weekOfdays[] = array(
                        "day" => $day,
                        "date" => $date,
                        "slot_count" => $slotCount,
                        "slot" => $slot,
                    );
                }
            }
        }
        return $weekOfdays;
    }

    private function getSlotByDay($input, $day, $date) {
        try {
            $query = "SELECT
                        mbss.*,
                        mbss.id AS slot_id
                FROM
                        menu_based_service_slot AS mbss 
                WHERE
                        mbss.menu_based_service_id = " . $input['menu_based_service_id'];
            $query .= " AND mbss.status_id = " . STATUS_ACTIVE . "
                        AND mbss.`day` = '" . $day . "' 
                        AND (
                                mbss.id NOT IN ( 
                                SELECT menu_based_service_slot_id FROM menu_based_service_block_slot
                                WHERE date = '" . $date . "'
                            )
                        )";
            if ($date == date('Y-m-d')) {
                $query .= " AND mbss.from_time >= '" . date('H:i:s') . "'";
            }
            $query .= " ORDER BY 
                            mbss.from_time ASC";
            //For to time to greter : AND mbss.from_time >= '" . date('H:i:s') . "'
            return executeSelectQueryOnMySQLDB($query);
        } catch (Exception $exc) {
            errorLog($exc);
        }
        return error(COMMON_ERROR);
    }

}
