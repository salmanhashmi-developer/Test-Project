<?php

namespace App\Http\Controllers\API;

use App\Http\Controllers\Controller;
use App\Http\Repository\LabRepository;
use Illuminate\Http\Request;

class LabTestController extends Controller {

    private $labRepository;

    public function __construct(LabRepository $labRepository) {
        $this->labRepository = $labRepository;
    }

    public function labTestList(Request $request) {
        $input = $request->all();
        if (empty($input['lab_id'])) {
            return error("Sorry, Lab id is empty");
        }
        if (empty($input['type'])) {
            return error("Sorry, Type is empty");
        }
        $page = !empty($input['page']) ? $input['page'] : 1;
        $skip = $page > 1 ? ($page * LIMIT) - LIMIT : 0;
        if (!empty($input['lab_id']) && !empty($input['self_test_available'])) {
            $query = \App\Models\LabTest::where('lab_id', $input['lab_id']);
        } else {
            $query = \App\Models\LabTest::where('lab_id', $input['parent_id']);
        }
        $query->where('status_id', STATUS_ACTIVE);
        if ($input['type'] == 'PACKAGE') {
            $query->where('is_package', 1);
        } else {
            $query->where('is_package', 0);
        }
        if (!empty($input['name'])) {
            $name = $input['name'];
            $query->where('name', 'like', '%' . $name . '%');
        }
        $query->skip($skip);
        $query->limit(LIMIT);
        $result = $query->get();
        return success($result, 'Lab test list');
    }

    private function healthismLabTest() {
        $query = "SELECT
                    count( lt.Id ) AS count,
                    lt.id,
                    lt.`name`,
                    lt.test_count,
                    lt.discount,
                    lt.price,
                    lt.is_package,
                    l.id as lab_id,
                    l.`name` AS lab_name 
                FROM
                    lab_test lt
                    JOIN lab l ON lt.lab_id = l.id
                WHERE
                    lt.is_package = 0
                    AND l.id=".HEALTHISM_LAB_ID;
        $query .= " GROUP BY
                    lt.id 
                ORDER BY
                    count DESC 
                    ";
        $query .= " LIMIT " . 25;
        return  executeSelectQueryOnMySQLDB($query);
    }

    public function topTestList(Request $request) {
        try {
            return success($this->healthismLabTest(), 'Lab test list');
            $latitude = $request->header('latitudeUserLocation');
            $longitude = $request->header('longitudeUserLocation');
            $pincode = $request->header('postalCodeUserLocation');
            $input = $request->all();
            if (empty($latitude) || empty($longitude)) {
                return error("Sorry, Latitude/Longitude is empty.");
            }
            $limit = 30;
            $page = !empty($input['page']) ? $input['page'] : 1;
            $skip = $page > 1 ? ($page * $limit) - $limit : 0;
            // lt.price-((lt.discount*lt.price)/100) AS healthisam_price,
            $query = "SELECT
                    count( lt.Id ) AS count,
                    lt.id,
                    lt.`name`,
                    lt.test_count,
                    lt.discount,
                    lt.price,
                    lt.is_package,
                    temp.*
                FROM
                    lab_test lt
                    JOIN lab_booking_details lbook ON ( lbook.test_id = lt.id )
                    JOIN (
                    SELECT DISTINCT
                            ls.lab_id,
                            l.`name` AS lab_name 
                    FROM
                            (
                            SELECT
                                    ls.id,
                                    ls.lab_id,
                                    ls.pincode,
                                    haversine ( '" . $latitude . "', '" . $longitude . "', ls.latitude, ls.longitude ) AS 'distance' 
                            FROM
                                    lab_search ls 
                            ORDER BY
                                    distance 
                            ) ls
                            JOIN lab AS l ON ( ls.lab_id = l.id AND l.status_id = 1 ) 
                    WHERE
                            ( ls.pincode = '" . $pincode . "' OR ls.distance < " . LAB_DISTANCE . " ) 
                    ORDER BY
                            ls.lab_id 
                    ) temp ON ( temp.lab_id = lbook.lab_id ) 
                WHERE
                    lt.is_package = 0";
            if (!empty($input['name'])) {
                $name = $input['name'];
                $query .= " AND lt.name like '%" . $name . "%' ";
            }
            $query .= " GROUP BY
                    lt.id 
                ORDER BY
                    count DESC 
                    ";
            $query .= " LIMIT " . $limit . " OFFSET " . $skip;
            $result = executeSelectQueryOnMySQLDB($query);
            if (empty($result)) {
                $input['is_package'] = 0;
                $result = $this->labRepository->getTopTestOrPackage($latitude, $longitude, $pincode, $input);
            }
            return success($result, 'Lab test list');
        } catch (Exception $exc) {
            errorLog($exc);
        }
        return error(COMMON_ERROR);
    }

    public function topPackageList(Request $request) {
        try {
            return success([], 'Lab test list');
            $latitude = $request->header('latitudeUserLocation');
            $longitude = $request->header('longitudeUserLocation');
            $pincode = $request->header('postalCodeUserLocation');
            $input = $request->all();
            if (empty($latitude) || empty($longitude)) {
                return error("Sorry, Latitude/Longitude is empty.");
            }
            $limit = 30;
            $page = !empty($input['page']) ? $input['page'] : 1;
            $skip = $page > 1 ? ($page * $limit) - $limit : 0;
            // lt.price-((lt.discount*lt.price)/100) AS healthisam_price,
            $query = "SELECT
                    count( lt.Id ) AS count,
                    lt.id,
                    lt.`name`,
                    lt.test_count,
                    lt.discount,
                    lt.price,
                    lt.is_package,
                    temp.*
                FROM
                    lab_test lt
                    JOIN lab_booking_details lbook ON ( lbook.test_id = lt.id )
                    JOIN (
                    SELECT DISTINCT
                            ls.lab_id,
                            l.`name` AS lab_name 
                    FROM
                            (
                            SELECT
                                    ls.id,
                                    ls.lab_id,
                                    ls.pincode,
                                    haversine ( '" . $latitude . "', '" . $longitude . "', ls.latitude, ls.longitude ) AS 'distance' 
                            FROM
                                    lab_search ls 
                            ORDER BY
                                    distance 
                            ) ls
                            JOIN lab AS l ON ( ls.lab_id = l.id AND l.status_id = 1 ) 
                    WHERE
                            ( ls.pincode = '" . $pincode . "' OR ls.distance < " . LAB_DISTANCE . " ) 
                    ORDER BY
                            ls.lab_id 
                    ) temp ON ( temp.lab_id = lbook.lab_id ) 
                WHERE
                    lt.is_package = 1";
            if (!empty($input['category'])) {
                $query .= " AND package_category=" . $input['category'];
            }
            if (!empty($input['name'])) {
                $name = $input['name'];
                $query .= " AND lt.name like '%" . $name . "%' ";
            }
            $query .= " GROUP BY
                    lt.id 
                ORDER BY
                    count DESC 
                    ";
            $query .= " LIMIT " . $limit . " OFFSET " . $skip;
            // pr($query);
            $result = executeSelectQueryOnMySQLDB($query);
            if (empty($result)) {
                $input['is_package'] = 1;
                $result = $this->labRepository->getTopTestOrPackage($latitude, $longitude, $pincode, $input);
            }
            return success($result, 'Lab test list');
        } catch (Exception $exc) {
            errorLog($exc);
        }
        return error(COMMON_ERROR);
    }

    public function testDetail(Request $request) {
        if (empty($request->test_id)) {
            return error("Sorry, Test id is empty");
        }
        $result = \App\Models\LabTest::where('id', $request->test_id)->first();
        if (!empty($result)) {
            if ($result->status_id != STATUS_ACTIVE) {
                return error("Sorry, currently this test not available");
            }
        }
        return success($result, 'Lab test data');
    }

}
