<?php

namespace App\Http\Controllers\API;

use App\Http\Controllers\Controller;
use App\Models\Orders;
use Illuminate\Http\Request;

class OrderController extends Controller {

    public function orderList(Request $request) {
        $page = !empty($request->page) ? $request->page : 1;
        $skip = $page > 1 ? ($page * LIMIT) - LIMIT : 0;
        $query = Orders::where('user_id', $request->user()->id);
        if (!empty($request->status_id)) {
            $query->where('status_id', $request->status_id);
        }
        if (!empty($request->search)) {
            $query->where('description_json', 'like', '%' . $request->search . '%');
        }
        if (!empty($request->date)) {
            //$query->where('date', 'like', '%' . $request->search . '%');
        }
        $query->orderBy('id', 'DESC');
        $query->skip($skip)->limit(LIMIT);
        $result = $query->get();
        if (!empty($result)) {
            foreach ($result as $key => $value) {
                $result[$key]['description_json'] = json_decode($value['description_json'], TRUE);
            }
        }
        return success($result, "Booking Data...");
    }

    public function orderDetail(Request $request) {
        if (empty($request->order_id)) {
            return error('Sorry, Order id is empty.');
        }
        $orderData = Orders::where('id', $request->order_id)->with('detail', 'payment', 'payment.paymentmode', 'charges', 'histories', 'status')->first();
        if (empty($orderData)) {
            return error('Sorry, Order data not found.');
        }
        if ($orderData->user_id != $request->user()->id) {
            return error('Invalid order id.');
        }
        if (empty($orderData->detail)) {
            return error('Order detail not found.');
        }
        foreach ($orderData->detail as $key => $orderDetail) {
            if ($orderDetail->service_id == SERVICE_DOCTOR_APPOINTMENT) {
                $orderDetailArr['transaction'] = \App\Models\DoctorAppointmentBooking::where('id', $orderDetail->ref_id)
                                ->with('hospital', 'doctor', 'user_patient', 'status', 'user')->first();
                $orderDetailArr['transaction']['doctor']['doctor_image_url'] = getUrl('image/doctor_profile');
                $orderCalculation = $this->getOrderCalculation($orderData, $orderDetail);
                $result = array_merge($orderDetailArr, $orderCalculation);
            }
            if ($orderDetail->service_id == SERVICE_SUBSCRIPTION_PLAN) {
                $orderDetailArr['transaction'] = \App\Models\UserSubscription::where('id', $orderDetail->ref_id)
                                ->with('subscription')->first();
                $orderCalculation = $this->getOrderCalculation($orderData, $orderDetail);
                $result = array_merge($orderDetailArr, $orderCalculation);
            }
            if ($orderDetail->service_id == SERVICE_LAB_REPORT) {
                $orderDetailArr['transaction'] = \App\Models\LabBooking::where('id', $orderDetail->ref_id)
                                ->with('lab', 'labBookingDetail', 'labBookingDetail.test', 'user_patient', 'status', 'user')->first();
                $orderCalculation = $this->getOrderCalculation($orderData, $orderDetail);
                $result = array_merge($orderDetailArr, $orderCalculation);
            }
            if ($orderDetail->service_id == MENU_BASED_SERVICE) {
                $orderDetailArr['transaction'] = \App\Models\MenuBasedServiceBooking::where('id', $orderDetail->ref_id)
                                ->with('menuBasedService', 'menuBasedServiceBookingDetails', 'menuBasedServiceBookingDetails.menuBasedServiceFacility', 'userMember', 'status', 'user')->first();
                $orderCalculation = $this->getOrderCalculation($orderData, $orderDetail);
                $result = array_merge($orderDetailArr, $orderCalculation);
            }
            if ($orderDetail->service_id == SUBSCRIPTION_BASED_SERVICE) {
                $orderDetailArr['transaction'] = \App\Models\SubscriptionBasedServiceBooking::where('id', $orderDetail->ref_id)
                                ->with('subscriptionBasedService', 'subscriptionBasedService.city', 'subscriptionBasedService.state', 'subscriptionBasedService.category', 'subscriptionBasedServiceBookingDetails', 'subscriptionBasedServiceBookingDetails.subscriptionBasedServiceFacility', 'userMember', 'status', 'user')->first();
                $orderCalculation = $this->getOrderCalculation($orderData, $orderDetail);
                $result = array_merge($orderDetailArr, $orderCalculation);
            }
        }
        $result['status_code'] = statusWiseColor($orderData->status_id, True);
        return success($result, "Booking Data...");
    }

    private function getOrderCalculation($orderData, $orderDetail) {
        $orderDetailArr['order']['order_id'] = (int) $orderDetail['order_id'];
        $orderDetailArr['order']['transaction_id'] = (int) $orderDetail['id'];
        $orderDetailArr['order']['order_code'] = $orderData->order_code;
        $orderDetailArr['order']['status_id'] = $orderDetail->status_id;
        $orderDetailArr['order']['remark_color_code'] = $orderDetail->remark_color_code;
        $orderDetailArr['order']['remark'] = $orderDetail->remark;
        $orderPayment = $orderData->payment;
        $totalAmount = $orderDetail['coupon_amount'] + $orderDetail['wallet_amount'] + $orderDetail['pg_amount'];
        $orderDetailArr['calculation']['charges'][] = ['title' => 'Amount', 'symbol' => '', 'value' => numberFormat($totalAmount)];
        if (!empty($orderDetail['coupon_amount'])) {
            $orderDetailArr['calculation']['charges'][] = ['title' => 'Coupon Amount', 'symbol' => '-', 'value' => numberFormat($orderDetail['coupon_amount']), 'color' => '#209f7b'];
        }
        if (!empty($orderDetail['wallet_amount'])) {
            $orderDetailArr['calculation']['charges'][] = ['title' => 'Wallet Amount', 'symbol' => '-', 'value' => numberFormat($orderDetail['wallet_amount']), 'color' => '#209f7b'];
        }
        if (!empty($orderDetail['refund_amount'])) {
            $orderDetailArr['calculation']['charges'][] = ['title' => 'Refund Amount', 'symbol' => '-', 'value' => numberFormat($orderDetail['refund_amount'])];
        }
        $paidAmount = numberFormat($orderDetail['pg_amount']);
        if ($orderPayment->payment_mode_id == OFFLINE || $orderPayment->status_id != STATUS_DONE) {
            $paidAmount = '0.00';
        }
        $orderDetailArr['calculation']['grand_total'] = ['title' => 'Amount Paid', 'symbol' => '', 'value' => $paidAmount];
        $orderDetailArr['payment_method'] = ['title' => 'Paid Via', 'symbol' => '', 'value' => $orderPayment->payment_mode_id];
        return $orderDetailArr;
    }

}
