<?php

namespace App\Http\Controllers\API;

use App\Http\Resources\HospitalCollection;
use App\Http\Controllers\Controller;
use App\Models\Hospital;
use Illuminate\Http\Request;

class HospitalController extends Controller {

    /**
     * Display a listing of the resource.
     *
     * @param Request $request
     * @return HospitalCollection
     */
    public function index(Request $request) {
        $hospital = Hospital::where('status_id', 1);
        if ($request->name != null) {
            $hospital = $hospital
                    ->where('name', 'like', '%' . $request->name . '%');
        }
        /*
         *  Here we have to add other param for searching like lat, lng we will do that later after discussion
         */
        return new HospitalCollection($hospital->paginate(20));
    }

    public function doctorWiseHospitalDetail(Request $request) {
        if (empty($request->doctor_id)) {
            return error("Sorry, Doctor id is empty");
        }
        if (empty($request->hospital_id)) {
            return error("Sorry, Hospital id is empty");
        }
        $request->merge(['is_app' => 1]);
        $hospitalMapping = \App\Models\DoctorHospitalMapping::where('doctor_id', $request->doctor_id)
                        ->where('hospital_id', $request->hospital_id)
                        ->with('hospital')->first();
        if (empty($hospitalMapping)) {
            return error("Sorry, Doctor is not observed in this hospital");
        }
        $hospital = Hospital::where('status_id', 1)
                        ->where('id', $request->hospital_id)
                        ->with('hospital_details', 'state', 'city')->first();
        if (empty($hospital)) {
            return error("Sorry, Hospital data not found");
        }
        $result['fees'] = $hospitalMapping->fees;
        $result['discount'] = $hospitalMapping->discount;
        $result['video_consultation_available'] = $hospitalMapping->video_consultation_available;
        $result['doctor_timing'] = json_decode($hospitalMapping->timing_json);
        $result['hospital'] = $hospital;
        $result['hospital']['image_url'] = getUrl('image/hospital');
        $result['hospital']['image_url_gallery'] = getUrl('image/hospital_gallery');
        $result['hospital']['cancel_policy'] = json_decode($hospital->cancel_policy);
        $result['hospital']['cancel_policy_setting'] = json_decode($hospital->cancel_policy_setting);
        if (!empty($hospital->hospital_details)) {
            $result['hospital']['hospital_details']['gallery_json'] = !empty($hospital->hospital_details->gallery_json) ? json_decode($hospital->hospital_details->gallery_json) : $hospital->hospital_details->gallery_json;
        }
        return success($result, "Hospital details...");
    }

}
