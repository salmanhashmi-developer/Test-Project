<?php

namespace App\Http\Controllers\API;

use App\Http\Resources\SubMenuCollection;
use App\Http\Controllers\Controller;
use App\Models\SubMenu;
use Illuminate\Http\Request;

class SubMenuController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        return new SubMenuCollection(SubMenu::where([
            'active' => 1,
        ])->orderBy("sort_order", "desc")->get());
    }

}
