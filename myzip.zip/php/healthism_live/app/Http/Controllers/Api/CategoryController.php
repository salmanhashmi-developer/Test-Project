<?php

namespace App\Http\Controllers\API;

use App\Http\Resources\CategoryCollection;
use App\Http\Controllers\Controller;
use App\Models\Category;
use Illuminate\Http\Request;

class CategoryController extends Controller {

    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index(Request $request) {
        $categoryId = !empty($request->category_id) ? $request->category_id : 0;
        $categoryList = \App\Models\Category::where('parent_id', $categoryId)->where('active', STATUS_ACTIVE)->orderBy('sort_order', 'ASC')->orderBy('name', 'ASC')->with('parentcategory')->get();
        if (!empty($categoryList)) {
            foreach ($categoryList as $key => $category) {
                $subCategory = \App\Models\Category::where('parent_id', $category->id)->where('active', STATUS_ACTIVE)->orderBy('sort_order', 'ASC')->get()->toArray();
                if (!empty(count($subCategory))) {
                    if ($category['id'] == 1) {
                        //Health
                        $dieticianData['id'] = 17;
                        $dieticianData['name'] = 'Dietician';
                        $dieticianData['parent_id'] = 3;
                        $dieticianData['image'] = '1.png';
                        $subCategory[1] = $dieticianData;
                    }
                    $categoryList[$key]['sub_category'] = $subCategory;
                }
            }
        }
        if ($categoryId == 1) {
            $dieticianData['id'] = 17;
            $dieticianData['name'] = 'Dietician';
            $dieticianData['parent_id'] = 3;
            $dieticianData['image'] = '1.png';
            $categoryList[] = $dieticianData;
        }
        $result['image_url'] = getUrl('image/category/');
        $result['category'] = $categoryList;
        return success($result, "Category list");
    }

    /**
     * Display the specified resource.
     *
     * @param  \App\Models\Category  $category
     * @return \Illuminate\Http\Response
     */
    public function show(Category $category) {
        //
    }

}
