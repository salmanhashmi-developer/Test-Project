<?php

namespace App\Http\Controllers\API;

use App\Http\Controllers\Controller;
use App\Http\Repository\LabRepository;
use Illuminate\Http\Request;

class LabController extends Controller {

    private $labRepository;

    public function __construct(LabRepository $labRepository) {
        $this->labRepository = $labRepository;
    }

    public function clicktoCall() {
        return success([
            'mobile' => LAB_CLICK_TO_CALL,
            'mobile2' => COMMON_MOBILE_NO
                ], 'Done...');
    }

    public function search(Request $request) {
        $latitude = $request->header('latitudeUserLocation');
        $longitude = $request->header('longitudeUserLocation');
        $pincode = $request->header('postalCodeUserLocation');
        $input = $request->all();
        if (empty($latitude) || empty($longitude)) {
            return error("Sorry, Latitude/Longitude is empty.");
        }
        if (empty($input['name'])) {
            return error("Sorry, Name is empty");
        }
        $type = !empty($input['type']) ? $input['type'] : 'Test';
        if ($type == 'Test') {
            $result = $this->labRepository->getTestFromLocation($latitude, $longitude, $pincode, $input);
        } else {
            $result = $this->getLabData($latitude, $longitude, $pincode, $input);
        }
        return success($result, 'Search data');
    }

    public function lebListing(Request $request) {
        try {
            $latitude = $request->header('latitudeUserLocation');
            $longitude = $request->header('longitudeUserLocation');
            $pincode = $request->header('postalCodeUserLocation');
            $input = $request->all();
            if ($request->user()->id == 74) {
                $latitude = '18.969538920783755';
                $longitude = '72.81932909041643';
                $pincode = '400008';
            } else {
                if (empty($latitude) || empty($longitude)) {
                    return error("Sorry, Latitude/Longitude is empty.");
                }
            }
            $healthismLab = [];
            $result = [];
            $page = !empty($input['page']) ? $input['page'] : 1;
            $allLab = $this->getLabData($latitude, $longitude, $pincode, $input);
            if ($page == 1) {
                $healthismLab = $this->getHealthismLabData();
            }
            if (empty($allLab)) {
                $result = $healthismLab;
            } else {
                if (!empty($healthismLab) && !empty($healthismLab[0])) {
                    $result[] = $healthismLab[0];
                }
                if (!empty($result)) {
                    foreach ($allLab as $value) {
                        $result[] = $value;
                    }
                } else {
                    $result = $allLab;
                }
            }
            return success($result, 'Lab data list');
        } catch (Exception $exc) {
            errorLog($exc);
        }
        return error(COMMON_ERROR);
    }

    private function getHealthismLabData() {
        $query = "SELECT
                        l.id AS lab_id,
                        l.parent_id AS lab_parent_id,
                        l.self_test_available,
                        l.NAME AS lab_name,
                        concat( 'http://api.healthismplus.com/image/lab/', l.photo ) AS lab_photo,
                        l.address1 AS lab_address1,
                        l.address2 AS lab_addres2,
                        l.area AS lab_area,
                        l.pincode AS lab_pincode,
                        l.virtual_location AS lab_virtual_location,
                        l.discount AS discount,
                        s.`name` AS state_name,
                        c.`name` AS city_name,
                        ( SELECT COUNT(*) FROM review WHERE ref_id = ls.lab_id AND service_id =" . SERVICE_LAB_REPORT . " AND status_id = " . STATUS_APPROVED . " ) AS review_count,
                        ROUND(( SELECT AVG( rating ) FROM review WHERE ref_id = ls.lab_id AND service_id = " . SERVICE_LAB_REPORT . " AND status_id = " . STATUS_APPROVED . "), 1 ) AS lab_rating 
                    FROM
                        (SELECT ls.* FROM lab_search ls) ls
                        JOIN lab AS l ON ( ls.lab_id = l.id AND l.status_id = 1 )
                        LEFT JOIN state AS s ON ls.state_id = s.id
                        LEFT JOIN city AS c ON ls.city_id = c.id 
                     WHERE 
                        l.id =" . HEALTHISM_LAB_ID;

        $result = executeSelectQueryOnMySQLDB($query);
        return $result;
    }

    private function getLabData($latitude, $longitude, $pincode, $input) {
        $limit = 25;
        $page = !empty($input['page']) ? $input['page'] : 1;
        $skip = $page > 1 ? ($page * $limit) - $limit : 0;
        $query = "SELECT
                        l.id AS lab_id,
                        l.parent_id AS lab_parent_id,
                        l.self_test_available,
                        l.name AS lab_name,
                        concat('" . getUrl('image/lab') . "',l.photo) AS lab_photo,
                        l.address1 AS lab_address1,
                        l.address2 AS lab_addres2,
                        l.area AS lab_area,
                        l.pincode AS lab_pincode,
                        l.virtual_location AS lab_virtual_location,
                        l.discount AS discount,
                        s.`name` AS state_name,
                        c.`name` AS city_name,
                        haversine ( '" . $latitude . "', '" . $longitude . "', ls.latitude, ls.longitude ) AS lab_distance,
                        ( SELECT COUNT(*) FROM review WHERE ref_id = ls.lab_id AND service_id = " . SERVICE_LAB_REPORT . " AND status_id = " . STATUS_APPROVED . " ) AS review_count,
                        ROUND(( SELECT AVG( rating ) FROM review WHERE ref_id = ls.lab_id AND service_id =" . SERVICE_LAB_REPORT . " AND status_id = " . STATUS_APPROVED . "), 1 ) AS lab_rating 
                FROM
                        ( SELECT ls.*, haversine ( '" . $latitude . "', '" . $longitude . "', ls.latitude, ls.longitude ) AS 'distance' FROM lab_search ls ORDER BY distance ) ls
                        JOIN lab AS l ON (ls.lab_id = l.id AND l.status_id = 1)
                        LEFT JOIN state AS s ON ls.state_id = s.id
                        LEFT JOIN city AS c ON ls.city_id = c.id 
                WHERE  
                        1=1
                        AND (";
        if (!empty($pincode)) {
            $query .= "ls.pincode = '" . $pincode . "' OR ";
        }
        $query .= "ls.distance < " . LAB_DISTANCE . " )";
        if (!empty($input['name'])) {
            $query .= " AND ls.`name` like  '%" . $input['name'] . "%' ";
        }
        $query .= " GROUP BY l.id";
        $query .= " ORDER BY ls.distance";
        $query .= " LIMIT " . $limit . " OFFSET " . $skip;
        //pr($query);
        $result = executeSelectQueryOnMySQLDB($query);
        return $result;
    }

    public function labDetail(Request $request) {
        $input = $request->all();
        if (empty($input['lab_id'])) {
            return error("Sorry, Lab id is empty");
        }
        $result = \App\Models\Lab::where('id', $input['lab_id'])->with('lab_details', 'state', 'city')->first();
        if ($result->status_id != STATUS_ACTIVE) {
            return error("Sorry, This Lab currently not available for service.");
        }
        return success($result, 'Lab data');
    }

    public function labSlotList(Request $request) {
        //This Function also use in admin lab booking flow
        try {
            $input = $request->all();
            if (empty($input['lab_id'])) {
                return error("Sorry, Lab id is empty.");
            }
            if (empty($input['test_collection_type'])) {
                return error("Sorry, Slot type is empty.");
            }
            $lab = \App\Models\Lab::findOrFail($input['lab_id']);
            if ($lab['status_id'] != STATUS_ACTIVE) {
                return error("Sorry, This Lab currently not available for service.");
            }
            if ($lab['virtual_location'] == 1 && $input['test_collection_type'] == 1) {
                return error("Sorry, Test at lab not possible.");
            }
            $result = $this->getLabSlotByDay($input);
            if (!empty($input['platform_id']) && $input['platform_id'] = WEB) {
                if (!empty($result)) {
                    $result = $this->getSlotUi($result);
                }
            }
            return success($result, "Lab slot list...");
        } catch (Exception $exc) {
            errorLog($exc);
        }
        return error(COMMON_ERROR);
    }

    private function getSlotUi($param) {
        $html = "";
        foreach ($param as $value) {
            $html .= '<div class="col-md-12" style="border-bottom: 1px solid;padding: 30px 20px 10px 20px;"><span style="font-size: 13px;font-weight: 600;color: #2caa8a;">';
            $html .= date("d/m/Y", strtotime($value['date'])) . '-' . $value['day'];
            $html .= '</span></div>';
            foreach ($value['slot'] as $slot) {
                $from = $value['date'] . ' ' . $slot['from_time'];
                $to = $value['date'] . ' ' . $slot['to_time'];
                $slotdata = date('d/m/Y', strtotime($from)) . ' - ' . $value['day'] . ' at ' . date('h:i A', strtotime($from));
                $html .= '<div class="col-md-3 mt-1">';
                $html .= '<a data-slot-id="' . $slot['id'] . '" data-slot-date="' . $value['date'] . '" data-slot="' . $slotdata . '" data-action="select-slot" class="slot-data">';
                $html .= '<span style="padding: 5px;background: aliceblue;">' . date("h:i A", strtotime($from)) . '-' . date("h:i A", strtotime($to)) . '</span>';
                $html .= '</a>';
                $html .= '</div>';
            }
        }
        return $html;
    }

    private function getLabSlotByDay($input) {
        $weekOfdays = array();
        $noOfDay = !empty($input['no_of_day']) ? $input['no_of_day'] : 6;
        $todayDate = date('Y-m-d'); //today date
        if ($input['test_collection_type'] == 2) {
            //Home Collection : Start slot tommorow
            $todayDate = date('Y-m-d', strtotime('+1 day', strtotime($todayDate)));
        }
        for ($i = 0; $i <= $noOfDay; $i++) {

            $date = date('Y-m-d', strtotime('+' . $i . ' day', strtotime($todayDate)));

            $day = date('D', strtotime($date));
            $date = date('Y-m-d', strtotime($date));
            $checkDateBlock = \App\Models\LabBlockSlot::where('lab_id', $input['lab_id'])
                    ->where('date', $date)
                    ->whereNull('lab_slot_id')
                    ->count();
            if (empty($checkDateBlock)) {
                $slot = $this->getSlotByDay($input, $day, $date);
                $slotCount = count($slot) > 0 ? count($slot) : 0;
                if ($slotCount != 0) {
                    $weekOfdays[] = array(
                        "day" => $day,
                        "date" => $date,
                        "slot_count" => $slotCount,
                        "slot" => $slot,
                    );
                }
            }
        }
        return $weekOfdays;
    }

    private function getSlotByDay($input, $day, $date) {
        try {
            $query = "SELECT
                        ls.*,
                        ls.id AS slot_id
                FROM
                        lab_slot AS ls 
                WHERE
                        ls.lab_id = " . $input['lab_id'];
            if ($input['test_collection_type'] == 1) {
                //Report at lab
                $query .= " AND ls.is_offline = 1";
            }
            if ($input['test_collection_type'] == 2) {
                //Home collection
                $query .= " AND ls.is_home_collection = 1";
            }
            $query .= " AND ls.status_id = " . STATUS_ACTIVE . "
                        AND ls.`day` = '" . $day . "' 
                        AND (
                                ls.id NOT IN ( 
                                SELECT lab_slot_id FROM lab_block_slot
                                WHERE date = '" . $date . "'
                            )
                        )";
            if ($date == date('Y-m-d')) {
                $query .= " AND ls.from_time >= '" . date('H:i:s') . "'";
            }
            $query .= " ORDER BY 
                            ls.from_time ASC";

            //For to time to greter : AND ls.from_time >= '" . date('H:i:s') . "'
            return executeSelectQueryOnMySQLDB($query);
        } catch (Exception $exc) {
            errorLog($exc);
        }
        return error(COMMON_ERROR);
    }

}
