<?php

namespace App\Http\Controllers\API;

use App\Http\Controllers\Controller;
use App\Models\ReportProblem;
use Illuminate\Http\Request;

class ReportController extends Controller {

    public function reportTypeList() {
        return success(\App\Models\ReportProblemType::all(), "Report type list");
    }

    public function store(Request $request) {
        $rules = ReportProblem::$rules;
        if (sizeof($rules) > 0) {
            $validation = $this->validateRequest($request, $rules);
            if (!empty($validation)) {
                return error($validation);
            }
        }
        $input = $request->all();
        $input['created_at'] = date('Y-m-d H:i:s');
        $input['user_id'] = $request->user()->id;
        $input['status_id'] = STATUS_PENDING;
        $input['type'] = ',' . $input['type'] . ',';
        $result = ReportProblem::create($input);
        return success($result, "Report has been saved successfully");
    }

}
