<?php

namespace App\Http\Controllers\API;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;

class ClickToCallController extends Controller {

    public function clickToCallDoctor(Request $request) {
        if (empty($request->doctor_id)) {
            return error("Sorry, Doctor id is empty");
        }
        $doctorData = HEALTHISMPLUS_DOCTOR_LIST[$request->doctor_id];
        if (empty($doctorData)) {
            return error("Sorry, Doctor data not found");
        }
        if (empty($request->user()->mobile)) {
            return error("Please, Add your mobile number in profile for this service");
        }
        $specialPlanBenefits = getSpecialPlanBenefits($request->user()->id);
        if (empty($specialPlanBenefits)) {
            return error("Sorry, Your special plan is expired.");
        }
        $url = "https://mcube.vmc.in/api/outboundcall?apikey=8f3f5a706e940b538271843dc7960f19&exenumber=" . $doctorData['mobile'] . "&custnumber=" . $request->user()->mobile . "&url=1";
        $response = curl_GET($url);
        \App\Models\Log::create([
            'created_by' => $request->user()->id,
            'type' => 'CLICK_TO_CALL',
            'sub_type' => 'DOCTOR',
            'log_detail' => $request->user()->first_name . " " . $request->user()->last_name . "(" . $request->user()->mobile . ") call to doctor " . $doctorData['name'] . "(" . $doctorData['mobile'] . ")",
            'ip' => $request->ip(),
            'extra_detail' => json_encode($response),
            'created_at' => date('Y-m-d H:i:s'),
        ]);
        return success($response, "We will contact you shortly");
    }

}
