<?php

namespace App\Http\Controllers\API;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use App\Models\MenuBasedServiceBooking;
use App\Http\Controllers\Api\OrderPaymentController;
use App\Http\Repository\NotificationRepository;
use App\Http\Repository\OfferRepository;
use Illuminate\Support\Facades\DB;
use Exception;

class MenuBasedServiceBookingController extends Controller {

    private $orderPaymentController;
    private $notificationRepository;
    private $offerRepository;

    public function __construct(OrderPaymentController $orderPaymentController, OfferRepository $offerRepository, NotificationRepository $notificationRepository) {
        $this->orderPaymentController = $orderPaymentController;
        $this->notificationRepository = $notificationRepository;
        $this->offerRepository = $offerRepository;
    }

    public function promocodeTest() {
        $result = [];
        $response = $this->offerRepository->applyOfferCode('DEV-TEST', MENU_BASED_SERVICE, 2, 1500);
        return success($response, "Test...");
    }

    public function menuBasedServiceCart(Request $request) {
        try {
            $input = $request->all();
            if (empty($input['menu_based_service_id'])) {
                return error("Sorry, Menu based service id is empty");
            }
            if (empty($input['facility_ids'])) {
                return error("Sorry, Facility ids is empty");
            }
            $result = $this->cartValidation($input);
            if ($result['code'] == 0) {
                return error($result['message'], $result['data']);
            }
            return success($result['data'], "Yor cart is ready!");
        } catch (Exception $exc) {
            errorLog($exc);
        }
        return error(COMMON_ERROR);
    }

    public function cartValidation($input) {
        try {
            $response = ['code' => 0, 'data' => [], 'message' => COMMON_ERROR];
            $menuBasedService = \App\Models\MenuBasedService::where('id', $input['menu_based_service_id'])->with('state', 'city')->first();
            if (empty($menuBasedService)) {
                $response['message'] = "Sorry, Service data not found";
                return $response;
            }
            if ($menuBasedService['status_id'] != STATUS_ACTIVE) {
                $response['message'] = "Sorry, This service currently not available for service.";
                return $response;
            }
            $facilityIdArr = explode(',', $input['facility_ids']);
            $facilityList = \App\Models\MenuBasedServiceFacility::whereIn('id', $facilityIdArr)->get();
            $facilityCount = count($facilityList);
            $error = 0;
            $facilityData = [];
            foreach ($facilityList as $key => $facility) {
                $facilityData[$key] = $facility;
                if ($facility['status_id'] != STATUS_ACTIVE) {
                    $response['message'] = $facility['name'] . " currently not available!";
                    return $response;
                }
//                if ($facility['is_package'] == 1 && $facilityCount > 1) {
//                    $response['message'] = "Sorry, Only single package add";
//                    return $response;
//                }
                //check facility in branch or Menu Based Service
                if (!in_array($facility['menu_based_service_id'], [$menuBasedService['id'], $menuBasedService['parent_id']])) {
                    $response['message'] = $facility['name'] . "  not serve by service";
                    return $response;
                }
            }
            if ($error == 0) {
                $response['code'] = 1;
            } else {
                $response['code'] = 0;
            }
            $response['data']['facility_list'] = $facilityData;
            $response['data']['menu_based_service'] = $menuBasedService;
            return $response;
        } catch (Exception $exc) {
            errorLog($exc);
        }
        return error(COMMON_ERROR);
    }

    public function bookingPage(Request $request) {
        $input = $request->all();
        $result = [];
        $input['login_user_id'] = $request->user()->id;
        $input['login_user_mobile'] = $request->user()->mobile;
        $input['login_user_type'] = $request->user()->user_type_id;
        $bookingValidation = $this->MBSBookingValidation($input);
        if (isset($bookingValidation[0]) && $bookingValidation[0] == 0) {
            return error($bookingValidation[1]);
        }
        $orderRefId = KEY_ORDER_REF_ID . "_" . $request->user()->id . '_' . time();
        setRedisData($orderRefId, 0);
        $result['order_ref_id'] = $orderRefId;
        $result['slot_data'] = $bookingValidation['slot_data'];
        $result['user_patient'] = $bookingValidation['user_patient'];
        $result['payment_mode'] = getPaymentMode(MENU_BASED_SERVICE);
        $cartValidation = $this->cartValidation($input);
        $result['cart_data'] = $cartValidation['data']['facility_list'];
        $result['menu_based_service_data'] = $cartValidation['data']['menu_based_service'];
        $result['calculation'] = $this->bookingCalculation($result);
        if ($cartValidation['code'] == 0) {
            return error($cartValidation['message'], $result);
        }
        return success($result, "Booking Data...");
    }

    /* Calculation Of Booking */

    private function bookingCalculation($data) {
        $amount = 0;
        $discount = 0;
        $bookingCharges = !empty($data['slot_data']['charge']) ? $data['slot_data']['charge'] : '0.00';
        foreach ($data['cart_data'] as $key => $facility) {
            $amount = $amount + $facility['price'];
            $discount = $discount + (($facility['price'] * $facility['discount']) / 100);
        }
        $result['charges'] = array(
            ['title' => 'Amount', 'value' => numberFormat($amount), 'symbol' => '+'],
            ['title' => 'Booking Charge', 'value' => $bookingCharges, 'symbol' => '+'],
            ['title' => 'Healthismplus Discount', 'value' => numberFormat($discount), 'symbol' => '-', 'color' => '#209f7b']
        );
        $grandTotal = ((int) $amount - (int) $discount) + $bookingCharges;
        $result['grandTotal'] = ['title' => 'Total Payable', 'value' => numberFormat($grandTotal)];
        if (!empty($discount)) {
            $result['discountMessage'] = 'You will save RS. ' . numberFormat($discount) . ' on this';
        }
        $result['amount'] = $grandTotal;
        $result['discount'] = $discount;
        $result['charge'] = $bookingCharges;
        return $result;
    }

    /* Use booking menu based service validation function for booking and payment time */

    private function MBSBookingValidation($input) {
        $result = null;
        if (empty($input['menu_based_service_slot_id'])) {
            return array(0, "Sorry, slot id is empty");
        }
        if (empty($input['user_patient_id'])) {
            return array(0, "Sorry, User patient id is empty");
        }
        if (empty($input['date'])) {
            return array(0, "Sorry, Date is empty");
        }
        if (empty($input['menu_based_service_id'])) {
            return array(0, "Sorry, Menu based service id is empty");
        }
        if (empty($input['facility_ids'])) {
            return array(0, "Sorry, Facility ids is empty");
        }
        if (empty($input['platform_id'])) {
            return array(0, "Sorry, Platform id is empty");
        }
        $userSubscription = getUserSubscription($input['login_user_id']);
        if (empty($userSubscription)) {
            return array(0, "Sorry, No activate plan available");
        } else {
            if ($userSubscription['expire'] == 1) {
                return array(0, "Please renew plan, Your plan is expired");
            }
        }
        $slot = \App\Models\MenuBasedServiceSlot::where('id', $input['menu_based_service_slot_id'])->first();
        if (empty($slot)) {
            return array(0, "Sorry, Slot data not found.");
        } else {
            if ($slot['menu_based_service_id'] != $input['menu_based_service_id']) {
                return array(0, "Sorry, Selected Slot not assign to service.");
            }
        }
        $checkSlotBlocked = \App\Models\MenuBasedServiceBlockSlot::where(
                        [
                            'menu_based_service_slot_id' => $input['menu_based_service_slot_id'],
                            'date' => $input['date']
                ])->count();
        if ($checkSlotBlocked > 0) {
            return array(0, "Sorry, Slot has been blocked");
        }
        $patientData = \App\Models\UserPatientMapping::where('id', $input['user_patient_id'])->first();
        if (empty($patientData)) {
            return array(0, 'Sorry, Patient data not found');
        } else {

            if ($patientData->user_id != $input['login_user_id']) {
                return array(0, 'Sorry, You have not mapped with Patient');
            }

            if ($patientData->status_id != STATUS_ACTIVE) {
                return array(0, 'Sorry, Patient is blocked.');
            }
            if ($patientData->is_deleted == 1) {
                return array(0, 'Sorry, Patient was deleted.');
            }
        }
        $result['slot_data'] = $slot;
        $result['user_patient'] = $patientData;
        $result['user_subscription'] = $userSubscription;
        return $result;
    }

    public function orderPayment(Request $request) {
        try {
            $input = $request->all();
            if (empty($input['order_ref_id'])) {
                return error('Sorry, Order ref id is empty');
            } else {
                $orderId = getDataFromRedisKey($input['order_ref_id']);
                if (!empty($orderId)) {
                    return error(COMMON_ERROR, ['order_id' => $orderId, 'message' => 'Order already processed']);
                }
            }
            $input['ip'] = $request->ip();
            if (empty($input['payment_mode_id'])) {
                return error("Sorry, Payment mode id is empty.");
            } else {
                $paymentMode = paymentMethodValidation($input['payment_mode_id']);
                if ($paymentMode['data'] == 0) {
                    return error($paymentMode['message']);
                }
                $paymentMode = $paymentMode['data'];
            }
            if (empty($input['platform_id'])) {
                return error("Sorry, Platform id is empty.");
            }

            $input['login_user_id'] = $request->user()->id;
            $input['login_user_email'] = $request->user()->email;
            $input['login_user_mobile'] = $request->user()->mobile;
            $input['login_user_type'] = $request->user()->user_type_id;

            $validation = $this->MBSBookingValidation($input);
            if (isset($validation[0]) && $validation[0] == 0) {
                return error($validation[1]);
            }
            $slotData = $validation['slot_data'];
            $userPatient = $validation['user_patient'];

            $cartValidation = $this->cartValidation($input);
            if ($cartValidation['code'] == 0) {
                return error($cartValidation['message']);
            }
            $menuBasedServiceData = $cartValidation['data']['menu_based_service'];
            $facilityData = $cartValidation['data']['facility_list'];

            $input['user_subscription_id'] = $validation['user_subscription']['id'];
            $statusId = STATUS_PENDING;
            if ($paymentMode['id'] == OFFLINE) {
                if ($menuBasedServiceData['cash_booking_allowed'] != 1) {
                    return error("Sorry, Service not allowed offline(cash) booking");
                }
                $statusId = STATUS_SUCCESS;
            }
            $amountCalculation = $this->bookingCalculation(array('cart_data' => $cartValidation['data']['facility_list'], 'slot_data' => $slotData));
            $input['charges'] = $amountCalculation['charge'];
            try {
                /* ------------------------------------------
                  --------------------------------------------
                  Start DB Transaction
                  --------------------------------------------
                  -------------------------------------------- */
                DB::beginTransaction();
                $bookingInsertedData = [
                    'user_id' => $input['login_user_id'],
                    'user_subscription_id' => $input['user_subscription_id'],
                    'menu_based_service_id' => $menuBasedServiceData['id'],
                    'menu_based_service_parent_id' => $menuBasedServiceData['parent_id'],
                    'menu_based_service_category_id' => $menuBasedServiceData['category_id'],
                    'user_member_id' => $userPatient['id'],
                    'member_name' => $userPatient['first_name'] . ' ' . $userPatient['last_name'],
                    'member_mobile' => $userPatient['mobile'],
                    'menu_based_service_slot_id' => $input['menu_based_service_slot_id'],
                    'appointment_date' => $input['date'],
                    'appointment_time' => $slotData['from_time'],
                    'amount' => $amountCalculation['amount'],
                    'discount' => $amountCalculation['discount'],
                    'created_by' => $input['login_user_id'],
                    'status_id' => $statusId,
                    'created_at' => date('Y-m-d H:i:s'),
                ];
                $bookingData = MenuBasedServiceBooking::create($bookingInsertedData);
                if (empty($bookingData['id'])) {
                    return error("Sorry, Something went wrong.");
                } else {
                    foreach ($facilityData as $key => $facility) {
                        $discount = ($facility['price'] * $facility['discount']) / 100;
                        $bookingDetailData = [
                            'menu_based_service_booking_id' => $bookingData['id'],
                            'menu_based_service_id' => $bookingData['menu_based_service_id'],
                            'menu_based_service_parent_id' => $bookingData['menu_based_service_parent_id'],
                            'menu_based_service_facility_id' => $facility['id'],
                            'amount' => $facility['price'] - $discount,
                            'discount' => $discount,
                            'created_at' => date('Y-m-d H:i:s')
                        ];
                        \App\Models\MenuBasedServiceBookingDetails::create($bookingDetailData);
                    }
                }
                $result = $this->createOrder($bookingData, $menuBasedServiceData, $paymentMode, $input);
            } catch (Exception $exc) {
                /* ------------------------------------------
                  --------------------------------------------
                  Rollback Database Entry
                  --------------------------------------------
                  -------------------------------------------- */
                errorLog($exc);
                DB::rollback();
            }
            if (!empty($result)) {
                if (empty($result['error'])) {
                    return success($result, "Thank you");
                } else {
                    return error(COMMON_ERROR, ['order_id' => $result['order_id'], 'message' => $result['error_message']]);
                }
            } else {
                return error(COMMON_ERROR);
            }
        } catch (Exception $exc) {
            errorLog($exc);
        }
        return error(COMMON_ERROR);
    }

    private function createOrder($bookingData, $menuBasedServiceData, $paymentMode, $input) {
        try {
            $categoryName = $bookingData['menuBasedService']['category']['name'];
            $ds1 = $categoryName . ' booking for ' . $bookingData['member_name'];
            $ds2 = $categoryName . ' : ' . $bookingData['menuBasedService']['name'];
            $time = strtotime($bookingData['appointment_date'] . ' ' . $bookingData['appointment_time']);
            $ds3 = 'Facility Time : ' . date('d/M/Y h:i A', $time);
            $descripationArr = ["desc1" => $ds1, "desc2" => $ds2, "desc3" => $ds3];
            $transactionArr = [
                $categoryName => $menuBasedServiceData['name'],
                'member_name' => $bookingData['member_name'],
                'member_mobile' => $bookingData['member_mobile'],
                'appointment_date_time' => $bookingData['appointment_date'] . ' ' . $bookingData['appointment_time'],
            ];
            $statusId = STATUS_SENT_ON_PG;
            $status = 'SENT ON PG';
            $remark = "PAYMENT PENDING";
            $paymentRemark = "PAYMENT PENDING";
            $color = statusWiseColor(STATUS_SENT_ON_PG);
            if ($paymentMode['id'] == OFFLINE) {
                $statusId = STATUS_DONE;
                $status = 'DONE';
                $remark = "ORDER CONFIRM PAY AT " . strtoupper($categoryName);
                $paymentRemark = "PAYMENT PENDING PAY AT " . strtoupper($categoryName);
                $color = statusWiseColor(STATUS_DONE);
            }

            /* ........... CRETAE NEW ORDER............ */
            $orderArr = [
                'order_code' => 'MBS' . platformCode($input['platform_id']) . $input['login_user_id'] . time(),
                'user_id' => $input['login_user_id'],
                'user_subscription_id' => $input['user_subscription_id'],
                'service_id' => MENU_BASED_SERVICE,
                'amount' => $bookingData['amount'],
                'status_id' => $statusId,
                'remark' => $remark,
                'charges' => $input['charges'],
                'remark_color_code' => $color,
                'description_json' => json_encode($descripationArr),
                'transaction_json' => json_encode($transactionArr),
            ];
            $order = $this->orderPaymentController->createOrder($orderArr);
            if (!empty($order['id'])) {
                setRedisData($input['order_ref_id'], $order['id']);

                $menuBasedServiceBookingUpdate = \App\Models\MenuBasedServiceBooking::findOrFail($bookingData['id']);
                $menuBasedServiceBookingUpdate->fill(['order_id' => $order['id']])->save();

                /* ........... CRETAE NEW ORDER HISTORY............ */
                $orderHistoryArr = [
                    'order_id' => $order['id'],
                    'type' => 'ORDER',
                    'status_id' => $statusId,
                    'remark' => $remark,
                    'updated_by' => $input['login_user_id']
                ];
                $this->orderPaymentController->saveOrderHistory($orderHistoryArr);

                /* ........... CRETAE NEW ORDER DETAIL............ */
                $orderDeatilArr = [
                    'order_id' => $order['id'],
                    'service_id' => MENU_BASED_SERVICE,
                    'ref_id' => $bookingData['id'],
                    'coupon_id' => null,
                    'coupon_amount' => null,
                    'wallet_amount' => null,
                    'pg_amount' => $bookingData['amount'],
                    'paid_amount' => $bookingData['amount'],
                    'tax' => null,
                    'charges' => $input['charges'],
                    'status_id' => $statusId,
                    'remark' => $remark,
                    'remark_color_code' => $color,
                ];
                $orderDeatil = $this->orderPaymentController->saveOrderDetail($orderDeatilArr);

                /* ........... CRETAE NEW ORDER DETAIL HISTORY............ */
                $orderDeatilHistoryArr = [
                    'order_id' => $order['id'],
                    'order_detail_id' => $orderDeatil['id'],
                    'type' => 'ORDER_DETAIL',
                    'status_id' => STATUS_PENDING,
                    'remark' => $remark,
                    'updated_by' => $input['login_user_id']
                ];
                $this->orderPaymentController->saveOrderHistory($orderDeatilHistoryArr);


                /* ........... CRETAE NEW ORDER PAYMENT............ */
                $orderPaymentArr = [
                    'order_id' => $order['id'],
                    'user_id' => $input['login_user_id'],
                    'payment_mode_id' => $paymentMode['id'],
                    'pg_amount' => $bookingData['amount'],
                    'status_id' => STATUS_PENDING,
                    'ip_address' => $input['ip'],
                ];
                $orderPayment = $this->orderPaymentController->saveOrderPayment($orderPaymentArr);

                /* ........... CRETAE NEW ORDER PAYMENT HISTORY............ */
                $paymentHistoryArr = [
                    'order_id' => $order['id'],
                    'type' => 'PAYMENT',
                    'status_id' => STATUS_PENDING,
                    'remark' => $paymentRemark,
                    'updated_by' => $input['login_user_id']
                ];
                $this->orderPaymentController->saveOrderHistory($paymentHistoryArr);
            }
            /* ------------------------------------------
              --------------------------------------------
              Commit Transaction to Save Data to Database
              --------------------------------------------
              -------------------------------------------- */
            DB::commit();

            $order['description'] = $categoryName . ' Appointment Booking';
            $order['mobile'] = $input['login_user_mobile'];
            $order['email'] = $input['login_user_email'];
            $order['payment_mode_id'] = $paymentMode['id'];
            $order['amount'] = $bookingData['amount']; //Pass on payment getaway
            $result = $this->orderPaymentController->makePayment($order);
            return $result;
        } catch (Exception $exc) {
            /* ------------------------------------------
              --------------------------------------------
              Rollback Database Entry
              --------------------------------------------
              -------------------------------------------- */
            DB::rollback();
            setRedisData($input['order_ref_id'], 0);
            errorLog($exc);
        }
        return 0;
    }

    public function rescheduleAppointment(Request $request) {
        try {
            $input = $request->all();
            $input['login_user_id'] = $request->user()->id;
            $input['login_user_mobile'] = $request->user()->mobile;
            $input['login_user_type'] = $request->user()->user_type_id;
            if (empty($input['appointment_id'])) {
                return error('Sorry, Appointment id is empty');
            }
            if (empty($input['menu_based_service_slot_id'])) {
                return error('Sorry, Slot id is empty');
            }
            if (empty($input['date'])) {
                return error('Sorry, Date is empty');
            }
            $appintmentData = \App\Models\MenuBasedServiceBooking::where('id', $input['appointment_id'])->first();
            $oldDate = date_format(date_create($appintmentData->appointment_date), "d/m/Y") . ' ' . $appintmentData->appointment_time;
            if (empty($appintmentData)) {
                return error('Sorry, Invalid appointment id');
            }

            if ($appintmentData->created_by != $input['login_user_id']) {
                return error('Sorry, You are not authorized to reschedule this appointment');
            }
            if ($appintmentData->status_id != STATUS_SUCCESS) {
                return error('Sorry, Your appointment has not been confirmed. so you cannot reschedule the appointment');
            }
            $date = $appintmentData->appointment_date . " " . $appintmentData->appointment_time;
            $dateNow = strtotime(date('Y-m-d H:i:s'));
            $rescheduleTime = strtotime(date('Y-m-d H:i:s', strtotime($date . ' -2 hours')));

            if ($dateNow > $rescheduleTime) {
                return array('code' => 0, 'message' => "Sorry, Reschedule time has been over");
            }

            $slotData = \App\Models\MenuBasedServiceSlot::where('id', $input['menu_based_service_slot_id'])->first();
            if (empty($slotData)) {
                return error('Sorry, Invalid slot id');
            }
            if ($appintmentData->menu_based_service_id != $slotData->menu_based_service_id) {
                return error("Sorry, Can't select other service slot.");
            }
            $checkSlotBlocked = \App\Models\MenuBasedServiceBlockSlot::where(
                            [
                                'menu_based_service_slot_id' => $input['menu_based_service_slot_id'],
                                'date' => $input['date']
                    ])->count();
            if ($checkSlotBlocked > 0) {
                return array(0, "Sorry, Slot has been blocked");
            }
            $result = $appintmentData->fill([
                        'menu_based_service_slot_id' => $input['menu_based_service_slot_id'],
                        'appointment_date' => $input['date'],
                        'appointment_time' => $slotData->from_time,
                    ])->save();

            $remark = "Reschedule Appointment : Old  Appointment - " . $oldDate
                    . ' New  Appointment - ' . $input['date'] . ' ' . $slotData->from_time;
            $this->orderPaymentController->saveOrderHistory([
                'order_id' => $appintmentData->order_id,
                'type' => 'TRACKING', 'status_id' => STATUS_SUCCESS,
                'remark' => $remark,
                'updated_by' => $input['login_user_id']
            ]);
            $this->notificationRepository->MBSAppointmentNotification($appintmentData->order_id, 'RESCHEDULE', ['old_date' => $oldDate]);
            return success($result, "Appointment rescheduled successfully!");
        } catch (Exception $exc) {
            errorLog($exc);
        }
        return error(COMMON_ERROR);
    }

    public function cancellationReason(Request $request) {
        if (empty($request->appointment_id)) {
            return error("Sorry, appointment id is empty");
        }
        $validation = $this->cancelationTimeValidation($request);
        if ($validation['code'] == 0) {
            return error($validation['message']);
        }
        $appintmentData = $validation['data'];
        $result['menu_based_service_name'] = $appintmentData->menuBasedService->name;
        $result['menu_based_service_area'] = $appintmentData->menuBasedService->area;
        $result['date'] = $appintmentData->appointment_date;
        $result['time'] = $appintmentData->appointment_time;
        $result['appointment_id'] = $appintmentData->id;
        $result['cancellation_reason'] = [
            'I am busy',
            'Forget about the appointment',
            'Changed my mind',
            'Visited another service provider',
            'Service provider asked me to cancel',
        ];
        return success($result, "Booking Data...");
    }

    public function cancellationDetail(Request $request) {
        if (empty($request->appointment_id)) {
            return error("Sorry, Appointment id is empty");
        }
        $validation = $this->cancelationTimeValidation($request);
        if ($validation['code'] == 0) {
            return error($validation['message']);
        }
        $appintmentData = $validation['data'];
        $orderDetail = \App\Models\OrderDetail::where('order_id', $appintmentData->order_id)
                        ->where('ref_id', $request->appointment_id)->first();
        if (empty($orderDetail)) {
            return error("Sorry, Order data not found");
        }
        $paymentModeId = \App\Models\OrderPayment::where('order_id', $appintmentData->order_id)->first()->payment_mode_id;
        $totalAmount = $orderDetail->coupon_amount + $orderDetail->wallet_amount + $orderDetail->pg_amount;
        $result['calculation']['charges'][] = ['title' => 'Amount', 'symbol' => '', 'value' => numberFormat($totalAmount - $orderDetail->charges)];
        $result['calculation']['charges'][] = ['title' => 'Charges', 'symbol' => '+', 'value' => numberFormat($orderDetail->charges)];

        if ($paymentModeId == OFFLINE) {
            $result['calculation']['grandTotal'] = ['title' => 'Amount Paid', 'value' => '0.00'];
        } else {
            if (!empty($orderDetail->coupon_amount)) {
                $result['calculation']['charges'][] = ['title' => 'Coupon Amount', 'symbol' => '-', 'value' => numberFormat($orderDetail->coupon_amount)];
            }
            if (!empty($orderDetail->wallet_amount)) {
                $result['calculation']['charges'][] = ['title' => 'Wallet Amount', 'symbol' => '-', 'value' => numberFormat($orderDetail->wallet_amount)];
            }
            $result['calculation']['grandTotal'] = ['title' => 'Amount Paid', 'value' => numberFormat($orderDetail->pg_amount)];
        }
        $cancelationCharges = $this->cancelationCharges($appintmentData);
        if ($paymentModeId == OFFLINE) {
            $result['refund_calculation']['charges'][] = ['title' => 'Amount Paid', 'value' => '0.00'];
            $result['refund_calculation']['charges'][] = ['title' => 'Cancellation Charges', 'symbol' => '-', 'value' => '0.00'];
            $result['refund_calculation']['grandTotal'] = ['title' => 'Amount Paid', 'value' => '0.00'];
        } else {
            $result['refund_calculation']['charges'][] = ['title' => 'Amount Paid', 'value' => numberFormat($orderDetail->pg_amount)];
            $result['refund_calculation']['charges'][] = ['title' => 'Cancellation Charges', 'symbol' => '-', 'value' => numberFormat($cancelationCharges)];
            $result['refund_calculation']['grandTotal'] = ['title' => 'Amount Paid', 'value' => numberFormat($orderDetail->pg_amount - $cancelationCharges)];
        }

        $result['payment_method'] = ['title' => 'Paid Via', 'symbol' => '', 'value' => $paymentModeId];
        $result['cancel_policy'] = !empty($appintmentData->menuBasedService->cancel_policy) ? json_decode($appintmentData->menuBasedService->cancel_policy, true) : MENU_BASED_SERVICE_CANCEL_POLICY;
        $result['reason'] = $request->reason;
        return success($result, "Booking Data...");
    }

    public function cancelOrder(Request $request) {
        try {
            if (empty($request->appointment_id)) {
                return error("Sorry, Appointment id is empty");
            }
            if (empty($request->reason)) {
                return error("Sorry, Reason is empty");
            }
            $validation = $this->cancelationTimeValidation($request);
            if ($validation['code'] == 0) {
                return error($validation['message']);
            }
            $appintmentData = $validation['data'];
            $orderDetail = \App\Models\OrderDetail::where('order_id', $appintmentData->order_id)
                            ->where('ref_id', $request->appointment_id)->first();
            if (empty($orderDetail)) {
                return error("Sorry, Order data not found");
            }
            $orderPayment = \App\Models\OrderPayment::where('order_id', $appintmentData->order_id)->first();
            $cancelationData['cancelationCharges'] = $request->user()->user_type_id == END_USER ? $this->cancelationCharges($appintmentData) : 0;
            if (!empty($orderPayment)) {
                if ($orderPayment->status_id == STATUS_DONE && $orderPayment->payment_mode_id == RAZORPAY) {
                    $cancelationData['refundAmount'] = $orderDetail->pg_amount - $cancelationData['cancelationCharges'];
                }
            }
            $cancelationData['reason'] = $request->reason;
            $cancelationData['order_id'] = $appintmentData->order_id;
            $cancelationData['order_detail_id'] = $orderDetail->id;
            $cancelationData['ref_id'] = $appintmentData->id;
            $cancelationData['login_user_id'] = $request->user()->id;
            $cancelationData['login_user_type'] = $request->user()->user_type_id;
            $cancelationData['login_user_name'] = $request->user()->first_name . ' ' . $request->user()->last_name;
            $this->orderPaymentController->orderCancel($cancelationData);
            $appintmentData->fill(array('status_id' => STATUS_CANCELLED, 'updated_at' => date('Y-m-d H:i:s'),
                'refund_amount' => !empty($cancelationData['refundAmount']) ? $cancelationData['refundAmount'] : null))->save();
            $remark = "Cancel by user - reason: " . $request->reason;
            $this->orderPaymentController->saveOrderHistory(['order_id' => $appintmentData->order_id, 'type' => 'TRACKING', 'status_id' => STATUS_CANCELLED, 'remark' => $remark, 'updated_by' => $request->user()->id]);

            $mainOrder = \App\Models\Orders::where('id', $appintmentData->order_id)->with('detail', 'payment', 'payment.paymentmode', 'user')->first();

            $this->notificationRepository->MBSAppointmentNotification($appintmentData->order_id, 'CANCELLED');

            return success(array(), "Appointment cancelled!");
        } catch (Exception $exc) {
            errorLog($exc);
        }
        return error(COMMON_ERROR);
    }

    private function cancelationCharges($appintmentData) {
        $cancelSetting = MENU_BASED_SERVICE_CANCEL_POLICY_SETTING;
        if (!empty($appintmentData->menuBasedService->cancel_policy_setting)) {
            $hours = array();
            foreach ($appintmentData->menuBasedService->cancel_policy_setting as $key => $val) {
                $hours[$key] = $val['hours'];
            }
            array_multisort($hours, SORT_ASC, $cancelSetting);
        }
        $appoimentDate = $appintmentData->appointment_date . ' ' . $appintmentData->appointment_time;
        $now = date('Y-m-d H:i:s');
        $timestamp2 = strtotime($appoimentDate);
        $timestamp1 = strtotime($now);
        $timeDiff = abs($timestamp2 - $timestamp1) / (60 * 60);
        $cancelationCharges = 0;
        foreach ($cancelSetting as $key => $val) {
            if ($timeDiff < $val['hours']) {
                $cancelationCharges = ($appintmentData->amount * $val['charge']) / 100;
                break;
            }
        }
        return $cancelationCharges;
    }

    private function cancelationTimeValidation($request) {
        $appointmentId = $request->appointment_id;
        $loginUserId = $request->user()->id;
        $appintmentData = \App\Models\MenuBasedServiceBooking::where('id', $appointmentId)->with('menuBasedService')->first();
        if (empty($appintmentData)) {
            return array('code' => 0, 'message' => "Sorry, Appointment data not found");
        }
        if ($appintmentData->created_by != $loginUserId) {
            return array('code' => 0, 'message' => "Sorry, You don't cancel other user's appointment");
        }
        if ($appintmentData->status_id == STATUS_CANCELLED) {
            return array('code' => 0, 'message' => "Sorry, Appointment already cancelled");
        }
        if (empty($appintmentData->menuBasedService->cancellation_allowed)) {
            return array('code' => 0, 'message' => "Sorry, This service has not allowed to appointment cancellation");
        }
        $date = $appintmentData->appointment_date . " " . $appintmentData->appointment_time;
        $appointmentDateTime = strtotime($date);
        $dateNow = strtotime(date('Y-m-d H:i:s')); //current timestamp
        if ($dateNow > $appointmentDateTime) {
            return array('code' => 0, 'message' => "Sorry, Cancellation time has been over");
        } else {
            return array('code' => 1, 'data' => $appintmentData);
        }
    }

    public function testNotification() {
        $this->notificationRepository->MBSAppointmentNotification(424, 'CANCELLED');
    }

}
