<?php

namespace App\Http\Controllers\API;

use App\Http\Resources\MenuCollection;
use App\Http\Controllers\Controller;
use App\Models\Menu;
use Illuminate\Http\Request;

class MenuController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     * test commit, checking gitlab..
     */
    public function index()
    {
        return new MenuCollection(Menu::where([
            'active' => 1,
        ])->orderBy("sort_order", "desc")->get());
    }

    /*
     *  For test commit only
     */
    public function show()
    {
    }
}
