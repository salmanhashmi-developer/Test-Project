<?php

namespace App\Http\Controllers\API;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;

class SubscriptionBasedServiceController extends Controller {

    public function search(Request $request) {
        $latitude = $request->header('latitudeUserLocation');
        $longitude = $request->header('longitudeUserLocation');
        $pincode = $request->header('postalCodeUserLocation');
        $input = $request->all();
        if (empty($latitude) || empty($longitude)) {
            return error("Sorry, Latitude/Longitude is empty.");
        }
        if (empty($input['name'])) {
            return error("Sorry, Name is empty");
        }
        $type = !empty($input['type']) ? $input['type'] : 'Facility';
        if ($type == 'Facility') {
            $result = $this->getFacilityFromLocation($latitude, $longitude, $pincode, $input);
        } else {
            $result = $this->getSubscriptionBasedServiceData($latitude, $longitude, $pincode, $input);
        }
        return success($result, 'Search data');
    }

    public function facilityListByEminity(Request $request) {
        $latitude = $request->header('latitudeUserLocation');
        $longitude = $request->header('longitudeUserLocation');
        $pincode = $request->header('postalCodeUserLocation');
        $input = $request->all();
        if (empty($latitude) || empty($longitude)) {
            return error("Sorry, Latitude/Longitude is empty.");
        }
        if (empty($input['sub_category_id'])) {
            return error("Sorry, Sub category id is empty");
        }
        if (empty($input['category_id'])) {
            return error("Sorry, Category id is empty");
        }
        $result = $this->getFacilityFromLocation($latitude, $longitude, $pincode, $input);

        return success($result, 'Search data');
    }

    public function getFacilityFromLocation($latitude, $longitude, $pincode, $input) {
        try {
            $limit = 30;
            $page = !empty($input['page']) ? $input['page'] : 1;
            $skip = $page > 1 ? ($page * $limit) - $limit : 0;
            $query = "SELECT
                            sbs.id AS subscription_based_service_id,
                            sbs.`name` AS subscription_based_service_name,
                            sbsf.id,
                            sbsf.`name`,
                            sbsf.discount,
                            sbsf.price,
                            sbsf.gender,
                            sbsf.days,
                            haversine ( '" . $latitude . "', '" . $longitude . "', sbss.latitude, sbss.longitude ) AS subscription_based_service_distance 
                        FROM
                            ( SELECT sbss.*, haversine ( '" . $latitude . "', '" . $longitude . "', sbss.latitude, sbss.longitude ) AS 'distance' FROM subscription_based_service_search sbss ORDER BY distance ) sbss
                            JOIN subscription_based_service AS sbs ON sbss.subscription_based_service_id = sbs.id
                            JOIN subscription_based_service_facility AS sbsf ON sbs.id = sbsf.subscription_based_service_id 
                        WHERE
                            sbs.status_id = " . STATUS_ACTIVE . " 
                            AND sbsf.status_id = " . STATUS_ACTIVE . " 
                            AND sbss.category_id=" . $input['category_id'] . "
                            AND ( sbss.pincode = '" . $pincode . "' OR sbss.distance < " . SUBSCRIPTION_BASED_SERVICE_DISTANCE . " )";
            if (!empty($input['name'])) {
                $name = $input['name'];
               // $query .= " AND sbsf.name like '%" . $name . "%' ";
                /*25-05-2023 03:44 PM Rikin a kidhu hatu*/
                $query .= " AND sbs.name like '%" . $name . "%' ";
            }
            if (!empty($input['sub_category_id'])) {
                $subCategory = "," . $input['sub_category_id'] . ",";
                $query .= " AND sbsf.sub_category_ids like '%" . $subCategory . "%' ";
            }
            $query .= " GROUP BY
                    sbs.id 
                ORDER BY
                    sbss.distance ";
            $query .= " LIMIT " . $limit . " OFFSET " . $skip;
            return executeSelectQueryOnMySQLDB($query);
        } catch (Exception $exc) {
            errorLog($exc);
        }
        return error(COMMON_ERROR);
    }

    public function clicktoCall(Request $request) {
        $input = $request->all();
        if (empty($input['category_id'])) {
            return error("Sorry, Category id is empty.");
        }
        return success([
            'mobile' => SUBSCRIPTION_BASED_SERVICE_CLICK_TO_CALL,
            'mobile2' => COMMON_MOBILE_NO
            ], 'Done...');
    }

    public function subCategory(Request $request) {
        $input = $request->all();
        if (empty($input['category_id'])) {
            return error("Sorry, Category id is empty.");
        }
        $categoryList = \App\Models\Category::where('parent_id', $input['category_id'])
                        ->where('active', 1)->get();
        $result['image_url'] = getUrl('image/category/');
        $result['category'] = $categoryList;
        return success($result, 'Category list');
    }

    public function subCategoryV1(Request $request) {
        $input = $request->all();
        if (empty($input['subscription_based_service_id'])) {
            return error("Sorry, Menu based service id is empty.");
        }
        if (!isset($input['subscription_based_service_parent_id'])) {
            return error("Sorry, Menu based service parent id is empty.");
        }
        $result = [];
        $facility = \App\Models\SubscriptionBasedServiceFacility::where('subscription_based_service_id', $input['subscription_based_service_id'])->groupBy('sub_category_ids')->get();
        if (empty(count($facility))) {
            $facility = \App\Models\SubscriptionBasedServiceFacility::where('subscription_based_service_id', $input['subscription_based_service_parent_id'])->groupBy('sub_category_ids')->get();
        }
        if (!empty(count($facility))) {
            $categotyIds = "";
            foreach ($facility as $category) {
                if (!empty($category['sub_category_ids'])) {
                    $categotyIds .= $category['sub_category_ids'];
                }
            }
        }
        if (!empty($categotyIds)) {
            $categotyIdsArr = explode(',', $categotyIds);
            $result = \App\Models\Category::whereIn('id', $categotyIdsArr)->get();
        }
        return success($result, 'Category list');
    }

    public function slider(Request $request) {
        $input = $request->all();
        if (empty($input['category_id'])) {
            return error("Sorry, Category id is empty.");
        }
        $banner = \App\Models\AppDashboard::where('type', 'SBS_Slide')->orderBy('sort_order', 'ASC')->get();
        $result = [];
        if (!empty($banner)) {
            foreach ($banner as $key => $value) {
                $result[$key]['file'] = getUrl('image/dashboard/') . $value['file'];
            }
        }
        return success($result, "Dashboard data");
    }

    public function freeTrialBanner(Request $request) {
        $input = $request->all();
        if (empty($input['subscription_based_service_id'])) {
            return error("Sorry, Menu based service id is empty.");
        }
        $result = [];
        $service = \App\Models\SubscriptionBasedService::where('id', $input['subscription_based_service_id'])->first();
        if (!empty($service) && $service->free_trial == 1) {
            $result['file'] = getUrl('image/dashboard/') . 'free_trial_gym.png';
        }
        return success($result, "Banner data");
    }

    public function subscriptionBasedServiceListing(Request $request) {
        try {
            $latitude = $request->header('latitudeUserLocation');
            $longitude = $request->header('longitudeUserLocation');
            $pincode = $request->header('postalCodeUserLocation');
            $input = $request->all();
            if (empty($input['category_id'])) {
                return error("Sorry, Category id is empty.");
            }
            if ($request->user()->id == 74) {
                $latitude = '18.969538920783755';
                $longitude = '72.81932909041643';
                $pincode = '400008';
            } else {
                if (empty($latitude) || empty($longitude)) {
                    return error("Sorry, Latitude/Longitude is empty.");
                }
            }
            $result = $this->getSubscriptionBasedServiceData($latitude, $longitude, $pincode, $input);
            return success($result, 'Service data list');
        } catch (Exception $exc) {
            errorLog($exc);
        }
        return error(COMMON_ERROR);
    }

    private function getSubscriptionBasedServiceData($latitude, $longitude, $pincode, $input) {
        $limit = 10;
        $page = !empty($input['page']) ? $input['page'] : 1;
        $skip = $page > 1 ? ($page * $limit) - $limit : 0;
        $query = "SELECT
                        sbs.id AS subscription_based_service_id,
                        sbs.parent_id AS subscription_based_service_parent_id,
                        sbs.self_facility_available,
                        sbs.name AS subscription_based_service_name,
                        sbs.sub_category_ids AS subscription_based_service_sub_category_ids,
                        sbs.amenity_ids AS subscription_based_service_sub_amenity_ids,
                        sbs.free_trial,
                        concat('" . getUrl('image/subscription_base_service') . "',sbs.photo) AS subscription_based_service_photo,
                        sbs.address1 AS subscription_based_service_address1,
                        sbs.address2 AS subscription_based_service_addres2,
                        sbs.area AS subscription_based_service_area,
                        sbs.pincode AS subscription_based_service_pincode,
                        sbs.discount AS discount,
                        sbs.category_id AS category_id,
                        s.`name` AS state_name,
                        c.`name` AS city_name,
                        haversine ( '" . $latitude . "', '" . $longitude . "', sbss.latitude, sbss.longitude ) AS subscription_based_service_distance,
                        ( SELECT COUNT(*) FROM review WHERE ref_id = sbss.subscription_based_service_id AND service_id = " . SUBSCRIPTION_BASED_SERVICE . " AND status_id = " . STATUS_APPROVED . " ) AS review_count,
                        ROUND(( SELECT AVG( rating ) FROM review WHERE ref_id = sbss.subscription_based_service_id AND service_id =" . SUBSCRIPTION_BASED_SERVICE . " AND status_id = " . STATUS_APPROVED . "), 1 ) AS subscription_based_service_rating 
                    FROM
                        ( SELECT sbss.*, haversine ( '" . $latitude . "', '" . $longitude . "', sbss.latitude, sbss.longitude ) AS 'distance' FROM subscription_based_service_search sbss ORDER BY distance ) sbss
                        JOIN subscription_based_service AS sbs ON (sbss.subscription_based_service_id = sbs.id AND sbs.status_id = 1)
                        LEFT JOIN state AS s ON sbss.state_id = s.id
                        LEFT JOIN city AS c ON sbss.city_id = c.id 
                    WHERE  
                        sbss.category_id=" . $input['category_id'] . "
                        AND (";
        if (!empty($pincode)) {
            $query .= "sbss.pincode = '" . $pincode . "' OR ";
        }
        $query .= "sbss.distance < " . SUBSCRIPTION_BASED_SERVICE_DISTANCE . " )";
        if (!empty($input['name'])) {
            $query .= " AND sbss.`name` like  '%" . $input['name'] . "%' ";
        }
        $query .= " ORDER BY sbss.distance";
        $query .= " LIMIT " . $limit . " OFFSET " . $skip;
        //pr($query);
        $result = executeSelectQueryOnMySQLDB($query);
        if (!empty($result)) {
            foreach ($result as $key => $value) {
                if (!empty($value['subscription_based_service_sub_category_ids'])) {
                    $ids = explode(',', $value['subscription_based_service_sub_category_ids']);
                    if (!empty($ids)) {
                        $result[$key]['sub_category'] = \App\Models\Category::whereIn('id', $ids)->get();
                    }
                }
                if (!empty($value['subscription_based_service_sub_amenity_ids'])) {
                    $ids = explode(',', $value['subscription_based_service_sub_amenity_ids']);
                    if (!empty($ids)) {
                        $result[$key]['amenity'] = \App\Models\ServiceAmenity::whereIn('id', $ids)->get();
                    }
                }
            }
        }
        return $result;
    }

    public function subscriptionBaseServiceDetail(Request $request) {
        $input = $request->all();
        if (empty($input['subscription_based_service_id'])) {
            return error("Sorry, Subscription base service id is empty");
        }
        $result = \App\Models\SubscriptionBasedService::where('id', $input['subscription_based_service_id'])->with('subscriptionBasedServiceDetails', 'state', 'city')->first();
        if (empty($result)) {
            return error("Sorry, Service data not faound");
        }
        if ($result->status_id != STATUS_ACTIVE) {
            return error("Sorry, This service currently not available for service.");
        }
        if ($result->free_trial == 1) {
            $result->free_trial_image = getUrl('image/dashboard/') . 'free_trial_gym.png';
        }
        return success($result, 'Service data');
    }

}
