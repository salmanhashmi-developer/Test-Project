<?php

namespace App\Http\Controllers\API;

use App\Http\Controllers\Controller;
use App\Models\City;
use Illuminate\Http\Request;

//use App\Http\Resources\CityCollection;

class CityController extends Controller {

    /**
     * Display a listing of the resource.
     *
     * @param $id
     * @return CityCollection
     */
    public function index($id) {
        $city = City::where(["state_id" => $id, 'active' => 1])->orderBy("name", 'ASC')->get();
        return success($city, 'City list retrieved successfully');
    }

}
