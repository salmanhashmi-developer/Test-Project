<?php

namespace App\Http\Controllers\API\Doctor;

use App\Http\Resources\HospitalCollection;
use App\Http\Controllers\Controller;
use App\Http\Controllers\Api\OrderPaymentController;
use App\Http\Repository\NotificationRepository;
use App\Models\DoctorAppointmentBooking;
use App\Models\DoctorHospitalBlockSlot;
use Illuminate\Http\Request;
use Exception;

class AppointmentBookingController extends Controller {

    private $orderPaymentController;
    private $notificationRepository;

    public function __construct(OrderPaymentController $orderPaymentController, NotificationRepository $notificationRepository) {
        $this->orderPaymentController = $orderPaymentController;
        $this->notificationRepository = $notificationRepository;
    }

    public function appointmentEndCron() {
        $result = DoctorAppointmentBooking::whereNull('appointment_end')
                ->whereNotNull('appointment_start')
                ->where('appointment_date', date('Y-m-d', strtotime("-1 days")))
                ->update(array('appointment_end' => date('Y-m-d H:i:s')));
        return success($result, 'Appointment list');
    }

    public function blockSlot(Request $request) {
        $input = $request->all();
        if (empty($input['doctor_id'])) {
            return error("Sorry, Doctor id is empty");
        }
        if (empty($input['hospital_id'])) {
            return error("Sorry, Hospital id is empty");
        }
        $input['created_at'] = date('Y-m-d H:i:s');
        $input['created_by'] = $request->user()->id;
        if (!empty($input['slot_ids'])) {
            if (empty($input['date'])) {
                return error("Sorry, Date is empty");
            }
            $slotIdArr = explode(',', $input['slot_ids']);
            if (!empty($slotIdArr)) {
                foreach ($slotIdArr as $slotId) {
                    if (!empty($slotId)) {
                        $slotData = \App\Models\DoctorHospitalSlot::where('id', $slotId)
                                ->where('doctor_id', $input['doctor_id'])
                                ->where('hospital_id', $input['hospital_id'])
                                ->first();
                        if (!empty($slotData)) {
                            $input['doctor_id'] = $slotData->doctor_id;
                            $input['hospital_id'] = $slotData->hospital_id;
                            $input['doctor_hospital_slot_id'] = $slotData->id;
                            $input['from_time'] = $slotData->from_time;
                            $input['to_time'] = $slotData->to_time;
                            $input['is_video'] = $slotData->is_video;
                            $input['is_offline'] = $slotData->is_offline;
                            $result = DoctorHospitalBlockSlot::create($input);
                        }
                    }
                }
            }
        } else {
            if (!empty($input['date_list'])) {
                $dateArr = explode(',', $input['date_list']);
                foreach ($dateArr as $date) {
                    $input['date'] = $date;
                    $result = DoctorHospitalBlockSlot::create($input);
                }
            }
        }
        return success([], "Blocked slot");
    }

    public function unblockSlot(Request $request) {
        $input = $request->all();
        if (empty($input['doctor_id'])) {
            return error("Sorry, Doctor id is empty");
        }
        if (empty($input['hospital_id'])) {
            return error("Sorry, Hospital id is empty");
        }
        if (!empty($input['slot_ids'])) {
            if (empty($input['date'])) {
                return error("Sorry, Date is empty");
            }
            $idArr = explode(',', $input['slot_ids']);
            if (!empty($idArr)) {
                DoctorHospitalBlockSlot::whereIn('doctor_hospital_slot_id', $idArr)
                        ->where('doctor_id', $input['doctor_id'])
                        ->where('hospital_id', $input['hospital_id'])
                        ->whereDate('date', $input['date'])
                        ->delete();
            }
        } else {
            if (!empty($input['date_list'])) {
                $dateArr = explode(',', $input['date_list']);
                foreach ($dateArr as $date) {
                    DoctorHospitalBlockSlot::whereDate('date', $date)
                            ->where('doctor_id', $input['doctor_id'])
                            ->where('hospital_id', $input['hospital_id'])
                            ->delete();
                }
            }
        }
        return success(array(), "Unblocked slot list");
    }

    public function slotListBlockUnblock(Request $request) {
        $input = $request->all();
        if (empty($input['doctor_id'])) {
            return error("Sorry, Doctor id is empty");
        }
        if (empty($input['hospital_id'])) {
            return error("Sorry, Hospital id is empty");
        }
        if (empty($input['date'])) {
            return error("Sorry, Date is empty");
        }
        $day = date('D', strtotime($input['date']));
        $result = \App\Models\DoctorHospitalSlot::where('day', $day)
                ->where('doctor_id', $input['doctor_id'])
                ->where('hospital_id', $input['hospital_id'])
                ->get();
        if (!empty($result)) {
            $slotBlock = DoctorHospitalBlockSlot::where('doctor_id', $input['doctor_id'])
                    ->where('hospital_id', $input['hospital_id'])
                    ->whereDate('date', $input['date'])
                    ->get();
            foreach ($result as $key => $value) {
                $result[$key]['is_blocked'] = 0;
                if (!empty($slotBlock)) {
                    foreach ($slotBlock as $slot) {
                        if (empty($slot['doctor_hospital_slot_id'])) {
                            $result[$key]['is_blocked'] = 1;
                        } else {
                            if ($slot['doctor_hospital_slot_id'] == $value['id']) {
                                $result[$key]['is_blocked'] = 1;
                            }
                        }
                    }
                }
            }
        }
        return success($result, "Blocked slot list");
    }

    public function slotBlockdate(Request $request) {
        $input = $request->all();
        if (empty($input['doctor_id'])) {
            return error("Sorry, Doctor id is empty");
        }
        if (empty($input['hospital_id'])) {
            return error("Sorry, Hospital id is empty");
        }
        if (empty($input['month'])) {
            return error("Sorry, Month is empty");
        }
        if (empty($input['year'])) {
            return error("Sorry, Year is empty");
        }
        $response = [];
        $result = DoctorHospitalBlockSlot::where('doctor_id', $input['doctor_id'])
                ->where('hospital_id', $input['hospital_id'])
                ->whereYear('date', $input['year'])
                ->whereMonth('date', $input['month'])
                ->whereNull('doctor_hospital_slot_id')
                ->orderBy('date', 'ASC')
                ->get();
        if (!empty($result)) {
            foreach ($result as $value) {
                $response[] = $value['date'];
            }
        }
        return success($response, "Blocked date list");
    }

    public function rescheduleAppointment(Request $request) {
        if ($request->user()->user_type_id != DOCTOR) {
            return error('Sorry, Only for doctor.');
        }
        try {
            $input = $request->all();
            $input['login_user_id'] = $request->user()->id;
            $input['login_user_mobile'] = $request->user()->mobile;
            $input['login_user_type'] = $request->user()->user_type_id;
            if (empty($input['appointment_id'])) {
                return error('Sorry, Appointment id is empty');
            }
            if (empty($input['doctor_hospital_slot_id'])) {
                return error('Sorry, Doctor hospital slot id is empty');
            }
            if (empty($input['date'])) {
                return error('Sorry, Date is empty');
            }
            $appintmentData = DoctorAppointmentBooking::where('id', $input['appointment_id'])->first();
            $oldDate = date_format(date_create($appintmentData->appointment_date), "d/m/Y") . ' ' . $appintmentData->appointment_time;
            if (empty($appintmentData)) {
                return error('Sorry, Invalid appointment id');
            }
            if (empty($input['doctor_id'])) {
                return error("Sorry, Doctor id is empty");
            }
            if ($appintmentData->doctor_id != $input['doctor_id']) {
                return error('Sorry, You are not authorized to reschedule this appointment');
            }
            if ($appintmentData->status_id != STATUS_SUCCESS) {
                return error('Sorry, Your appointment has not been confirmed. so you cannot reschedule the appointment');
            }
            $date = $appintmentData->appointment_date . " " . $appintmentData->appointment_time;
            $appointmentDateTime = strtotime($date);
            $dateNow = strtotime(date('Y-m-d H:i:s'));
//current timestamp
            if ($dateNow > $appointmentDateTime) {
                return array('code' => 0, 'message' => "Sorry, Reschedule time has been over");
            }

            $slotData = \App\Models\DoctorHospitalSlot::where('id', $input['doctor_hospital_slot_id'])->first();
            if (empty($slotData)) {
                return error('Sorry, Invalid doctor hospital slot id');
            }
            if ($appintmentData->doctor_id != $slotData->doctor_id) {
                return error("Sorry, Can't select other doctor slot.");
            }
            if ($appintmentData->hospital_id != $slotData->hospital_id) {
                return error("Sorry, Can't select other hospital slot.");
            }

            $result = [];
            $input['user_patient_id'] = $appintmentData->user_patient_id;
            $validation = $this->bookingDoctorValidation($input);
            if (isset($validation[0]) && $validation[0] == 0) {
                return error($validation[1]);
            }
            $hospitalDoctorMapping = \App\Models\DoctorHospitalMapping::where(
                            [
                                'doctor_id' => $slotData->doctor_id,
                                'hospital_id' => $slotData->hospital_id
                    ])->first();
            $discount = ($hospitalDoctorMapping->fees * $hospitalDoctorMapping->discount) / 100;
            $grandTotal = (int) $hospitalDoctorMapping->fees - (int) $discount;
            if ($grandTotal != $appintmentData->amount) {
                return error('Sorry, Amount mismatch between old and reschedule appointment. Cancel appointment and rebook.');
            }
            $result = $appintmentData->fill([
                        'doctor_hospital_slot_id' => $input['doctor_hospital_slot_id'],
                        'appointment_date' => $input['date'],
                        'appointment_time' => $slotData->from_time,
                    ])->save();
            $remark = "Reschedule Appointment By Doctor : Old  Appointment - " . $oldDate
                    . ' New  Appointment - ' . $input['date'] . ' ' . $slotData->from_time;
            $this->orderPaymentController->saveOrderHistory([
                'order_id' => $appintmentData->order_id,
                'type' => 'TRACKING', 'status_id' => STATUS_SUCCESS,
                'remark' => $remark,
                'updated_by' => $input['login_user_id']
            ]);
            $this->notificationRepository->doctorAppointmentNotification($appintmentData->order_id, 'RESCHEDULE', ['old_date' => $oldDate]);
            return success($result, "Appointment rescheduled successfully!");
        } catch (Exception $exc) {
            errorLog($exc);
        }
        return error(COMMON_ERROR);
    }

    /* Use booking doctor validation function for booking and payment time */

    private function bookingDoctorValidation($input) {
        if (empty($input['doctor_hospital_slot_id'])) {
            return array(0, "Sorry, Doctor hospital slot id is empty");
        }
        if (empty($input['user_patient_id'])) {
            return array(0, "Sorry, User patient id is empty");
        }
        if (empty($input['date'])) {
            return array(0, "Sorry, Date is empty");
        }
        $slot = \App\Models\DoctorHospitalSlot::where('id', $input['doctor_hospital_slot_id'])->with('hospital', 'doctor')->first();
        if (empty($slot)) {
            return array(0, "Sorry, Slot data not found.");
        }
        if (empty($slot->hospital)) {
            return array(0, "Sorry, hospital service has been disabled");
        } else {
            if ($slot->hospital->cancel_policy) {
                $slot->hospital->cancel_policy = json_decode($slot->hospital->cancel_policy);
            } else {
                $slot->hospital->cancel_policy = HOSPITAL_CANCEL_POLICY;
            }
        }
        if (empty($slot->doctor)) {
            return array(0, "Sorry, doctor service has been disabled");
        }
        $checkSlotBooked = DoctorAppointmentBooking::where(
                        [
                            'doctor_hospital_slot_id' => $input['doctor_hospital_slot_id'],
                            'appointment_date' => $input['date'],
                            'status_id' => STATUS_SUCCESS
                ])->count();
        if ($checkSlotBooked > 0) {
            return array(0, "Sorry, Someone already booked the slot");
        }
        $checkSlotBlocked = DoctorHospitalBlockSlot::where(
                        [
                            'doctor_hospital_slot_id' => $input['doctor_hospital_slot_id'],
                            'date' => $input['date']
                ])->count();
        if ($checkSlotBlocked > 0) {
            return array(0, "Sorry, Slot has been blocked");
        }
        $patientData = \App\Models\UserPatientMapping::where('id', $input['user_patient_id'])->first();
        if (empty($patientData)) {
            return array(0, 'Sorry,Patient data not found');
        } else {

            if ($patientData->status_id != STATUS_ACTIVE) {
                return array(0, 'Sorry,Patient is blocked.');
            }
            if ($patientData->is_deleted == 1) {
                return array(0, 'Sorry,Patient was deleted.');
            }
        }
        $result['slot_data'] = $slot;
        $result['user_patient'] = $patientData;
        //$result['userSubscription'] = $userSubscription;
        return $result;
    }

    public function appointmentList(Request $request) {
        if ($request->user()->user_type_id != DOCTOR) {
            return error('Sorry, Only for doctor.');
        }
        $input = $request->all();
        if (empty($input['doctor_id'])) {
            return error('Sorry, Doctor id is empty.');
        }
        $sort = !empty($input['booking_api']) ? 'DESC' : 'ASC';
        $page = !empty($input['page']) ? $input['page'] : 1;
        $skip = $page > 1 ? ($page * LIMIT) - LIMIT : 0;
        $query = "SELECT
                        dab.id AS appointment_id,
                        dab.user_patient_id,
                        dab.patient_name,
                        dab.patient_mobile,
                        dhs.doctor_id,
                        dab.appointment_date,
                        dab.doctor_hospital_slot_id AS slot_id,
                        dab.appointment_start,
                        dab.appointment_end,
                        dhs.from_time,
                        dhs.to_time,
                        dhs.is_video,
                        dhs.is_offline,
                        h.id AS hospital_id,
                        h.`name` AS hospital_name,
                        h.area AS hospital_area,
                        c.`name` AS city_name,
                        us.card_no AS healthismplus_id,
                        s.id AS status_id,
                        s.name AS status_name
                FROM
                        `doctor_appointment_booking` AS dab,
                        doctor_hospital_slot AS dhs,
                        hospital AS h,
                        city AS c,
                        user_subscription AS us,
                        status AS s
                WHERE
                        dab.doctor_hospital_slot_id = dhs.id 
                        AND dab.status_id = s.id 
                        AND dab.hospital_id = h.id 
                        AND h.city_id = c.id 
                        AND dab.user_subscription_id = us.id 
                        AND dab.doctor_id =  " . $input['doctor_id'] . "
                        AND dab.status_id IN (" . STATUS_SUCCESS . "," . STATUS_CANCELLED . ")";
        if (!empty($input['hospital_id'])) {
            $query .= " AND dab.hospital_id = '" . $input['hospital_id'] . "'";
        }
        if (!empty($input['booking_api'])) {
//Appoiment booking api for my booking
            if (!empty($input['from_date'])) {
                $query .= " AND dab.appointment_date >= '" . date('Y-m-d', strtotime($input['from_date'])) . "'";
            }
            if (!empty($input['to_date'])) {
                $query .= " AND dab.appointment_date <= '" . date('Y-m-d', strtotime($input['to_date'])) . "'";
            }
        } else {
//Appoiment booking api for dashboard
            $appoimentDate = !empty($input['date']) ? $input['date'] : date('Y-m-d');
            if (!empty($appoimentDate)) {
                $query .= " AND dab.appointment_date = '" . $appoimentDate . "'";
            }
        }
        if (!empty($input['patient_name'])) {
            $query .= " AND dab.patient_name LIKE '%" . $input['patient_name'] . "%'";
        }
        $query .= " ORDER BY
                        dab.appointment_date " . $sort . ",
                        dhs.from_time " . $sort;
        $query .= " LIMIT " . LIMIT . " OFFSET " . $skip;
        $result = executeSelectQueryOnMySQLDB($query);
        return success($result, 'Appointment list');
    }

    public function appointmentUpdate(Request $request) {
        if ($request->user()->user_type_id != DOCTOR) {
            return error('Sorry, Only for doctor.');
        }
        $input = $request->all();
        if (!isset($input['action'])) {
            return error('Sorry,Action param missing.');
        }
        if (empty($input['doctor_id'])) {
            return error('Sorry, Doctor id is empty.');
        }
        if (empty($input['appointment_id'])) {
            return error('Sorry, Appointment id is empty.');
        }
        $appointment = DoctorAppointmentBooking::where('id', $input['appointment_id'])->first();
        if (empty($appointment)) {
            return error('Sorry, Appointment data not found.');
        }
        if ($appointment->doctor_id != $input['doctor_id']) {
            return error('Sorry, Appointment not for you.');
        }

        if ($input['action'] == 1 && empty($appointment->appointment_start)) {
            $data = array('appointment_start' => date('Y-m-d H:i:s'));
        }
        if ($input['action'] == 0 && empty($appointment->appointment_end)) {
            $data = array('appointment_end' => date('Y-m-d H:i:s'));
        }

        if (!empty($data)) {
            $appointment->fill($data)->save();
        }
        return success($appointment, 'Appointment list');
    }

    public function appointmentCalendar(Request $request) {
        if ($request->user()->user_type_id != DOCTOR) {
            return error('Sorry, Only for doctor.');
        }
        $input = $request->all();
        if (empty($input['doctor_id'])) {
            return error('Sorry, Doctor id is empty.');
        }
        if (empty($input['month'])) {
            return error('Sorry, Month is empty.');
        }
        if (empty($input['year'])) {
            return error('Sorry, Year is empty.');
        }
        $query = "SELECT
                        appointment_date,
                        DAY ( appointment_date ) as day,
                        COUNT(*) as appointment_count
                    FROM
                        `doctor_appointment_booking` 
                    WHERE 
                        doctor_id =  " . $input['doctor_id'] . "
                        AND status_id = " . STATUS_SUCCESS;
        if (!empty($input['hospital_id'])) {
            $query .= " AND hospital_id = '" . $input['hospital_id'] . "'";
        }
        $query .= " AND MONTH ( appointment_date )= " . $input['month'];
        $query .= " AND YEAR ( appointment_date ) = " . $input['year'];
        $query .= " GROUP BY appointment_date";
        $result = executeSelectQueryOnMySQLDB($query);
        return success($result, 'Appointment list');
    }

    public function appointmentDetails(Request $request) {
        if (empty($request->appointment_id)) {
            return error('Sorry,Appointment id is empty.');
        }
        $appointment = DoctorAppointmentBooking::where('id', $request->appointment_id)
                        ->with('hospital', 'hospital.city', 'doctor', 'user_patient', 'status', 'hospitalslot', 'order', 'user_subscription', 'order.payment.paymentmode')->first();
        $result = [];
        if (!empty($appointment)) {
            $result['appointment_id'] = $appointment['id'];
            $result['order_id'] = $appointment['order_id'];
            $result['is_video'] = $appointment['is_video'];
            $result['patient_name'] = $appointment['patient_name'];
            $result['patient_mobile'] = $appointment['patient_mobile'];
            $result['patient_dob'] = $appointment['user_patient']['dob'];
            $result['patient_blood_group'] = $appointment['user_patient']['blood_group'];
            $result['booking_date'] = $appointment['created_at'];
            $result['appointment_date'] = $appointment['appointment_date'];
            $result['appointment_time'] = $appointment['appointment_time'];
            $result['appointment_start'] = $appointment['appointment_start'];
            $result['appointment_end'] = $appointment['appointment_end'];
            $result['amount'] = $appointment['amount'];
            $result['refund_amount'] = $appointment['refund_amount'];
            $result['hospital_id'] = $appointment['hospital']['id'];
            $result['hospital_name'] = $appointment['hospital']['name'];
            $result['hospital_address'] = $appointment['hospital']['area'] . ' ' . $appointment['hospital']['city']['name'];
            $result['order_code'] = $appointment['order']['order_code'];
            $result['healthismplus_id'] = $appointment['user_subscription']['card_no'];
            $result['payment_mode'] = $appointment['order']['payment']['paymentmode']['name'];
            $result['status'] = $appointment['status']['name'];
            $result['status_id'] = $appointment['status']['id'];
        }
        return success($result, 'Appointment detail');
    }

    public function cancellationReason(Request $request) {
        if (empty($request->appointment_id)) {
            return error("Sorry, appointment id is empty");
        }
        $validation = $this->cancelationTimeValidation($request);
        if ($validation['code'] == 0) {
            return error($validation['message']);
        }
        $appintmentData = $validation['data'];
        $result['patient_name'] = $appintmentData->patient_name;
        $result['hospital_name'] = $appintmentData->hospital->name;
        $result['hospital_area'] = $appintmentData->hospital->area;
        $result['date'] = $appintmentData->appointment_date;
        $result['time'] = $appintmentData->appointment_time;
        $result['appointment_id'] = $appintmentData->id;
        $result['cancellation_reason'] = [
            'I am Unavailable',
            'I am busy',
            'I have another appointment'
        ];

        return success($result, "Booking Data...");
    }

    public function cancellationDetail(Request $request) {
        if (empty($request->appointment_id)) {
            return error("Sorry, Appointment id is empty");
        }
        $validation = $this->cancelationTimeValidation($request);
        if ($validation['code'] == 0) {
            return error($validation['message']);
        }
        $appintmentData = $validation['data'];
        $orderDetail = \App\Models\OrderDetail::where('order_id', $appintmentData->order_id)
                        ->where('ref_id', $request->appointment_id)->first();
        if (empty($orderDetail)) {
            return error("Sorry, Order data not found");
        }
        $paymentModeId = \App\Models\OrderPayment::where('order_id', $appintmentData->order_id)->first()->payment_mode_id;
        $totalAmount = $orderDetail->coupon_amount + $orderDetail->wallet_amount + $orderDetail->pg_amount;
        $result['calculation']['charges'][] = ['title' => 'Amount', 'symbol' => '', 'value' => numberFormat($totalAmount)];

        if ($paymentModeId == OFFLINE) {
            $result['calculation']['grandTotal'] = ['title' => 'Amount Paid', 'value' => '0.00'];
        } else {
            if (!empty($orderDetail->coupon_amount)) {
                $result['calculation']['charges'][] = ['title' => 'Coupon Amount', 'symbol' => '-', 'value' => numberFormat($orderDetail->coupon_amount)];
            }
            if (!empty($orderDetail->wallet_amount)) {
                $result['calculation']['charges'][] = ['title' => 'Wallet Amount', 'symbol' => '-', 'value' => numberFormat($orderDetail->wallet_amount)];
            }
            $result['calculation']['grandTotal'] = ['title' => 'Amount Paid', 'value' => numberFormat($orderDetail->pg_amount)];
        }
        $cancelationCharges = $this->cancelationCharges($appintmentData);
        if ($paymentModeId == OFFLINE) {
            $result['refund_calculation']['charges'][] = ['title' => 'Amount Paid', 'value' => '0.00'];
            $result['refund_calculation']['charges'][] = ['title' => 'Cancellation Charges', 'symbol' => '-', 'value' => '0.00'];
            $result['refund_calculation']['grandTotal'] = ['title' => 'Amount Paid', 'value' => '0.00'];
        } else {
            $result['refund_calculation']['charges'][] = ['title' => 'Amount Paid', 'value' => numberFormat($orderDetail->pg_amount)];
            $result['refund_calculation']['charges'][] = ['title' => 'Cancellation Charges', 'symbol' => '-', 'value' => numberFormat($cancelationCharges)];
            $result['refund_calculation']['grandTotal'] = ['title' => 'Amount Paid', 'value' => numberFormat($orderDetail->pg_amount - $cancelationCharges)];
        }

        $result['payment_method'] = ['title' => 'Paid Via', 'symbol' => '', 'value' => $paymentModeId];
        $result['cancel_policy'] = !empty($appintmentData->hospital->cancel_policy) ? json_decode($appintmentData->hospital->cancel_policy, true) : HOSPITAL_CANCEL_POLICY;
        $result['reason'] = $request->reason;
        return success($result, "Booking Data...");
    }

    public function cancelOrder(Request $request) {
        try {
            if (empty($request->appointment_id)) {
                return error("Sorry, Appointment id is empty");
            }
            if (empty($request->reason)) {
                return error("Sorry, Reason is empty");
            }
            $validation = $this->cancelationTimeValidation($request);
            if ($validation['code'] == 0) {
                return error($validation['message']);
            }
            $appintmentData = $validation['data'];
            $orderDetail = \App\Models\OrderDetail::where('order_id', $appintmentData->order_id)
                            ->where('ref_id', $request->appointment_id)->first();
            if (empty($orderDetail)) {
                return error("Sorry, Order data not found");
            }
            $orderPayment = \App\Models\OrderPayment::where('order_id', $appintmentData->order_id)->first();
            $cancelationData['cancelationCharges'] = $request->user()->user_type_id == END_USER ? $this->cancelationCharges($appintmentData) : 0;
            if (!empty($orderPayment)) {
                if ($orderPayment->status_id == STATUS_DONE && $orderPayment->payment_mode_id == RAZORPAY) {
                    $cancelationData['refundAmount'] = $orderDetail->pg_amount - $cancelationData['cancelationCharges'];
                }
            }
            $cancelationData['reason'] = $request->reason;
            $cancelationData['order_id'] = $appintmentData->order_id;
            $cancelationData['order_detail_id'] = $orderDetail->id;
            $cancelationData['ref_id'] = $appintmentData->id;
            $cancelationData['login_user_id'] = $request->user()->id;
            $cancelationData['user_type_id'] = $request->user()->user_type_id;
            $cancelationData['login_user_name'] = $request->user()->first_name . ' ' . $request->user()->last_name;
            $this->orderPaymentController->orderCancel($cancelationData);
            $appintmentData->fill(array('status_id' => STATUS_CANCELLED, 'updated_at' => date('Y-m-d H:i:s'),
                'refund_amount' => !empty($cancelationData['refundAmount']) ? $cancelationData['refundAmount'] : null))->save();
            $remark = "Cancel by doctor - reason: " . $request->reason;
            $this->orderPaymentController->saveOrderHistory(['order_id' => $appintmentData->order_id, 'type' => 'TRACKING', 'status_id' => STATUS_CANCELLED, 'remark' => $remark, 'updated_by' => $request->user()->id]);

            $this->notificationRepository->doctorAppointmentNotification($appintmentData->order_id, 'CANCELLED');
            return success(array(), "Appointment cancelled!");
        } catch (Exception $exc) {
            errorLog($exc);
        }
        return error(COMMON_ERROR);
    }

    private function cancelationCharges($appintmentData) {
        $cancelSetting = CANCEL_POLICY_SETTING;
        if (!empty($appintmentData->hospital->cancel_policy_setting)) {
            $cancelSetting = json_decode($appintmentData->hospital->cancel_policy_setting, true);
            $hours = array();
            foreach ($cancelSetting as $key => $val) {
                $hours[$key] = $val['hours'];
            }
            array_multisort($hours, SORT_ASC, $cancelSetting);
        }
        $appoimentDate = $appintmentData->appointment_date . ' ' . $appintmentData->appointment_time;
        $now = date('Y-m-d H:i:s');
        $timestamp2 = strtotime($appoimentDate);
        $timestamp1 = strtotime($now);
        $timeDiff = abs($timestamp2 - $timestamp1) / (60 * 60);
        $cancelationCharges = 0;
        foreach ($cancelSetting as $key => $val) {
            if ($timeDiff < $val['hours']) {
                $cancelationCharges = ($appintmentData->amount * $val['charge']) / 100;
                break;
            }
        }
        return $cancelationCharges;
    }

    private function cancelationTimeValidation($request) {
        $appointmentId = $request->appointment_id;
        $loginUserId = $request->user()->id;
        $appintmentData = DoctorAppointmentBooking::where('id', $appointmentId)->with('hospital', 'hospital.state', 'hospital.city', 'doctor')->first();
        if (empty($appintmentData)) {
            return array('code' => 0, 'message' => "Sorry, Appointment data not found");
        }
        if (empty($request->doctor_id)) {
            return array('code' => 0, 'message' => "Sorry, Doctor id is empty");
        }
        if ($appintmentData->doctor_id != $request->doctor_id) {
            return array('code' => 0, 'message' => "Sorry, You don't cancel other doctor's appointment");
        }

        if ($appintmentData->status_id == STATUS_CANCELLED) {
            return array('code' => 0, 'message' => "Sorry, Appointment already cancelled");
        }
        if (empty($appintmentData->hospital->cancellation_allowed)) {
            return array('code' => 0, 'message' => "Sorry, This hospital has not allowed to appointment cancellation");
        }
        $date = $appintmentData->appointment_date;
        $appointmentDate = strtotime($date);
        $dateNow = strtotime(date('Y-m-d')); //current timestamp
        if ($dateNow > $appointmentDate) {
            return array('code' => 0, 'message' => "Sorry, Cancellation time has been over");
        } else {
            return array('code' => 1, 'data' => $appintmentData);
        }
    }

}
