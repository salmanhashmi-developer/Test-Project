<?php

namespace App\Http\Controllers\API\Doctor;

use App\Http\Controllers\Controller;
use App\Models\UserPatientMapping;
use Illuminate\Http\Request;

class PatientMappingController extends Controller {

    public function index(Request $request) {
        $result = UserPatientMapping::where([
                    'user_id' => $request->user()->id,
                    'is_deleted' => 0
                ])->orderBy('created_at', 'desc')->get();
        return success($result, "User patient list");
    }

    public function relationshipList() {
        return success(array('GRAND FATHER', 'GRAND MOTHER', 'FATHER', 'MOTHER', 'WIFE', 'HUSBAND', 'SISTER', 'BROTHER', 'SON', 'DAUGHTER', 'COUSIN', 'AUNT', 'UNCLE', 'GUEST', 'OTHER'), "Gender list.");
    }

    public function store(Request $request) {
        $rules = UserPatientMapping::$rules;
        if (sizeof($rules) > 0) {
            $validation = $this->validateRequest($request, $rules);
            if (!empty($validation)) {
                return error($validation);
            }
        }
        $input = $request->all();
        $input['user_id'] = $request->user()->id;
        $input['status_id'] = STATUS_ACTIVE;
        $input['first_name'] = ucwords($input['first_name']);
        $input['last_name'] = ucwords($input['last_name']);
        $input['created_at'] = date('Y-m-d H:i:s');
        $result = UserPatientMapping::create($input);
        return success($result, "User patient has been saved successfully");
    }

    public function update(Request $request) {
        $rules = UserPatientMapping::$rules;
        if (sizeof($rules) > 0) {
            $validation = $this->validateRequest($request, $rules);
            if (!empty($validation)) {
                return error($validation);
            }
        }
        $input = $request->all();
        if (empty($input['id'])) {
            return error('Sorry, Id is empty');
        }
        $mapping = UserPatientMapping::where('id', $input['id'])->first();
        if (empty($mapping)) {
            return error('Sorry, Patient not found');
        }
        if ($mapping->user_id != $request->user()->id) {
            return error('Sorry, Access denied');
        }
        $patientBooking = \App\Models\DoctorAppointmentBooking::where('user_patient_id', $input['id'])->count();
        if ($patientBooking > 0) {
            return error("Sorry, You can't update patient because he/she booked appointment. So,delete patient and reenter");
        }
        $input['first_name'] = ucwords($input['first_name']);
        $input['last_name'] = ucwords($input['last_name']);
        $patient = UserPatientMapping::findOrFail($input['id']);
        $patient->fill($input)->save();
        return success(UserPatientMapping::findOrFail($input['id']), "User patient had been updated successfully");
    }

    public function delete(Request $request) {
        $input = $request->all();
        if (empty($input['id'])) {
            return error('Sorry, Id is empty');
        }
        $mapping = UserPatientMapping::where('id', $input['id'])->first();
        if (empty($mapping)) {
            return error('Sorry, Patient not found');
        }
        if ($mapping->user_id != $request->user()->id) {
            return error('Sorry, Access denied');
        }
        $patientBooking = \App\Models\DoctorAppointmentBooking::where('user_patient_id', $input['id'])->count();
        $patient = UserPatientMapping::findOrFail($input['id']);
        if ($patientBooking > 0) {
            $input['is_deleted'] = 1;
            $input['status_id'] = STATUS_INACTIVE;
            $patient->fill($input)->save();
        } else {
            $patient->delete();
        }

        return success(array(), "User patient had been deleted successfully");
    }

    public function show(UserPatientMapping $userPatientMapping) {
        //
    }

    public function destroy(UserPatientMapping $userPatientMapping) {
        //
    }

}
