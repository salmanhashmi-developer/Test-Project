<?php

namespace App\Http\Controllers\API\Doctor;

use App\Http\Controllers\Controller;
use App\Http\Repository\UserMedicalHistoryRepository;
use Illuminate\Http\Request;

class UserMedicalHistoryController extends Controller {

    private $userMedicalHistoryRepository;

    public function __construct(UserMedicalHistoryRepository $userMedicalHistoryRepository) {
        $this->userMedicalHistoryRepository = $userMedicalHistoryRepository;
    }

    public function store(Request $request) {
        $input = $request->all();
        if (empty($input['ref_id'])) {
            return error("Sorry, Ref id is empty");
        } else {
            $bookingData = \App\Models\DoctorAppointmentBooking::findOrFail($input['ref_id']);
            if (empty($bookingData)) {
                return error("Sorry, Booking data not found");
            }
        }
        $input['image_prifix'] = "DA-";
        $input['service_ref_id'] = $bookingData->doctor_id;
        $input['ref_id'] = $bookingData->id;
        $input['user_id'] = $bookingData->user_id;
        $input['service_id'] = SERVICE_DOCTOR_APPOINTMENT;
        $input['uploaded_by'] = $request->user()->id;
        $result = $this->userMedicalHistoryRepository->saveMedicalHistory($input);
        return success($result, "Data has been saved successfully!");
    }

    public function getMedicalHistory(Request $request) {
        $input = $request->all();
        if (empty($input['ref_id'])) {
            return error("Sorry, Ref id is empty");
        }
        $input['service_id'] = SERVICE_DOCTOR_APPOINTMENT;
        $history = $this->userMedicalHistoryRepository->getMedicalHistory($input);
        $result = [];
        if (!empty($history)) {
            foreach ($history as $key => $value) {
                $result[$key] = $value;
                $result[$key]['frequency_json'] = !empty($value['frequency_json']) ? json_decode($value['frequency_json'], true) : null;
                $result[$key]['file'] = !empty($value['file']) ? getUrl('image/user_medical_history/') . $value['file'] : null;
            }
        }
        return success($result, "Data found successfully!");
    }

    public function delete(Request $request) {
        $input = $request->all();
        if (empty($input['id'])) {
            return error('Sorry, Id is empty');
        }
        $this->userMedicalHistoryRepository->deleteMedicalHistoryMapping($input['id']);
        return success(array(), "Data had been deleted successfully!");
    }

}
