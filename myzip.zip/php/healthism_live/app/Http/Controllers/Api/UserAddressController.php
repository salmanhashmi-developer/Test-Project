<?php

namespace App\Http\Controllers\API;

use App\Http\Controllers\Controller;
use App\Models\UserAddress;
use Illuminate\Http\Request;

class UserAddressController extends Controller {

    public function index(Request $request) {
        $result = UserAddress::where([
                    'user_id' => $request->user()->id,
                ])->orderBy('created_at', 'desc')->with('city', 'state')->get();
        return success($result, "Address");
    }

    public function store(Request $request) {
        $rules = UserAddress::$rules;
        if (sizeof($rules) > 0) {
            $validation = $this->validateRequest($request, $rules);
            if (!empty($validation)) {
                return error($validation);
            }
        }
        $input = $request->all();
        $cityStateId = $this->getCityStateIdFromName($input);
        $input['state_id'] = $cityStateId['state_id'];
        $input['city_id'] = $cityStateId['city_id'];
        $input['user_id'] = $request->user()->id;
        $input['created_at'] = date('Y-m-d H:i:s');
        $result = UserAddress::create($input);
        return success($result, "Address has been saved successfully");
    }

    public function update(Request $request) {
        $rules = UserAddress::$rules;
        if (sizeof($rules) > 0) {
            $validation = $this->validateRequest($request, $rules);
            if (!empty($validation)) {
                return error($validation);
            }
        }
        $input = $request->all();
        $cityStateId = $this->getCityStateIdFromName($input);
        $input['state_id'] = $cityStateId['state_id'];
        $input['city_id'] = $cityStateId['city_id'];
        $address = UserAddress::findOrFail($input['id']);
        $address->fill($input)->save();
        return success($address, "Address has been updated successfully");
    }

    private function getCityStateIdFromName($input) {
        $response = ['state_id' => 0, 'city_id' => 0];
        $stateName = trim($input['state']);
        $state = \App\Models\State::where('name', $stateName)->first();
        if (!empty($state)) {
            $response['state_id'] = $state->id;
        }
        $cityName = trim($input['city']);
        $city = \App\Models\City::where('name', $cityName)->first();
        if (!empty($city)) {
            $response['city_id'] = $city->id;
        }
        return $response;
    }

    public function delete(Request $request) {
        $input = $request->all();
        if (empty($input['id'])) {
            return error("Sorry, Id is empty");
        }
        $address = UserAddress::findOrFail($input['id']);
        if (!empty($address)) {
            $address->delete();
        }
        return success(array(), "Address has been deleted successfully");
    }

    public function getCityStateId(Request $request) {
        if (empty($request->data)) {
            return error('Sorry, Data is empty');
        }
        $result = [];
        $data = json_decode($request->data, true);
        $result['state'] = ['id' => 21, 'name' => 'Maharashtra'];
        $result['city'] = ['id' => 2126, 'name' => 'Mumbai'];
        if (!empty($data['administrativeArea'])) {
            $stateName = trim($data['administrativeArea']);
            $state = \App\Models\State::where('name', $stateName)->first();
            if (empty($state)) {
                \App\Models\Log::create([
                    'created_by' => $request->user()->id,
                    'type' => 'LOCATION',
                    'sub_type' => 'STATE',
                    'log_detail' => $stateName . ' : State name is not match with our data.',
                    'ip' => $request->ip(),
                    'created_at' => date('Y-m-d H:i:s'),
                ]);
                $result['state'] = ['id' => 0, 'name' => $stateName];
            } else {
                $result['state'] = $state;
            }
        }
        if (!empty($data['locality'])) {
            $cityName = trim($data['locality']);
        } else {
            $cityName = trim($data['subAdministrativeArea']);
        }
        $city = \App\Models\City::where('name', $cityName)->first();
        if (empty($city)) {
            \App\Models\Log::create([
                'created_by' => $request->user()->id,
                'type' => 'LOCATION',
                'sub_type' => 'CITY',
                'log_detail' => $cityName . ' : City name is not match with our data.',
                'ip' => $request->ip(),
                'created_at' => date('Y-m-d H:i:s'),
            ]);
            $result['city'] = ['id' => 0, 'name' => $cityName];
        } else {
            $result['city'] = $city;
        }
        $location = !empty($data['subLocality']) ? trim($data['subLocality']) . ', ' : "";
        $location .= $cityName;
        $result['location'] = $location;
        $result['pincode'] = !empty($data['postalCodeUserLocation']) ? $data['postalCodeUserLocation'] : "";
        return success($result, "Successfully...");
    }

}
