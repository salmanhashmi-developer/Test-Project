<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\City;

class CityController extends Controller {

    public function index(Request $request) {
        $city = City::query();
        $records_per_page = 10;
        if (!empty($request->name)) {
            $city = $city->where('name', 'like', '%' . $request->name . '%');
        }
        if (!empty($request->state_id)) {
            $city = $city->where('state_id', $request->state_id);
        }
        if (!empty($request->records_per_page) && is_numeric($request->records_per_page)) {
            $records_per_page = $request->records_per_page;
        }
        $city = $city->orderBy("name", "ASC");
        $stateList = \App\Models\State::get();
        $cityList = $city->paginate($records_per_page);
        if ($request->ajax()) {
            return view('backend.city.ajax_content', compact('cityList', 'stateList'));
        } else {
            return view('backend.city.index', compact('cityList', 'stateList'));
        }
    }

    public function add(Request $request) {
        $stateList = \App\Models\State::get();
        return view('backend.city.add', compact('stateList'));
    }

    public function edit($id) {
        $city = City::findOrFail($id);
        $stateList = \App\Models\State::get();
        return view('backend.city.edit', compact('city', 'stateList'));
    }

    public function update(Request $request, $id) {
        $city = City::findOrFail($id);
        $name = ucfirst($request->name);
        $duplicate = City::where('name', $name)->where('state_id', $request->state_id)->first();
        if (!empty($duplicate)) {
            if ($duplicate->id != $id) {
                return redirect()->route('admin.city', $city->id)->with('error', $name . ' : City already exists');
            }
        }
        $city->name = $request->name;
        $city->state_id = $request->state_id;
        $city->save();
        return redirect()->route('admin.city', $city->id)->with('success', $request->name . ' : City  Updated Successfully!');
    }

    public function store(Request $request) {
        $city = new City;
        $name = ucfirst($request->name);
        $duplicate = City::where('name', $name)->where('state_id', $request->state_id)->first();
        if (!empty($duplicate)) {
            return redirect()->route('admin.city', $city->id)->with('error', $name . ' : City already exists');
        }
        $city->name = $name;
        $city->state_id = $request->state_id;
        $city->save();
        return redirect()->route('admin.city', $city->id)->with('success', $name . ' City Details Added Successfully!');
    }

}
