<?php

namespace App\Http\Controllers;

use App\Http\Controllers\Controller;
use App\Http\Repository\UserMedicalHistoryRepository;
use Illuminate\Http\Request;
use App\Helpers\Helpers;

class UserMedicalHistoryController extends Controller {

    private $userMedicalHistoryRepository;

    public function __construct(UserMedicalHistoryRepository $userMedicalHistoryRepository) {
        $this->userMedicalHistoryRepository = $userMedicalHistoryRepository;
    }

    public function getUserMedicalHistory(Request $request) {
        $input = $request->all();
        if (empty($input['service_id'])) {
            return error("Sorry, Service id is empty");
        }
        if (empty($input['ref_id'])) {
            return error("Sorry, Ref id is empty");
        }
        $history = $this->userMedicalHistoryRepository->getMedicalHistory($input);
        $files = [];
        if (!empty($history)) {
            foreach ($history as $key => $value) {
                $files[$key] = $value;
                $files[$key]['frequency_json'] = !empty($value['frequency_json']) ? json_decode($value['frequency_json'], true) : null;
                $files[$key]['file'] = !empty($value['file']) ? getUrl('image/user_medical_history/') . $value['file'] : null;
            }
        }
        if ($input['service_id'] == SERVICE_LAB_REPORT) {
            $order = \App\Models\LabBooking::findOrFail($input['ref_id']);
            if ($request->user()->user_type_id == ADMIN) {
                return view('backend.lab_orders.upload_file', compact('order', 'files'));
            } else {
                return view('backend.lab_partner.orders.upload_file', compact('order', 'files'));
            }
        }
    }

    public function store(Request $request) {
        $input = $request->all();
        $input['uploaded_by'] = $request->user()->id;
        $paramArr = ['service_id' => $input['service_id'], 'ref_id' => $input['ref_id']];
        if (empty($input['new_file'])) {
            if ($input['service_id'] == SERVICE_LAB_REPORT) {
                return redirect()->route('lab.file.view', $paramArr)->with('error', 'Sorry, Please select file!');
            }
        }
        $result = $this->userMedicalHistoryRepository->uploadReports($input);
        if ($input['service_id'] == SERVICE_LAB_REPORT) {
            if ($request->user()->user_type_id == ADMIN) {
                return redirect()->route('admin.lab.file.view', $paramArr)->with('success', 'Test report uploaded successfully');
            } else {
                return redirect()->route('lab.file.view', $paramArr)->with('success', 'Test report uploaded successfully');
            }
        }
    }

    public function getMedicalHistory(Request $request) {
        $input = $request->all();
        if (empty($input['ref_id'])) {
            return error("Sorry, Ref id is empty");
        }
        $input['service_id'] = SERVICE_DOCTOR_APPOINTMENT;
        $history = $this->userMedicalHistoryRepository->getMedicalHistory($input);
        $result = [];
        if (!empty($history)) {
            foreach ($history as $key => $value) {
                $result[$key] = $value;
                $result[$key]['frequency_json'] = !empty($value['frequency_json']) ? json_decode($value['frequency_json'], true) : null;
                $result[$key]['file'] = !empty($value['file']) ? getUrl('image/user_medical_history/') . $value['file'] : null;
            }
        }
        return success($result, "Data found successfully!");
    }

    public function delete(Request $request) {
        $input = $request->all();
        if (empty($input['id'])) {
            return error('Sorry, Id is empty');
        }
        $this->userMedicalHistoryRepository->deleteMedicalHistoryMapping($input['id']);
        if ($input['service_id'] == SERVICE_LAB_REPORT) {
            if ($request->user()->user_type_id == ADMIN) {
                return redirect()->route('admin.lab.booking.view', $input['ref_id'])->with('success', 'Test report deleted successfully');
            } else {
                return redirect()->route('lab.order.view', $input['ref_id'])->with('success', 'Test report deleted successfully');
            }
        }
    }

}
