<?php

namespace App\Http\Controllers;

use App\Helpers\Helpers;
use App\Http\Requests\MenuBasedServiceFacilityRequest;
use App\Models\MenuBasedServiceFacility;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Auth;
use function Psr\Log\debug;

class MenuBasedServiceFacilityController extends Controller {

    public function index(Request $request) {
        $facilitis = MenuBasedServiceFacility::query();
        $records_per_page = 10;
        $menuBasedService = "";
        if (!empty($request->name)) {
            $facilitis = $facilitis->where('name', 'like', '%' . $request->name . '%');
        }
        if (!empty($request->menu_based_service_id)) {
            $menuBasedService = \App\Models\MenuBasedService::findOrFail($request->menu_based_service_id);
            $facilitis = $facilitis->where('menu_based_service_id', '=', $request->menu_based_service_id);
        } else {
            if (Auth::user()->user_type_id == MBS_USER) {
                $menuBasedService = \App\Models\MenuBasedService::where('user_id', $request->user()->id)->first();
                $facilitis = $facilitis->where('menu_based_service_id', '=', $menuBasedService->id);
            }
        }
        if ($request->type != '') {
            $facilitis = $facilitis->where('is_package', '=', $request->type);
        }
        if (!empty($request->status_id)) {
            $facilitis = $facilitis->where('status_id', '=', $request->status_id);
        }
        if (!empty($request->menu_based_service_name)) {
            $facilitis = $facilitis->whereRelation('menuBasedService', 'name', 'like', '%' . trim($request->menu_based_service_name) . '%');
        }
        if (!empty($request->records_per_page) && is_numeric($request->records_per_page)) {
            $records_per_page = $request->records_per_page;
        }
        $facilitis = $facilitis->orderBy("id", "DESC");
        $facilitis = $facilitis->paginate($records_per_page);
        if (Auth::user()->user_type_id == MBS_USER) {
            if ($request->ajax()) {
                return view('backend.menu_based_service_partner.facility.ajax_content', compact('facilitis', 'menuBasedService'));
            } else {
                return view('backend.menu_based_service_partner.facility.index', compact('facilitis', 'menuBasedService'));
            }
        }
        if ($request->ajax()) {
            return view('backend.menu_based_service.facility.ajax_content', compact('facilitis', 'menuBasedService'));
        } else {
            return view('backend.menu_based_service.facility.index', compact('facilitis', 'menuBasedService'));
        }
    }

    public function add(Request $request) {
        $menuBasedService = "";
        if (!empty($request->menu_based_service_id)) {
            $menuBasedService = \App\Models\MenuBasedService::findOrFail($request->menu_based_service_id);
        }
        $categoryList = \App\Models\Category::where('parent_id', $menuBasedService->category_id)
                        ->where('active', 1)->get();
        $categoryArr = [];
        if (!empty($categoryList)) {
            $result[] = "All";
            foreach ($categoryList as $category) {
                $categoryArr[] = $category['name'];
            }
        }
        if (Auth::user()->user_type_id == MBS_USER) {
            return view('backend.menu_based_service_partner.facility.add', compact('menuBasedService', 'categoryArr'));
        }

        return view('backend.menu_based_service.facility.add', compact('menuBasedService', 'categoryArr'));
    }

    public function edit(Request $request, $id) {
        $facility = MenuBasedServiceFacility::findOrFail($id);
        $facility->facility_desc_json = !empty($facility->detail_json) ? json_encode($facility->detail_json) : '';
        $flag = $request->flag;
        $categoryList = \App\Models\Category::where('parent_id', $facility->menuBasedService->category_id)
                        ->where('active', 1)->get();
        $categoryArr = [];
        if (!empty($categoryList)) {
            foreach ($categoryList as $category) {
                $categoryArr[] = $category['name'];
            }
        }
        if (Auth::user()->user_type_id == MBS_USER) {
            return view('backend.menu_based_service_partner.facility.edit', compact('facility', 'flag', 'categoryArr'));
        }

        return view('backend.menu_based_service.facility.edit', compact('facility', 'flag', 'categoryArr'));
    }

    public function view(Request $request, $id) {
        $facility = MenuBasedServiceFacility::findOrFail($id);
        $flag = $request->flag;
        if (Auth::user()->user_type_id == MBS_USER) {
            return view('backend.menu_based_service_partner.facility.view', compact('facility', 'flag'));
        }
        return view('backend.menu_based_service.facility.view', compact('facility', 'flag'));
    }

    public function update(MenuBasedServiceFacilityRequest $request, $id) {
        $input = $request->all();
        $facility = MenuBasedServiceFacility::findOrFail($id);
        $facility->menu_based_service_id = $request->menu_based_service_id;
        $facility->menu_based_service_parent_id = $request->menu_based_service_parent_id;
        $facility->name = $request->name;
        $facility->description = $request->description;
        $facility->gender = !empty($request->gender) ? $request->gender : null;
        $facility->time = $request->time;
        $facility->is_package = $request->is_package == 'on' ? 1 : 0;
        $facility->category = $request->package_category;
        $facility->facility_count = $request->facility_count;
        $facility->detail_json = !empty($request->facility_desc_json && $request->facility_desc_json != 'null') ? $request->facility_desc_json : null;
        $facility->price = $request->price;
        //   $facility->discount = $request->discount;
        $facility->status_id = $request->status_id;
        $facility->save();
        if (Auth::user()->user_type_id == MBS_USER) {
            return redirect()->route('mbs.facility.view', [$facility->id, 'flag' => $request->flag])->with('success', 'Menu Based Service Facility Master Details Updated Successfully!');
        }
        return redirect()->route('admin.menu_based_service.facility.view', [$facility->id, 'flag' => $request->flag])->with('success', 'Menu Based Service Facility Master Details Updated Successfully!');
    }

    public function store(MenuBasedServiceFacilityRequest $request) {
        $facility = new MenuBasedServiceFacility;
        $facility->menu_based_service_id = $request->menu_based_service_id;
        $facility->menu_based_service_parent_id = $request->menu_based_service_parent_id;
        $facility->name = $request->name;
        $facility->description = $request->description;
        $facility->gender = !empty($request->gender) ? $request->gender : null;
        $facility->time = $request->time;
        $facility->is_package = $request->is_package == 'on' ? 1 : 0;
        $facility->category = $request->package_category;
        $facility->facility_count = $request->facility_count;
        $facility->detail_json = !empty($request->facility_desc_json && $request->facility_desc_json != 'null') ? $request->facility_desc_json : null;
        $facility->price = $request->price;
        $facility->discount = $request->discount;
        $facility->status_id = $request->status_id;
        $facility->save();
        if (!empty($facility->id)) {
            $this->updateMenuBasedServiceSelfFacilityAvailable($facility->menu_based_service_id);
        }
        if (Auth::user()->user_type_id == MBS_USER) {
            return redirect()->route('mbs.facility.view', [$facility->id, 'flag' => $request->flag])->with('success', 'Menu Based Service Facility Master Details Added Successfully!');
        }
        return redirect()->route('admin.menu_based_service.facility.view', [$facility->id, 'flag' => $request->flag])->with('success', 'Menu Based Service Facility Master Details Added Successfully!');
    }

    public function delete(Request $request) {
        $input = $request->all();
        if (empty($input['facility_id'])) {
            return error('Sorry, Id is empty.');
        }
        $facility = MenuBasedServiceFacility::findOrFail($input['facility_id']);
        $facility->delete();
        $this->updateMenuBasedServiceSelfFacilityAvailable($facility->menu_based_service_id);
        return success(array(), 'Facility has been deleted successfully!');
    }

    public function updateMenuBasedServiceSelfFacilityAvailable($menuBasedServiceId) {
        $menuBasedService = \App\Models\MenuBasedService::findOrFail($menuBasedServiceId);
        $facilitiCount = count($menuBasedService->menuBasedServiceFacility);
        $menuBasedService->self_facility_available = $facilitiCount > 0 ? 1 : 0;
        $menuBasedService->save();
    }

    public function menuBasedServiceFacilityList(Request $request) {
        $input = $request->all();
        if (empty($input['menu_based_service_id'])) {
            return error("Sorry, Menu based service id is empty");
        }
        $menuBasedService = \App\Models\MenuBasedService::where('id', $input['menu_based_service_id'])->with('city', 'state')->first();
        if (empty($menuBasedService)) {
            return error("Sorry, Facility not found.");
        }
        if ($menuBasedService->status_id != STATUS_ACTIVE) {
            return error("Sorry, Menu based bervice is blocked.");
        }
        $input['self_facility_available'] = $menuBasedService->self_facility_available;
        $input['menu_based_service_id'] = $menuBasedService->id;
        $input['parent_id'] = $menuBasedService->parent_id;
        $input['type'] = isset($input['type']) ? $input['type'] : 'FECILITY';
        $result = [];
        $page = !empty($input['page']) ? $input['page'] : 1;
        $skip = $page > 1 ? ($page * 25) - 25 : 0;
        if (!empty($input['menu_based_service_id']) && !empty($input['self_facility_available'])) {
            $query = MenuBasedServiceFacility::where('menu_based_service_id', $input['menu_based_service_id']);
        } else {
            $query = MenuBasedServiceFacility::where('menu_based_service_id', $input['parent_id']);
        }
        $query->where('status_id', STATUS_ACTIVE);
        if ($input['type'] == 'PACKAGE') {
            $query->where('is_package', 1);
        } else {
            $query->where('is_package', 0);
        }
        if (!empty($input['name'])) {
            $name = $input['name'];
            $query->where('name', 'like', '%' . $name . '%');
        }
        $result['total_records'] = $query->count();
        $query->limit(25);
        if (isset($input['offset'])) {
            $query->offset($input['offset']);
        }
        $result['records'] = $query->get();
        $result['menuBasedService'] = $menuBasedService;
        return success($result, 'Menu based service facilitis list');
    }

}
