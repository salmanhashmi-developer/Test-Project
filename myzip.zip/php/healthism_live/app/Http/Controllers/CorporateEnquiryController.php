<?php

namespace App\Http\Controllers;

use App\Models\CorporateEnquiry;
use Illuminate\Http\Request;

class CorporateEnquiryController extends Controller {

    public function index(Request $request) {
        $enquiry = CorporateEnquiry::query();
        $records_per_page = 5;
        if (!empty($request->company_name)) {
            $enquiry->where('company_name', 'like', '%' . $request->company_name . '%');
        }
        if (!empty($request->status_id)) {
            $enquiry->where('status_id', "=", $request->status_id);
        }
        if (!empty($request->user_id)) {
            $enquiry->where('user_id', "=", $request->user_id);
        }
        if (!empty($request->start_date)) {
            $enquiry->whereDate('created_at', '>=', date('Y-m-d', strtotime($request->start_date)));
        }
        if (!empty($request->end_date)) {
            $enquiry->whereDate('created_at', '<=', date('Y-m-d', strtotime($request->end_date)));
        }
        
        if (!empty($request->records_per_page) && is_numeric($request->records_per_page)) {
            $records_per_page = $request->records_per_page;
        }
        $enquiry=$enquiry->orderBy("id",'DESC');
        $enquiry = $enquiry->paginate($records_per_page);
        $statusList = [STATUS_OPEN => 'OPEN', STATUS_CLOSED => 'CLOSED', STATUS_PENDING => 'PENDING'];
        if ($request->ajax()) {
            return view('backend.corporate.enquiry.ajax_content', compact('enquiry', 'statusList'));
        } else {
            return view('backend.corporate.enquiry.index', compact('enquiry', 'statusList'));
        }
    }

    public function update(Request $request) {
        $input = $request->all();
        $enquiry = CorporateEnquiry::findOrFail($input['id']);
        if ($enquiry->status_id != $input['status_id']) {
            $updateData = ['status_id' => $input['status_id']];
            $enquiry->fill($updateData)->save();
        }
        return 1;
    }

}
