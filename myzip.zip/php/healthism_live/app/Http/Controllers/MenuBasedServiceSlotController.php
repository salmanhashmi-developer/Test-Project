<?php

namespace App\Http\Controllers;

use App\Models\MenuBasedServiceSlot;
use Illuminate\Http\Request;

class MenuBasedServiceSlotController extends Controller {

    public function index(Request $request) {

        if (!empty($request->id)) {
            $mbs_data = \App\Models\MenuBasedService::findOrFail($request->id);
        }
        if (!empty($mbs_data->id)) {
            $slot = MenuBasedServiceSlot::query();
            $slot->where('menu_based_service_id', $request->id);
            $slot->orderBy('day', 'ASC');
            $slot->orderBy('from_time', 'ASC');
            $slot = $slot->get();
        }
        $slotData = [];
        if (!empty($slot)) {
            foreach ($slot as $key => $value) {
                $fromTime = substr($value['from_time'], 0, -3);
                $slotData[$value['day']][$fromTime] = [
                    'id' => $value['id'],
                    'startTime' => $fromTime,
                    'endTime' => substr($value['to_time'], 0, -3),
                ];
            }
        }
        $mbs_data->slot = empty($slotData) ? '' : json_encode($slotData);
        return view('backend.menu_based_service.add_slot', compact('mbs_data'));
    }

    public function store(Request $request) {
        $input = $request->all();
        if (empty($input['slot_data_obj'])) {
            return redirect()->route('admin.menu_based_service.slot', '')->with('error', 'Slot object is empty');
        }
        if (empty($input['menu_based_service_id'])) {
            return redirect()->route('admin.menu_based_service.slot', '')->with('error', 'MBS id is empty');
        }
        if (!empty($input['delete_slot_data_obj'])) {
            $deleteSlotArr = json_decode($input['delete_slot_data_obj'], TRUE);
            if (!empty($deleteSlotArr)) {
                MenuBasedServiceSlot::whereIn('id', $deleteSlotArr)->delete();
            }
        }
        $slotArr = json_decode($input['slot_data_obj'], TRUE);
        if (!empty($slotArr)) {
            $insertData = [];
            foreach ($slotArr as $key => $day) {
                foreach ($day as $slot) {
                    if (empty($slot['id'])) {
                        $data['day'] = $key;
                        $data['from_time'] = $slot['startTime'];
                        $data['to_time'] = $slot['endTime'];
                        $data['menu_based_service_id'] = $input['menu_based_service_id'];
                        $data['status_id'] = STATUS_ACTIVE;
                        $data['created_at'] = date('Y-m-d H:i:s');
                        $data['created_by'] = $request->user()->id;
                        $insertData[] = $data;
                    }
                }
            }
            if (!empty($insertData)) {
                MenuBasedServiceSlot::insert($insertData);
            }
        }

        $data = \App\Models\MenuBasedService::where('id', $request->menu_based_service_id)->first();
        return redirect()->route('admin.menu_based_service.slot', ['id' => $data->id])->with('success', 'Slot Details Added Successfully!');
    }

}
