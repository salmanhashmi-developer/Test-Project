<?php

namespace App\Http\Controllers;

use App\Helpers\Helpers;
use App\Http\Requests\UserPostRequest;
use App\Models\User;
use App\Models\UserType;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use Intervention\Image\ImageManagerStatic as Image;
use function Psr\Log\debug;

class UserController extends Controller {

    public function index(Request $request) {
        $users = User::query();
        $records_per_page = 10;
        if (!empty($request->first_name)) {
            $users = $users->where('first_name', 'like', '%' . $request->first_name . '%');
        }
        if (!empty($request->last_name)) {
            $users = $users->where('last_name', 'like', '%' . $request->last_name . '%');
        }
        if (!empty($request->email)) {
            $users = $users->where('email', 'like', '%' . $request->email . '%');
        }
        if (!empty($request->mobile)) {
            $users = $users->where('mobile', 'like', '%' . $request->mobile . '%');
        }
        if (!empty($request->user_type)) {
            $users = $users->where('user_type_id', '=', $request->user_type);
        }
        if (!empty($request->ref_code)) {
            $users = $users->where('ref_code', '=', $request->ref_code);
        }
        if (!empty($request->start_date)) {
            $users = $users->whereDate('created_at', '>=', date('Y-m-d', strtotime($request->start_date)));
        }
        if (!empty($request->end_date)) {
            $users = $users->whereDate('created_at', '<=', date('Y-m-d', strtotime($request->end_date)));
        }
        if (!empty($request->records_per_page) && is_numeric($request->records_per_page)) {
            $records_per_page = $request->records_per_page;
        }
        if (!empty($request->sort_field)) {
            if ($request->sort_field == 'fname' && ($request->sort_action == 'ASC' || $request->sort_action == 'DESC')) {
                $users = $users->orderBy("first_name", $request->sort_action);
            } elseif ($request->sort_field == 'lname' && ($request->sort_action == 'ASC' || $request->sort_action == 'DESC')) {
                $users = $users->orderBy("last_name", $request->sort_action);
            } elseif ($request->sort_field == 'email' && ($request->sort_action == 'ASC' || $request->sort_action == 'DESC')) {
                $users = $users->orderBy("email", $request->sort_action);
            } elseif ($request->sort_field == 'mobile' && ($request->sort_action == 'ASC' || $request->sort_action == 'DESC')) {
                $users = $users->orderBy("mobile", $request->sort_action);
            } elseif ($request->sort_field == 'dob' && ($request->sort_action == 'ASC' || $request->sort_action == 'DESC')) {
                $users = $users->orderBy("dob", $request->sort_action);
            } elseif ($request->sort_field == 'bloodGroup' && ($request->sort_action == 'ASC' || $request->sort_action == 'DESC')) {
                $users = $users->orderBy("blood_group", $request->sort_action);
            } elseif ($request->sort_field == 'gender' && ($request->sort_action == 'ASC' || $request->sort_action == 'DESC')) {
                $users = $users->orderBy("gender", $request->sort_action);
            } elseif ($request->sort_field == 'userType' && ($request->sort_action == 'ASC' || $request->sort_action == 'DESC')) {
                $users = $users->orderBy("user_type_id", $request->sort_action);
            } elseif ($request->sort_field == 'status' && ($request->sort_action == 'ASC' || $request->sort_action == 'DESC')) {
                $users = $users->orderBy("status_id", $request->sort_action);
            }
        } else {
            $users = $users->orderBy("id", "DESC");
        }
        $userType = UserType::get();
        $users = $users->paginate($records_per_page);
        if ($request->ajax()) {
            return view('backend.users.ajax_content', compact('users', 'userType'));
        } else {
            return view('backend.users.index', compact('users', 'userType'));
        }
    }

    public function add(Request $request) {
        $userTypes = UserType::get();
        $genders = Helpers::getEnumValues('user', 'gender');
        $bloodGroups = Helpers::getEnumValues('user', 'blood_group');
        return view('backend.users.add', compact('userTypes', 'genders', 'bloodGroups'));
    }

    public function edit($id) {
        $user = User::findOrFail($id);
        $userTypes = UserType::get();
        $genders = Helpers::getEnumValues('user', 'gender');
        $bloodGroups = Helpers::getEnumValues('user', 'blood_group');

        return view('backend.users.edit', compact('user', 'userTypes', 'genders', 'bloodGroups'));
    }

    public function view($id) {
        $user = User::findOrFail($id);
        return view('backend.users.view', compact('user'));
    }

    public function update(UserPostRequest $request, $id) {
        $input = $request->all();
        $input['id'] = $id;
        $mobileUser = $this->getMobileUser($input);
        if (!empty($mobileUser)) {
            if ($mobileUser->id != $id) {
                return redirect()->route('admin.user.edit', $id)->with('error', 'Sorry, ' . $input['mobile'] . ' Mobile no already use by other user try with different Mobile no');
            }
        }
        $emailUser = $this->getMobileEmail($input);
        if (!empty($emailUser)) {
            if ($emailUser->id != $id) {
                return redirect()->route('admin.user.edit', $id)->with('error', 'Sorry, ' . $input['email'] . ' Email already use by other user try with different email');
            }
        }
        $user = User::findOrFail($id);
        $user->first_name = $request->first_name;
        $user->last_name = $request->last_name;
        $user->email = $request->email;
        $user->mobile = $request->mobile;
        $user->dob = !empty($request->dob) ? date('Y-m-d', strtotime($request->dob)) : null;
        $user->blood_group = $request->blood_group;
        $user->gender = $request->gender;
        $user->user_type_id = $request->user_type_id;
        $user->status_id = $request->status_id;

        if (!empty($request->photo) && in_array($request->photo->extension(), allow_file_type_uploads)) {
            if (!empty($user->photo)) {
                @unlink('image/use_profile/' . $user->photo);
            }
//            $imageName = seo_url("{$request->first_name} {$request->last_name}") . '.' . $request->photo->extension();
//            $imageName = change_filename("image/use_profile/", $imageName);
//
//            if ($request->photo->move(public_path('image/use_profile'), $imageName)) {
//                $user->photo = $imageName;
//            }
            $image = $request->file('photo');
            $imageName = seo_url("{$request->first_name} {$request->last_name}") . '.' . $request->photo->extension();
            $image_resize = Image::make($image->getRealPath());
            $image_resize->resize(400, null, function ($constraint) {
                $constraint->aspectRatio();
            });
            $image_resize->save(public_path('image/use_profile/' . $imageName));
            $user->photo = $imageName;
        }

        $user->save();
        if ($user->user_type_id == END_USER) {
            $input['first_name'] = $request->first_name;
            $input['last_name'] = $request->last_name;
            $input['email'] = $request->email;
            $input['mobile'] = $request->mobile;
            $input['dob'] = !empty($request->dob) ? date('Y-m-d', strtotime($request->dob)) : null;
            $input['blood_group'] = $request->blood_group;
            $input['gender'] = $request->gender;
            $input['user_type_id'] = $request->user_type_id;
            $input['status_id'] = $request->status_id;
            $userPatientMapping = \App\Models\UserPatientMapping::where(['user_id' => $user->id, "relation" => 'SELF'])->first();
            $userPatientMapping->fill($input)->save();
        }
        return redirect()->route('admin.user.view', $user->id)->with('success', 'User Details Updated Successfully!');
    }

    public function store(UserPostRequest $request) {
        $mobileUser = $this->getMobileUser($request->all());
        if (!empty($mobileUser)) {
            return redirect()->route('admin.user.add')->with('error', 'Sorry, ' . $request->mobile . '  Mobile no already use by other user try with different Mobile no');
        }
        $emailUser = $this->getMobileEmail($request->all());
        if (!empty($emailUser)) {
            return redirect()->route('admin.user.add')->with('error', 'Sorry, ' . $request->email . '   Email already use by other user try with different email');
        }
        $user = new User;
        $user->first_name = $request->first_name;
        $user->last_name = $request->last_name;
        $user->email = $request->email;
        $user->mobile = $request->mobile;
        $user->dob = !empty($request->dob) ? date('Y-m-d', strtotime($request->dob)) : null;
        $user->blood_group = $request->blood_group;
        $user->gender = $request->gender;
        $user->user_type_id = $request->user_type_id;
        $user->status_id = $request->status_id;

        if (!empty($request->photo) && in_array($request->photo->extension(), allow_file_type_uploads)) {
//            $imageName = seo_url("{$request->first_name} {$request->last_name}") . '.' . $request->photo->extension();
//            $imageName = change_filename("image/use_profile/", $imageName);
//            if ($request->photo->move(public_path('image/use_profile'), $imageName)) {
//                $user->photo = $imageName;
//            }
            $image = $request->file('photo');
            $imageName = seo_url("{$request->first_name} {$request->last_name}") . '.' . $request->photo->extension();
            $image_resize = Image::make($image->getRealPath());
            $image_resize->resize(400, null, function ($constraint) {
                $constraint->aspectRatio();
            });
            $image_resize->save(public_path('image/use_profile/' . $imageName));
            $user->photo = $imageName;
        }

        $user->save();
        if (!empty($user) && $user->user_type_id == END_USER) {
            \App\Models\UserPatientMapping::create(array(
                "first_name" => $request->first_name,
                "last_name" => $request->last_name,
                "email" => $request->email,
                "mobile" => $request->mobile,
                "blood_group" => $request->blood_group,
                "gender" => $request->gender,
                "user_id" => $user->id,
                "status_id" => STATUS_ACTIVE, "relation" => 'SELF',
                "created_at" => date('Y-m-d H:i:s')
            ));
        }
        return redirect()->route('admin.user.view', $user->id)->with('success', 'User Details Added Successfully!');
    }

    public function getMobileUser($input) {
        $user = User::where('mobile', $input['mobile'])
                ->where('user_type_id', $input['user_type_id'])
                ->first();
        return $user;
    }

    public function getMobileEmail($input) {
        $user = User::where('email', $input['email'])
                ->where('user_type_id', $input['user_type_id'])
                ->first();
        return $user;
    }

    public function userSearch(Request $request) {
        $search = $request->get('search');
        $data = User::select(DB::raw("CONCAT(user.first_name,' ',user.last_name,' (', user.email,' - ', user.mobile,')') as label"), "id", DB::raw("CONCAT(user.first_name,' ',user.last_name) as value"))
                        ->where('user_type_id', END_USER)
                        ->where(function ($data) use ($search) {
                            return $data->where('first_name', 'LIKE', '%' . $search . '%')
                                    ->orwhere('last_name', 'LIKE', '%' . $search . '%')
                                    ->orwhere('mobile', 'LIKE', '%' . $search . '%')
                                    ->orwhere('email', 'LIKE', '%' . $search . '%');
                        })->get();

        return response()->json($data);
    }

}
