<?php

namespace App\Http\Controllers;

use App\Helpers\Helpers;
use App\Http\Requests\DoctorHospitalMappingPostRequest;
use App\Models\Hospital;
use App\Models\Doctor;
use App\Models\DoctorHospitalMapping;
use Illuminate\Http\Request;

class DoctorHospitalMappingController extends Controller {

    public function index(Request $request) {
        $mapping = DoctorHospitalMapping::query();
        $records_per_page = 10;
        if (!empty($request->doctor_id)) {
            $mapping->where('doctor_id', $request->doctor_id);
        }
        if (!empty($request->hospital_id)) {
            $mapping->where('hospital_id', $request->hospital_id);
        }
        if (!empty($request->doctor_name)) {
            $mapping->whereRelation('doctor', 'first_name', 'like', '%' . trim($request->doctor_name) . '%')
                    ->orwhereRelation('doctor', 'last_name', 'like', '%' . trim($request->doctor_name) . '%');
        }
        if (!empty($request->hospital_name)) {
            $mapping->whereRelation('hospital', 'name', 'like', '%' . trim($request->hospital_name) . '%');
        }
        if (!empty($request->records_per_page) && is_numeric($request->records_per_page)) {
            $records_per_page = $request->records_per_page;
        }
        if (!empty($request->sort_field)) {
            if ($request->sort_field == 'hospital_id' && ($request->sort_action == 'ASC' || $request->sort_action == 'DESC')) {
                $mapping->orderBy("hospital_id", $request->sort_action);
            } elseif ($request->sort_field == 'doctor_id' && ($request->sort_action == 'ASC' || $request->sort_action == 'DESC')) {
                $mapping->orderBy("doctor_id", $request->sort_action);
            }
        }

        $mapping = $mapping->paginate($records_per_page);
        if ($request->ajax()) {
            return view('backend.doctor_hospital_mapping.ajax_content', compact('mapping'));
        } else {
            return view('backend.doctor_hospital_mapping.index', compact('mapping'));
        }
    }

    public function add(Request $request) {
        $slot_type = Helpers::getEnumValues('doctor_hospital_mapping', 'slot_type');
        $day_list = ['Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday', 'Saturday', 'Sunday'];
        return view('backend.doctor_hospital_mapping.add', compact('slot_type', 'day_list'));
    }

    public function edit($id) {
        $mapping = DoctorHospitalMapping::findOrFail($id);
        $slot_type = Helpers::getEnumValues('doctor_hospital_mapping', 'slot_type');
        $day_list = ['Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday', 'Saturday', 'Sunday'];
        return view('backend.doctor_hospital_mapping.edit', compact('slot_type', 'mapping', 'day_list'));
    }

    public function view($id) {
        $mapping = DoctorHospitalMapping::where('id', $id)->with('doctor', 'hospital')->first();
        return view('backend.doctor_hospital_mapping.view', compact('mapping'));
    }

    public function update(DoctorHospitalMappingPostRequest $request, $id) {
        $mapping = $this->getMapping($request);
        if (empty($mapping) || $mapping->id == $id) {
            $mapping = DoctorHospitalMapping::findOrFail($id);
            $mapping->doctor_id = $request->doctor_id;
            $mapping->hospital_id = $request->hospital_id;
            $mapping->timing_json = $request->slot_data_obj;
            $mapping->fees = $request->fees;
            $mapping->discount = $request->discount;
            $mapping->video_consultation_available = $request->video_consultation_available == 'on' ? 1 : 0;
            $mapping->slot_type = $request->slot_type;
            $mapping->save();
            return redirect()->route('admin.doctor.hospital.mapping.view', $mapping->id)->with('success', 'Mapping Details Added Successfully!');
        }
    }

    public function store(DoctorHospitalMappingPostRequest $request) {
        $mapping = $this->getMapping($request);
        if (empty($mapping)) {
            $mapping = new DoctorHospitalMapping;
            $mapping->doctor_id = $request->doctor_id;
            $mapping->hospital_id = $request->hospital_id;
            $mapping->timing_json = $request->slot_data_obj;
            $mapping->fees = $request->fees;
            $mapping->discount = $request->discount;
            $mapping->video_consultation_available = $request->video_consultation_available == 'on' ? 1 : 0;
            $mapping->slot_type = $request->slot_type;
            $mapping->save();
            return redirect()->route('admin.doctor.hospital.mapping.view', $mapping->id)->with('success', 'Mapping Details Added Successfully!');
        }
        return redirect()->route('admin.doctor.hospital.mapping.view', $mapping->id)->with('warning', 'Sorry,Mapping Already Added!');
    }

    private function getMapping($input) {
        return DoctorHospitalMapping::where('doctor_id', $input->doctor_id)
                        ->where('hospital_id', $input->hospital_id)
                        ->first();
    }

    public function timingJsonData($dayTime) {
        if (!empty($dayTime)) {
            $timeJson = json_decode($dayTime, true);
            if (!empty($timeJson)) {
                foreach ($timeJson as $key => $value) {
                    if (!empty($value)) {
                        $timeData['DAY'] = $key;
                        $timeData['TIMING'] = [];
                        foreach ($value as $data) {
                            $timeData['TIMING'][] = $data;
                        }
                        $finalTimeArr[] = $timeData;
                    }
                }
                return json_encode($finalTimeArr);
            }
        }
        return null;
    }

}
