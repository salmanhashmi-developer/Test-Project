<?php

namespace App\Http\Controllers;

use App\Helpers\Helpers;
use App\Models\AppDashboard;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use Intervention\Image\ImageManagerStatic as Image;
use function Psr\Log\debug;

class BannerController extends Controller {

    public function index(Request $request) {
        $banners = AppDashboard::query();
        $records_per_page = 5;
        if (!empty($request->banner_type)) {
            $banners = $banners->where('type', '=', $request->banner_type);
        }
        if (!empty($request->records_per_page) && is_numeric($request->records_per_page)) {
            $records_per_page = $request->records_per_page;
        }
        $banners = $banners->orderBy("id", "DESC");
        $bannerType = Helpers::getEnumValues('app_dashboard', 'type');
        $banners = $banners->paginate($records_per_page);
        if ($request->ajax()) {
            return view('backend.banner.ajax_content', compact('banners', 'bannerType'));
        } else {
            return view('backend.banner.index', compact('banners', 'bannerType'));
        }
    }

    public function add(Request $request) {
        $type = Helpers::getEnumValues('app_dashboard', 'type');
        return view('backend.banner.add', compact('type'));
    }

    public function view($id) {
        $banner = AppDashboard::findOrFail($id);
        return view('backend.banner.view', compact('banner'));
    }

    public function store(Request $request) {
        $banner = new AppDashboard;
        $banner->type = $request->type;
        $banner->name = $request->name;
        $banner->file_type = 'Image';
        $banner->sort_order = $request->sort_order;
        $banner->data_json = $request->data_json;
        if (!empty($request->file) && in_array($request->file->extension(), allow_file_type_uploads)) {
            $imageName = seo_url("{$request->first_name} {$request->last_name}") . '.' . $request->file->extension();
            $imageName = change_filename("image/dashboard/", $imageName);
            if ($request->file->move(public_path('image/dashboard'), $imageName)) {
                $banner->file = $imageName;
            }
        }
        $banner->save();
        return redirect()->route('admin.banner.view', $banner->id)->with('success', 'Banner Details Added Successfully!');
    }

    public function delete($id) {
        $banner = AppDashboard::findOrFail($id);
        if (!empty($banner)) {
            if (!empty($banner->file)) {
                if (file_exists(public_path('image/dashboard/' . $banner->file))) {
                    unlink(public_path('image/dashboard/' . $banner->file));
                }
            }
            $banner->delete();
        }
        return success(array(), 'Banner has been deleted successfully!');
    }

}
