<?php

namespace App\Http\Controllers;

use App\Helpers\Helpers;
use App\Http\Requests\MenuBasedServiceRequest;
use App\Models\MenuBasedService;
use App\Models\MenuBasedServiceDetails;
use App\Models\State;
use App\Models\City;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Auth;
use Intervention\Image\ImageManagerStatic as Image;
use function Psr\Log\debug;

class MenuBasedServiceController extends Controller {

    public function location($id) {
        $menuBasedService = MenuBasedService::findOrFail($id)->toArray();
        $location = \App\Models\MenuBasedServiceSearch::where('menu_based_service_id', $id)->get()->toArray();
        if (Auth::user()->user_type_id == MBS_USER) {
            return view('backend.menu_based_service_partner.branch.location', compact('menuBasedService', 'location'));
        }
        return view('backend.menu_based_service.location', compact('menuBasedService', 'location'));
    }

    public function profile(Request $request) {
        $menuBasedService = MenuBasedService::where('user_id', $request->user()->id)->first();
        $images = $menuBasedService->menuBasedServiceDetails->gallery_json;
        return view('backend.menu_based_service_partner.profile', compact('menuBasedService', 'images'));
    }

    public function locationDelete($id) {
        $search = \App\Models\MenuBasedServiceSearch::findOrFail($id);
        if (!empty($search))
            $search->delete();
        return success($id, "Location has been deleted successfully");
    }

    public function locationSave(Request $request) {
        $inputArr['menu_based_service_id'] = $request->menu_based_service_id;
        $inputArr['pincode'] = $request->pincode;
        $inputArr['latitude'] = $request->latitude;
        $inputArr['longitude'] = $request->longitude;
        $inputArr['category_id'] = $request->category_id;
        $duplicate = \App\Models\MenuBasedServiceSearch::where($inputArr)->count();
        if ($duplicate > 0) {
            return error("Duplicate Entry");
        }
        $inputArr['menu_based_service_parent_id'] = !empty($request->menu_based_service_parent_id) ? $request->menu_based_service_parent_id : 0;
        $inputArr['name'] = $request->name;
        $result = \App\Models\MenuBasedServiceSearch::Create($inputArr);
        return success($result, "Location has been saved successfully");
    }

    public function menuBasedServiceSearch(Request $request) {
        $search = $request->get('search');
        $parentId = !empty($request->get('parent_id')) ? $request->get('parent_id') : '';
        $data = MenuBasedService::where('name', 'LIKE', '%' . $search . '%');
        if ($request->user()->user_type_id == MBS_USER) {
            $menuBasedServiceData = \App\Models\MenuBasedService::where('user_id', $request->user()->id)->first();
            $parentId = $menuBasedServiceData->id;
        }
        if (!empty($parentId)) {
            $data->where('parent_id', $parentId);
        }
        $data = $data->limit(25)->get();
        $result = [];
        if (!empty($data)) {
            $menuBasedService = [];
            foreach ($data as $value) {
                $menuBasedService['label'] = $value['name'] . '(' . $value['area'] . ',' . $value['city']['name'] . ',' . $value['state']['name'] . ')';
                $menuBasedService['id'] = $value['id'];
            }
            $result[] = $menuBasedService;
        }
        return response()->json($result);
    }

    public function index(Request $request) {
        $menuBasedService = MenuBasedService::query();
        $records_per_page = 10;
        $menuBasedService->where('parent_id', '=', 0);
        if (!empty($request->name)) {
            $menuBasedService = $menuBasedService->where('name', 'like', '%' . $request->name . '%');
        }
        if (!empty($request->area)) {
            $menuBasedService = $menuBasedService->where('area', 'like', '%' . $request->area . '%');
        }
        if (!empty($request->pincode)) {
            $menuBasedService = $menuBasedService->where('pincode', 'like', '%' . $request->pincode . '%');
        }
        if (!empty($request->category_id)) {
            $menuBasedService = $menuBasedService->where('category_id', "=", $request->category_id);
        }
        if (!empty($request->city_id)) {
            $menuBasedService = $menuBasedService->where('city_id', "=", $request->city_id);
        }
        if (!empty($request->state_id)) {
            $menuBasedService = $menuBasedService->where('state_id', "=", $request->state_id);
        }

        if (!empty($request->records_per_page) && is_numeric($request->records_per_page)) {
            $records_per_page = $request->records_per_page;
        }
        if (!empty($request->sort_field)) {
            if ($request->sort_field == 'name' && ($request->sort_action == 'ASC' || $request->sort_action == 'DESC')) {
                $menuBasedService = $menuBasedService->orderBy("name", $request->sort_action);
            } elseif ($request->sort_field == 'Area' && ($request->sort_action == 'ASC' || $request->sort_action == 'DESC')) {
                $menuBasedService = $menuBasedService->orderBy("area", $request->sort_action);
            } elseif ($request->sort_field == 'Pincode' && ($request->sort_action == 'ASC' || $request->sort_action == 'DESC')) {
                $menuBasedService = $menuBasedService->orderBy("pincode", $request->sort_action);
            }
        } else {
            $menuBasedService = $menuBasedService->orderBy("id", "DESC");
        }

        $menuBasedService = $menuBasedService->paginate($records_per_page);
        $states = State::where('active', 1)->get();
        $cities = [];
        if (!empty($request->state_id)) {
            $cities = City::where(['active' => 1, 'state_id' => $request->state_id])->get();
        }
        if ($request->ajax()) {
            return view('backend.menu_based_service.ajax_content', compact('menuBasedService', 'states', 'cities'));
        } else {
            return view('backend.menu_based_service.index', compact('menuBasedService', 'states', 'cities'));
        }
    }

    public function bulkInsert(Request $request) {
        return view('backend.menu_based_service.import');
    }

    public function add(Request $request) {
        $input = $request->all();
        $parent_menu_based_service = "";
        if (!empty($input['menu_based_service_id'])) {
            $parent_menu_based_service = MenuBasedService::findOrFail($request->menu_based_service_id);
        } else {
            if (Auth::user()->user_type_id == MBS_USER) {
                $parent_menu_based_service = \App\Models\MenuBasedService::where('user_id', Auth::user()->id)->first();
            }
        }
        $day_list = ['Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday', 'Saturday', 'Sunday'];
        $states = State::where('active', 1)->get();
        if (Auth::user()->user_type_id == MBS_USER) {
            return view('backend.menu_based_service_partner.branch.add', compact('states', 'day_list', 'parent_menu_based_service'));
        }
        return view('backend.menu_based_service.add', compact('states', 'day_list', 'parent_menu_based_service'));
    }

    public function edit($id) {
        $menuBasedService = MenuBasedService::findOrFail($id);
        $day_list = ['Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday', 'Saturday', 'Sunday'];
        $states = State::where('active', 1)->get();
        $cities = City::where(['active' => 1, 'state_id' => $menuBasedService->state_id])->get();
        if (Auth::user()->user_type_id == MBS_USER) {
            return view('backend.menu_based_service_partner.branch.edit', compact('menuBasedService', 'states', 'cities', 'day_list'));
        }
        return view('backend.menu_based_service.edit', compact('menuBasedService', 'states', 'cities', 'day_list'));
    }

    public function removeProfile($id) {
        $menuBasedService = MenuBasedService::findOrFail($id);
        $images = [];
        if ($menuBasedService->menuBasedServiceDetails->gallery_json != 'NULL' && !empty($menuBasedService->menuBasedServiceDetails->gallery_json)) {
            $gallery_images = json_decode($menuBasedService->menuBasedServiceDetails->gallery_json, true);
            if (!empty($gallery_images)) {
                foreach ($gallery_images as $row) {
                    $images[] = ['name' => $row];
                }
            }
        }
        if (!empty($menuBasedService->photo)) {
            if (file_exists(public_path('image/menu_base_service/' . $menuBasedService->photo))) {
                unlink(public_path('image/menu_base_service/' . $menuBasedService->photo));
            }
            $menuBasedService->photo = null;
            $menuBasedService->save();
        }
        return view('backend.menu_based_service.view', compact('menuBasedService', 'images'));
    }

    public function view($id) {
        $menuBasedService = MenuBasedService::findOrFail($id);
        $images = !empty($menuBasedService->menuBasedServiceDetails) ? $menuBasedService->menuBasedServiceDetails->gallery_json : '';
        if (Auth::user()->user_type_id == MBS_USER) {
            return view('backend.menu_based_service_partner.branch.view', compact('menuBasedService', 'images'));
        }
        return view('backend.menu_based_service.view', compact('menuBasedService', 'images'));
    }

    public function fetchGalleryImages(Request $request, $id) {
        $menuBasedService = MenuBasedService::findOrFail($id);
        $gallery_images = $menuBasedService->menuBasedServiceDetails->gallery_json;
        $images = [];
        if (!empty($gallery_images)) {
            foreach ($gallery_images as $row) {
                $row = str_replace(getUrl('image/menu_base_service_gallery'), "", $row);
                $size = @filesize("image/menu_base_service_gallery/" . $row);
                $images[] = ['name' => $row, 'size' => $size, 'path' => "/image/menu_base_service_gallery/"];
            }
        }
        return $images;
    }

    public function galleryImagesDelete(Request $request, $id) {
        if (!empty($id)) {
            $menuBasedService = MenuBasedService::findOrFail($id);
            $gallery_images = $menuBasedService->menuBasedServiceDetails->gallery_json;
            $result = [];
            foreach ($gallery_images as $imageName) {
                $result[] = str_replace(getUrl('image/menu_base_service_gallery/'), "", $imageName);
            }
            $gallery_images = $result;
            $gallery_images = array_filter($gallery_images, fn($m) => $m != $request->name);
            $menuBasedService->menuBasedServiceDetails->gallery_json = json_encode($gallery_images);
            @unlink('image/menu_base_service_gallery/' . $request->name);
            $menuBasedService->menuBasedServiceDetails->save();
        } else {
            unlink(public_path('/image/temp/') . $request->name);
        }
    }

    public function updateSortOrderGallery(Request $request, $id) {
        $menuBasedService = MenuBasedService::findOrFail($id);
        $menuBasedService->menuBasedServiceDetails->gallery_json = json_encode(array_values($request->order_list));
        $menuBasedService->menuBasedServiceDetails->save();
    }

    public function galleryImages(Request $request, $id) {
        if (!empty($id)) {
            $menuBasedService = MenuBasedService::findOrFail($id);

            $result = [];
            $gallery_images = $menuBasedService->menuBasedServiceDetails->gallery_json;
            if (!empty($request->file) && in_array($request->file->extension(), allow_file_type_uploads)) {
                $image = $request->file('file');
                $imageName = seo_url("healthism  {$menuBasedService->name}") . '.' . $request->file->extension();
                $image_resize = Image::make($image->getRealPath());
                $image_resize->resize(800, null, function ($constraint) {
                    $constraint->aspectRatio();
                });
                $image_resize->save(public_path('image/menu_base_service_gallery/' . $imageName));
                $gallery_images[] = $imageName;
                foreach ($gallery_images as $imageName) {
                    $result[] = str_replace(getUrl('image/menu_base_service_gallery/'), "", $imageName);
                }
            }
            echo $imageName;
            $menuBasedService->menuBasedServiceDetails->gallery_json = json_encode(array_values($result));
            $menuBasedService->menuBasedServiceDetails->save();
        } else {
            if (!empty($request->file) && in_array($request->file->extension(), allow_file_type_uploads)) {
                $image = $request->file('file');
                $fileName = pathinfo($request->file->getClientOriginalName(), PATHINFO_FILENAME);
                $imageName = seo_url($fileName) . '.' . $request->file->extension();
                $image_resize = Image::make($image->getRealPath());
                $image_resize->resize(800, null, function ($constraint) {
                    $constraint->aspectRatio();
                });
                $image_resize->save(public_path('/image/temp/' . $imageName));
                echo $imageName;
            }
        }
    }

    public function update(MenuBasedServiceRequest $request, $id) {
        $menuBasedService = MenuBasedService::findOrFail($id);
        $menuBasedService->contact_person = $request->contact_person;
        $menuBasedService->user_id = !empty($request->user) ? $request->user_id : null;
        $menuBasedService->parent_id = !empty($request->parent_id) ? $request->parent_id : 0;
        $menuBasedService->name = $request->name;
        $menuBasedService->phone = $request->phone;
        $menuBasedService->email = $request->email;
        $menuBasedService->address1 = $request->address1;
        $menuBasedService->address2 = $request->address2;
        $menuBasedService->area = $request->area;
        $menuBasedService->pincode = $request->pincode;
        $menuBasedService->city_id = $request->city_id;
        $menuBasedService->state_id = $request->state_id;
        $menuBasedService->mobile = $request->mobile;
        $menuBasedService->discount = $request->discount;
        $menuBasedService->category_id = $request->category_id;
        $menuBasedService->gender = $request->gender;
        $validateLatLong = validateLatLong($request->latitude, $request->longitude);
        $errorMessageLetLong = "";
        if (!empty($validateLatLong)) {
            $menuBasedService->latitude = $request->latitude;
            $menuBasedService->longitude = $request->longitude;
        } else {
            $errorMessageLetLong .= 'longitude and latitude are not valid';
        }
        $menuBasedService->discount = $request->discount;
        $menuBasedService->status_id = !empty($request->status_id) ? $request->status_id : STATUS_ACTIVE;

        /*
         *  details
         */
        $menuBasedService->cash_booking_allowed = $request->cash_booking_allowed == 'on' ? 1 : 0;
        $menuBasedService->cancellation_allowed = $request->cancellation_allowed == 'on' ? 1 : 0;
        if (!empty($request->cancel_policy)) {
            $cancel_policy = [];
            foreach ($request->cancel_policy as $key => $val) {
                if (!empty($val['cancel_policy'])) {
                    $cancel_policy[] = $val['cancel_policy'];
                }
            }
            if (!empty($cancel_policy)) {
                $menuBasedService->cancel_policy = json_encode($cancel_policy);
            }
        } else {
            $menuBasedService->cancel_policy = null;
        }
        if (!empty($request->cancel_policy_setting)) {
            $cancelPolicySetting = [];
            foreach ($request->cancel_policy_setting as $value) {
                if (!empty($value['hours']) && !empty($value['charge'])) {
                    $cancelPolicySetting[] = $value;
                }
            }
            if (!empty($cancelPolicySetting)) {
                $menuBasedService->cancel_policy_setting = json_encode($cancelPolicySetting);
            }
        } else {
            $menuBasedService->cancel_policy_setting = null;
        }
        $multipleLocation = [];
        $menuBasedService->menuBasedServiceDetails->timing_json = !empty($request->slot_data_obj) ? $request->slot_data_obj : null;
        $menuBasedService->menuBasedServiceDetails->description = $request->description;
        $menuBasedService->menuBasedServiceDetails->pancard_number = strtoupper($request->pancard_number);
        $menuBasedService->menuBasedServiceDetails->gst_number = strtoupper($request->gst_number);
        $menuBasedService->menuBasedServiceDetails->bank_account_number = $request->bank_account_number;
        $menuBasedService->menuBasedServiceDetails->bank_account_name = $request->bank_account_name;
        $menuBasedService->menuBasedServiceDetails->bank_name = $request->bank_name;
        $menuBasedService->menuBasedServiceDetails->bank_ifsc_code = strtoupper($request->bank_ifsc_code);
        if (!empty($request->photo) && in_array($request->photo->extension(), allow_file_type_uploads)) {
            $image = $request->file('photo');
            $imageName = seo_url("healthism {$request->name}") . '.' . $request->photo->extension();
            $image_resize = Image::make($image->getRealPath());
            $image_resize->resize(800, null, function ($constraint) {
                $constraint->aspectRatio();
            });
            $image_resize->save(public_path('image/menu_base_service/' . $imageName));
            $menuBasedService->photo = $imageName;
        }

        if (!empty($request->pancard_document)) {
            $imageName = seo_url("pan healthism {$request->name}") . '.' . $request->pancard_document->extension();
            $imageName = change_filename("image/menu_base_service/pan", $imageName);

            if ($request->pancard_document->move(public_path('image/menu_base_service/pan'), $imageName)) {
                if (!empty($menuBasedService->menuBasedServiceDetails->pancard_document)) {
                    @unlink('image/menu_base_service/pan/' . $menuBasedService->menuBasedServiceDetails->pancard_document);
                }
            }
            $menuBasedService->menuBasedServiceDetails->pancard_document = $imageName;
        }

        if (!empty($request->gst_certificate)) {
            $imageName = seo_url("gst healthism {$request->name}") . '.' . $request->gst_certificate->extension();
            $imageName = change_filename("image/menu_base_service/gst/", $imageName);

            if ($request->gst_certificate->move(public_path('image/menu_base_service/gst'), $imageName)) {
                if (!empty($menuBasedService->menuBasedServiceDetails->gst_certificate)) {
                    @unlink('image/menu_base_service/gst/' . $menuBasedService->menuBasedServiceDetails->gst_certificate);
                }
            }
            $menuBasedService->menuBasedServiceDetails->gst_certificate = $imageName;
        }
        $menuBasedService->menuBasedServiceDetails->save();
        $menuBasedService->save();
        if (Auth::user()->user_type_id == MBS_USER) {
            if (!empty($errorMessageLetLong)) {
                return redirect()->route('mbs.view', $menuBasedService->id)->with('error', $errorMessageLetLong);
            }
            return redirect()->route('mbs.view', $menuBasedService->id)->with('success', 'Menu based service details updated successfully!');
        }
        if (!empty($errorMessageLetLong)) {
            return redirect()->route('admin.menu_based_service.view', $menuBasedService->id)->with('error', $errorMessageLetLong);
        }
        return redirect()->route('admin.menu_based_service.view', $menuBasedService->id)->with('success', 'Menu based service details updated successfully!');
    }

    public function store(MenuBasedServiceRequest $request) {
        $menuBasedService = new MenuBasedService;
        $menuBasedServiceDetails = new MenuBasedServiceDetails();
        $gallery_images = [];
        if (!empty($request->images_list)) {
            foreach ($request->images_list as $row) {
                $fileName = explode(".", $row);
                $imageName = seo_url("healthism  $request->name {$fileName[0]}") . "." . $fileName[1];
                $imageName = change_filename("image/menu_base_service/", $imageName);
                copy(public_path("/image/temp/{$row}"), public_path('image/menu_base_service_gallery/' . $imageName));
                $gallery_images[] = $imageName;
            }
            $menuBasedServiceDetails->gallery_json = json_encode(array_values($gallery_images));
        }
        $menuBasedService->contact_person = $request->contact_person;
        $menuBasedService->user_id = !empty($request->user) ? $request->user_id : null;
        $menuBasedService->parent_id = !empty($request->parent_id) ? $request->parent_id : 0;
        $menuBasedService->name = $request->name;
        $menuBasedService->phone = $request->phone;
        $menuBasedService->mobile = $request->mobile;
        $menuBasedService->email = $request->email;
        $menuBasedService->address1 = $request->address1;
        $menuBasedService->address2 = $request->address2;
        $menuBasedService->area = $request->area;
        $menuBasedService->pincode = $request->pincode;
        $menuBasedService->city_id = $request->city_id;
        $menuBasedService->state_id = $request->state_id;
        $menuBasedService->discount = $request->discount;
        $menuBasedService->category_id = $request->category_id;
        $menuBasedService->gender = $request->gender;
        $menuBasedService->self_facility_available = 0;
        $validateLatLong = validateLatLong($request->latitude, $request->longitude);
        $errorMessageLetLong = "";
        if (!empty($validateLatLong)) {
            $menuBasedService->latitude = $request->latitude;
            $menuBasedService->longitude = $request->longitude;
        } else {
            $errorMessageLetLong .= 'longitude and latitude are not valid';
        }
        $menuBasedService->discount = $request->discount;
        $menuBasedService->status_id = !empty($request->status_id) ? $request->status_id : STATUS_ACTIVE;

        /*
         * details
         */
        $menuBasedService->cash_booking_allowed = $request->cash_booking_allowed == 'on' ? 1 : 0;
        $menuBasedService->cancellation_allowed = $request->cancellation_allowed == 'on' ? 1 : 0;
        if (!empty($request->cancel_policy)) {
            $cancel_policy = [];
            foreach ($request->cancel_policy as $key => $val) {
                if (!empty($val['cancel_policy'])) {
                    $cancel_policy[] = $val['cancel_policy'];
                }
            }
            if (!empty($cancel_policy)) {
                $menuBasedService->cancel_policy = json_encode($cancel_policy);
            }
        }
        if (!empty($request->cancel_policy_setting)) {
            $cancelPolicySetting = [];
            foreach ($request->cancel_policy_setting as $value) {
                if (!empty($value['hours']) && !empty($value['charge'])) {
                    $cancelPolicySetting[] = $value;
                }
            }
            if (!empty($cancelPolicySetting)) {
                $menuBasedService->cancel_policy_setting = json_encode($cancelPolicySetting);
            }
        }
        $menuBasedServiceDetails->timing_json = !empty($request->slot_data_obj) ? $request->slot_data_obj : null;
        $menuBasedServiceDetails->description = $request->description;
        $menuBasedServiceDetails->pancard_number = strtoupper($request->pancard_number);
        $menuBasedServiceDetails->gst_number = strtoupper($request->gst_number);
        $menuBasedServiceDetails->bank_account_number = $request->bank_account_number;
        $menuBasedServiceDetails->bank_account_name = $request->bank_account_name;
        $menuBasedServiceDetails->bank_name = $request->bank_name;
        $menuBasedServiceDetails->bank_ifsc_code = strtoupper($request->bank_ifsc_code);

        $multipleLocation = [];
        if (!empty($validateLatLong)) {
            $multipleLocation = [
                'pincode' => $request->pincode,
                'latitude' => $request->latitude,
                'longitude' => $request->longitude
            ];
        }
        if (!empty($request->photo) && in_array($request->photo->extension(), allow_file_type_uploads)) {
            $image = $request->file('photo');
            $imageName = seo_url("healthism {$request->name}") . '.' . $request->photo->extension();
            $image_resize = Image::make($image->getRealPath());
            $image_resize->resize(800, null, function ($constraint) {
                $constraint->aspectRatio();
            });
            $image_resize->save(public_path('image/menu_base_service/' . $imageName));
            $menuBasedService->photo = $imageName;
        }

        if (!empty($request->pancard_document)) {
            $imageName = seo_url("pan healthism {$request->name}") . '.' . $request->pancard_document->extension();
            $imageName = change_filename("image/menu_base_service/pan/", $imageName);
            if ($request->pancard_document->move(public_path('image/menu_base_service/pan'), $imageName)) {
                $menuBasedServiceDetails->pancard_document = $imageName;
            }
        }

        if (!empty($request->gst_certificate)) {
            $imageName = seo_url("gst healthism {$request->name}") . '.' . $request->gst_certificate->extension();
            $imageName = change_filename("image/menu_base_service/gst/", $imageName);
            if ($request->gst_certificate->move(public_path('image/menu_base_service/gst'), $imageName)) {
                $menuBasedServiceDetails->gst_certificate = $imageName;
            }
        }

        $menuBasedService->save();
        $menuBasedServiceDetails->menu_based_service_id = $menuBasedService->id;
        $menuBasedServiceDetails->save();
        if (Auth::user()->user_type_id == MBS_USER) {
            if (!empty($errorMessageLetLong)) {
                return redirect()->route('mbs.view', $menuBasedService->id)->with('error', $errorMessageLetLong);
            }
            return redirect()->route('mbs.view', $menuBasedService->id)->with('success', 'Menu based service details added successfully!');
        }
        if (!empty($errorMessageLetLong)) {
            return redirect()->route('admin.menu_based_service.view', $menuBasedService->id)->with('error', $errorMessageLetLong);
        }
        return redirect()->route('admin.menu_based_service.view', $menuBasedService->id)->with('success', 'Menu based service details added successfully!');
    }

    public function delete(Request $request) {
        $input = $request->all();
        if (empty($input['menu_based_service_id'])) {
            return error('Sorry, Id is empty.');
        }
        $menuBasedService = MenuBasedService::findOrFail($input['menu_based_service_id']);
        if (!empty($menuBasedService)) {
            $booking = \App\Models\MenuBasedServiceBooking::where('menu_based_service_id', $input['menu_based_service_id'])->count();
            if ($booking == 0) {
                if (!empty($menuBasedService->photo)) {
                    @unlink('image/menu_base_service/' . $menuBasedService->photo);
                }
                if (!empty($menuBasedService->menuBasedServiceDetails->gst_certificate)) {
                    @unlink('image/menu_base_service/gst/' . $menuBasedService->menuBasedServiceDetails->gst_certificate);
                }
                if (!empty($menuBasedService->menuBasedServiceDetails->pancard_document)) {
                    @unlink('image/menu_base_service/pan/' . $menuBasedService->menuBasedServiceDetails->pancard_document);
                }
                $menuBasedService->delete();
                MenuBasedServiceDetails::where('menu_based_service_id', $input['menu_based_service_id'])->delete();
                \App\Models\MenuBasedServiceSlot::where('menu_based_service_id', $input['menu_based_service_id'])->delete();
                \App\Models\MenuBasedServiceBlockSlot::where('menu_based_service_id', $input['menu_based_service_id'])->delete();
                \App\Models\MenuBasedServiceFacility::where('menu_based_service_id', $input['menu_based_service_id'])->delete();
                \App\Models\MenuBasedServiceSearch::where('menu_based_service_id', $input['menu_based_service_id'])->delete();
                \App\Models\ReportProblem::where('ref_id', $input['menu_based_service_id'])->where('service_id', MENU_BASED_SERVICE)->delete();
                \App\Models\UserReview::where('ref_id', $input['menu_based_service_id'])->where('service_id', MENU_BASED_SERVICE)->delete();
            } else {
                return error('Sorry, Menu based service has too many booking');
            }
        }
        return success(array(), 'Menu based service has been deleted successfully!');
    }

    public function menuBasedServiceUserSearch(Request $request) {
        $search = $request->get('search');
        $type = $request->get('type');
        $data = \App\Models\User::select(DB::raw("CONCAT(user.first_name,' ',user.last_name,' (', user.email,' - ', user.mobile,')') as label"), "id", DB::raw("CONCAT(user.first_name,' ',user.last_name) as value"))
                        ->where('user_type_id', $type)
                        ->where(function ($data) use ($search) {
                            return $data->where('first_name', 'LIKE', '%' . $search . '%')
                                    ->orwhere('last_name', 'LIKE', '%' . $search . '%')
                                    ->orwhere('mobile', 'LIKE', '%' . $search . '%');
                        })->limit(10)->get();
        if (!empty($data)) {
            foreach ($data as $key => $value) {
                $menuBasedServiceUser = MenuBasedService::where('user_id', $value['id'])->where('status_id', STATUS_ACTIVE)->count();
                if ($menuBasedServiceUser > 0) {
                    unset($data[$key]);
                }
            }
        }
        return response()->json($data);
    }

    public function menuBasedServiceBranch(Request $request) {
        $menuBasedServiceBranch = MenuBasedService::query();
        $records_per_page = 10;
        $parentId = 0;
        if (Auth::user()->user_type_id == MBS_USER) {
            $menuBasedService = \App\Models\MenuBasedService::where('user_id', Auth::user()->id)->first();
            if (!empty($menuBasedService)) {
                $parentId = $menuBasedService->id;
            }
        } else {
            if (!empty($request->menu_based_service_id)) {
                $parentId = $request->menu_based_service_id;
            }
        }

        $menuBasedServiceBranch = $menuBasedServiceBranch->where('parent_id', '=', $parentId);
        if (!empty($request->name)) {
            $menuBasedServiceBranch = $menuBasedServiceBranch->where('name', 'like', '%' . $request->name . '%');
        }
        if (!empty($request->phone)) {
            $menuBasedServiceBranch = $menuBasedServiceBranch->where('phone', 'like', '%' . $request->phone . '%');
        }
        if (!empty($request->pincode)) {
            $menuBasedServiceBranch = $menuBasedServiceBranch->where('pincode', 'like', '%' . $request->pincode . '%');
        }
        if (!empty($request->city_id)) {
            $menuBasedServiceBranch = $menuBasedServiceBranch->where('city_id', "=", $request->city_id);
        }
        if (!empty($request->state_id)) {
            $menuBasedServiceBranch = $menuBasedServiceBranch->where('state_id', "=", $request->state_id);
        }

        if (!empty($request->records_per_page) && is_numeric($request->records_per_page)) {
            $records_per_page = $request->records_per_page;
        }

        $menuBasedServiceBranch = $menuBasedServiceBranch->orderBy("id", "DESC");
        $menuBasedServiceBranch = $menuBasedServiceBranch->paginate($records_per_page);
        $states = State::where('active', 1)->get();
        $cities = [];
        $menuBasedService = MenuBasedService::findOrFail($parentId);
        if (!empty($request->state_id)) {
            $cities = City::where(['active' => 1, 'state_id' => $request->state_id])->get();
        }
        if (Auth::user()->user_type_id == ADMIN) {
            if ($request->ajax()) {
                return view('backend.menu_based_service.branch_content', compact('menuBasedServiceBranch', 'states', 'cities', 'menuBasedService'));
            } else {
                return view('backend.menu_based_service.branch', compact('menuBasedServiceBranch', 'states', 'cities', 'menuBasedService'));
            }
        }
        if (Auth::user()->user_type_id == MBS_USER) {
            if ($request->ajax()) {
                return view('backend.menu_based_service_partner.branch.ajax_content', compact('menuBasedServiceBranch', 'states', 'cities', 'menuBasedService'));
            } else {
                return view('backend.menu_based_service_partner.branch.index', compact('menuBasedServiceBranch', 'states', 'cities', 'menuBasedService'));
            }
        }
    }

    public function slotList(Request $request) {
        $input = $request->all();
        if (empty($input['id'])) {
            return false;
        }
        $order = \App\Models\MenuBasedServiceBooking::findOrFail($input['id']);
        $weekOfdays = array();
        $noOfDay = 15;
        for ($i = 0; $i <= $noOfDay; $i++) {
            $date = date('Y-m-d'); //today date
            $date = date('Y-m-d', strtotime('+' . $i . ' day', strtotime($date)));

            $day = date('D', strtotime($date));
            $date = date('Y-m-d', strtotime($date));
            $checkDateBlock = \App\Models\MenuBasedServiceBlockSlot::where('menu_based_service_id', $order->menu_based_service_id)
                    ->where('date', $date)
                    ->whereNull('menu_based_service_slot_id')
                    ->count();
            if (empty($checkDateBlock)) {
                $slot = $this->getSlotByDay($order, $day, $date);
                $slotCount = count($slot) > 0 ? count($slot) : 0;
                if ($slotCount != 0) {
                    $weekOfdays[] = array(
                        "day" => $day,
                        "date" => $date,
                        "slot_count" => $slotCount,
                        "slot" => $slot,
                    );
                }
            }
        }
        return view('backend.menu_based_service_partner.orders.slot', compact('order', 'weekOfdays'));
    }

    private function getSlotByDay($order, $day, $date) {
        try {
            $query = "SELECT
                        mbss.*,
                        mbss.id AS slot_id
                FROM
                        menu_based_service_slot AS mbss 
                WHERE
                        mbss.menu_based_service_id = " . $order->menu_based_service_id;
            $query .= " AND mbss.status_id = " . STATUS_ACTIVE . "
                        AND mbss.`day` = '" . $day . "' 
                        AND (
                                mbss.id NOT IN ( 
                                SELECT menu_based_service_slot_id FROM menu_based_service_block_slot
                                WHERE date = '" . $date . "'
                            )
                        )";
            if ($date == date('Y-m-d')) {
                $query .= " AND mbss.from_time >= '" . date('H:i:s') . "'";
            }
            $query .= " ORDER BY 
                            mbss.from_time ASC";

            //For to time to greter : AND mbss.from_time >= '" . date('H:i:s') . "'
            return executeSelectQueryOnMySQLDB($query);
        } catch (Exception $exc) {
            errorLog($exc);
        }
        return error(COMMON_ERROR);
    }

    public function menuBasedServiceList(Request $request) {
        $menuBasedService = MenuBasedService::query();
        if (!empty($request->name)) {
            $menuBasedService->where('name', 'like', '%' . $request->name . '%');
        }
        if (!empty($request->area)) {
            $menuBasedService->where('area', 'like', '%' . $request->area . '%');
        }
        if (!empty($request->pincode)) {
            $menuBasedService->whereRelation('menu_based_service_search', 'pincode', '=', trim($request->pincode));
            // $menuBasedService->where('pincode', '=', $request->pincode);
        }
        $menuBasedService->where('status_id', '=', STATUS_ACTIVE);
        $menuBasedService->limit(30);
        $result = $menuBasedService->with('city', 'state')->get();
        return success($result, "Menu based service List");
    }

}
