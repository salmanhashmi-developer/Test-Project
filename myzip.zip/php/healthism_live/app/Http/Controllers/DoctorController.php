<?php

namespace App\Http\Controllers;

use App\Helpers\Helpers;
use App\Http\Requests\DoctorPostRequest;
use App\Models\Category;
use App\Models\Doctor;
use App\Models\DoctorDetails;
use App\Models\User;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use Intervention\Image\ImageManagerStatic as Image;

class DoctorController extends Controller {

    public function index(Request $request) {
        $doctors = Doctor::query();
        $records_per_page = 10;
        if (!empty($request->name)) {
            $doctors = $doctors->where('first_name', 'like', '%' . trim($request->name) . '%')
                    ->orWhere('last_name', 'like', '%' . trim($request->name) . '%');
        }
        if (!empty($request->phone)) {
            $doctors = $doctors->where('phone', 'like', '%' . trim($request->phone) . '%');
        }
        if (!empty($request->email)) {
            $doctors = $doctors->where('email', 'like', '%' . trim($request->email) . '%');
        }
        if (!empty($request->specialization)) {
            $doctors = $doctors->where('specialization', 'like', '%' . trim($request->specialization) . '%');
        }
        if (!empty($request->gender)) {
            $doctors = $doctors->where('gender', 'like', '%' . trim($request->gender) . '%');
        }

        if (!empty($request->records_per_page) && is_numeric($request->records_per_page)) {
            $records_per_page = $request->records_per_page;
        }
        if (!empty($request->sort_field)) {
            if ($request->sort_field == 'name' && ($request->sort_action == 'ASC' || $request->sort_action == 'DESC')) {
                $doctors = $doctors->orderBy("first_name", $request->sort_action);
            } elseif ($request->sort_field == 'Specialization' && ($request->sort_action == 'ASC' || $request->sort_action == 'DESC')) {
                $doctors = $doctors->orderBy("specialization", $request->sort_action);
            } elseif ($request->sort_field == 'Gender' && ($request->sort_action == 'ASC' || $request->sort_action == 'DESC')) {
                $doctors = $doctors->orderBy("gender", $request->sort_action);
            }
        }
        $specialization = Helpers::getEnumValues('doctor', 'specialization');
        $gender = Helpers::getEnumValues('doctor', 'gender');

        $doctors = $doctors->paginate($records_per_page);
        if ($request->ajax()) {
            return view('backend.doctor.ajax_content', compact('doctors', 'specialization', 'gender'));
        } else {
            return view('backend.doctor.index', compact('doctors', 'specialization', 'gender'));
        }
    }

    public function add(Request $request) {
        $categories = Category::where(['parent_id' => CATEGORY_DOCTOR])->get();
        $specialization = Helpers::getEnumValues('doctor', 'specialization');
        $gender = Helpers::getEnumValues('doctor', 'gender');
        $registration_council = Helpers::getEnumValues('doctor_details', 'registration_council');

        return view('backend.doctor.add', compact('categories', 'specialization', 'gender', 'registration_council'));
    }

    public function userSearch(Request $request) {
        $search = $request->get('search');
        $data = User::select(DB::raw("CONCAT(user.first_name,' ',user.last_name,' (', user.email,' - ', user.mobile,')') as label"), "id", DB::raw("CONCAT(user.first_name,' ',user.last_name) as value"))
                        ->where('user_type_id', DOCTOR)
                        ->where(function ($data) use ($search) {
                            return $data->where('first_name', 'LIKE', '%' . $search . '%')
                                    ->orwhere('last_name', 'LIKE', '%' . $search . '%')
                                    ->orwhere('mobile', 'LIKE', '%' . $search . '%');
                        })->limit(10)->get();

        return response()->json($data);
    }

    public function doctorSearch(Request $request) {
        $search = $request->get('search');
        $data = Doctor::select(DB::raw("CONCAT(doctor.first_name,' ',doctor.last_name,' (', doctor.email,' - ', doctor.phone,')') as label"), "id", DB::raw("CONCAT(doctor.first_name,' ',doctor.last_name) as value"))
                        ->where(function ($data) use ($search) {
                            return $data->where('first_name', 'LIKE', '%' . $search . '%')
                                    ->orwhere('last_name', 'LIKE', '%' . $search . '%')
                                    ->orwhere('phone', 'LIKE', '%' . $search . '%');
                        })->get();
        return response()->json($data);
    }

    public function edit($id) {
        $doctor = Doctor::findOrFail($id);
        $categories = Category::where(['parent_id' => CATEGORY_DOCTOR])->get();
        $specialization = Helpers::getEnumValues('doctor', 'specialization');
        $gender = Helpers::getEnumValues('doctor', 'gender');
        $registration_council = Helpers::getEnumValues('doctor_details', 'registration_council');
        return view('backend.doctor.edit', compact('doctor', 'categories', 'specialization', 'gender', 'registration_council'));
    }

    public function removeProfile($id) {
        $doctor = Doctor::findOrFail($id);
        $categories = Category::where(['active' => 1])->get();
        if (!empty($doctor->photo)) {
            if (file_exists(public_path('image/doctor_profile/' . $doctor->photo))) {
                unlink(public_path('image/doctor_profile/' . $doctor->photo));
            }
            $doctor->photo = null;
            $doctor->save();
        }
        return view('backend.doctor.view', compact('doctor', 'categories'));
    }

    public function view($id) {
        $doctor = Doctor::findOrFail($id);
        $categories = Category::where(['active' => 1])->get();
        return view('backend.doctor.view', compact('doctor', 'categories'));
    }

    public function update(DoctorPostRequest $request, $id) {
        $doctor = Doctor::findOrFail($id);
        $doctor->first_name = $request->first_name;
        $doctor->middle_name = $request->middle_name;
        $doctor->last_name = $request->last_name;
        $doctor->phone = $request->phone;
        $doctor->email = $request->email;
        $doctor->status_id = $request->status_id;
        $doctor->gender = $request->gender;
        $doctor->specialization = $request->specialization;
        $doctor->short_desc = $request->short_desc;
        $doctor->experience = $request->experience;
        $doctor->user_id = $request->user_id;
        $doctor->sub_category_id = count($request->sub_category_id) > 1 ? ',' . implode(",", $request->sub_category_id) . ',' : implode(",", $request->sub_category_id);


        /*
         *  Doctor Details table updates..
         */

        $doctor->doctor_details->pan_card_no = $request->pan_card_no;
        $doctor->doctor_details->description = $request->description;
        $doctor->doctor_details->registration_number = $request->registration_number;
        $doctor->doctor_details->registration_council = $request->registration_council;
        $doctor->doctor_details->last_degree_obtained = $request->last_degree_obtained;
        $doctor->doctor_details->college_institute_name = $request->college_institute_name;
        $doctor->doctor_details->aadhar_card_no = $request->aadhar_card_no;
        $doctor->doctor_details->service_json = !empty($request->services) ? json_encode($request->services) : null;
        $doctor->doctor_details->specialization_json = !empty($request->specialization_json) ? json_encode($request->specialization_json) : null;
        $doctor->doctor_details->education_json = !empty($request->education) ? json_encode($request->education) : null;
        $doctor->doctor_details->membership_json = !empty($request->membership) ? json_encode($request->membership) : null;
        $doctor->doctor_details->experience_json = !empty($request->experience_json) ? json_encode($request->experience_json) : null;
        $doctor->doctor_details->registration_json = !empty($request->registration) ? json_encode($request->registration) : null;
        $doctor->doctor_details->registration_date = date('Y-m-d', strtotime($request->registration_date));
        $doctor->doctor_details->date_of_completion = date('Y-m-d', strtotime($request->date_of_completion));

        if (!empty($request->photo) && in_array($request->photo->extension(), allow_file_type_uploads)) {
            if (!empty($doctor->photo)) {
                @unlink('image/doctor_profile/' . $doctor->photo);
            }

//            $imageName = seo_url("healthism doctor {$request->first_name} {$request->last_name}") . '.' . $request->photo->extension();
//            $imageName = change_filename("image/doctor_profile/", $imageName);
//            $newPhoto = resizeImage($_FILES['photo']['tmp_name'], 300, 300);
//            if ($newPhoto->move(public_path('image/doctor_profile'), $imageName)) {
//                $doctor->photo = $imageName;
//            }
            $image = $request->file('photo');
            $filename = seo_url("healthism doctor {$request->first_name} {$request->last_name}") . '.' . $request->photo->extension();
            $image_resize = Image::make($image->getRealPath());
            $image_resize->resize(400, null, function ($constraint) {
                $constraint->aspectRatio();
            });
            $image_resize->save(public_path('image/doctor_profile/' . $filename));
            $doctor->photo = $filename;
        }
        if (!empty($request->registration_proof)) {

            if (!empty($doctor->doctor_details->registration_proof)) {
                @unlink('image/doctor_mix/' . $doctor->doctor_details->registration_proof);
            }

            $imageName = seo_url("registration healthism doctor {$request->first_name} {$request->last_name}") . '.' . $request->registration_proof->extension();
            $imageName = change_filename("image/doctor_mix/", $imageName);

            if ($request->registration_proof->move(public_path('image/doctor_mix'), $imageName)) {
                $doctor->doctor_details->registration_proof = $imageName;
            }
        }
        if (!empty($request->qualification_certificates)) {
            $imageName = seo_url("qualification healthism doctor {$request->first_name} {$request->last_name}") . '.' . $request->qualification_certificates->extension();
            $imageName = change_filename("image/doctor_mix/", $imageName);

            if ($request->qualification_certificates->move(public_path('image/doctor_mix'), $imageName)) {
                if (!empty($doctor->doctor_details->qualification_certificates)) {
                    @unlink('image/doctor_mix/' . $doctor->doctor_details->qualification_certificates);
                }
            }
            $doctor->doctor_details->qualification_certificates = $imageName;
        }
        if (!empty($request->pan_card_document)) {
            if (!empty($doctor->doctor_details->pan_card_document)) {
                @unlink('image/doctor_mix/' . $doctor->doctor_details->pan_card_document);
            }

            $imageName = seo_url("pan healthism doctor {$request->first_name} {$request->last_name}") . '.' . $request->pan_card_document->extension();
            $imageName = change_filename("image/doctor_mix/", $imageName);

            if ($request->pan_card_document->move(public_path('image/doctor_mix'), $imageName)) {
                $doctor->doctor_details->pan_card_document = $imageName;
            }
        }
        if (!empty($request->aadhar_card_document)) {
            if (!empty($doctor->doctor_details->aadhar_card_document)) {
                @unlink('image/doctor_mix/' . $doctor->doctor_details->aadhar_card_document);
            }

            $imageName = seo_url("aadhar healthism doctor {$request->first_name} {$request->last_name}") . '.' . $request->aadhar_card_document->extension();
            $imageName = change_filename("image/doctor_mix/", $imageName);

            if ($request->aadhar_card_document->move(public_path('image/doctor_mix'), $imageName)) {
                $doctor->doctor_details->aadhar_card_document = $imageName;
            }
        }
        $doctor->save();
        $doctor->doctor_details->save();

        return redirect()->route('admin.doctor.view', $doctor->id)->with('success', 'Doctor Details Updated Successfully!');
    }

    public function store(DoctorPostRequest $request) {
        $doctor = new Doctor;
        $doctor_details = new DoctorDetails();
        $doctor->first_name = $request->first_name;
        $doctor->middle_name = $request->middle_name;
        $doctor->last_name = $request->last_name;
        $doctor->phone = $request->phone;
        $doctor->email = $request->email;
        $doctor->specialization = $request->specialization;
        $doctor->gender = $request->gender;
        $doctor->status_id = $request->status_id;
        $doctor->short_desc = $request->short_desc;
        $doctor->experience = $request->experience;
        $doctor->user_id = $request->user_id;
        $doctor->sub_category_id = count($request->sub_category_id) > 1 ? ',' . implode(",", $request->sub_category_id) . ',' : implode(",", $request->sub_category_id);
        if (!empty($request->photo) && in_array($request->photo->extension(), allow_file_type_uploads)) {
//            $imageName = seo_url("healthism doctor {$request->first_name} {$request->last_name}") . '.' . $request->photo->extension();
//            $imageName = change_filename("image/doctor_profile/", $imageName);
//            if ($request->photo->move(public_path('image/doctor_profile'), $imageName)) {
//                $doctor->photo = $imageName;
//            }

            $image = $request->file('photo');
            $imageName = seo_url("healthism doctor {$request->first_name} {$request->last_name}") . '.' . $request->photo->extension();
            $image_resize = Image::make($image->getRealPath());
            $image_resize->resize(400, null, function ($constraint) {
                $constraint->aspectRatio();
            });
            $image_resize->save(public_path('image/doctor_profile/' . $imageName));
            $doctor->photo = $imageName;
        }
        $doctor->code = strtoupper(substr($request->last_name, 0, 3)) . rand(1000, 9999) . 'HP';
        $doctor->save();

        $doctor_details->doctor_id = $doctor->id;
        $doctor_details->description = $request->description;
        $doctor_details->registration_number = $request->registration_number;
        $doctor_details->registration_council = $request->registration_council;
        $doctor_details->last_degree_obtained = $request->last_degree_obtained;
        $doctor_details->college_institute_name = $request->college_institute_name;
        $doctor_details->aadhar_card_no = $request->aadhar_card_no;
        $doctor_details->pan_card_no = $request->pan_card_no;
        $doctor_details->service_json = !empty($request->services) ? json_encode($request->services) : null;
        $doctor_details->specialization_json = !empty($request->specialization_json) ? json_encode($request->specialization_json) : null;
        $doctor_details->education_json = !empty($request->education) ? json_encode($request->education) : null;
        $doctor_details->membership_json = !empty($request->membership) ? json_encode($request->membership) : null;
        $doctor_details->experience_json = !empty($request->experience_json) ? json_encode($request->experience_json) : null;
        $doctor_details->registration_json = !empty($request->registration) ? json_encode($request->registration) : null;
        $doctor_details->registration_date = date('Y-m-d', strtotime($request->registration_date));
        $doctor_details->date_of_completion = date('Y-m-d', strtotime($request->date_of_completion));

        if (!empty($request->registration_proof)) {
            $imageName = seo_url("registration healthism doctor {$request->first_name} {$request->last_name}") . '.' . $request->registration_proof->extension();
            $imageName = change_filename("image/doctor_mix/", $imageName);
            if ($request->registration_proof->move(public_path('image/doctor_mix'), $imageName)) {
                $doctor_details->registration_proof = $imageName;
            }
        }
        if (!empty($request->qualification_certificates)) {
            $imageName = seo_url("qualification healthism doctor {$request->first_name} {$request->last_name}") . '.' . $request->qualification_certificates->extension();
            $imageName = change_filename("image/doctor_mix/", $imageName);
            if ($request->qualification_certificates->move(public_path('image/doctor_mix'), $imageName)) {
                $doctor_details->qualification_certificates = $imageName;
            }
        }
        if (!empty($request->pan_card_document)) {
            $imageName = seo_url("pan healthism doctor {$request->first_name} {$request->last_name}") . '.' . $request->pan_card_document->extension();
            $imageName = change_filename("image/doctor_mix/", $imageName);
            if ($request->pan_card_document->move(public_path('image/doctor_mix'), $imageName)) {
                $doctor_details->pan_card_document = $imageName;
            }
        }
        if (!empty($request->aadhar_card_document)) {
            $imageName = seo_url("aadhar healthism doctor {$request->first_name} {$request->last_name}") . '.' . $request->aadhar_card_document->extension();
            $imageName = change_filename("image/doctor_mix/", $imageName);
            if ($request->aadhar_card_document->move(public_path('image/doctor_mix'), $imageName)) {
                $doctor_details->aadhar_card_document = $imageName;
            }
        }

        $doctor_details->save();


        return redirect()->route('admin.doctor.view', $doctor->id)->with('success', 'Doctor Details Added Successfully!');
    }

    public function delete(Request $request) {
        $input = $request->all();
        if (empty($input['doctor_id'])) {
            return error('Sorry, Id is empty.');
        }
        $doctor = Doctor::findOrFail($input['doctor_id']);
        if (!empty($doctor)) {
            $booking = \App\Models\DoctorAppointmentBooking::where('doctor_id', $input['doctor_id'])->count();
            if ($booking == 0) {
                if (!empty($doctor->photo)) {
                    @unlink('image/doctor_profile/' . $doctor->photo);
                }
                if (!empty($doctor->doctor_details->aadhar_card_document)) {
                    @unlink('image/doctor_mix/' . $doctor->doctor_details->aadhar_card_document);
                }
                if (!empty($doctor->doctor_details->pan_card_document)) {
                    @unlink('image/doctor_mix/' . $doctor->doctor_details->pan_card_document);
                }
                if (!empty($doctor->doctor_details->qualification_certificates)) {
                    @unlink('image/doctor_mix/' . $doctor->doctor_details->qualification_certificates);
                }
                if (!empty($doctor->doctor_details->registration_proof)) {
                    @unlink('image/doctor_mix/' . $doctor->doctor_details->registration_proof);
                }
                $doctor->delete();
                DoctorDetails::where('doctor_id', $input['doctor_id'])->delete();
                \App\Models\DoctorHospitalBlockSlot::where('doctor_id', $input['doctor_id'])->delete();
                \App\Models\DoctorHospitalMapping::where('doctor_id', $input['doctor_id'])->delete();
                \App\Models\DoctorHospitalSlot::where('doctor_id', $input['doctor_id'])->delete();
                \App\Models\ReportProblem::where('ref_id', $input['doctor_id'])->where('service_id', SERVICE_DOCTOR_APPOINTMENT)->delete();
                \App\Models\UserReview::where('ref_id', $input['doctor_id'])->where('service_id', SERVICE_DOCTOR_APPOINTMENT)->delete();
            } else {
                return error('Sorry, Doctor has appointment booking');
            }
        }
        return success(array(), 'Doctor has been deleted successfully!');
    }

}
