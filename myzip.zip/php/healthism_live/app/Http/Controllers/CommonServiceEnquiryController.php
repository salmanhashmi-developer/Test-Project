<?php

namespace App\Http\Controllers;

use App\Models\CommonServiceEnquiry;
use Illuminate\Http\Request;

class CommonServiceEnquiryController extends Controller {

    public function index(Request $request) {
        $commonServiceEnquiry = CommonServiceEnquiry::query();
        $records_per_page = 10;
        $commonServiceEnquiry->join('common_service', 'common_service_enquiry.common_service_id', '=', 'common_service.id');
        //$commonServiceEnquiry->join('status', 'common_service_enquiry.status_id', '=', 'status.id');
        if (!empty($request->phone)) {
            $commonServiceEnquiry->where('mobile', 'like', '%' . $request->phone . '%');
        }
        if (!empty($request->mobile)) {
            $commonServiceEnquiry->where('mobile', "=", $request->mobile);
        }
        if (!empty($request->user_id)) {
            $commonServiceEnquiry->where('user_id', "=", $request->user_id);
        }
        if (!empty($request->start_date)) {
            $commonServiceEnquiry->whereDate('appointment_date', '>=', date('Y-m-d', strtotime($request->start_date)));
        }
        if (!empty($request->end_date)) {
            $commonServiceEnquiry->whereDate('appointment_date', '<=', date('Y-m-d', strtotime($request->end_date)));
        }
        if (!empty($request->catogry_id)) {
            $commonServiceEnquiry->where('common_service.category_id', "=", $request->catogry_id);
        }
        $commonServiceEnquiry->select('common_service_enquiry.*', 'common_service.name AS operator_name', 'common_service.phone', 'common_service.category_id');
        if (!empty($request->records_per_page) && is_numeric($request->records_per_page)) {
            $records_per_page = $request->records_per_page;
        }
        // pr($commonServiceEnquiry->toSql());
        $commonServiceEnquiry = $commonServiceEnquiry->paginate($records_per_page);
        $categoryList = \App\Models\CommonServiceMapping::all();
        $statusList = [STATUS_PENDING => 'PENDING', STATUS_INPROGRESS => 'INPROGRESS', STATUS_DONE => 'DONE', STATUS_CANCELLED => 'CANCELLED'];
        if ($request->ajax()) {
            return view('backend.common_service_enquiry.ajax_content', compact('commonServiceEnquiry', 'categoryList', 'statusList'));
        } else {
            return view('backend.common_service_enquiry.index', compact('commonServiceEnquiry', 'categoryList', 'statusList'));
        }
    }

    public function view($id) {
        $commonServiceEnquiry = CommonServiceEnquiry::findOrFail($id);
        $statusList = [STATUS_PENDING => 'PENDING', STATUS_INPROGRESS => 'INPROGRESS', STATUS_DONE => 'DONE', STATUS_CANCELLED => 'CANCELLED'];
        return view('backend.common_service_enquiry.view', compact('commonServiceEnquiry', 'statusList'));
    }

    public function adminUpdateOrder(Request $request) {
        $input = $request->all();
        $commonServiceEnquiry = CommonServiceEnquiry::findOrFail($input['id']);
        if ($commonServiceEnquiry->status_id != $input['status_id']) {
            $remarks = [];
            if (!empty($commonServiceEnquiry->remark_json)) {
                $remarks = json_decode($commonServiceEnquiry->remark_json, true);
            }
            $statusList = [STATUS_PENDING => 'PENDING', STATUS_INPROGRESS => 'INPROGRESS', STATUS_DONE => 'DONE', STATUS_CANCELLED => 'CANCELLED'];
            $updatedBy = $request->user()->first_name . ' ' . $request->user()->last_name . '(' . $request->user()->mobile . ')';
            $remarks[] = array('remark' => $input['remark'], 'status' => $statusList[$input['status_id']], 'updated_at' => date('Y-m-d H:i:s'), 'updated_by_name' => $updatedBy, 'updated_by' => $request->user()->id);
            $updateData = ['status_id' => $input['status_id'], 'remark_json' => json_encode($remarks)];
            $commonServiceEnquiry->fill($updateData)->save();
        }
        return redirect()->route('admin.common.service.enquiry.view', $input['id'])->with('success', 'Enquiry status Updated Successfully!');
    }

}
