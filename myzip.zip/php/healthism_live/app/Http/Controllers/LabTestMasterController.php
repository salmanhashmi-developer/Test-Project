<?php

namespace App\Http\Controllers;

use App\Helpers\Helpers;
use App\Http\Requests\LabTestMasterRequest;
use App\Models\LabTestMaster;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use function Psr\Log\debug;

class LabTestMasterController extends Controller {

    public function index(Request $request) {
        $tests = LabTestMaster::query();
        $records_per_page = 10;
        if (!empty($request->name)) {
            $tests = $tests->where('name', 'like', '%' . $request->name . '%');
        }
        if ($request->type != '') {
            $tests = $tests->where('is_package', '=', $request->type);
        }
        if (!empty($request->status_id)) {
            $tests = $tests->where('status_id', '=', $request->status_id);
        }
        if (!empty($request->records_per_page) && is_numeric($request->records_per_page)) {
            $records_per_page = $request->records_per_page;
        }
        $tests = $tests->orderBy("id", "DESC");
        $tests = $tests->paginate($records_per_page);
        if ($request->ajax()) {
            return view('backend.lab_test_masters.ajax_content', compact('tests'));
        } else {
            return view('backend.lab_test_masters.index', compact('tests'));
        }
    }

    public function add(Request $request) {
        return view('backend.lab_test_masters.add');
    }

    public function edit($id) {
        $test = LabTestMaster::findOrFail($id);
        $test->test_desc_json = !empty($test->test_json) ? json_encode($test->test_json) : '';
        return view('backend.lab_test_masters.edit', compact('test'));
    }

    public function view($id) {
        $test = LabTestMaster::findOrFail($id);
        return view('backend.lab_test_masters.view', compact('test'));
    }

    public function update(LabTestMasterRequest $request, $id) {
        $input = $request->all();
        $test = LabTestMaster::findOrFail($id);
        $test->name = $request->name;
        $test->test_count = $request->test_count;
        $test->test_json = !empty($request->test_desc_json && $request->test_desc_json != 'null') ? $request->test_desc_json : null;
        $test->description = $request->description;
        $test->requirement = $request->requirement;
        $test->preparation = $request->preparation;
        $test->gender = !empty($request->gender) ? implode(",", $request->gender) : null;
        $test->is_package = $request->is_package == 'on' ? 1 : 0;
        $test->package_category = $request->package_category;
        $test->status_id = $request->status_id;
        $test->alias_name = $request->alias_name;
        $test->body_part = $request->body_part;
        $test->disease_name = $request->disease_name;
        $test->save();
        return redirect()->route('admin.test.view', $test->id)->with('success', 'Lab Test Master Details Updated Successfully!');
    }

    public function store(LabTestMasterRequest $request) {
        $test = new LabTestMaster;
        $test->name = $request->name;
        $test->test_count = $request->test_count;
        $test->test_json = !empty($request->test_desc_json && $request->test_desc_json != 'null') ? $request->test_desc_json : null;
        $test->description = $request->description;
        $test->requirement = $request->requirement;
        $test->preparation = $request->preparation;
        $test->gender = !empty($request->gender) ? implode(",", $request->gender) : null;
        $test->is_package = $request->is_package == 'on' ? 1 : 0;
        $test->package_category = $request->package_category;
        $test->status_id = $request->status_id;
        $test->alias_name = $request->alias_name;
        $test->body_part = $request->body_part;
        $test->disease_name = $request->disease_name;
        $test->save();
        return redirect()->route('admin.test.view', $test->id)->with('success', 'Lab Test Master Details Added Successfully!');
    }

    public function delete(Request $request) {
        $input = $request->all();
        if (empty($input['test_id'])) {
            return error('Sorry, Id is empty.');
        }
        $test = LabTestMaster::findOrFail($input['test_id']);
        $test->delete();
        return success(array(), 'Test has been deleted successfully!');
    }

    public function testSearch(Request $request) {
        $search = $request->get('search');
        $data = LabTestMaster::where('name', 'LIKE', '%' . $search . '%')
                ->where('status_id', STATUS_ACTIVE)
                ->limit(15)
                ->get();
        $result = [];
        if (!empty($data)) {
            foreach ($data as $key => $value) {
                $test = $value;
                $result[$key]['id'] = $value['id'];
                $result[$key]['label'] = $value['name'];
                $result[$key]['test_data'] = json_encode($value);
                $result[$key]['view'] = view('backend.lab_test_masters.popup_view', compact('test'))->render();
            }
        }
        return response()->json($result);
    }

}
