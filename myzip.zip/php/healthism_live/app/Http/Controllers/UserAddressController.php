<?php

namespace App\Http\Controllers;

use App\Http\Controllers\Controller;
use App\Models\UserAddress;
use Illuminate\Http\Request;

class UserAddressController extends Controller {

    public function store(Request $request) {
        $rules = [
            "type" => "Required",
            "address_1" => "Required",
            "address_2" => "Required",
            "pincode" => "Required",
            "state_id" => "Required",
            "city_id" => "Required",
        ];
        if (sizeof($rules) > 0) {
            $validation = $this->validateRequest($request, $rules);
            if (!empty($validation)) {
                return error($validation);
            }
        }
        $input = $request->all();
        $cityStateId = $this->getCityStateName($input);
        $input['state'] = $cityStateId['state'];
        $input['city'] = $cityStateId['city'];
        $input['user_id'] = $input['user_id'];
        $input['created_at'] = date('Y-m-d H:i:s');
        $result = UserAddress::create($input);
        return success($result, "User address has been saved successfully");
    }

    private function getCityStateName($input) {
        $response = [];
        $stateId = trim($input['state_id']);
        $state = \App\Models\State::where('id', $stateId)->first();
        if (!empty($state)) {
            $response['state'] = $state->name;
        }
        $cityId = trim($input['city_id']);
        $city = \App\Models\City::where('id', $cityId)->first();
        if (!empty($city)) {
            $response['city'] = $city->name;
        }
        return $response;
    }

}
