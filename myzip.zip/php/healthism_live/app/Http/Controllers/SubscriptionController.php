<?php

namespace App\Http\Controllers;

use App\Http\Controllers\Controller;
use App\Models\Subscription;
use App\Models\UserSubscription;
use Illuminate\Http\Request;

class SubscriptionController extends Controller {

    public function index(Request $request) {
        $userSubscription = UserSubscription::query();
        $records_per_page = 10;
        if (!empty($request->order_id) && is_numeric($request->order_id)) {
            $userSubscription->where('order_id', '=', trim($request->order_id));
        }
        if (!empty($request->status_id)) {
            $userSubscription->where('status_id', '=', trim($request->status_id));
        } else {
            $userSubscription->whereIn('status_id', [STATUS_ACTIVE, STATUS_INACTIVE]);
        }
        if (!empty($request->user_id) && is_numeric($request->user_id)) {
            $userSubscription->where('user_id', '=', trim($request->user_id));
        }
        if (!empty($request->subscription_id) && is_numeric($request->subscription_id)) {
            $userSubscription->where('subscription_id', '=', trim($request->subscription_id));
        }
        if (!empty($request->start_date)) {
            $userSubscription->whereDate('created_at', '>=', date('Y-m-d', strtotime($request->start_date)));
        }
        if (!empty($request->end_date)) {
            $userSubscription->whereDate('created_at', '<=', date('Y-m-d', strtotime($request->end_date)));
        }
        $userSubscription->orderBy("id", 'DESC');
        if (!empty($request->records_per_page) && is_numeric($request->records_per_page)) {
            $records_per_page = $request->records_per_page;
        }
//        $userSubscription->with('subscription', 'user', 'bookby', 'status');
        $userSubscription = $userSubscription->paginate($records_per_page);
        $subscription = Subscription::all();
        $statusList = [array('id' => STATUS_ACTIVE, 'name' => 'ACTIVE'), array('id' => STATUS_INACTIVE, 'name' => 'INACTIVE')];
        if ($request->ajax()) {
            return view('backend.user_subscription.ajax_content', compact('userSubscription', 'subscription', 'statusList'));
        } else {
            return view('backend.user_subscription.index', compact('userSubscription', 'subscription', 'statusList'));
        }
    }

    public function viewPlanList($id) {
        $user = \App\Models\User::findOrFail($id);
        $plan = getUserSubscription($id);
        $planList = [];
        if (empty($plan)) {
            $userTypeId = ',3,';
            $planList = Subscription::where('status_id', STATUS_ACTIVE)
                            ->where('user_type_id', 'like', '%' . $userTypeId . '%')->get();
        }
        return view('backend.users.plan', compact('user', 'plan', 'planList'));
    }

    public function saveUserSubscription(Request $request) {
        $input = $request->all();

        if (empty($input['user_id'])) {
            return error('Sorry, User id is empty');
        }
        if (empty($input['plan_id'])) {
            return error('Sorry, Plan id is empty');
        }
        $userDetail = \App\Models\User::findOrFail($input['user_id']);
        if (empty($userDetail['mobile'])) {
            return error('Sorry, User mobile not found');
        }
        if (empty($userDetail['email'])) {
            return error('Sorry, User email not found');
        }
        $plan = getUserSubscription($input['user_id']);
        if (!empty($plan)) {
            if ($plan['action'] == "Upgrade" && $plan['expire'] == 0) {
                return error('Sorry, User have already plan : ' . $plan['subscription']['name']);
            }
        }

        $planData = Subscription::where('id', $input['plan_id'])
                ->where('status_id', STATUS_ACTIVE)
                ->first();
        if (empty($planData)) {
            return error('Sorry, Plan data not found');
        }
        $tax = $planData['price'] - (($planData['price'] * 100) / (100 + SERVICE_SUBSCRIPTION_PLAN_TAX));
        $tax = round($tax, 2);

        $userSubscription = new UserSubscription;
        $userSubscription->subscription_id = $input['plan_id'];
        $userSubscription->user_id = $userDetail['id'];
        $userSubscription->card_no = getCardRandNumber($planData['card_prefix']);
        $userSubscription->amount = $planData['price'];
        $userSubscription->tax = $tax;
        $userSubscription->created_at = date('Y-m-d H:i:s');
        $userSubscription->expiry_date = date('Y-m-d', strtotime("+" . $planData['validity_in_days'] . " day"));
        $userSubscription->status_id = STATUS_ACTIVE;
        $userSubscription->created_by = $request->user()->id;
        $userSubscription->save();
        if (!empty($userSubscription->id)) {
            //Inacive Previous Plan
            UserSubscription::where('user_id', $userDetail['id'])->where('id', '!=', $userSubscription->id)
                    ->update(array('status_id' => STATUS_INACTIVE, 'updated_at' => date('Y-m-d H:i:s')));

            //User Family Member Inactive
            \App\Models\UserFamilyMember::where('user_id', $userDetail['id'])
                    ->update(array('status_id' => STATUS_INACTIVE, 'updated_at' => date('Y-m-d H:i:s')));

            //User Inactive In Other User Family Member
            \App\Models\UserFamilyMember::where('mobile', $userDetail['mobile'])
                    ->update(array('status_id' => STATUS_INACTIVE, 'updated_at' => date('Y-m-d H:i:s')));

            return success($userSubscription, 'Plane Saved successfully');
        } else {
            return error('oops something went wrong please try again');
        }
    }

}
