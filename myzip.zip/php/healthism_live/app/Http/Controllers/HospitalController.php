<?php

namespace App\Http\Controllers;

use App\Helpers\Helpers;
use App\Http\Requests\HospitalPostRequest;
use App\Models\Hospital;
use App\Models\HospitalDetails;
use App\Models\State;
use App\Models\City;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use Intervention\Image\ImageManagerStatic as Image;
use function Psr\Log\debug;

class HospitalController extends Controller {

    public function hospitalSearch(Request $request) {
        $search = $request->get('search');
//        $data = Hospital::select(DB::raw("CONCAT(hospital.name,' (', hospital.area,')') as label"), "id", DB::raw("CONCAT(hospital.name,' (', hospital.area,')') as value"))
//                        ->where('name', 'LIKE', '%' . $search . '%')->get();
        $data = Hospital::where('name', 'LIKE', '%' . $search . '%')->limit(10)->get();
        $result = [];
        if (!empty($data)) {
            foreach ($data as $value) {
                $hospital['label'] = $value['name'] . '(' . $value['area'] . ',' . $value['city']['name'] . ',' . $value['state']['name'] . ')';
                $hospital['id'] = $value['id'];
            }
            $result[] = $hospital;
        }
        return response()->json($result);
    }

    public function index(Request $request) {
        $hospitals = Hospital::query();
        $records_per_page = 10;
        if (!empty($request->name)) {
            $hospitals = $hospitals->where('name', 'like', '%' . $request->name . '%');
        }
        if (!empty($request->phone)) {
            $hospitals = $hospitals->where('phone', 'like', '%' . $request->phone . '%');
        }
        if (!empty($request->pincode)) {
            $hospitals = $hospitals->where('pincode', 'like', '%' . $request->pincode . '%');
        }
        if (!empty($request->city_id)) {
            //$hospitals = $hospitals->whereRelation('city', 'name', 'like', '%' . $request->city . '%');
            $hospitals = $hospitals->where('city_id', "=", $request->city_id);
        }
        if (!empty($request->state_id)) {
            //   $hospitals = $hospitals->whereRelation('state', 'name', 'like', '%' . $request->state . '%');
            $hospitals = $hospitals->where('state_id', "=", $request->state_id);
        }

        if (!empty($request->records_per_page) && is_numeric($request->records_per_page)) {
            $records_per_page = $request->records_per_page;
        }
        if (!empty($request->sort_field)) {
            if ($request->sort_field == 'name' && ($request->sort_action == 'ASC' || $request->sort_action == 'DESC')) {
                $hospitals = $hospitals->orderBy("name", $request->sort_action);
            } elseif ($request->sort_field == 'Area' && ($request->sort_action == 'ASC' || $request->sort_action == 'DESC')) {
                $hospitals = $hospitals->orderBy("area", $request->sort_action);
            } elseif ($request->sort_field == 'Pincode' && ($request->sort_action == 'ASC' || $request->sort_action == 'DESC')) {
                $hospitals = $hospitals->orderBy("pincode", $request->sort_action);
            }
        }

        $hospitals = $hospitals->paginate($records_per_page);
        $states = State::where('active', 1)->get();
        $cities = [];
        if (!empty($request->state_id)) {
            $cities = City::where(['active' => 1, 'state_id' => $request->state_id])->get();
        }
        if ($request->ajax()) {
            return view('backend.hospitals.ajax_content', compact('hospitals', 'states', 'cities'));
        } else {
            return view('backend.hospitals.index', compact('hospitals', 'states', 'cities'));
        }
    }

    public function add(Request $request) {
        $states = State::where('active', 1)->get();
        $type = Helpers::getEnumValues('hospital', 'type');
        return view('backend.hospitals.add', compact('states', 'type'));
    }

    public function edit($id) {
        $hospital = Hospital::findOrFail($id);
        $states = State::where('active', 1)->get();
        $cities = City::where(['active' => 1, 'state_id' => $hospital->state_id])->get();
        $type = Helpers::getEnumValues('hospital', 'type');

        return view('backend.hospitals.edit', compact('hospital', 'states', 'cities', 'type'));
    }

    public function removeProfile($id) {
        $hospital = Hospital::findOrFail($id);
        $images = [];
        if ($hospital->hospital_details->gallery_json != 'NULL' && !empty($hospital->hospital_details->gallery_json)) {
            $gallery_images = json_decode($hospital->hospital_details->gallery_json, true);
            if (!empty($gallery_images)) {
                foreach ($gallery_images as $row) {
                    $images[] = ['name' => $row];
                }
            }
        }
        if (!empty($hospital->photo)) {
            if (file_exists(public_path('image/hospital/' . $hospital->photo))) {
                unlink(public_path('image/hospital/' . $hospital->photo));
            }
            $hospital->photo = null;
            $hospital->save();
        }
        return view('backend.hospitals.view', compact('hospital', 'images'));
    }

    public function view($id) {
        $hospital = Hospital::findOrFail($id);
        $images = [];
        if ($hospital->hospital_details->gallery_json != 'NULL' && !empty($hospital->hospital_details->gallery_json)) {
            $gallery_images = json_decode($hospital->hospital_details->gallery_json, true);
            if (!empty($gallery_images)) {
                foreach ($gallery_images as $row) {
                    $images[] = ['name' => $row];
                }
            }
        }
        return view('backend.hospitals.view', compact('hospital', 'images'));
    }

    public function fetchGalleryImages(Request $request, $id) {
        $hospital = Hospital::findOrFail($id);
        $gallery_images = json_decode($hospital->hospital_details->gallery_json, true);
        $images = [];
        if (!empty($gallery_images)) {
            foreach ($gallery_images as $row) {
                $size = @filesize("image/hospital_gallery/" . $row);
                $images[] = ['name' => $row, 'size' => $size, 'path' => "/image/hospital_gallery/"];
            }
        }
        return $images;
    }

    public function galleryImagesDelete(Request $request, $id) {
        if (!empty($id)) {
            $hospital = Hospital::findOrFail($id);
            $gallery_images = json_decode($hospital->hospital_details->gallery_json, true);
            $gallery_images = array_filter($gallery_images, fn($m) => $m != $request->name);
            $hospital->hospital_details->gallery_json = json_encode($gallery_images);
            @unlink('image/hospital_gallery/' . $request->name);
            $hospital->hospital_details->save();
        } else {
            unlink(public_path('/image/temp/') . $request->name);
        }
    }

    public function updateSortOrderGallery(Request $request, $id) {
        $hospital = Hospital::findOrFail($id);
        $hospital->hospital_details->gallery_json = json_encode(array_values($request->order_list));
        $hospital->hospital_details->save();
    }

    public function galleryImages(Request $request, $id) {
        if (!empty($id)) {
            $hospital = Hospital::findOrFail($id);

            $gallery_images = json_decode($hospital->hospital_details->gallery_json, true);
            if (!empty($request->file) && in_array($request->file->extension(), allow_file_type_uploads)) {
//                $imageName = seo_url("healthism hospital {$hospital->name}") . '.' . $request->file->extension();
//                $imageName = change_filename("image/hospital_gallery/", $imageName);
//                if ($request->file->move(public_path('image/hospital_gallery'), $imageName)) {
//                    $gallery_images[] = $imageName;
//                }
                $image = $request->file('file');
                $imageName = seo_url("healthism hospital {$hospital->name}") . '.' . $request->file->extension();
                $image_resize = Image::make($image->getRealPath());
                $image_resize->resize(800, null, function ($constraint) {
                    $constraint->aspectRatio();
                });
                $image_resize->save(public_path('image/hospital_gallery/' . $imageName));
                $gallery_images[] = $imageName;
            }
            echo $imageName;
            $hospital->hospital_details->gallery_json = json_encode(array_values($gallery_images));
            $hospital->hospital_details->save();
        } else {
            if (!empty($request->file) && in_array($request->file->extension(), allow_file_type_uploads)) {
//                $fileName = pathinfo($request->file->getClientOriginalName(), PATHINFO_FILENAME);
//                $imageName = seo_url($fileName) . '.' . $request->file->extension();
//                $imageName = change_filename("/tmp/", $imageName);
//                if ($request->file->move('/tmp/', $imageName)) {
//                    echo $imageName;
//                }

                $image = $request->file('file');
                $fileName = pathinfo($request->file->getClientOriginalName(), PATHINFO_FILENAME);
                $imageName = seo_url($fileName) . '.' . $request->file->extension();
                $image_resize = Image::make($image->getRealPath());
                $image_resize->resize(800, null, function ($constraint) {
                    $constraint->aspectRatio();
                });
                $image_resize->save(public_path('/image/temp/' . $imageName));
                echo $imageName;
            }
        }
    }

    public function update(HospitalPostRequest $request, $id) {
        $hospital = Hospital::findOrFail($id);
        $hospital->name = $request->name;
        $hospital->phone = $request->phone;
        $hospital->address1 = $request->address1;
        $hospital->address2 = $request->address2;
        $hospital->area = $request->area;
        $hospital->pincode = $request->pincode;
        $hospital->city_id = $request->city_id;
        $hospital->state_id = $request->state_id;
        $validateLatLong = validateLatLong($request->latitude, $request->longitude);
        if (!empty($validateLatLong)) {
            $hospital->latitude = $request->latitude;
            $hospital->longitude = $request->longitude;
        }
        $hospital->type = $request->type;
        $hospital->cash_booking_allowed = $request->cash_booking_allowed == 'on' ? 1 : 0;
        $hospital->cancellation_allowed = $request->cancellation_allowed == 'on' ? 1 : 0;
        $hospital->status_id = $request->status_id;

        $cancel_policy = [];
        if (!empty($request->cancel_policy)) {
            foreach ($request->cancel_policy as $key => $val) {
                $val = array_values($val);
                if (!empty($val && !empty(trim($val[0])))) {
                    $cancel_policy[] = trim($val[0]);
                }
            }
        }
        if (!empty($cancel_policy)) {
            $hospital->cancel_policy = json_encode($cancel_policy);
        }

        $cancel_policy_setting = [];
        if (!empty($request->cancel_policy_setting)) {
            foreach ($request->cancel_policy_setting as $val) {
                if (!empty(trim($val['hours'])) && !empty(trim($val['charge']))) {
                    $cancel_policy_setting[] = $val;
                }
            }
        }
        if (!empty($cancel_policy_setting)) {
            $hospital->cancel_policy_setting = json_encode($cancel_policy_setting);
        }

        /*
         * hospital details
         */

        $hospital->hospital_details->pancard_number = $request->pancard_number;
        $hospital->hospital_details->gst_number = $request->gst_number;
        $hospital->hospital_details->bank_account_number = $request->bank_account_number;
        $hospital->hospital_details->bank_account_name = $request->bank_account_name;
        $hospital->hospital_details->bank_name = $request->bank_name;
        $hospital->hospital_details->bank_ifsc_code = $request->bank_ifsc_code;

        if (!empty($request->photo) && in_array($request->photo->extension(), allow_file_type_uploads)) {
//            $imageName = seo_url("healthism hospital {$request->name}") . '.' . $request->photo->extension();
//            $imageName = change_filename("image/hospital/", $imageName);
//
//            if ($request->photo->move(public_path('image/hospital'), $imageName)) {
//                if (!empty($hospital->photo)) {
//                    @unlink('image/hospital/' . $hospital->photo);
//                }
//            }
//            $hospital->photo = $imageName;

            $image = $request->file('photo');
            $imageName = seo_url("healthism hospital {$request->name}") . '.' . $request->photo->extension();
            $image_resize = Image::make($image->getRealPath());
            $image_resize->resize(800, null, function ($constraint) {
                $constraint->aspectRatio();
            });
            $image_resize->save(public_path('image/hospital/' . $imageName));
            $hospital->photo = $imageName;
        }

        if (!empty($request->pancard_document)) {
            $imageName = seo_url("pan healthism hospital {$request->name}") . '.' . $request->pancard_document->extension();
            $imageName = change_filename("image/hospital/", $imageName);

            if ($request->pancard_document->move(public_path('image/hospital'), $imageName)) {
                if (!empty($hospital->hospital_details->pancard_document)) {
                    @unlink('image/hospital/' . $hospital->hospital_details->pancard_document);
                }
            }
            $hospital->hospital_details->pancard_document = $imageName;
        }

        if (!empty($request->gst_certificate)) {
            $imageName = seo_url("gst healthism hospital {$request->name}") . '.' . $request->gst_certificate->extension();
            $imageName = change_filename("image/hospital/", $imageName);

            if ($request->gst_certificate->move(public_path('image/hospital'), $imageName)) {
                if (!empty($hospital->hospital_details->gst_certificate)) {
                    @unlink('image/hospital/' . $hospital->hospital_details->gst_certificate);
                }
            }
            $hospital->hospital_details->gst_certificate = $imageName;
        }


        $hospital->hospital_details->save();
        $hospital->save();
        if (empty($validateLatLong)) {
            return redirect()->route('admin.hospital.view', $hospital->id)->with('error', 'longitude and latitude are not valid');
        }
        return redirect()->route('admin.hospital.view', $hospital->id)->with('success', 'Hospital Details Updated Successfully!');
    }

    public function store(HospitalPostRequest $request) {
        $hospital = new Hospital;
        $hospital_details = new HospitalDetails();


        $gallery_images = [];
        if (!empty($request->images_list)) {
            foreach ($request->images_list as $row) {
                $fileName = explode(".", $row);
                $imageName = seo_url("healthism hospital $request->name {$fileName[0]}") . "." . $fileName[1];
                $imageName = change_filename("image/hospital/", $imageName);
                copy(public_path("/image/temp/{$row}"), public_path('image/hospital_gallery/' . $imageName));
                $gallery_images[] = $imageName;
            }
            $hospital_details->gallery_json = json_encode(array_values($gallery_images));
        }

        $hospital->name = $request->name;
        $hospital->phone = $request->phone;
        $hospital->address1 = $request->address1;
        $hospital->address2 = $request->address2;
        $hospital->area = $request->area;
        $hospital->pincode = $request->pincode;
        $hospital->city_id = $request->city_id;
        $hospital->state_id = $request->state_id;
        $validateLatLong = validateLatLong($request->latitude, $request->longitude);
        if (!empty($validateLatLong)) {
            $hospital->latitude = $request->latitude;
            $hospital->longitude = $request->longitude;
        }
        $hospital->type = $request->type;
        $hospital->cash_booking_allowed = $request->cash_booking_allowed == 'on' ? 1 : 0;
        $hospital->cancellation_allowed = $request->cancellation_allowed == 'on' ? 1 : 0;
        $hospital->status_id = $request->status_id;
        if (!empty($request->cancel_policy)) {
            $cancel_policy = [];
            foreach ($request->cancel_policy as $key => $val) {
                $val = array_values($val);
                if (!empty($val && !empty(trim($val[0])))) {
                    $cancel_policy[] = trim($val[0]);
                }
            }
            if (!empty($cancel_policy)) {
                $hospital->cancel_policy = json_encode($cancel_policy);
            }
        }
        if (!empty($request->cancel_policy_setting)) {
            $cancel_policy_setting = [];
            foreach ($request->cancel_policy_setting as $val) {
                if (!empty(trim($val['hours'])) && !empty(trim($val['charge']))) {
                    $cancel_policy_setting[] = $val;
                }
            }
            if (!empty($cancel_policy_setting)) {
                $hospital->cancel_policy_setting = json_encode($cancel_policy_setting);
            }
        }

        /*
         * hospital details
         */

        $hospital_details->pancard_number = $request->pancard_number;
        $hospital_details->gst_number = $request->gst_number;
        $hospital_details->bank_account_number = $request->bank_account_number;
        $hospital_details->bank_account_name = $request->bank_account_name;
        $hospital_details->bank_name = $request->bank_name;
        $hospital_details->bank_ifsc_code = $request->bank_ifsc_code;

        if (!empty($request->photo) && in_array($request->photo->extension(), allow_file_type_uploads)) {
//            $imageName = seo_url("healthism hospital {$request->name}") . '.' . $request->photo->extension();
//            $imageName = change_filename("image/hospital/", $imageName);
//            if ($request->photo->move(public_path('image/hospital'), $imageName)) {
//                $hospital->photo = $imageName;
//            }
            $image = $request->file('photo');
            $imageName = seo_url("healthism hospital {$request->name}") . '.' . $request->photo->extension();
            $image_resize = Image::make($image->getRealPath());
            $image_resize->resize(800, null, function ($constraint) {
                $constraint->aspectRatio();
            });
            $image_resize->save(public_path('image/hospital/' . $imageName));
            $hospital->photo = $imageName;
        }

        if (!empty($request->pancard_document)) {
            $imageName = seo_url("pan healthism hospital {$request->name}") . '.' . $request->pancard_document->extension();
            $imageName = change_filename("image/hospital/", $imageName);
            if ($request->pancard_document->move(public_path('image/hospital'), $imageName)) {
                $hospital_details->pancard_document = $imageName;
            }
        }

        if (!empty($request->gst_certificate)) {
            $imageName = seo_url("gst healthism hospital {$request->name}") . '.' . $request->gst_certificate->extension();
            $imageName = change_filename("image/hospital/", $imageName);

            if ($request->gst_certificate->move(public_path('image/hospital'), $imageName)) {
                if (!empty($doctor->gst_certificate)) {
                    @unlink('image/hospital/' . $hospital->hospital_details->gst_certificate);
                }
            }
            $hospital_details->gst_certificate = $imageName;
        }
        $hospital->save();
        $hospital_details->hospital_id = $hospital->id;
        $hospital_details->save();
        if (empty($validateLatLong)) {
            return redirect()->route('admin.hospital.view', $hospital->id)->with('error', 'longitude and latitude are not valid');
        }
        return redirect()->route('admin.hospital.view', $hospital->id)->with('success', 'Hospital Details Added Successfully!');
    }

    public function delete(Request $request) {
        $input = $request->all();
        if (empty($input['hospital_id'])) {
            return error('Sorry, Id is empty.');
        }
        $hospital = Hospital::findOrFail($input['hospital_id']);
        if (!empty($hospital)) {
            $booking = \App\Models\DoctorAppointmentBooking::where('hospital_id', $input['hospital_id'])->count();
            if ($booking == 0) {
                if (!empty($hospital->photo)) {
                    @unlink('image/hospital/' . $hospital->photo);
                }
                if (!empty($hospital->hospital_details->gst_certificate)) {
                    @unlink('image/hospital/' . $hospital->hospital_details->gst_certificate);
                }
                if (!empty($hospital->hospital_details->pancard_document)) {
                    @unlink('image/hospital/' . $hospital->hospital_details->pancard_document);
                }
                $hospital->delete();
                HospitalDetails::where('hospital_id', $input['hospital_id'])->delete();
                \App\Models\DoctorHospitalBlockSlot::where('hospital_id', $input['hospital_id'])->delete();
                \App\Models\DoctorHospitalMapping::where('hospital_id', $input['hospital_id'])->delete();
                \App\Models\DoctorHospitalSlot::where('hospital_id', $input['hospital_id'])->delete();
            } else {
                return error('Sorry, Hospital has appointment booking');
            }
        }
        return success(array(), 'Hospital has been deleted successfully!');
    }

}
