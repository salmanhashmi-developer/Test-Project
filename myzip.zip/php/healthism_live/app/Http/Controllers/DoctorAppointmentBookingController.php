<?php

namespace App\Http\Controllers;

use App\Helpers\Helpers;
use App\Http\Requests\DoctorAppointmentBookingPostRequest;
use App\Models\Category;
use App\Models\DoctorAppointmentBooking;
use App\Models\DoctorAppointmentBookingDetails;
use App\Models\User;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;

class DoctorAppointmentBookingController extends Controller {

    public function index(Request $request) {
        $doctorAppointmentBookings = DoctorAppointmentBooking::query();
        $records_per_page = 10;
        if (!empty($request->patient_name)) {
            $doctorAppointmentBookings = $doctorAppointmentBookings->where('patient_name', 'like', '%' . trim($request->patient_name) . '%');
        }
        if (!empty($request->order_id) && is_numeric($request->order_id)) {
            $doctorAppointmentBookings = $doctorAppointmentBookings->where('order_id', '=', trim($request->order_id));
        }
        if (!empty($request->status_id) && is_numeric($request->status_id)) {
            $doctorAppointmentBookings = $doctorAppointmentBookings->where('status_id', '=', trim($request->status_id));
        }
        if (!empty($request->mobile)) {
            $doctorAppointmentBookings = $doctorAppointmentBookings->where('patient_mobile', 'like', '%' . trim($request->mobile) . '%');
        }
        if (!empty($request->doctor_name)) {
            $doctorAppointmentBookings = $doctorAppointmentBookings->whereRelation('doctor', 'first_name', 'like', '%' . trim($request->doctor_name) . '%')
                    ->orwhereRelation('doctor', 'last_name', 'like', '%' . trim($request->doctor_name) . '%');
        }
        if (!empty($request->hospital_name)) {
            $doctorAppointmentBookings = $doctorAppointmentBookings->whereRelation('hospital', 'name', 'like', '%' . trim($request->hospital_name) . '%');
        }
        if (!empty($request->start_date)) {
            $doctorAppointmentBookings = $doctorAppointmentBookings->whereDate('created_at', '>=', date('Y-m-d', strtotime($request->start_date)));
        }
        if (!empty($request->end_date)) {
            $doctorAppointmentBookings = $doctorAppointmentBookings->whereDate('created_at', '<=', date('Y-m-d', strtotime($request->end_date)));
        }

        if (!empty($request->records_per_page) && is_numeric($request->records_per_page)) {
            $records_per_page = $request->records_per_page;
        }
        if (!empty($request->sort_field)) {
            if ($request->sort_field == 'order_id' && ($request->sort_action == 'ASC' || $request->sort_action == 'DESC')) {
                $doctorAppointmentBookings = $doctorAppointmentBookings->orderBy("order_id", $request->sort_action);
            } elseif ($request->sort_field == 'Status' && ($request->sort_action == 'ASC' || $request->sort_action == 'DESC')) {
                $doctorAppointmentBookings = $doctorAppointmentBookings->orderBy("status_id", $request->sort_action);
            } elseif ($request->sort_field == 'discount' && ($request->sort_action == 'ASC' || $request->sort_action == 'DESC')) {
                $doctorAppointmentBookings = $doctorAppointmentBookings->orderBy("discount", $request->sort_action);
            } elseif ($request->sort_field == 'Appointment Date' && ($request->sort_action == 'ASC' || $request->sort_action == 'DESC')) {
                $doctorAppointmentBookings = $doctorAppointmentBookings->orderBy("created_at", $request->sort_action);
            } elseif ($request->sort_field == 'created_at' && ($request->sort_action == 'ASC' || $request->sort_action == 'DESC')) {
                $doctorAppointmentBookings = $doctorAppointmentBookings->orderBy("created_at", $request->sort_action);
            }
        } else {
            $doctorAppointmentBookings = $doctorAppointmentBookings->orderBy("id", "DESC");
        }
        $doctorAppointmentBookings = $doctorAppointmentBookings->paginate($records_per_page);
        $statusList = array(
            ['id' => 6, 'name' => 'PENDING'],
            ['id' => 9, 'name' => 'FAILED'],
            ['id' => 8, 'name' => 'SUCCESS'],
            ['id' => 10, 'name' => 'CANCELLED'],
        );
        if ($request->ajax()) {
            return view('backend.doctor_appointment_booking.ajax_content', compact('doctorAppointmentBookings', 'statusList'));
        } else {
            return view('backend.doctor_appointment_booking.index', compact('doctorAppointmentBookings', 'statusList'));
        }
    }

    public function view($id) {
        $doctorAppointmentBooking = DoctorAppointmentBooking::findOrFail($id);
        return view('backend.doctor_appointment_booking.view', compact('doctorAppointmentBooking'));
    }

}
