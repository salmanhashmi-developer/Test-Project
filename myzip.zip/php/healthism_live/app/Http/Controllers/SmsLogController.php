<?php

namespace App\Http\Controllers;

use App\Http\Controllers\Controller;
use App\Models\SmsLog;
use Illuminate\Http\Request;

class SmsLogController extends Controller {

    public function index(Request $request) {
        $records_per_page = 10;
        $data = SmsLog::query();
        if (!empty($request->mobile) && is_numeric($request->mobile)) {
            $data->where('mobile',  'like', '%' . trim($request->mobile) . '%');
        }

        $data->orderBy("id", 'DESC');
        if (!empty($request->records_per_page) && is_numeric($request->records_per_page)) {
            $records_per_page = $request->records_per_page;
        }
        $data = $data->paginate($records_per_page);
        if ($request->ajax()) {
            return view('backend.sms_log.ajax_content', compact('data'));
        } else {
            return view('backend.sms_log.index', compact('data'));
        }
    }

}
