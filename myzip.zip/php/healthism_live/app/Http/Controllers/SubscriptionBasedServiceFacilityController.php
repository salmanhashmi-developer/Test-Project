<?php

namespace App\Http\Controllers;

use App\Helpers\Helpers;
use App\Http\Requests\SubscriptionBasedServiceFacilityRequest;
use App\Models\SubscriptionBasedServiceFacility;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Auth;
use function Psr\Log\debug;

class SubscriptionBasedServiceFacilityController extends Controller {

    public function index(Request $request) {
        $facilitis = SubscriptionBasedServiceFacility::query();
        $records_per_page = 10;
        $subscriptionBasedService = "";
        if (!empty($request->name)) {
            $facilitis = $facilitis->where('name', 'like', '%' . $request->name . '%');
        }
        if (!empty($request->subscription_based_service_id)) {
            $subscriptionBasedService = \App\Models\SubscriptionBasedService::findOrFail($request->subscription_based_service_id);
            $facilitis = $facilitis->where('subscription_based_service_id', '=', $request->subscription_based_service_id);
        } else {
            if (Auth::user()->user_type_id == SBS_USER) {
                $subscriptionBasedService = \App\Models\SubscriptionBasedService::where('user_id', $request->user()->id)->first();
                $facilitis = $facilitis->where('subscription_based_service_id', '=', $subscriptionBasedService->id);
            }
        }
        if (!empty($request->status_id)) {
            $facilitis = $facilitis->where('status_id', '=', $request->status_id);
        }
        if (!empty($request->subscription_based_service_name)) {
            $facilitis = $facilitis->whereRelation('subscriptionBasedService', 'name', 'like', '%' . trim($request->subscription_based_service_name) . '%');
        }
        if (!empty($request->records_per_page) && is_numeric($request->records_per_page)) {
            $records_per_page = $request->records_per_page;
        }
        $facilitis = $facilitis->orderBy("id", "DESC");
        $facilitis = $facilitis->paginate($records_per_page);
        if (Auth::user()->user_type_id == SBS_USER) {
            if ($request->ajax()) {
                return view('backend.subscription_based_service_partner.facility.ajax_content', compact('facilitis', 'subscriptionBasedService'));
            } else {
                return view('backend.subscription_based_service_partner.facility.index', compact('facilitis', 'subscriptionBasedService'));
            }
        }
        if ($request->ajax()) {
            return view('backend.subscription_based_service.facility.ajax_content', compact('facilitis', 'subscriptionBasedService'));
        } else {
            return view('backend.subscription_based_service.facility.index', compact('facilitis', 'subscriptionBasedService'));
        }
    }

    public function add(Request $request) {
        $subscriptionBasedService = "";
        $subCategory = "";
        if (!empty($request->subscription_based_service_id)) {
            $subscriptionBasedService = \App\Models\SubscriptionBasedService::findOrFail($request->subscription_based_service_id);
            $subCategory = \App\Models\Category::where('parent_id', $subscriptionBasedService->category_id)->where('active', 1)->get();
        }
        if (Auth::user()->user_type_id == SBS_USER) {
            return view('backend.subscription_based_service_partner.facility.add', compact('subscriptionBasedService', 'subCategory'));
        }
        return view('backend.subscription_based_service.facility.add', compact('subscriptionBasedService', 'subCategory'));
    }

    public function edit(Request $request, $id) {
        $facility = SubscriptionBasedServiceFacility::findOrFail($id);
        $subscriptionBasedService = \App\Models\SubscriptionBasedService::findOrFail($facility->subscription_based_service_id);
        $subCategory = \App\Models\Category::where('parent_id', $subscriptionBasedService->category_id)->where('active', 1)->get();
        $facility->facility_desc_json = !empty($facility->detail_json) ? json_encode($facility->detail_json) : '';
        $flag = $request->flag;
        if (Auth::user()->user_type_id == SBS_USER) {
            return view('backend.subscription_based_service_partner.facility.edit', compact('facility', 'flag', 'subCategory'));
        }
        return view('backend.subscription_based_service.facility.edit', compact('facility', 'flag', 'subCategory'));
    }

    public function view(Request $request, $id) {
        $facility = SubscriptionBasedServiceFacility::findOrFail($id);
        $flag = $request->flag;
        if (Auth::user()->user_type_id == SBS_USER) {
            return view('backend.subscription_based_service_partner.facility.view', compact('facility', 'flag'));
        }
        return view('backend.subscription_based_service.facility.view', compact('facility', 'flag'));
    }

    public function update(SubscriptionBasedServiceFacilityRequest $request, $id) {
        $input = $request->all();
        $facility = SubscriptionBasedServiceFacility::findOrFail($id);
        $categoryIds = "";
        if (!empty($request->sub_category_ids)) {
            $categoryIds .= implode(',', $request->sub_category_ids);
            $categoryIds = ',' . $categoryIds . ',';
        }
        $facility->subscription_based_service_id = $request->subscription_based_service_id;
        $facility->subscription_based_service_parent_id = $request->subscription_based_service_parent_id;
        $facility->name = $request->name;
        $facility->description = $request->description;
        $facility->gender = !empty($request->gender) ? $request->gender : null;
        $facility->days = $request->days;
        $facility->sub_category_ids = $categoryIds;
        $facility->calories_burn = $request->calories_burn;
        $facility->result = $request->result;
        $facility->note = $request->note;
        $facility->detail_json = !empty($request->facility_desc_json && $request->facility_desc_json != 'null') ? $request->facility_desc_json : null;
        $facility->price = $request->price;
        $facility->discount = $request->discount;
        $facility->status_id = $request->status_id;
        $facility->save();
        if (Auth::user()->user_type_id == SBS_USER) {
            return redirect()->route('sbs.facility.view', [$facility->id, 'flag' => $request->flag])->with('success', 'Subscription Based Service Facility Master Details Updated Successfully!');
        }
        return redirect()->route('admin.subscription_based_service.facility.view', [$facility->id, 'flag' => $request->flag])->with('success', 'Subscription Based Service Facility Master Details Updated Successfully!');
    }

    public function store(SubscriptionBasedServiceFacilityRequest $request) {
        $facility = new SubscriptionBasedServiceFacility;
        $categoryIds = "";
        if (!empty($request->sub_category_ids)) {
            $categoryIds .= implode(',', $request->sub_category_ids);
            $categoryIds = ',' . $categoryIds . ',';
        }
        $facility->subscription_based_service_id = $request->subscription_based_service_id;
        $facility->subscription_based_service_parent_id = $request->subscription_based_service_parent_id;
        $facility->name = $request->name;
        $facility->description = $request->description;
        $facility->gender = !empty($request->gender) ? $request->gender : null;
        $facility->days = $request->days;
        $facility->sub_category_ids = $categoryIds;
        $facility->calories_burn = $request->calories_burn;
        $facility->result = $request->result;
        $facility->note = $request->note;
        $facility->detail_json = !empty($request->facility_desc_json && $request->facility_desc_json != 'null') ? $request->facility_desc_json : null;
        $facility->price = $request->price;
        $facility->discount = $request->discount;
        $facility->status_id = $request->status_id;
        $facility->save();
        if (!empty($facility->id)) {
            $this->updateSubscriptionBasedServiceSelfFacilityAvailable($facility->subscription_based_service_id);
        }
        if (Auth::user()->user_type_id == SBS_USER) {
            return redirect()->route('sbs.facility.view', [$facility->id, 'flag' => $request->flag])->with('success', 'Subscription Based Service Facility Master Details Added Successfully!');
        }
        return redirect()->route('admin.subscription_based_service.facility.view', [$facility->id, 'flag' => $request->flag])->with('success', 'Subscription Based Service Facility Master Details Added Successfully!');
    }

    public function delete(Request $request) {
        $input = $request->all();
        if (empty($input['facility_id'])) {
            return error('Sorry, Id is empty.');
        }
        $facility = SubscriptionBasedServiceFacility::findOrFail($input['facility_id']);
        $facility->delete();
        $this->updateSubscriptionBasedServiceSelfFacilityAvailable($facility->subscription_based_service_id);
        return success(array(), 'Facility has been deleted successfully!');
    }

    public function updateSubscriptionBasedServiceSelfFacilityAvailable($subscriptionBasedServiceId) {
        $subscriptionBasedService = \App\Models\SubscriptionBasedService::findOrFail($subscriptionBasedServiceId);
        $facilitiCount = count($subscriptionBasedService->subscriptionBasedServiceFacility);
        $subscriptionBasedService->self_facility_available = $facilitiCount > 0 ? 1 : 0;
        $subscriptionBasedService->save();
    }

    public function subscriptionBasedServiceFacilityList(Request $request) {
        $input = $request->all();
        if (empty($input['subscription_based_service_id'])) {
            return error("Sorry, Subscription based service id is empty");
        }
        $subscriptionBasedService = \App\Models\SubscriptionBasedService::where('id', $input['subscription_based_service_id'])->with('city', 'state')->first();
        if (empty($subscriptionBasedService)) {
            return error("Sorry, Facility not found.");
        }
        if ($subscriptionBasedService->status_id != STATUS_ACTIVE) {
            return error("Sorry, Subscription based bervice is blocked.");
        }
        $input['self_facility_available'] = $subscriptionBasedService->self_facility_available;
        $input['subscription_based_service_id'] = $subscriptionBasedService->id;
        $input['parent_id'] = $subscriptionBasedService->parent_id;
        $input['type'] = isset($input['type']) ? $input['type'] : 'FECILITY';
        $result = [];
        $page = !empty($input['page']) ? $input['page'] : 1;
        $skip = $page > 1 ? ($page * 25) - 25 : 0;
        if (!empty($input['subscription_based_service_id']) && !empty($input['self_facility_available'])) {
            $query = SubscriptionBasedServiceFacility::where('subscription_based_service_id', $input['subscription_based_service_id']);
        } else {
            $query = SubscriptionBasedServiceFacility::where('subscription_based_service_id', $input['parent_id']);
        }
        $query->where('status_id', STATUS_ACTIVE);
        if ($input['type'] == 'PACKAGE') {
            $query->where('is_package', 1);
        } else {
            $query->where('is_package', 0);
        }
        if (!empty($input['name'])) {
            $name = $input['name'];
            $query->where('name', 'like', '%' . $name . '%');
        }
        $result['total_records'] = $query->count();
        $query->limit(25);
        if (isset($input['offset'])) {
            $query->offset($input['offset']);
        }
        $result['records'] = $query->get();
        $result['subscriptionBasedService'] = $subscriptionBasedService;
        return success($result, 'Subscription based service facilitis list');
    }

}
