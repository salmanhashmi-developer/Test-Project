<?php

namespace App\Http\Controllers\Corporate;

use App\Http\Controllers\Controller;
use App\Helpers\Helpers;
use App\Http\Requests\CorporateUserPostRequest;
use App\Models\UserDetails;
use App\Models\User;
use App\Models\Department;
use App\Models\Designation;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use Intervention\Image\ImageManagerStatic as Image;
use function Psr\Log\debug;

class UserController extends Controller {

    public function index(Request $request) {
        $users = UserDetails::query();
        $users->join('user', 'user_details.user_id', '=', 'user.id');
        $users->leftjoin('status', 'user.status_id', '=', 'status.id');
        $users->leftjoin('designation', 'user_details.designation_id', '=', 'designation.id');
        $users->leftjoin('corporate_company_branch', 'user_details.branch_id', '=', 'corporate_company_branch.id');
        $users->leftjoin('department', 'user_details.department_id', '=', 'department.id');
        $users = $users->where('user_details.company_id', '=', $request->user()->company->id);
        $records_per_page = 10;
        if (!empty($request->first_name)) {
            $users = $users->where('user.first_name', 'like', '%' . $request->first_name . '%');
        }
        if (!empty($request->email)) {
            $users = $users->where('user.email', 'like', '%' . $request->email . '%');
        }
        if (!empty($request->mobile)) {
            $users = $users->where('user.mobile', 'like', '%' . $request->mobile . '%');
        }
        if (!empty($request->user_type)) {
            $users = $users->where('user.user_type_id', '=', $request->user_type);
        }
        if (!empty($request->department_id)) {
            $users = $users->where('user_details.department_id', '=', $request->department_id);
        }
        if (!empty($request->designation_id)) {
            $users = $users->where('user_details.designation_id', '=', $request->designation_id);
        }
        if (!empty($request->branch_id)) {
            $users = $users->where('user_details.branch_id', '=', $request->branch_id);
        }
        $users->select('user.*', 'status.name AS status_name', 'department.name AS department_name', 'designation.name AS designation_name', 'corporate_company_branch.name AS branch_name');
        if (!empty($request->records_per_page) && is_numeric($request->records_per_page)) {
            $records_per_page = $request->records_per_page;
        }

        $users = $users->orderBy("user.id", "DESC");
        $users = $users->paginate($records_per_page);
        $filter = $this->getFilterData($request->user()->company->id);
        if ($request->ajax()) {
            return view('backend.corporate.users.ajax_content', compact('users', 'filter'));
        } else {
            return view('backend.corporate.users.index', compact('users', 'filter'));
        }
    }

    public function delete(Request $request) {
        $input = $request->all();
        if (empty($input['user_id'])) {
            return error("Sorry, User id is empty");
        }
        UserDetails::where('user_id', $input['user_id'])
                ->where('company_id', $request->user()->company->id)
                ->delete();
        return success(array(), 'Employee  has been deleted successfully!');
    }

    public function add(Request $request) {
        $filter = $this->getFilterData($request->user()->company->id);
        return view('backend.corporate.users.add', compact('filter'));
    }

    public function userSearch(Request $request) {
        $search = $request->search;
        $data = User::where('user_type_id', END_USER)
                        ->where(function ($data) use ($search) {
                            return $data->orwhere('mobile', $search)
                                    ->orwhere('email', $search);
                        })->with('status', 'detail', 'detail.company')->get();
        return response()->json($data);
    }

    public function edit(Request $request, $id) {
        $user = User::findOrFail($id);
        $filter = $this->getFilterData($request->user()->company->id);
        return view('backend.corporate.users.edit', compact('user', 'filter'));
    }

    public function getFilterData($companyId) {
        $data['userType'] = [
            array("id" => END_USER, "name" => 'Employee'),
            array("id" => CORPORATE_USER, "name" => 'Admin'),
        ];
        $data['designation'] = Designation::where('company_id', $companyId)->get();
        $data['department'] = Department::where('company_id', $companyId)->get();
        $data['branch'] = \App\Models\CorporateCompanyBranch::where('company_id', $companyId)->get();
        $data['genders'] = Helpers::getEnumValues('user', 'gender');
        $data['bloodGroups'] = Helpers::getEnumValues('user', 'blood_group');
        return $data;
    }

    public function view($id) {
        $user = User::findOrFail($id);
        return view('backend.corporate.users.view', compact('user'));
    }

    public function update(CorporateUserPostRequest $request, $id) {
        $input = $request->all();
        $input['id'] = $id;
        $mobileUser = $this->getMobileUser($input);
        if (!empty($mobileUser)) {
            if ($mobileUser->id != $id) {
                return redirect()->route('corporate.user.edit', $id)->with('error', 'Sorry, ' . $input['mobile'] . ' Mobile no already use by other Employee try with different Mobile no');
            }
        }
        $emailUser = $this->getMobileEmail($input);
        if (!empty($emailUser)) {
            if ($emailUser->id != $id) {
                return redirect()->route('corporate.user.edit', $id)->with('error', 'Sorry, ' . $input['email'] . ' Email already use by other Employee try with different email');
            }
        }
        $user = User::findOrFail($id);
        $user->first_name = $request->first_name;
        $user->last_name = $request->last_name;
        $user->email = $request->email;
        $user->mobile = $request->mobile;
        $user->dob = !empty($request->dob) ? date('Y-m-d', strtotime($request->dob)) : null;
        $user->blood_group = $request->blood_group;
        $user->gender = $request->gender;
        $user->user_type_id = $request->user_type_id;
        $user->status_id = $request->status_id;
        $user->save();
        if ($user->user_type_id == END_USER) {
            $input['first_name'] = $request->first_name;
            $input['last_name'] = $request->last_name;
            $input['email'] = $request->email;
            $input['mobile'] = $request->mobile;
            $input['dob'] = !empty($request->dob) ? date('Y-m-d', strtotime($request->dob)) : null;
            $input['blood_group'] = $request->blood_group;
            $input['gender'] = $request->gender;
            $input['user_type_id'] = $request->user_type_id;
            $input['status_id'] = $request->status_id;
            $userPatientMapping = \App\Models\UserPatientMapping::where(['user_id' => $user->id, "relation" => 'SELF'])->first();
            if (!empty($userPatientMapping)) {
                $userPatientMapping->fill($input)->save();
            } else {
                \App\Models\UserPatientMapping::create($input);
            }
        }
        $userDetail['branch_id'] = $request->branch_id;
        $userDetail['department_id'] = $request->department_id;
        $userDetail['designation_id'] = $request->designation_id;
        $userDetail['company_id'] = $request->user()->company->id;
        $detial = UserDetails::where(['user_id' => $user->id])->first();
        if (!empty($detial)) {
            $detial->update($userDetail);
        } else {
            $userDetail['user_id'] = $user->id;
            UserDetails::create($userDetail);
        }
        return redirect()->route('corporate.user.view', $user->id)->with('success', 'Employee Details Updated Successfully!');
    }

    public function save(CorporateUserPostRequest $request) {
        $mobileUser = $this->getMobileUser($request->all());
        if (!empty($mobileUser)) {
            return redirect()->route('corporate.user.add')->with('error', 'Sorry, ' . $request->mobile . '  Mobile no already use by other user try with different Mobile no');
        }
        $emailUser = $this->getMobileEmail($request->all());
        if (!empty($emailUser)) {
            return redirect()->route('corporate.user.add')->with('error', 'Sorry, ' . $request->email . '   Email already use by other user try with different email');
        }
        $user = new User;
        $user->first_name = $request->first_name;
        $user->last_name = $request->last_name;
        $user->email = $request->email;
        $user->mobile = $request->mobile;
        $user->dob = !empty($request->dob) ? date('Y-m-d', strtotime($request->dob)) : null;
        $user->blood_group = $request->blood_group;
        $user->gender = $request->gender;
        $user->user_type_id = $request->user_type_id;
        $user->status_id = $request->status_id;
        $user->save();
        if (!empty($user) && $user->user_type_id == END_USER) {
            \App\Models\UserPatientMapping::create(array(
                "first_name" => $request->first_name,
                "last_name" => $request->last_name,
                "email" => $request->email,
                "mobile" => $request->mobile,
                "blood_group" => $request->blood_group,
                "gender" => $request->gender,
                "user_id" => $user->id,
                "status_id" => STATUS_ACTIVE, "relation" => 'SELF',
                "created_at" => date('Y-m-d H:i:s')
            ));
        }
        $userDetail = new UserDetails;
        $userDetail->user_id = $user->id;
        $userDetail->branch_id = $request->branch_id;
        $userDetail->department_id = $request->department_id;
        $userDetail->designation_id = $request->designation_id;
        $userDetail->company_id = $request->user()->company->id;
        $userDetail->save();
        return redirect()->route('corporate.user.view', $user->id)->with('success', 'Employee Details Added Successfully!');
    }

    public function getMobileUser($input) {
        $user = User::where('mobile', $input['mobile'])
                ->where('user_type_id', $input['user_type_id'])
                ->first();
        return $user;
    }

    public function getMobileEmail($input) {
        $user = User::where('email', $input['email'])
                ->where('user_type_id', $input['user_type_id'])
                ->first();
        return $user;
    }

}
