<?php

namespace App\Http\Controllers\Corporate;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use App\Helpers\PushNotifications;

class CorporateController extends Controller {

    public function profile(Request $request) {
        $data['emp_count'] = \App\Models\UserDetails::where('company_id', $request->user()->company->id)->count();
        $activePlan = \App\Models\CorporateSubscription::where('company_id', $request->user()->company->id)->where('status_id', STATUS_ACTIVE)->get();
        $data['active_scubscription_count'] = count($activePlan);
        $total = $usedTotal = 0;
        if (!empty($data['active_scubscription_count'])) {
            foreach ($activePlan as $key => $value) {
                $total = $total + $value->qty;
                $usedTotal = $usedTotal + $value->used;
            }
        }
        $data['plan_count'] = $total;
        $data['remaining_plan_count'] = $total - $usedTotal;
        $data['subscription'] = $activePlan;
        $query = "SELECT
                                        COUNT(*) as total_record,SUM(amount+discount) as totla_order_amount,SUM(discount) as total_discount 
                                FROM
                                        doctor_appointment_booking 
                                WHERE
                                        status_id = " . STATUS_SUCCESS . " 
                                        AND user_id IN (
                                        SELECT
                                                user_id 
                                        FROM
                                                user_details 
                                WHERE
                                        company_id = " . $request->user()->company->id . ")";
        $order['doctor'] = getFirstRowOfResult($query);
        $query = "SELECT
                                        COUNT(*) as total_record,SUM(amount+discount) as totla_order_amount,SUM(discount) as total_discount 
                                FROM
                                        lab_booking 
                                WHERE
                                        status_id = " . STATUS_SUCCESS . " 
                                        AND user_id IN (
                                        SELECT
                                                user_id 
                                        FROM
                                                user_details 
                                WHERE
                                        company_id = " . $request->user()->company->id . ")";
        $order['lab'] = getFirstRowOfResult($query);
        $query = "SELECT
                                        COUNT(*) as total_record,SUM(amount+discount) as totla_order_amount,SUM(discount) as total_discount 
                                FROM
                                        menu_based_service_booking 
                                WHERE
                                        status_id = " . STATUS_SUCCESS . " 
                                        AND user_id IN (
                                        SELECT
                                                user_id 
                                        FROM
                                                user_details 
                                WHERE
                                        company_id = " . $request->user()->company->id . ")";
        $order['mbs'] = getFirstRowOfResult($query);
        $query = "SELECT
                                        COUNT(*) as total_record,SUM(amount+discount) as totla_order_amount,SUM(discount) as total_discount 
                                FROM
                                        subscription_based_service_booking 
                                WHERE
                                        status_id = " . STATUS_SUCCESS . " 
                                        AND user_id IN (
                                        SELECT
                                                user_id 
                                        FROM
                                                user_details 
                                WHERE
                                        company_id = " . $request->user()->company->id . ")";
        $order['sbs'] = getFirstRowOfResult($query);
        array_walk_recursive($order, function($item, $key) use (&$data) {
            $data[$key] = isset($data[$key]) ? $item + $data[$key] : $item;
        });
        $order['mbs']['service'] = 'Spa/Salon Appointment';
        $order['sbs']['service'] = 'Gym Appointment';
        $order['doctor']['service'] = 'Doctor Appointment';
        $order['lab']['service'] = 'Lab Appointment';
        $data['order'] = $order;
        return view('backend.corporate.dashBoard', compact('data'));
    }

}
