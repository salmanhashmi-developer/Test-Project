<?php

namespace App\Http\Controllers\Corporate;

use App\Http\Controllers\Controller;
use App\Http\Repository\NotificationRepository;
use App\Models\Subscription;
use App\Models\CorporateSubscription;
use Illuminate\Http\Request;

class SubscriptionController extends Controller {

    private $notificationRepository;

    public function __construct(NotificationRepository $notificationRepository) {
        $this->notificationRepository = $notificationRepository;
    }

    public function index(Request $request, $id) {
        $corporateSubscription = CorporateSubscription::query();
        $records_per_page = 75;
        $companyId = !empty($request->user()->company) ? $request->user()->company->id : $id;
        if (!empty($companyId)) {
            $corporateSubscription->where('company_id', '=', $companyId);
        }
        $corporateSubscription->orderBy("id", 'DESC');
        if (!empty($request->records_per_page) && is_numeric($request->records_per_page)) {
            $records_per_page = $request->records_per_page;
        }
        $corporateSubscription = $corporateSubscription->paginate($records_per_page);
        //$corporateSubscription = $corporateSubscription->get();
        $corporateTypeId = ',10,';
        $planList = Subscription::where('status_id', STATUS_ACTIVE)
                        ->where('user_type_id', 'like', '%' . $corporateTypeId . '%')->get();
        $company = \App\Models\CorporateCompany::where('id', $companyId)->first();
        return view('backend.corporate.company.subscription', compact('corporateSubscription', 'company', 'planList'));
//        if ($request->ajax()) {
//            return view('backend.corporate.company.subscription.ajax_content', compact('corporateSubscription'));
//        } else {
//            return view('backend.corporate.company.subscription.index', compact('corporateSubscription'));
//        }
    }

    public function add(Request $request) {
        $input = $request->all();
        $rules = \App\Models\CorporateSubscription::$rules;
        if (sizeof($rules) > 0) {
            $validation = $this->validateRequest($request, $rules);
            if (!empty($validation)) {
                return redirect()->route('admin.corporate.company.plan', ['id' => $input['company_id']])->with('error', $validation);
            }
        }
        $subscription = json_decode($input['subscription_id'], true);
        $data['subscription_id'] = $subscription['id'];
        $data['company_id'] = $input['company_id'];
        $data['qty'] = $input['qty'];
        $data['amount'] = $input['amount'];
        $data['used'] = 0;
        $data['status_id'] = STATUS_ACTIVE;
        $data['created_by'] = $request->user()->id;
        $data['tax'] = 0;
        $data['created_at'] = date('Y-m-d H:i:s');
        $data['expiry_date'] = date('Y-m-d', strtotime('+' . $subscription['validity_in_days'] . ' day'));
        CorporateSubscription::create($data);
        return redirect()->route('admin.corporate.company.plan', ['id' => $input['company_id']])->with('success', 'Plan Added Successfully!');
    }

    public function delete($id) {
        $data = CorporateSubscription::findOrFail($id);
        if (!empty($data)) {
            if ($data->used > 0) {
                return redirect()->route('admin.corporate.company.plan', ['id' => $data->company_id])->with('error', $data->used . " Plan used so you can't delete it.");
            }
            $data->delete();
        }
        return redirect()->route('admin.corporate.company.plan', ['id' => $data->company_id])->with('success', 'Plan Added Successfully!');
    }

    public function CorporateSubsciption(Request $request) {
        $data = CorporateSubscription::query();
        $records_per_page = 3;
        $data->where('company_id', '=', $request->user()->company->id);
        if (!empty($request->plan_id)) {
            $data = $data->where('subscription_id', $request->plan_id);
        }
        if (!empty($request->status_id)) {
            $data = $data->where('status_id', $request->status_id);
        } else {
            $data = $data->where('status_id', STATUS_ACTIVE);
        }
        if (!empty($request->records_per_page) && is_numeric($request->records_per_page)) {
            $records_per_page = $request->records_per_page;
        }
        $data = $data->orderBy("expiry_date", "ASC");
        $data = $data->paginate($records_per_page);
        if ($request->ajax()) {
            return view('backend.corporate.subscription.ajax_content', compact('data'));
        } else {
            return view('backend.corporate.subscription.index', compact('data'));
        }
    }

    public function viewPlanList(Request $request, $id) {
        $user = \App\Models\User::findOrFail($id);
        $plan = getUserSubscription($id);
        $planList = CorporateSubscription::where('company_id', $request->user()->company->id)
                ->where('status_id', STATUS_ACTIVE)
                ->where('expiry_date', '>', date('Y-m-d'))
                ->whereColumn('qty', '>', 'used')
                ->groupBy('subscription_id')
                ->orderBy("expiry_date", "ASC")
                ->get();
        return view('backend.corporate.users.plan', compact('user', 'plan', 'planList'));
    }

    public function saveUserSubscription(Request $request) {
        $input = $request->all();

        if (empty($input['user_id'])) {
            return error('Sorry, User id is empty');
        }
        if (empty($input['plan_id'])) {
            return error('Sorry, Plan id is empty');
        }
        if (empty($input['plan_expiry'])) {
            return error('Sorry, Plan expiry is empty');
        }
        if (empty($input['price'])) {
            return error('Sorry, Price not found');
        }
        if (empty($input['corporate_subscription_id'])) {
            return error('Sorry, Corporate subscription id not found');
        }
        $userDetail = \App\Models\User::findOrFail($input['user_id']);
        if (empty($userDetail['mobile'])) {
            return error('Sorry, User mobile not found');
        }
        if (empty($userDetail['email'])) {
            return error('Sorry, User email not found');
        }
        /* $plan = getUserSubscription($input['user_id']);
          if (!empty($plan)) {
          if ($plan['action'] == "Upgrade" && $plan['expire'] == 0) {
          return error('Sorry, User have already plan : ' . $plan['subscription']['name']);
          }
          } */
        $planData = Subscription::where('id', $input['plan_id'])
                ->where('status_id', STATUS_ACTIVE)
                ->first();
        if (empty($planData)) {
            return error('Sorry, Plan data not found');
        }
        $corporateSubscription = CorporateSubscription::where('id', $input['corporate_subscription_id'])->first();
        if ($corporateSubscription->used >= $corporateSubscription->qty) {
            return error('Sorry, No remaining plan, All plan allocated to employee');
        }
//        $tax = $planData['price'] - (($planData['price'] * 100) / (100 + SERVICE_SUBSCRIPTION_PLAN_TAX));
//        $tax = round($tax, 2);

        $userSubscription = new \App\Models\UserSubscription;
        $userSubscription->subscription_id = $input['plan_id'];
        $userSubscription->user_id = $userDetail['id'];
        $userSubscription->card_no = getCardRandNumber($planData['card_prefix']);
        $userSubscription->amount = $input['price'];
        $userSubscription->tax = 0;
        $userSubscription->created_at = date('Y-m-d H:i:s');
        $userSubscription->expiry_date = date('Y-m-d', strtotime('+' . $planData->validity_in_days . ' day'));
        $userSubscription->status_id = STATUS_ACTIVE;
        $userSubscription->created_by = $request->user()->id;
        $userSubscription->save();
        if (!empty($userSubscription->id)) {
            //Update Corporate Subscription
            $data['used'] = $corporateSubscription->used + 1;
            if ($data['used'] >= $corporateSubscription->qty) {
                $data['status_id'] = STATUS_USED;
            }
            $corporateSubscription->fill($data)->save();
            //Inacive Previous Plan
            \App\Models\UserSubscription::where('user_id', $userDetail['id'])->where('id', '!=', $userSubscription->id)
                    ->update(array('status_id' => STATUS_INACTIVE, 'updated_at' => date('Y-m-d H:i:s')));

            //User Family Member Inactive
            \App\Models\UserFamilyMember::where('user_id', $userDetail['id'])
                    ->update(array('status_id' => STATUS_INACTIVE, 'updated_at' => date('Y-m-d H:i:s')));

            //User Inactive In Other User Family Member
            \App\Models\UserFamilyMember::where('mobile', $userDetail['mobile'])
                    ->update(array('status_id' => STATUS_INACTIVE, 'updated_at' => date('Y-m-d H:i:s')));

            $this->notificationRepository->corporateNotification($userDetail['id'], 'SIGNING_TIPS', ['expiry_date' => $userSubscription->expiry_date, 'company_name' => $request->user()->company->name]);
            return success($userSubscription, 'Plane Saved successfully');
        } else {
            return error('oops something went wrong please try again');
        }
    }

}
