<?php

namespace App\Http\Controllers\Corporate;

use App\Http\Controllers\Controller;
use App\Helpers\Helpers;
use Illuminate\Http\Request;

class DepartmentController extends Controller {

    public function index(Request $request) {
        $data = \App\Models\Department::query();
        $records_per_page = 50;
        $data = $data->where('company_id', '=', $request->user()->company->id);
        if (!empty($request->name)) {
            $data = $data->where('name', 'like', '%' . $request->name . '%');
        }
        if (!empty($request->records_per_page) && is_numeric($request->records_per_page)) {
            $records_per_page = $request->records_per_page;
        }
        $data = $data->orderBy("id", "DESC");
        $data = $data->paginate($records_per_page);
        if ($request->ajax()) {
            return view('backend.corporate.department.ajax_content', compact('data'));
        } else {
            return view('backend.corporate.department.index', compact('data'));
        }
    }

    public function add(Request $request) {
        return view('backend.corporate.department.add');
    }

    public function edit($id) {
        $data = \App\Models\Department::findOrFail($id);
        return view('backend.corporate.department.edit', compact('data'));
    }

    public function update(Request $request, $id) {
        $data = \App\Models\Department::findOrFail($id);
        $data->name = $request->name;
        $data->company_id = $request->user()->company->id;
        $data->save();
        return redirect()->route('corporate.department')->with('success', 'Data Updated Successfully!');
    }

    public function store(Request $request) {
        $data = new \App\Models\Department;
        $data->name = $request->name;
        $data->company_id = $request->user()->company->id;
        $data->save();
        return redirect()->route('corporate.department.add')->with('success', 'Data Added Successfully!');
    }

}
