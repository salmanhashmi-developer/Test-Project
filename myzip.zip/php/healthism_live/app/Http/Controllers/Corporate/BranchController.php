<?php

namespace App\Http\Controllers\Corporate;

use App\Http\Controllers\Controller;
use App\Helpers\Helpers;
use App\Models\CorporateCompanyBranch;
use Illuminate\Http\Request;

class BranchController extends Controller {

    public function index(Request $request) {
        $data = CorporateCompanyBranch::query();
        $records_per_page = 50;
        $data = $data->where('company_id', '=', $request->user()->company->id);
        if (!empty($request->name)) {
            $data = $data->where('name', 'like', '%' . $request->name . '%');
        }
        if (!empty($request->records_per_page) && is_numeric($request->records_per_page)) {
            $records_per_page = $request->records_per_page;
        }
        $data = $data->orderBy("id", "DESC");
        $data = $data->paginate($records_per_page);
        if ($request->ajax()) {
            return view('backend.corporate.branch.ajax_content', compact('data'));
        } else {
            return view('backend.corporate.branch.index', compact('data'));
        }
    }

    public function add(Request $request) {
        return view('backend.corporate.branch.add');
    }

    public function edit($id) {
        $data = CorporateCompanyBranch::findOrFail($id);
        return view('backend.corporate.branch.edit', compact('data'));
    }

    public function update(Request $request, $id) {
        $data = CorporateCompanyBranch::findOrFail($id);
        $data->name = $request->name;
        $data->company_id = $request->user()->company->id;
        $data->save();
        return redirect()->route('corporate.branch')->with('success', 'Data Updated Successfully!');
    }

    public function store(Request $request) {
        $data = new CorporateCompanyBranch;
        $data->name = $request->name;
        $data->company_id = $request->user()->company->id;
        $data->save();
        return redirect()->route('corporate.branch.add')->with('success', 'Data Added Successfully!');
    }

}
