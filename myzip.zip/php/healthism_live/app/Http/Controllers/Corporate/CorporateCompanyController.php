<?php

namespace App\Http\Controllers\Corporate;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use App\Models\CorporateCompany;
use Illuminate\Support\Facades\DB;

class CorporateCompanyController extends Controller {

    public function index(Request $request) {
        $company = CorporateCompany::query();
        $records_per_page = 10;
        if (!empty($request->name)) {
            $company = $company->where('name', 'like', '%' . $request->name . '%');
        }
        if (!empty($request->records_per_page) && is_numeric($request->records_per_page)) {
            $records_per_page = $request->records_per_page;
        }
        $company = $company->orderBy("name", "ASC");
        $companyList = $company->paginate($records_per_page);
        if ($request->ajax()) {
            return view('backend.corporate.company.ajax_content', compact('companyList'));
        } else {
            return view('backend.corporate.company.index', compact('companyList'));
        }
    }

    public function add(Request $request) {
        $stateList = \App\Models\State::get();
        return view('backend.corporate.company.add', compact('stateList'));
    }

    public function edit($id) {
        $company = CorporateCompany::findOrFail($id);
        return view('backend.corporate.company.edit', compact('company'));
    }

    public function update(Request $request, $id) {
        $rules = CorporateCompany::$rules;
        if (sizeof($rules) > 0) {
            $validation = $this->validateRequest($request, $rules);
            if (!empty($validation)) {
                return error($validation);
            }
        }
        $input = $request->all();

        $company = CorporateCompany::findOrFail($id);
        if (!empty($input['user_id'])) {
            $mappingData = ['user_id' => $input['user_id'], 'company_id' => $id, 'old_uesr_id' => $company->user_id, 'user' => $input['user']];
            $validate = $this->userMapping($mappingData);
            if (!empty($validate)) {
                return redirect()->route('admin.corporate.company.edit', $company->id)->with('error', $validate);
            }
        }
        $company->fill($input)->save();
        $company = CorporateCompany::find($id);
        return redirect()->route('admin.corporate.company')->with('success', $request->name . ' : Corporate Company  Updated Successfully!');
    }

    public function userMapping($input) {
        $checkUserExsist = \App\Models\CorporateCompany::where('user_id', $input['user_id'])
                        ->where('id', '!=', $input['company_id'])->count();
        if ($checkUserExsist > 0) {
            return $input['user'] . ' user already exist in other company.';
        }
        if (!empty($input['old_uesr_id'])) {
            \App\Models\UserDetails::where('user_id', $input['old_uesr_id'])
                    ->where('company_id', $input['company_id'])->delete();
        }
        \App\Models\UserDetails::create(['user_id' => $input['user_id'], 'company_id' => $input['company_id']]);
    }

    public function store(Request $request) {
        $rules = CorporateCompany::$rules;
        if (sizeof($rules) > 0) {
            $validation = $this->validateRequest($request, $rules);
            if (!empty($validation)) {
                return error($validation);
            }
        }
        $input = $request->all();
        if (!empty($input['user_id'])) {
            $checkUserExsist = \App\Models\CorporateCompany::where('user_id', $input['user_id'])->count();
            if ($checkUserExsist > 0) {
                return redirect()->route('admin.corporate.company.add')->with('error', $input['user'] . ' user already exist in other company.');
            }
        }
        $input['status_id'] = STATUS_ACTIVE;
        $input['ref_code'] = strtoupper(substr($input['name'], 0, 3)) . rand(1000, 9999) . 'HP,';
        $input['created_at'] = date('Y-m-d H:i:s');
        $company = CorporateCompany::create($input);
        if (!empty($input['user_id'])) {
            $mappingData = ['user_id' => $input['user_id'], 'company_id' => $company->id];
            $validate = $this->userMapping($mappingData);
        }
        return redirect()->route('admin.corporate.company')->with('success', $company->name . ' Corporate Company Details Added Successfully!');
    }

    public function corporateUserSearch(Request $request) {
        $search = $request->get('search');
        $data = \App\Models\User::select(DB::raw("CONCAT(user.first_name,' ',user.last_name,' (', user.email,' - ', user.mobile,')') as label"), "id", DB::raw("CONCAT(user.first_name,' ',user.last_name) as value"))
                        ->where('user_type_id', CORPORATE_USER)
                        ->where(function ($data) use ($search) {
                            return $data->where('first_name', 'LIKE', '%' . $search . '%')
                                    ->orwhere('last_name', 'LIKE', '%' . $search . '%')
                                    ->orwhere('mobile', 'LIKE', '%' . $search . '%')
                                    ->orwhere('email', 'LIKE', '%' . $search . '%');
                        })->get();

        return response()->json($data);
    }

}
