<?php

namespace App\Http\Controllers\Corporate;

use App\Http\Controllers\Controller;
use App\Helpers\Helpers;
use Illuminate\Http\Request;

class DesignationController extends Controller {

    public function index(Request $request) {
        $data = \App\Models\Designation::query();
        $records_per_page = 50;
        $data = $data->where('company_id', '=', $request->user()->company->id);
        if (!empty($request->name)) {
            $data = $data->where('name', 'like', '%' . $request->name . '%');
        }
        if (!empty($request->records_per_page) && is_numeric($request->records_per_page)) {
            $records_per_page = $request->records_per_page;
        }
        $data = $data->orderBy("id", "DESC");
        $data = $data->paginate($records_per_page);
        if ($request->ajax()) {
            return view('backend.corporate.designation.ajax_content', compact('data'));
        } else {
            return view('backend.corporate.designation.index', compact('data'));
        }
    }

    public function add(Request $request) {
        return view('backend.corporate.designation.add');
    }

    public function edit($id) {
        $data = \App\Models\Designation::findOrFail($id);
        return view('backend.corporate.designation.edit', compact('data'));
    }

    public function update(Request $request, $id) {
        $data = \App\Models\Designation::findOrFail($id);
        $data->name = $request->name;
       $data->company_id = $request->user()->company->id;
        $data->save();
        return redirect()->route('corporate.designation')->with('success', 'Data Updated Successfully!');
    }

    public function store(Request $request) {
        $data = new \App\Models\Designation;
        $data->name = $request->name;
        $data->company_id = $request->user()->company->id;
        $data->save();
        return redirect()->route('corporate.designation.add')->with('success', 'Data Added Successfully!');
    }

}
