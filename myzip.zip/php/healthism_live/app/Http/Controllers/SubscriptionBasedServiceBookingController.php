<?php

namespace App\Http\Controllers;

use App\Http\Controllers\Controller;
use App\Http\Controllers\Api\OrderPaymentController;
use App\Http\Repository\NotificationRepository;
use App\Models\UserUpload;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Validator;

class SubscriptionBasedServiceBookingController extends Controller {

    private $orderPaymentController;
    private $notificationRepository;

    public function __construct(OrderPaymentController $orderPaymentController, NotificationRepository $notificationRepository) {
        $this->orderPaymentController = $orderPaymentController;
        $this->notificationRepository = $notificationRepository;
    }

    public function cancelBookingPage(Request $request) {
        $input = $request->all();
        $reasones = [
            'I am Unavailable',
            'I am busy',
            'I have another appointment'
        ];
        $order = \App\Models\SubscriptionBasedServiceBooking::findOrFail($input['id']);
        return view('backend.subscription_based_service_partner.orders.cancel', compact('order', 'reasones'));
    }

    public function cancelBooking(Request $request) {
        try {
            $input = $request->all();
            $input['login_user_id'] = $request->user()->id;
            $input['login_user_type'] = $request->user()->user_type_id;
            if (empty($request->appointment_id)) {
                return error("Sorry, Appointment id is empty");
            }
            if (empty($request->reason)) {
                return error("Sorry, Reason is empty");
            }
            $appintmentData = \App\Models\SubscriptionBasedServiceBooking::where('id', $input['appointment_id'])->first();
            if ($input['login_user_type'] == SBS_USER) {
                $parentData = \App\Models\SubscriptionBasedService::where('user_id', $input['login_user_id'])->first();
                if ($appintmentData->subscriptionBasedService->user_id != $input['login_user_id']) {
                    if ($appintmentData->subscription_based_service_parent_id != $parentData->id) {
                        return error('Sorry, You are not authorized to reschedule this appointment');
                    }
                }
            } else {
                if ($appintmentData->lab->user_id != $input['login_user_id']) {
                    return error('Sorry, You are not authorized to reschedule this appointment');
                }
            }
            $orderDetail = \App\Models\OrderDetail::where('order_id', $appintmentData->order_id)
                            ->where('ref_id', $request->appointment_id)->first();
            if (empty($orderDetail)) {
                return error("Sorry, Order data not found");
            }
            $orderPayment = \App\Models\OrderPayment::where('order_id', $appintmentData->order_id)->first();
            $cancelationData['cancelationCharges'] = $request->user()->user_type_id == END_USER ? $this->cancelationCharges($appintmentData) : 0;
            if (!empty($orderPayment)) {
                if ($orderPayment->status_id == STATUS_DONE && $orderPayment->payment_mode_id == RAZORPAY) {
                    $cancelationData['refundAmount'] = $orderDetail->pg_amount - $cancelationData['cancelationCharges'];
                }
            }
            $cancelationData['reason'] = "Cancel by lab : " . $request->reason;
            $cancelationData['order_id'] = $appintmentData->order_id;
            $cancelationData['order_detail_id'] = $orderDetail->id;
            $cancelationData['ref_id'] = $appintmentData->id;
            $cancelationData['login_user_id'] = $request->user()->id;
            $cancelationData['login_user_type'] = $request->user()->user_type_id;
            $cancelationData['login_user_name'] = $request->user()->first_name . ' ' . $request->user()->last_name;
            $this->orderPaymentController->orderCancel($cancelationData);
            $appintmentData->fill(array('status_id' => STATUS_CANCELLED, 'updated_at' => date('Y-m-d H:i:s'),
                'refund_amount' => !empty($cancelationData['refundAmount']) ? $cancelationData['refundAmount'] : null))->save();
            $remark = "Cancel by service provider - reason: " . $request->reason;
            $this->orderPaymentController->saveOrderHistory(['order_id' => $appintmentData->order_id, 'type' => 'TRACKING', 'status_id' => STATUS_CANCELLED, 'remark' => $remark, 'updated_by' => $request->user()->id]);

            $this->notificationRepository->SBSAppointmentNotification($appintmentData->order_id, 'CANCELLED');

            return success(array(), "Appointment cancelled!");
        } catch (Exception $exc) {
            errorLog($exc);
        }
        return error(COMMON_ERROR);
    }

    public function rescheduleBooking(Request $request) {
        try {
            $input = $request->all();
            $input['login_user_id'] = $request->user()->id;
            $input['login_user_mobile'] = $request->user()->mobile;
            $input['login_user_type'] = $request->user()->user_type_id;
            if (empty($input['appointment_id'])) {
                return error('Sorry, Appointment id is empty');
            }
            if (empty($input['subscription_based_service_slot_id'])) {
                return error('Sorry, Slot id is empty');
            }
            if (empty($input['date'])) {
                return error('Sorry, Date is empty');
            }
            $appintmentData = \App\Models\SubscriptionBasedServiceBooking::where('id', $input['appointment_id'])->first();
            $oldDate = date_format(date_create($appintmentData->appointment_date), "d/m/Y") . ' ' . $appintmentData->appointment_time;
            if (empty($appintmentData)) {
                return error('Sorry, Invalid appointment id');
            }

            if ($input['login_user_type'] == SBS_USER) {
                $parentData = \App\Models\SubscriptionBasedService::where('user_id', $input['login_user_id'])->first();
                if ($appintmentData->subscriptionBasedService->user_id != $input['login_user_id']) {
                    if ($appintmentData->subscription_based_service_parent_id != $parentData->id) {
                        return error('Sorry, You are not authorized to reschedule this appointment');
                    }
                }
            } else {
                if ($appintmentData->lab->user_id != $input['login_user_id']) {
                    return error('Sorry, You are not authorized to reschedule this appointment');
                }
            }
            if ($appintmentData->status_id != STATUS_SUCCESS) {
                return error('Sorry, Your appointment has not been confirmed. so you cannot reschedule the appointment');
            }
            $date = $appintmentData->appointment_date . " " . $appintmentData->appointment_time;
            $dateNow = strtotime(date('Y-m-d H:i:s'));
            $rescheduleTime = strtotime(date('Y-m-d H:i:s', strtotime($date . ' -2 hours')));

            if ($dateNow > $rescheduleTime) {
                return array('code' => 0, 'message' => "Sorry, Reschedule time has been over");
            }

            $slotData = \App\Models\SubscriptionBasedServiceSlot::where('id', $input['subscription_based_service_slot_id'])->first();
            if (empty($slotData)) {
                return error('Sorry, Invalid slot id');
            }
            if ($appintmentData->subscription_based_service_id != $slotData->subscription_based_service_id) {
                return error("Sorry, Can't select other service slot.");
            }
            $checkSlotBlocked = \App\Models\SubscriptionBasedServiceBlockSlot::where(
                            [
                                'subscription_based_service_slot_id' => $input['subscription_based_service_slot_id'],
                                'date' => $input['date']
                    ])->count();
            if ($checkSlotBlocked > 0) {
                return array(0, "Sorry, Slot has been blocked");
            }
            $result = $appintmentData->fill([
                        'subscription_based_service_slot_id' => $input['subscription_based_service_slot_id'],
                        'appointment_date' => $input['date'],
                        'appointment_time' => $slotData->from_time,
                    ])->save();

            $remark = "Reschedule Appointment : Old  Appointment - " . $oldDate
                    . ' New  Appointment - ' . $input['date'] . ' ' . $slotData->from_time;
            $this->orderPaymentController->saveOrderHistory([
                'order_id' => $appintmentData->order_id,
                'type' => 'TRACKING', 'status_id' => STATUS_SUCCESS,
                'remark' => $remark,
                'updated_by' => $input['login_user_id']
            ]);
            $this->notificationRepository->SBSAppointmentNotification($appintmentData->order_id, 'RESCHEDULE', ['old_date' => $oldDate]);
            return success($result, "Appointment rescheduled successfully!");
        } catch (Exception $exc) {
            errorLog($exc);
        }
        return error(COMMON_ERROR);
    }

}
