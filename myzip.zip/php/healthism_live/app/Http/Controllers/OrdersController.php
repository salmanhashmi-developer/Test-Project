<?php

namespace App\Http\Controllers;

use App\Helpers\Helpers;
use App\Models\Orders;
use App\Models\OrderDetail;
use App\Models\OrderPayment;
use App\Models\OrderHistories;
use App\Models\Service;
use App\Models\Subscription;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;

class OrdersController extends Controller {

    public function index(Request $request) {
        $orders = Orders::query();
        $records_per_page = 10;
        if (!empty($request->order_code)) {
            $orders = $orders->where('order_code', '=', trim($request->order_code));
        }
        if (!empty($request->order_id)) {
            $orders = $orders->where('id', '=', trim($request->order_id));
        }
        if (!empty($request->order_code)) {
            $orders = $orders->where('order_code', 'like', '%' . trim($request->order_code) . '%');
        }
//        if (!empty($request->subscription_id) && is_numeric($request->subscription_id)) {
//            $orders = $orders->where('subscription.subscription_id', '=', trim($request->subscription_id));
//        }
        if (!empty($request->user_id) && is_numeric($request->user_id)) {
            $orders = $orders->where('user_id', '=', trim($request->user_id));
        }
        if (!empty($request->status_id) && is_numeric($request->status_id)) {
            $orders = $orders->where('status_id', '=', trim($request->status_id));
        }
        if (!empty($request->start_date)) {
            $orders = $orders->whereDate('created_at', '>=', date('Y-m-d', strtotime($request->start_date)));
        }
        if (!empty($request->end_date)) {
            $orders = $orders->whereDate('created_at', '<=', date('Y-m-d', strtotime($request->end_date)));
        }
        if (!empty($request->service_id) && is_numeric($request->service_id)) {
            $orders = $orders->where('service_id', '=', trim($request->service_id));
        }
        if (!empty($request->name)) {
            $orders = $orders->whereRelation('user', 'first_name', 'like', '%' . trim($request->name) . '%')
                    ->orwhereRelation('user', 'last_name', 'like', '%' . trim($request->name) . '%');
        }
        if (!empty($request->records_per_page) && is_numeric($request->records_per_page)) {
            $records_per_page = $request->records_per_page;
        }
        if (!empty($request->sort_field)) {
            if ($request->sort_field == 'name' && ($request->sort_action == 'ASC' || $request->sort_action == 'DESC')) {
                $orders = $orders->orderBy("first_name", $request->sort_action);
            } elseif ($request->sort_field == 'order_id' && ($request->sort_action == 'ASC' || $request->sort_action == 'DESC')) {
                $orders = $orders->orderBy("id", $request->sort_action);
            } elseif ($request->sort_field == 'subscription' && ($request->sort_action == 'ASC' || $request->sort_action == 'DESC')) {
                $orders = $orders->orderBy("subscription_id", $request->sort_action);
            } elseif ($request->sort_field == 'service' && ($request->sort_action == 'ASC' || $request->sort_action == 'DESC')) {
                $orders = $orders->orderBy("service_id", $request->sort_action);
            } elseif ($request->sort_field == 'amount' && ($request->sort_action == 'ASC' || $request->sort_action == 'DESC')) {
                $orders = $orders->orderBy("amount", $request->sort_action);
            } elseif ($request->sort_field == 'Status' && ($request->sort_action == 'ASC' || $request->sort_action == 'DESC')) {
                $orders = $orders->orderBy("status_id", $request->sort_action);
            } elseif ($request->sort_field == 'created_at' && ($request->sort_action == 'ASC' || $request->sort_action == 'DESC')) {
                $orders = $orders->orderBy("created_at", $request->sort_action);
            }
        } else {
            $orders = $orders->orderBy("id", 'DESC');
        }

        $orders = $orders->paginate($records_per_page);
        $subscriptions = Subscription::where(['status_id' => 1])->orderBy('display_index')->get();
        $service = Service::orderBy('name')->get();
        $statusList = array(
            ['id' => 6, 'name' => 'PENDING'],
            ['id' => 9, 'name' => 'FAILED'],
            ['id' => 20, 'name' => 'DONE'],
            ['id' => 18, 'name' => 'SENT ON PG'],
            ['id' => 19, 'name' => 'RETURN FROM PG'],
            ['id' => 23, 'name' => 'PARTIAL REFUNDED'],
            ['id' => 24, 'name' => 'FULLY REFUNDED'],
            ['id' => 25, 'name' => 'REFUNDED INPROGRESS'],
            ['id' => 21, 'name' => 'PARTIAL CANCELLED'],
            ['id' => 22, 'name' => 'FULLY CANCELLED'],
        );
        $formValues = compact('orders', 'subscriptions', 'service', 'statusList');
        if ($request->ajax()) {
            return view('backend.orders.ajax_content', $formValues);
        } else {
            return view('backend.orders.index', $formValues);
        }
    }

    public function view($id) {
        $order = Orders::findOrFail($id);
        if (!empty($order->detail)) {
            foreach ($order->detail as $key => $orderDetail) {
                $order->detail[$key]['status_list'] = getUpdateStatusList($orderDetail->status_id);
            }
        }
        return view('backend.orders.view', compact('order'));
    }

    public function recheckOrder($orderId) {
        $result = $this->razorpayRecheck($orderId);
        $msg = 'Order Recheck Successfully';
        $code = 'success';
        if (!empty($result)) {
            $result = json_decode(json_encode($result), true);
            if (!empty($result)) {
                if (!empty($result['original'])) {
                    $msg = $result['original']['message'];
                    $code = $result['original']['code'] == 200 ? 'success' : 'error';
                }
            }
        }
        return redirect()->route('admin.orders.view', $orderId)->with($code, $msg);
    }

    public function orderRecheckCron() {
        $orderList = Orders::whereIn('status_id', [STATUS_PENDING, STATUS_SENT_ON_PG, STATUS_RETURN_FROM_PG])
                ->where('created_at', '<', date('Y-m-d H:i:s', strtotime("-15 minutes")))
                ->orderBy('id', 'ASC')
                ->limit(25)
                ->get();
        if (!empty($orderList)) {
            foreach ($orderList as $key => $order) {
                $this->razorpayRecheck($order['id']);
            }
        }
    }

    public function razorpayRecheck($orderId) {
        if (empty($orderId)) {
            return error('Sorry, Order id is empty.');
        }
        $orderPaymentData = OrderPayment::where('order_id', $orderId)->first();
        $respons = success(['order_id' => $orderId, 'status_id' => STATUS_FAILED], 'Order Recheck Successfully');
        cronLog(['order_id' => $orderId, 'status_id' => STATUS_FAILED], 'Order Recheck Successfully');
        if (empty($orderPaymentData)) {
            $this->orderUpdate($orderId, STATUS_FAILED, 'ORDER FAILED', ['order_remark' => 'Recheck order : payment data is empty.']);
            return $respons;
        }

        $orderDetail = OrderDetail::where('order_id', $orderId)->first();

        if (empty($orderPaymentData->pg_reference_id)) {
            $this->orderUpdate($orderId, STATUS_FAILED, 'ORDER FAILED', ['order_remark' => 'Recheck order : pg_reference_id is empty.']);
            return $respons;
        }
        $razorpayOrder = $this->getRazorpayOrderDetail($orderPaymentData->pg_reference_id, $orderId);
        if (empty($razorpayOrder)) {
            $this->orderUpdate($orderId, STATUS_FAILED, 'ORDER FAILED', ['order_remark' => 'Payment details not found in razorpay.']);
            return $respons;
        }
        if (empty($razorpayOrder['payments']['items'])) {
            $this->orderUpdate($orderId, STATUS_FAILED, 'ORDER FAILED', ['pg_response' => json_encode($razorpayOrder), 'order_remark' => 'Payment details not found in razorpay.']);
            return $respons;
        }

        $capturedPayment = 0;
        foreach ($razorpayOrder['payments']['items'] as $payment) {
            if ($payment['status'] == 'captured') {
                $capturedPayment = 1;
                return $this->razorpayFetchPayment($orderId, $payment['id']);
                break;
            }
        }
        $paymentSyncRetryCount = $orderPaymentData->payment_sync_retry_count + 1;
        if ($capturedPayment == 0 && $paymentSyncRetryCount <= 3) {
            $orderPaymentData->fill(['payment_sync_retry_count' => $paymentSyncRetryCount])->save();
            if ($paymentSyncRetryCount == 3) {
                $this->orderUpdate($orderId, STATUS_FAILED, 'ORDER FAILED', ['pg_response' => json_encode($razorpayOrder), 'order_remark' => 'Recheck order 3 time. Payment was not captured by razorpay.']);
                cronLog(['order_id' => $orderId], 'ORDER FAILED');
                return $respons;
            } else {
                return success(['order_id' => $orderId], 'Please, Wait payment was not captured by razorpay.');
                cronLog(['order_id' => $orderId], 'Please, Wait payment was not captured by razorpay.');
            }
        }
        cronLog(['order_id' => $orderId], 'Order Recheck Successfully');
        return success(['order_id' => $orderId], 'Order Recheck Successfully');
    }

    private function getRazorpayOrderDetail($pgReferenceId, $orderId) {
        $ch = curl_init();
        // $url = 'https://api.razorpay.com/v1/orders/'.$pgReferenceId.'/payments';
        $url = 'https://api.razorpay.com/v1/orders/' . $pgReferenceId . '?expand[]=payments';
        curl_setopt($ch, CURLOPT_URL, $url);
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
        curl_setopt($ch, CURLOPT_USERPWD, env('RAZORPAY_KEY_ID') . ":" . env('RAZORPAY_SECRET_KEY'));
        curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
        $headers = array();
        $headers[] = 'Content-Type: application/json';
        curl_setopt($ch, CURLOPT_HTTPHEADER, $headers);
        $data = curl_exec($ch);
        curl_close($ch);

        $fields["receipt"] = $orderId;
        paymentLog($url, json_encode($fields), $data);
        return json_decode($data, TRUE);
    }

    private function razorpayFetchPayment($orderId, $rzpPaymentId) {
        $orderData = OrderPayment::where('order_id', $orderId)->first();
        if (empty($orderData)) {
            return error('Sorry, Razorpay order not found.');
        }
        $amountInPaisa = $orderData->pg_amount * 100;
        $ch = curl_init();
        $url = 'https://api.razorpay.com/v1/payments/' . $rzpPaymentId;
        curl_setopt($ch, CURLOPT_URL, $url);
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
        curl_setopt($ch, CURLOPT_USERPWD, env('RAZORPAY_KEY_ID') . ":" . env('RAZORPAY_SECRET_KEY'));
        curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
        $headers = array();
        $headers[] = 'Content-Type: application/json';
        curl_setopt($ch, CURLOPT_HTTPHEADER, $headers);
        $data = curl_exec($ch);
        curl_close($ch);

        $fields["receipt"] = $orderData->id;
        paymentLog($url, json_encode($fields), $data);
        if (empty($data)) {
            return error('Sorry, No response from razorpay.', ['order_id' => $orderId]);
        } else {
            OrderPayment::where('order_id', $orderId)->limit(1)->update(array('pg_response' => $data));
            $result = json_decode($data, TRUE);
            $orderDetail = OrderDetail::where('order_id', $orderId)->first();


            if ($result['status'] != "captured") {
                $this->orderUpdate($orderId, STATUS_FAILED, 'ORDER FAILED', ['pg_response' => $data, 'order_remark' => 'Recheck order : Payment not captured by razorpay.']);
                cronLog(['order_id' => $orderId, 'status_id' => STATUS_FAILED], 'Sorry, Payment was not captured');
                return success(['order_id' => $orderId, 'status_id' => STATUS_FAILED], 'Sorry, Payment was not captured');
            }

            if ($orderData->pg_reference_id != $result['order_id']) {
                return error('System pg_ref_id and razorpay payment order_id not same', ['order_id' => $orderId]);
                cronLog(['order_id' => $orderId], 'System pg_ref_id and razorpay payment order_id not same');
            }
            if ($result['amount'] != $amountInPaisa) {
                cronLog(['order_id' => $orderId], 'Sorry, Booking amount(' . $amountInPaisa / 100 . ') and razorpay amount(' . $result['amount'] / 100 . ') not same.');
                return error('Sorry, Booking amount(' . $amountInPaisa / 100 . ') and razorpay amount(' . $result['amount'] / 100 . ') not same.', ['order_id' => $orderId]);
            }
            /** UPDATE RECORDE************** */
            $this->orderUpdate($orderId, STATUS_DONE, 'ORDER CONFIRM', ['pg_response' => $data, 'order_remark' => 'ORDER CONFIRM : Payment done successfully']);
            cronLog(['order_id' => $orderId, 'status_id' => STATUS_DONE], 'Order Recheck Successfully');
            return success(['order_id' => $orderId, 'status_id' => STATUS_DONE], 'Order Recheck Successfully');
        }
        return success(['order_id' => $orderId], 'Thank you.');
    }

    public function orderUpdate($orderId, $statusId, $remark, $otherParam = []) {
        $color = statusWiseColor($statusId);
        $order = Orders::where('id', $orderId)->first();
        if (!empty($order)) {
            if ($order->status_id != $statusId) {
                $order->fill(array('status_id' => $statusId, 'remark' => $remark, 'remark_color_code' => $color, 'updated_at' => date('Y-m-d H:i:s')))->save();
                $this->saveOrderHistory(['order_id' => $orderId, 'type' => 'ORDER', 'status_id' => $statusId, 'remark' => !empty($otherParam['order_remark']) ? $otherParam['order_remark'] : $remark]);
            }
        }

        $orderDetailData = OrderDetail::where('order_id', $orderId)->get();
        if (!empty($orderDetailData)) {
            foreach ($orderDetailData as $orderDetail) {
                if ($orderDetail->status_id != $statusId) {
                    $orderDetail->fill(array('status_id' => $statusId, 'remark' => $remark, 'remark_color_code' => $color, 'updated_at' => date('Y-m-d H:i:s')))->save();
                    $this->saveOrderHistory(['order_id' => $orderId, 'order_detail_id' => $orderDetail->id, 'type' => 'ORDER_DETAIL', 'status_id' => $statusId, 'remark' => $remark]);
                }
            }
        }
        $this->updateServiceData($orderId, 'Recheck payment', 0);

        $orderPayment = OrderPayment::where('order_id', $orderId)->first();
        if (!empty($orderPayment)) {
            if ($orderPayment->status_id != $statusId) {
                $orderPayment->fill(array('status_id' => $statusId, 'updated_at' => date('Y-m-d H:i:s'), 'pg_response' => !empty($otherParam['pg_response']) ? $otherParam['pg_response'] : null))->save();
                $this->saveOrderHistory(['order_id' => $orderId, 'type' => 'PAYMENT', 'status_id' => $statusId, 'remark' => $remark]);
            }
        }
    }

    public function updateServiceData($orderId, $remark, $logginUserId) {
        $orderDetail = OrderDetail::where('order_id', $orderId)->get();
        if (!empty($orderDetail)) {
            $orderDetailData = $orderDetail[0];
            $statusId = $orderDetailData->status_id == STATUS_DONE ? STATUS_SUCCESS : STATUS_FAILED;
            if ($orderDetail[0]->service_id == SERVICE_DOCTOR_APPOINTMENT) {
                //Single record mapped : get data from '0' index
                \App\Models\DoctorAppointmentBooking::where('id', $orderDetailData->ref_id)
                        ->limit(1)
                        ->update(array('status_id' => $statusId, 'updated_at' => date('Y-m-d H:i:s'), 'order_id' => $orderId));
            }
            if ($orderDetail[0]->service_id == SERVICE_LAB_REPORT) {
                //Single record mapped : get data from '0' index
                $appintmentData = \App\Models\LabBooking::where('id', $orderDetailData->ref_id)->first();
                $appintmentData->update(
                        array(
                            'status_id' => $statusId,
                            'updated_at' => date('Y-m-d H:i:s'),
                            'order_id' => $orderDetailData->order_id
                        )
                );
            }
            if ($orderDetail[0]->service_id == MENU_BASED_SERVICE) {
                //Single record mapped : get data from '0' index
                $appintmentData = \App\Models\MenuBasedServiceBooking::where('id', $orderDetailData->ref_id)->first();
                $appintmentData->update(
                        array(
                            'status_id' => $statusId,
                            'updated_at' => date('Y-m-d H:i:s'),
                            'order_id' => $orderDetailData->order_id
                        )
                );
            }
            if ($orderDetail[0]->service_id == SUBSCRIPTION_BASED_SERVICE) {
                //Single record mapped : get data from '0' index
                $appintmentData = \App\Models\SubscriptionBasedService::where('id', $orderDetailData->ref_id)->first();
                $appintmentData->update(
                        array(
                            'status_id' => $statusId,
                            'updated_at' => date('Y-m-d H:i:s'),
                            'order_id' => $orderDetailData->order_id
                        )
                );
            }
            if ($orderDetail[0]->service_id == SERVICE_SUBSCRIPTION_PLAN) {
                //Single record mapped : get data from '0' index
                $statusId = $orderDetailData->status_id == STATUS_DONE ? STATUS_ACTIVE : STATUS_FAILED;
                $userSubscription = \App\Models\UserSubscription::where('id', $orderDetailData->ref_id)->first();
                if ($statusId == STATUS_ACTIVE) {
                    \App\Models\UserSubscription::where('user_id', $userSubscription->user_id)
                            ->update(array('status_id' => STATUS_INACTIVE, 'updated_at' => date('Y-m-d H:i:s')));
                    \App\Models\UserFamilyMember::where('user_id', $userSubscription->user_id)
                            ->update(array('status_id' => STATUS_INACTIVE, 'updated_at' => date('Y-m-d H:i:s')));
                    $loginUser = App\Models\User::findOrFail($userSubscription->user_id);
                    if (!empty($loginUser) && !empty($loginUser->mobile)) {
                        \App\Models\UserFamilyMember::where('mobile', $loginUser->mobile)
                                ->update(array('status_id' => STATUS_INACTIVE, 'updated_at' => date('Y-m-d H:i:s')));
                    }
                    $userSubscription->update(array('status_id' => $statusId, 'updated_at' => date('Y-m-d H:i:s'), 'order_id' => $orderId));
                } else {
                    $userSubscription->update(array('status_id' => $statusId, 'updated_at' => date('Y-m-d H:i:s'), 'order_id' => $orderId, 'card_no' => null));
                }
            }
            //Multi record mapped : foreach set $orderDetail
        }
    }

    public function saveOrderHistory($input) {
        $input['created_at'] = date('Y-m-d H:i:s');
        $result = OrderHistories::create($input);
        return $result;
    }

    public function adminUpdateOrder(Request $request) {
        $input = $request->all();
        if (empty($input['order_detail_id'])) {
            return redirect()->route('admin.orders.view', $input['order_id'])->with('error', 'Sorry, Order detail id is empty.');
        }
        if (empty($input['status_id'])) {
            return redirect()->route('admin.orders.view', $input['order_id'])->with('error', 'Sorry, Status id is empty.');
        }
        if (empty($input['remark'])) {
            return redirect()->route('admin.orders.view', $input['order_id'])->with('error', 'Sorry, Reamrk is empty.');
        }
        $orderDetailData = OrderDetail::findOrFail($input['order_detail_id']);
        if (empty($orderDetailData)) {
            return redirect()->route('admin.orders.view', $input['order_id'])->with('error', 'Sorry, Order detail not found.');
        }
        $statusId = $input['status_id'];
        if ($orderDetailData->status_id == $statusId) {
            return redirect()->route('admin.orders.view', $input['order_id'])->with('success', 'Order updated...');
        }
        $statusList = getUpdateStatusList($orderDetailData->status_id);
        $validStatus = 0;
        $statusData = [];
        if (empty($statusList)) {
            return redirect()->route('admin.orders.view', $input['order_id'])->with('success', 'Order updated...');
        } else {
            foreach ($statusList as $status) {
                if ($status['id'] == $statusId) {
                    $validStatus = 1;
                    $statusData = $status;
                    break;
                }
            }
        }
        if ($validStatus == 1) {
            if ($statusId == STATUS_FULLY_CANCELLED) {
                $statusId = $this->cancelOrder($orderDetailData, $request->user()->id);
            }
            $orderDetailData->fill(
                    array(
                        'status_id' => $statusId,
                        'remark' => 'OREDR ' . $statusData['name'],
                        'remark_color_code' => statusWiseColor($statusId),
                        'updated_at' => date('Y-m-d H:i:s')
                    )
            )->save();
            $this->updateRelatedOrder($input['order_id'], $statusId, $request->user()->id);
            $this->updateServiceData($input['order_id'], "Order Status changed by admin.", $request->user()->id);
        }
        return redirect()->route('admin.orders.view', $input['order_id'])->with('success', 'Order updated...');
    }

    function cancelOrder($orderDetailData, $logginUserId) {
        $statusId = STATUS_FULLY_CANCELLED;
        $orderPayment = OrderPayment::where('order_id', $orderDetailData->order_id)->first();
        if (!empty($orderPayment)) {
            if ($orderPayment->status_id == STATUS_DONE) {
                if ($orderPayment->payment_mode_id == RAZORPAY) {
                    $razorpayRespons = $this->refundRequestToRazorpay($orderPayment, $orderDetailData->pg_amount);
                    if (!empty($razorpayRespons['error'])) {
                        $statusId = STATUS_REFUNDED_INPROGRESS;
                    } else {
                        $statusId = STATUS_FULLY_REFUNDED;
                    }
                    $orderPayment->update(
                            array(
                                'updated_at' => date('Y-m-d H:i:s'),
                                'refund_amount' => $orderPayment->refund_amount + $orderDetailData->pg_amount,
                                /* Discussion */
                                //'cancellation_amount' => $cancelationData['cancelationCharges'],
                                'pg_refund_response' => json_encode($razorpayRespons),
                            )
                    );
                    $this->saveOrderHistory(
                            [
                                'status_id' => $orderPayment->status_id,
                                'order_id' => $orderDetailData->order_id,
                                'type' => 'PAYMENT',
                                'remark' => 'Cancelled by admin : The refund is credited in your original payment method with in 6-7 days',
                                'updated_by' => $logginUserId
                            ]
                    );
                }
            }
        }
        return $statusId;
    }

    private function refundRequestToRazorpay($orderPayment, $refundAmount) {
        $amountInPaisa = $refundAmount * 100;
        $fields['amount'] = (string) $amountInPaisa;
        $fields['speed'] = "normal";
        $fields['receipt'] = (string) $orderPayment->order_id;
        $razorpayPamentResponse = json_decode($orderPayment->pg_response, true);
        $rzpPaymentId = $razorpayPamentResponse['id'];
        $ch = curl_init();
        $url = 'https://api.razorpay.com/v1/payments/' . $rzpPaymentId . '/refund';
        curl_setopt($ch, CURLOPT_URL, $url);
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
        curl_setopt($ch, CURLOPT_POST, 1);
        curl_setopt($ch, CURLOPT_POSTFIELDS, json_encode($fields));
        curl_setopt($ch, CURLOPT_USERPWD, env('RAZORPAY_KEY_ID') . ":" . env('RAZORPAY_SECRET_KEY'));
        curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
        $headers = array();
        $headers[] = 'Content-Type: application/json';
        curl_setopt($ch, CURLOPT_HTTPHEADER, $headers);
        $data = curl_exec($ch);
        curl_close($ch);
        paymentLog($url, json_encode($fields), $data);
        return json_decode($data, true);
    }

    function updateRelatedOrder($orderId, $status, $logginUserId) {
        $order = Orders::findOrFail($orderId);
        if (!empty($order)) {
            if ($status == STATUS_FULLY_REFUNDED || $status == STATUS_FULLY_CANCELLED) {
                $newStatusId = getOrderStatus($orderId, $status);
                if ($order->status_id != $newStatusId) {
                    $statusName = getStatus($newStatusId);
                    $order->fill(['status_id' => $newStatusId, 'remark' => 'ORDER ' . !empty($statusName['name']) ? $statusName['name'] : 'UPDATED', 'remark_color_code' => statusWiseColor($newStatusId), 'updated_at' => date('Y-m-d H:i:s')])->save();
                    $this->saveOrderHistory(['order_id' => $orderId, 'type' => 'ORDER', 'status_id' => $newStatusId, 'remark' => 'Update order status by admin', 'updated_by' => $logginUserId]);
                }
            } else {
                $orderDetail = OrderDetail::where('order_id', $orderId)->whereIn('status_id', [STATUS_DONE, STATUS_FULLY_REFUNDED, STATUS_PARTIAL_REFUNDED, STATUS_REFUNDED_INPROGRESS])->count();
                if (empty($orderDetail)) {
                    if ($order->status_id != STATUS_FULLY_CANCELLED) {
                        $order->fill(['status_id' => STATUS_FULLY_CANCELLED, 'remark' => 'ORDER CANCELLED', 'remark_color_code' => statusWiseColor(STATUS_FULLY_CANCELLED), 'updated_at' => date('Y-m-d H:i:s')])->save();
                        $this->saveOrderHistory(['order_id' => $orderId, 'type' => 'ORDER', 'status_id' => STATUS_FULLY_CANCELLED, 'remark' => 'All transactions are cancelled or fail', 'updated_by' => $logginUserId]);
                    }
                } else {
                    if ($order->status_id != $status) {
                        $statusName = getStatus($status);
                        $order->fill(['status_id' => $status, 'remark' => !empty($statusName['name']) ? "ORDER " . $statusName['name'] : 'ORDER UPDATED', 'remark_color_code' => statusWiseColor($status), 'updated_at' => date('Y-m-d H:i:s')])->save();
                        $this->saveOrderHistory(['order_id' => $orderId, 'type' => 'ORDER', 'status_id' => $status, 'remark' => 'Update order status by admin', 'updated_by' => $logginUserId]);
                    }
                }
            }
        }
        return $order;
    }

}
