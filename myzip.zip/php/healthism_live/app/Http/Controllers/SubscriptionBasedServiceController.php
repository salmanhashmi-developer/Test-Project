<?php

namespace App\Http\Controllers;

use App\Helpers\Helpers;
use App\Http\Requests\SubscriptionBasedServiceRequest;
use App\Models\SubscriptionBasedService;
use App\Models\SubscriptionBasedServiceDetails;
use App\Models\State;
use App\Models\City;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Auth;
use Intervention\Image\ImageManagerStatic as Image;
use function Psr\Log\debug;

class SubscriptionBasedServiceController extends Controller {

    public function location($id) {
        $subscriptionBasedService = SubscriptionBasedService::findOrFail($id)->toArray();
        $location = \App\Models\SubscriptionBasedServiceSearch::where('subscription_based_service_id', $id)->get()->toArray();
        if (Auth::user()->user_type_id == SBS_USER) {
            return view('backend.subscription_based_service_partner.branch.location', compact('subscriptionBasedService', 'location'));
        }
        return view('backend.subscription_based_service.location', compact('subscriptionBasedService', 'location'));
    }

    public function profile(Request $request) {
        $subscriptionBasedService = SubscriptionBasedService::where('user_id', $request->user()->id)->first();
        $images = $subscriptionBasedService->subscriptionBasedServiceDetails->gallery_json;
        return view('backend.subscription_based_service_partner.profile', compact('subscriptionBasedService', 'images'));
    }

    public function locationDelete($id) {
        $search = \App\Models\SubscriptionBasedServiceSearch::findOrFail($id);
        if (!empty($search))
            $search->delete();
        return success($id, "Location has been deleted successfully");
    }

    public function locationSave(Request $request) {
        $inputArr['subscription_based_service_id'] = $request->subscription_based_service_id;
        $inputArr['pincode'] = $request->pincode;
        $inputArr['latitude'] = $request->latitude;
        $inputArr['longitude'] = $request->longitude;
        $inputArr['category_id'] = $request->category_id;
        $duplicate = \App\Models\SubscriptionBasedServiceSearch::where($inputArr)->count();
        if ($duplicate > 0) {
            return error("Duplicate Entry");
        }
        $inputArr['subscription_based_service_parent_id'] = !empty($request->subscription_based_service_parent_id) ? $request->subscription_based_service_parent_id : 0;
        $inputArr['name'] = $request->name;
        $result = \App\Models\SubscriptionBasedServiceSearch::Create($inputArr);
        return success($result, "Location has been saved successfully");
    }

    public function subscriptionBasedServiceSearch(Request $request) {
        $search = $request->get('search');
        $parentId = !empty($request->get('parent_id')) ? $request->get('parent_id') : '';
        $data = SubscriptionBasedService::where('name', 'LIKE', '%' . $search . '%');
        if ($request->user()->user_type_id == SBS_USER) {
            $subscriptionBasedServiceData = \App\Models\SubscriptionBasedService::where('user_id', $request->user()->id)->first();
            $parentId = $subscriptionBasedServiceData->id;
        }
        if (!empty($parentId)) {
            $data->where('parent_id', $parentId);
        }
        $data = $data->limit(25)->get();
        $result = [];
        if (!empty($data)) {
            $subscriptionBasedService = [];
            foreach ($data as $value) {
                $subscriptionBasedService['label'] = $value['name'] . '(' . $value['area'] . ',' . $value['city']['name'] . ',' . $value['state']['name'] . ')';
                $subscriptionBasedService['id'] = $value['id'];
            }
            $result[] = $subscriptionBasedService;
        }
        return response()->json($result);
    }

    public function index(Request $request) {
        $subscriptionBasedService = SubscriptionBasedService::query();
        $records_per_page = 10;
        $subscriptionBasedService->where('parent_id', '=', 0);
        if (!empty($request->name)) {
            $subscriptionBasedService = $subscriptionBasedService->where('name', 'like', '%' . $request->name . '%');
        }
        if (!empty($request->area)) {
            $subscriptionBasedService = $subscriptionBasedService->where('area', 'like', '%' . $request->area . '%');
        }
        if (!empty($request->pincode)) {
            $subscriptionBasedService = $subscriptionBasedService->where('pincode', 'like', '%' . $request->pincode . '%');
        }
        if (!empty($request->category_id)) {
            $subscriptionBasedService = $subscriptionBasedService->where('category_id', "=", $request->category_id);
        }
        if (!empty($request->city_id)) {
            $subscriptionBasedService = $subscriptionBasedService->where('city_id', "=", $request->city_id);
        }
        if (!empty($request->state_id)) {
            $subscriptionBasedService = $subscriptionBasedService->where('state_id', "=", $request->state_id);
        }

        if (!empty($request->records_per_page) && is_numeric($request->records_per_page)) {
            $records_per_page = $request->records_per_page;
        }
        if (!empty($request->sort_field)) {
            if ($request->sort_field == 'name' && ($request->sort_action == 'ASC' || $request->sort_action == 'DESC')) {
                $subscriptionBasedService = $subscriptionBasedService->orderBy("name", $request->sort_action);
            } elseif ($request->sort_field == 'Area' && ($request->sort_action == 'ASC' || $request->sort_action == 'DESC')) {
                $subscriptionBasedService = $subscriptionBasedService->orderBy("area", $request->sort_action);
            } elseif ($request->sort_field == 'Pincode' && ($request->sort_action == 'ASC' || $request->sort_action == 'DESC')) {
                $subscriptionBasedService = $subscriptionBasedService->orderBy("pincode", $request->sort_action);
            }
        } else {
            $subscriptionBasedService = $subscriptionBasedService->orderBy("id", "DESC");
        }

        $subscriptionBasedService = $subscriptionBasedService->paginate($records_per_page);
        $states = State::where('active', 1)->get();
        $cities = [];
        if (!empty($request->state_id)) {
            $cities = City::where(['active' => 1, 'state_id' => $request->state_id])->get();
        }
        if ($request->ajax()) {
            return view('backend.subscription_based_service.ajax_content', compact('subscriptionBasedService', 'states', 'cities'));
        } else {
            return view('backend.subscription_based_service.index', compact('subscriptionBasedService', 'states', 'cities'));
        }
    }

    public function bulkInsert(Request $request) {
        return view('backend.subscription_based_service.import');
    }

    public function add(Request $request) {
        $input = $request->all();
        $parent_subscription_based_service = "";
        if (!empty($input['subscription_based_service_id'])) {
            $parent_subscription_based_service = SubscriptionBasedService::findOrFail($request->subscription_based_service_id);
        } else {
            if (Auth::user()->user_type_id == SBS_USER) {
                $parent_subscription_based_service = SubscriptionBasedService::where('user_id', Auth::user()->id)->first();
            }
        }
        $subCategory = $amenityList = [];
        if (!empty($parent_subscription_based_service)) {
            $subCategory = \App\Models\Category::where('parent_id', $parent_subscription_based_service->category_id)->where('active', 1)->get();
            $amenityList = \App\Models\ServiceAmenity::where('category_id', $parent_subscription_based_service->category_id)->get();
        }
        $day_list = ['Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday', 'Saturday', 'Sunday'];
        $states = State::where('active', 1)->get();
        if (Auth::user()->user_type_id == SBS_USER) {
            return view('backend.subscription_based_service_partner.branch.add', compact('states', 'day_list', 'parent_subscription_based_service', 'subCategory', 'amenityList'));
        }
        return view('backend.subscription_based_service.add', compact('states', 'day_list', 'parent_subscription_based_service', 'subCategory', 'amenityList'));
    }

    public function getCategoryAmenityFromCategoryId($id) {
        $result = [];
        $category = \App\Models\Category::where('parent_id', $id)->where('active', 1)->get();
        $amenity = \App\Models\ServiceAmenity::where('category_id', $id)->get();
        if (!empty(count($category))) {
            $result['category'] = $category;
        }
        if (!empty(count($amenity))) {
            $result['amenity'] = $amenity;
        }
        return success($result, 'Data!');
    }

    public function edit($id) {
        $subscriptionBasedService = SubscriptionBasedService::findOrFail($id);
        $subscriptionBasedService->sub_category_ids_array = !empty($subscriptionBasedService->sub_category_ids) ? array_column($subscriptionBasedService->sub_category_ids->toArray(), 'id') : [];
        $subscriptionBasedService->sub_amenity_ids_array = !empty($subscriptionBasedService->amenity_ids) ? array_column($subscriptionBasedService->amenity_ids->toArray(), 'id') : [];
        $day_list = ['Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday', 'Saturday', 'Sunday'];
        $states = State::where('active', 1)->get();
        $cities = City::where(['active' => 1, 'state_id' => $subscriptionBasedService->state_id])->get();
        $subCategory = \App\Models\Category::where('parent_id', $subscriptionBasedService->category_id)->where('active', 1)->get();
        $amenityList = \App\Models\ServiceAmenity::where('category_id', $subscriptionBasedService->category_id)->get();
        if (Auth::user()->user_type_id == SBS_USER) {
            return view('backend.subscription_based_service_partner.branch.edit', compact('subscriptionBasedService', 'states', 'cities', 'day_list', 'subCategory', 'amenityList'));
        }
        return view('backend.subscription_based_service.edit', compact('subscriptionBasedService', 'states', 'cities', 'day_list', 'subCategory', 'amenityList'));
    }

    public function removeProfile($id) {
        $subscriptionBasedService = SubscriptionBasedService::findOrFail($id);
        $images = [];
        if ($subscriptionBasedService->subscriptionBasedServiceDetails->gallery_json != 'NULL' && !empty($subscriptionBasedService->subscriptionBasedServiceDetails->gallery_json)) {
            $gallery_images = json_decode($subscriptionBasedService->subscriptionBasedServiceDetails->gallery_json, true);
            if (!empty($gallery_images)) {
                foreach ($gallery_images as $row) {
                    $images[] = ['name' => $row];
                }
            }
        }
        if (!empty($subscriptionBasedService->photo)) {
            if (file_exists(public_path('image/subscription_base_service/' . $subscriptionBasedService->photo))) {
                unlink(public_path('image/subscription_base_service/' . $subscriptionBasedService->photo));
            }
            $subscriptionBasedService->photo = null;
            $subscriptionBasedService->save();
        }
        return view('backend.subscription_based_service.view', compact('subscriptionBasedService', 'images'));
    }

    public function view($id) {
        $subscriptionBasedService = SubscriptionBasedService::findOrFail($id);
        $images = !empty($subscriptionBasedService->subscriptionBasedServiceDetails) ? $subscriptionBasedService->subscriptionBasedServiceDetails->gallery_json : '';
        if (Auth::user()->user_type_id == SBS_USER) {
            return view('backend.subscription_based_service_partner.branch.view', compact('subscriptionBasedService', 'images'));
        }
        return view('backend.subscription_based_service.view', compact('subscriptionBasedService', 'images'));
    }

    public function fetchGalleryImages(Request $request, $id) {
        $subscriptionBasedService = SubscriptionBasedService::findOrFail($id);
        $gallery_images = $subscriptionBasedService->subscriptionBasedServiceDetails->gallery_json;
        $images = [];
        if (!empty($gallery_images)) {
            foreach ($gallery_images as $row) {
                $row = str_replace(getUrl('image/subscription_base_service_gallery'), "", $row);
                $size = @filesize("image/subscription_base_service_gallery/" . $row);
                $images[] = ['name' => $row, 'size' => $size, 'path' => "/image/subscription_base_service_gallery/"];
            }
        }
        return $images;
    }

    public function galleryImagesDelete(Request $request, $id) {
        if (!empty($id)) {
            $subscriptionBasedService = SubscriptionBasedService::findOrFail($id);
            $gallery_images = $subscriptionBasedService->subscriptionBasedServiceDetails->gallery_json;
            $result = [];
            foreach ($gallery_images as $imageName) {
                $result[] = str_replace(getUrl('image/subscription_base_service_gallery/'), "", $imageName);
            }
            $gallery_images = $result;
            $gallery_images = array_filter($gallery_images, fn($m) => $m != $request->name);
            $subscriptionBasedService->subscriptionBasedServiceDetails->gallery_json = json_encode($gallery_images);
            @unlink('image/subscription_base_service_gallery/' . $request->name);
            $subscriptionBasedService->subscriptionBasedServiceDetails->save();
        } else {
            unlink(public_path('/image/temp/') . $request->name);
        }
    }

    public function updateSortOrderGallery(Request $request, $id) {
        $subscriptionBasedService = SubscriptionBasedService::findOrFail($id);
        $subscriptionBasedService->subscriptionBasedServiceDetails->gallery_json = json_encode(array_values($request->order_list));
        $subscriptionBasedService->subscriptionBasedServiceDetails->save();
    }

    public function galleryImages(Request $request, $id) {
        if (!empty($id)) {
            $subscriptionBasedService = SubscriptionBasedService::findOrFail($id);

            $result = [];
            $gallery_images = $subscriptionBasedService->subscriptionBasedServiceDetails->gallery_json;
            if (!empty($request->file) && in_array($request->file->extension(), allow_file_type_uploads)) {
                $image = $request->file('file');
                $imageName = seo_url("healthism  {$subscriptionBasedService->name}") . '.' . $request->file->extension();
                $image_resize = Image::make($image->getRealPath());
                $image_resize->resize(800, null, function ($constraint) {
                    $constraint->aspectRatio();
                });
                $image_resize->save(public_path('image/subscription_base_service_gallery/' . $imageName));
                $gallery_images[] = $imageName;
                foreach ($gallery_images as $imageName) {
                    $result[] = str_replace(getUrl('image/subscription_base_service_gallery/'), "", $imageName);
                }
            }
            echo $imageName;
            $subscriptionBasedService->subscriptionBasedServiceDetails->gallery_json = json_encode(array_values($result));
            $subscriptionBasedService->subscriptionBasedServiceDetails->save();
        } else {
            if (!empty($request->file) && in_array($request->file->extension(), allow_file_type_uploads)) {
                $image = $request->file('file');
                $fileName = pathinfo($request->file->getClientOriginalName(), PATHINFO_FILENAME);
                $imageName = seo_url($fileName) . '.' . $request->file->extension();
                $image_resize = Image::make($image->getRealPath());
                $image_resize->resize(800, null, function ($constraint) {
                    $constraint->aspectRatio();
                });
                $image_resize->save(public_path('/image/temp/' . $imageName));
                echo $imageName;
            }
        }
    }

    public function update(SubscriptionBasedServiceRequest $request, $id) {
        $subscriptionBasedService = SubscriptionBasedService::findOrFail($id);
        $categoryIds = "";
        if (!empty($request->sub_category_ids)) {
            $categoryIds .= implode(',', $request->sub_category_ids);
            $categoryIds = ',' . $categoryIds . ',';
        }
        $amenityIds = "";
        if (!empty($request->amenity_ids)) {
            $amenityIds .= implode(',', $request->amenity_ids);
            $amenityIds = ',' . $amenityIds . ',';
        }
        $subscriptionBasedService->contact_person = $request->contact_person;
        $subscriptionBasedService->user_id = !empty($request->user) ? $request->user_id : null;
        $subscriptionBasedService->parent_id = !empty($request->parent_id) ? $request->parent_id : 0;
        $subscriptionBasedService->name = $request->name;
        $subscriptionBasedService->phone = $request->phone;
        $subscriptionBasedService->email = $request->email;
        $subscriptionBasedService->address1 = $request->address1;
        $subscriptionBasedService->address2 = $request->address2;
        $subscriptionBasedService->area = $request->area;
        $subscriptionBasedService->pincode = $request->pincode;
        $subscriptionBasedService->city_id = $request->city_id;
        $subscriptionBasedService->state_id = $request->state_id;
        $subscriptionBasedService->mobile = $request->mobile;
        $subscriptionBasedService->discount = $request->discount;
        $subscriptionBasedService->category_id = $request->category_id;
        $subscriptionBasedService->gender = $request->gender;
        $subscriptionBasedService->sub_category_ids = $categoryIds;
        $subscriptionBasedService->amenity_ids = $amenityIds;
        $subscriptionBasedService->free_trial = $request->free_trial == 'on' ? 1 : 0;
        $validateLatLong = validateLatLong($request->latitude, $request->longitude);
        $errorMessageLetLong = "";
        if (!empty($validateLatLong)) {
            $subscriptionBasedService->latitude = $request->latitude;
            $subscriptionBasedService->longitude = $request->longitude;
        } else {
            $errorMessageLetLong .= 'longitude and latitude are not valid';
        }
        $subscriptionBasedService->discount = $request->discount;
        $subscriptionBasedService->status_id = !empty($request->status_id) ? $request->status_id : STATUS_ACTIVE;

        /*
         *  details
         */
        $subscriptionBasedService->cash_booking_allowed = $request->cash_booking_allowed == 'on' ? 1 : 0;
        $subscriptionBasedService->cancellation_allowed = $request->cancellation_allowed == 'on' ? 1 : 0;
        if (!empty($request->cancel_policy)) {
            $cancel_policy = [];
            foreach ($request->cancel_policy as $key => $val) {
                if (!empty($val['cancel_policy'])) {
                    $cancel_policy[] = $val['cancel_policy'];
                }
            }
            if (!empty($cancel_policy)) {
                $subscriptionBasedService->cancel_policy = json_encode($cancel_policy);
            }
        } else {
            $subscriptionBasedService->cancel_policy = null;
        }
        if (!empty($request->cancel_policy_setting)) {
            $cancelPolicySetting = [];
            foreach ($request->cancel_policy_setting as $value) {
                if (!empty($value['hours']) && !empty($value['charge'])) {
                    $cancelPolicySetting[] = $value;
                }
            }
            if (!empty($cancelPolicySetting)) {
                $subscriptionBasedService->cancel_policy_setting = json_encode($cancelPolicySetting);
            }
        } else {
            $subscriptionBasedService->cancel_policy_setting = null;
        }
        $subscriptionBasedService->subscriptionBasedServiceDetails->timing_json = !empty($request->slot_data_obj) ? $request->slot_data_obj : null;
        $subscriptionBasedService->subscriptionBasedServiceDetails->description = $request->description;
        $subscriptionBasedService->subscriptionBasedServiceDetails->pancard_number = strtoupper($request->pancard_number);
        $subscriptionBasedService->subscriptionBasedServiceDetails->gst_number = strtoupper($request->gst_number);
        $subscriptionBasedService->subscriptionBasedServiceDetails->bank_account_number = $request->bank_account_number;
        $subscriptionBasedService->subscriptionBasedServiceDetails->bank_account_name = $request->bank_account_name;
        $subscriptionBasedService->subscriptionBasedServiceDetails->bank_name = $request->bank_name;
        $subscriptionBasedService->subscriptionBasedServiceDetails->bank_ifsc_code = strtoupper($request->bank_ifsc_code);
        if (!empty($request->photo) && in_array($request->photo->extension(), allow_file_type_uploads)) {
            $image = $request->file('photo');
            $imageName = seo_url("healthism {$request->name}") . '.' . $request->photo->extension();
            $image_resize = Image::make($image->getRealPath());
            $image_resize->resize(800, null, function ($constraint) {
                $constraint->aspectRatio();
            });
            $image_resize->save(public_path('image/subscription_base_service/' . $imageName));
            $subscriptionBasedService->photo = $imageName;
        }

        if (!empty($request->pancard_document)) {
            $imageName = seo_url("pan healthism {$request->name}") . '.' . $request->pancard_document->extension();
            $imageName = change_filename("image/subscription_base_service/pan", $imageName);

            if ($request->pancard_document->move(public_path('image/subscription_base_service/pan'), $imageName)) {
                if (!empty($subscriptionBasedService->subscriptionBasedServiceDetails->pancard_document)) {
                    @unlink('image/subscription_base_service/pan/' . $subscriptionBasedService->subscriptionBasedServiceDetails->pancard_document);
                }
            }
            $subscriptionBasedService->subscriptionBasedServiceDetails->pancard_document = $imageName;
        }

        if (!empty($request->gst_certificate)) {
            $imageName = seo_url("gst healthism {$request->name}") . '.' . $request->gst_certificate->extension();
            $imageName = change_filename("image/subscription_base_service/gst/", $imageName);

            if ($request->gst_certificate->move(public_path('image/subscription_base_service/gst'), $imageName)) {
                if (!empty($subscriptionBasedService->subscriptionBasedServiceDetails->gst_certificate)) {
                    @unlink('image/subscription_base_service/gst/' . $subscriptionBasedService->subscriptionBasedServiceDetails->gst_certificate);
                }
            }
            $subscriptionBasedService->subscriptionBasedServiceDetails->gst_certificate = $imageName;
        }
        $subscriptionBasedService->subscriptionBasedServiceDetails->save();
        $subscriptionBasedService->save();
        if (!empty($subscriptionBasedService->id)) {
            $this->addSearchData($subscriptionBasedService);
        }
        if (Auth::user()->user_type_id == SBS_USER) {
            if (!empty($errorMessageLetLong)) {
                return redirect()->route('sbs.view', $subscriptionBasedService->id)->with('error', $errorMessageLetLong);
            }
            return redirect()->route('sbs.view', $subscriptionBasedService->id)->with('success', 'Subscription based service details updated successfully!');
        }
        if (!empty($errorMessageLetLong)) {
            return redirect()->route('admin.subscription_based_service.view', $subscriptionBasedService->id)->with('error', $errorMessageLetLong);
        }

        return redirect()->route('admin.subscription_based_service.view', $subscriptionBasedService->id)->with('success', 'Subscription based service details updated successfully!');
    }

    public function store(SubscriptionBasedServiceRequest $request) {
        $subscriptionBasedService = new SubscriptionBasedService;
        $subscriptionBasedServiceDetails = new SubscriptionBasedServiceDetails();
        $gallery_images = [];
        if (!empty($request->images_list)) {
            foreach ($request->images_list as $row) {
                $fileName = explode(".", $row);
                $imageName = seo_url("healthism  $request->name {$fileName[0]}") . "." . $fileName[1];
                $imageName = change_filename("image/subscription_base_service/", $imageName);
                copy(public_path("/image/temp/{$row}"), public_path('image/subscription_base_service_gallery/' . $imageName));
                $gallery_images[] = $imageName;
            }
            $subscriptionBasedServiceDetails->gallery_json = json_encode(array_values($gallery_images));
        }
        $categoryIds = "";
        if (!empty($request->sub_category_ids)) {
            $categoryIds .= implode(',', $request->sub_category_ids);
            $categoryIds = ',' . $categoryIds . ',';
        }
        $amenityIds = "";
        if (!empty($request->amenity_ids)) {
            $amenityIds .= implode(',', $request->amenity_ids);
            $amenityIds = ',' . $amenityIds . ',';
        }
        $subscriptionBasedService->contact_person = $request->contact_person;
        $subscriptionBasedService->user_id = !empty($request->user) ? $request->user_id : null;
        $subscriptionBasedService->parent_id = !empty($request->parent_id) ? $request->parent_id : 0;
        $subscriptionBasedService->name = $request->name;
        $subscriptionBasedService->phone = $request->phone;
        $subscriptionBasedService->mobile = $request->mobile;
        $subscriptionBasedService->email = $request->email;
        $subscriptionBasedService->address1 = $request->address1;
        $subscriptionBasedService->address2 = $request->address2;
        $subscriptionBasedService->area = $request->area;
        $subscriptionBasedService->pincode = $request->pincode;
        $subscriptionBasedService->city_id = $request->city_id;
        $subscriptionBasedService->state_id = $request->state_id;
        $subscriptionBasedService->discount = $request->discount;
        $subscriptionBasedService->category_id = $request->category_id;
        $subscriptionBasedService->gender = $request->gender;
        $subscriptionBasedService->self_facility_available = 0;
        $subscriptionBasedService->sub_category_ids = $categoryIds;
        $subscriptionBasedService->amenity_ids = $amenityIds;
        $subscriptionBasedService->free_trial = $request->free_trial == 'on' ? 1 : 0;
        $subscriptionBasedService->discount = $request->discount;
        $subscriptionBasedService->status_id = STATUS_ACTIVE;
        $validateLatLong = validateLatLong($request->latitude, $request->longitude);
        $errorMessageLetLong = "";
        if (!empty($validateLatLong)) {
            $subscriptionBasedService->latitude = $request->latitude;
            $subscriptionBasedService->longitude = $request->longitude;
        } else {
            $errorMessageLetLong .= 'longitude and latitude are not valid';
        }

        /*
         * details
         */
        $subscriptionBasedService->cash_booking_allowed = $request->cash_booking_allowed == 'on' ? 1 : 0;
        $subscriptionBasedService->cancellation_allowed = $request->cancellation_allowed == 'on' ? 1 : 0;
        if (!empty($request->cancel_policy)) {
            $cancel_policy = [];
            foreach ($request->cancel_policy as $key => $val) {
                if (!empty($val['cancel_policy'])) {
                    $cancel_policy[] = $val['cancel_policy'];
                }
            }
            if (!empty($cancel_policy)) {
                $subscriptionBasedService->cancel_policy = json_encode($cancel_policy);
            }
        }
        if (!empty($request->cancel_policy_setting)) {
            $cancelPolicySetting = [];
            foreach ($request->cancel_policy_setting as $value) {
                if (!empty($value['hours']) && !empty($value['charge'])) {
                    $cancelPolicySetting[] = $value;
                }
            }
            if (!empty($cancelPolicySetting)) {
                $subscriptionBasedService->cancel_policy_setting = json_encode($cancelPolicySetting);
            }
        }
        $subscriptionBasedServiceDetails->timing_json = !empty($request->slot_data_obj) ? $request->slot_data_obj : null;
        $subscriptionBasedServiceDetails->description = $request->description;
        $subscriptionBasedServiceDetails->pancard_number = strtoupper($request->pancard_number);
        $subscriptionBasedServiceDetails->gst_number = strtoupper($request->gst_number);
        $subscriptionBasedServiceDetails->bank_account_number = $request->bank_account_number;
        $subscriptionBasedServiceDetails->bank_account_name = $request->bank_account_name;
        $subscriptionBasedServiceDetails->bank_name = $request->bank_name;
        $subscriptionBasedServiceDetails->bank_ifsc_code = strtoupper($request->bank_ifsc_code);

        if (!empty($request->photo) && in_array($request->photo->extension(), allow_file_type_uploads)) {
            $image = $request->file('photo');
            $imageName = seo_url("healthism {$request->name}") . '.' . $request->photo->extension();
            $image_resize = Image::make($image->getRealPath());
            $image_resize->resize(800, null, function ($constraint) {
                $constraint->aspectRatio();
            });
            $image_resize->save(public_path('image/subscription_base_service/' . $imageName));
            $subscriptionBasedService->photo = $imageName;
        }

        if (!empty($request->pancard_document)) {
            $imageName = seo_url("pan healthism {$request->name}") . '.' . $request->pancard_document->extension();
            $imageName = change_filename("image/subscription_base_service/pan/", $imageName);
            if ($request->pancard_document->move(public_path('image/subscription_base_service/pan'), $imageName)) {
                $subscriptionBasedServiceDetails->pancard_document = $imageName;
            }
        }

        if (!empty($request->gst_certificate)) {
            $imageName = seo_url("gst healthism {$request->name}") . '.' . $request->gst_certificate->extension();
            $imageName = change_filename("image/subscription_base_service/gst/", $imageName);
            if ($request->gst_certificate->move(public_path('image/subscription_base_service/gst'), $imageName)) {
                $subscriptionBasedServiceDetails->gst_certificate = $imageName;
            }
        }

        $subscriptionBasedService->save();
        $subscriptionBasedServiceDetails->subscription_based_service_id = $subscriptionBasedService->id;
        $subscriptionBasedServiceDetails->save();
        if (!empty($subscriptionBasedService->id)) {
            $this->addSearchData($subscriptionBasedService);
        }
        if (Auth::user()->user_type_id == SBS_USER) {
            if (!empty($errorMessageLetLong)) {
                return redirect()->route('sbs.view', $subscriptionBasedService->id)->with('error', $errorMessageLetLong);
            }
            return redirect()->route('sbs.view', $subscriptionBasedService->id)->with('success', 'Subscription based service details added successfully!');
        }
        if (!empty($errorMessageLetLong)) {
            return redirect()->route('admin.subscription_based_service.view', $subscriptionBasedService->id)->with('error', $errorMessageLetLong);
        }

        return redirect()->route('admin.subscription_based_service.view', $subscriptionBasedService->id)->with('success', 'Subscription based service details added successfully!');
    }

    private function addSearchData($data) {
        $searchData = array(
            'subscription_based_service_id' => $data->id,
            'subscription_based_service_parent_id' => $data->id,
            'category_id' => $data->category_id,
            'name' => $data->name,
            'pincode' => $data->pincode,
            'latitude' => $data->latitude,
            'longitude' => $data->longitude,
        );
        if (!empty($searchData)) {
            $where = array(
                'subscription_based_service_id' => $data->id,
                'pincode' => $data->pincode,
                'latitude' => $data->latitude,
                'longitude' => $data->longitude,
            );
            $duplicate = \App\Models\SubscriptionBasedServiceSearch::where($where)->count();
            if ($duplicate > 0) {
                return false;
            } else {
                \App\Models\SubscriptionBasedServiceSearch::insert($searchData);
            }
        }
    }

    public function delete(Request $request) {
        $input = $request->all();
        if (empty($input['subscription_based_service_id'])) {
            return error('Sorry, Id is empty.');
        }
        $subscriptionBasedService = SubscriptionBasedService::findOrFail($input['subscription_based_service_id']);
        if (!empty($subscriptionBasedService)) {
            $booking = \App\Models\SubscriptionBasedServiceBooking::where('subscription_based_service_id', $input['subscription_based_service_id'])->count();
            if ($booking == 0) {
                if (!empty($subscriptionBasedService->photo)) {
                    @unlink('image/subscription_base_service/' . $subscriptionBasedService->photo);
                }
                if (!empty($subscriptionBasedService->subscriptionBasedServiceDetails->gst_certificate)) {
                    @unlink('image/subscription_base_service/gst/' . $subscriptionBasedService->subscriptionBasedServiceDetails->gst_certificate);
                }
                if (!empty($subscriptionBasedService->subscriptionBasedServiceDetails->pancard_document)) {
                    @unlink('image/subscription_base_service/pan/' . $subscriptionBasedService->subscriptionBasedServiceDetails->pancard_document);
                }
                $subscriptionBasedService->delete();
                SubscriptionBasedServiceDetails::where('subscription_based_service_id', $input['subscription_based_service_id'])->delete();
                \App\Models\SubscriptionBasedServiceFacility::where('subscription_based_service_id', $input['subscription_based_service_id'])->delete();
                \App\Models\SubscriptionBasedServiceSearch::where('subscription_based_service_id', $input['subscription_based_service_id'])->delete();
                \App\Models\ReportProblem::where('ref_id', $input['subscription_based_service_id'])->where('service_id', SUBSCRIPTION_BASED_SERVICE)->delete();
                \App\Models\UserReview::where('ref_id', $input['subscription_based_service_id'])->where('service_id', SUBSCRIPTION_BASED_SERVICE)->delete();
            } else {
                return error('Sorry, Subscription based service has too many booking');
            }
        }
        return success(array(), 'Subscription based service has been deleted successfully!');
    }

    public function subscriptionBasedServiceUserSearch(Request $request) {
        $search = $request->get('search');
        $type = $request->get('type');
        $data = \App\Models\User::select(DB::raw("CONCAT(user.first_name,' ',user.last_name,' (', user.email,' - ', user.mobile,')') as label"), "id", DB::raw("CONCAT(user.first_name,' ',user.last_name) as value"))
                        ->where('user_type_id', $type)
                        ->where(function ($data) use ($search) {
                            return $data->where('first_name', 'LIKE', '%' . $search . '%')
                                    ->orwhere('last_name', 'LIKE', '%' . $search . '%')
                                    ->orwhere('mobile', 'LIKE', '%' . $search . '%');
                        })->limit(10)->get();
        if (!empty($data)) {
            foreach ($data as $key => $value) {
                $subscriptionBasedServiceUser = SubscriptionBasedService::where('user_id', $value['id'])->where('status_id', STATUS_ACTIVE)->count();
                if ($subscriptionBasedServiceUser > 0) {
                    unset($data[$key]);
                }
            }
        }
        return response()->json($data);
    }

    public function subscriptionBasedServiceBranch(Request $request) {
        $subscriptionBasedServiceBranch = SubscriptionBasedService::query();
        $records_per_page = 10;
        $parentId = 0;
        if (Auth::user()->user_type_id == SBS_USER) {
            $subscriptionBasedService = SubscriptionBasedService::where('user_id', Auth::user()->id)->first();
            if (!empty($subscriptionBasedService)) {
                $parentId = $subscriptionBasedService->id;
            }
        } else {
            if (!empty($request->subscription_based_service_id)) {
                $parentId = $request->subscription_based_service_id;
            }
        }

        $subscriptionBasedServiceBranch = $subscriptionBasedServiceBranch->where('parent_id', '=', $parentId);
        if (!empty($request->name)) {
            $subscriptionBasedServiceBranch = $subscriptionBasedServiceBranch->where('name', 'like', '%' . $request->name . '%');
        }
        if (!empty($request->phone)) {
            $subscriptionBasedServiceBranch = $subscriptionBasedServiceBranch->where('phone', 'like', '%' . $request->phone . '%');
        }
        if (!empty($request->pincode)) {
            $subscriptionBasedServiceBranch = $subscriptionBasedServiceBranch->where('pincode', 'like', '%' . $request->pincode . '%');
        }
        if (!empty($request->city_id)) {
            $subscriptionBasedServiceBranch = $subscriptionBasedServiceBranch->where('city_id', "=", $request->city_id);
        }
        if (!empty($request->state_id)) {
            $subscriptionBasedServiceBranch = $subscriptionBasedServiceBranch->where('state_id', "=", $request->state_id);
        }

        if (!empty($request->records_per_page) && is_numeric($request->records_per_page)) {
            $records_per_page = $request->records_per_page;
        }

        $subscriptionBasedServiceBranch = $subscriptionBasedServiceBranch->orderBy("id", "DESC");
        $subscriptionBasedServiceBranch = $subscriptionBasedServiceBranch->paginate($records_per_page);
        $states = State::where('active', 1)->get();
        $cities = [];
        $subscriptionBasedService = SubscriptionBasedService::findOrFail($parentId);
        if (!empty($request->state_id)) {
            $cities = City::where(['active' => 1, 'state_id' => $request->state_id])->get();
        }
        if (Auth::user()->user_type_id == ADMIN) {
            if ($request->ajax()) {
                return view('backend.subscription_based_service.branch_content', compact('subscriptionBasedServiceBranch', 'states', 'cities', 'subscriptionBasedService'));
            } else {
                return view('backend.subscription_based_service.branch', compact('subscriptionBasedServiceBranch', 'states', 'cities', 'subscriptionBasedService'));
            }
        }
        if (Auth::user()->user_type_id == SBS_USER) {
            if ($request->ajax()) {
                return view('backend.subscription_based_service_partner.branch.ajax_content', compact('subscriptionBasedServiceBranch', 'states', 'cities', 'subscriptionBasedService'));
            } else {
                return view('backend.subscription_based_service_partner.branch.index', compact('subscriptionBasedServiceBranch', 'states', 'cities', 'subscriptionBasedService'));
            }
        }
    }

    public function slotList(Request $request) {
        $input = $request->all();
        if (empty($input['id'])) {
            return false;
        }
        $order = \App\Models\SubscriptionBasedServiceBooking::findOrFail($input['id']);
        $weekOfdays = array();
        $noOfDay = 15;
        for ($i = 0; $i <= $noOfDay; $i++) {
            $date = date('Y-m-d'); //today date
            $date = date('Y-m-d', strtotime('+' . $i . ' day', strtotime($date)));

            $day = date('D', strtotime($date));
            $date = date('Y-m-d', strtotime($date));
            $checkDateBlock = \App\Models\SubscriptionBasedServiceBlockSlot::where('subscription_based_service_id', $order->subscription_based_service_id)
                    ->where('date', $date)
                    ->whereNull('subscription_based_service_slot_id')
                    ->count();
            if (empty($checkDateBlock)) {
                $slot = $this->getSlotByDay($order, $day, $date);
                $slotCount = count($slot) > 0 ? count($slot) : 0;
                if ($slotCount != 0) {
                    $weekOfdays[] = array(
                        "day" => $day,
                        "date" => $date,
                        "slot_count" => $slotCount,
                        "slot" => $slot,
                    );
                }
            }
        }
        return view('backend.subscription_based_service_partner.orders.slot', compact('order', 'weekOfdays'));
    }

    public function subscriptionBasedServiceList(Request $request) {
        $subscriptionBasedService = SubscriptionBasedService::query();
        if (!empty($request->name)) {
            $subscriptionBasedService->where('name', 'like', '%' . $request->name . '%');
        }
        if (!empty($request->area)) {
            $subscriptionBasedService->where('area', 'like', '%' . $request->area . '%');
        }
        if (!empty($request->pincode)) {
            $subscriptionBasedService->whereRelation('subscription_based_service_search', 'pincode', '=', trim($request->pincode));
            // $subscriptionBasedService->where('pincode', '=', $request->pincode);
        }
        $subscriptionBasedService->where('status_id', '=', STATUS_ACTIVE);
        $subscriptionBasedService->limit(30);
        $result = $subscriptionBasedService->with('city', 'state')->get();
        return success($result, "Subscription based service List");
    }

}
