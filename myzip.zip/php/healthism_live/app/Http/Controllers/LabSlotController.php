<?php

namespace App\Http\Controllers;

use App\Models\LabSlot;
use Illuminate\Http\Request;

class LabSlotController extends Controller {

    public function index(Request $request) {

        if (!empty($request->id)) {
            $lab_data = \App\Models\Lab::findOrFail($request->id);
        }
        if (!empty($lab_data->id)) {
            $slot = LabSlot::query();
            $slot->where('lab_id', $request->id);
            $slot->orderBy('day', 'ASC');
            $slot->orderBy('from_time', 'ASC');
            $slot = $slot->get();
        }
        $slotData = [];
        if (!empty($slot)) {
            foreach ($slot as $key => $value) {
                $fromTime = substr($value['from_time'], 0, -3);
                $slotData[$value['day']][$fromTime] = [
                    'id' => $value['id'],
                    'startTime' => $fromTime,
                    'endTime' => substr($value['to_time'], 0, -3),
                    'isHomeCollection' => $value['is_home_collection'],
                    'offlineAvailable' => $value['is_offline'],
                    'charge' => $value['charge'],
                ];
            }
        }
        $lab_data->slot = empty($slotData) ? '' : json_encode($slotData);
        return view('backend.lab.add_slot', compact('lab_data'));
    }

    public function store(Request $request) {
        $input = $request->all();
        if (empty($input['slot_data_obj'])) {
            return redirect()->route('admin.lab.slot', '')->with('error', 'Slot object is empty');
        }
        if (empty($input['lab_id'])) {
            return redirect()->route('admin.lab.slot', '')->with('error', 'Lab id is empty');
        }
        if (!empty($input['delete_slot_data_obj'])) {
            $deleteSlotArr = json_decode($input['delete_slot_data_obj'], TRUE);
            if (!empty($deleteSlotArr)) {
                LabSlot::whereIn('id', $deleteSlotArr)->delete();
            }
        }
        $slotArr = json_decode($input['slot_data_obj'], TRUE);
        if (!empty($slotArr)) {
            $insertData = [];
            foreach ($slotArr as $key => $day) {
                foreach ($day as $slot) {
                    if (empty($slot['id'])) {
                        $data['day'] = $key;
                        $data['is_home_collection'] = $slot['isHomeCollection'];
                        $data['is_offline'] = $slot['offlineAvailable'];
                        $data['from_time'] = $slot['startTime'];
                        $data['to_time'] = $slot['endTime'];
                        $data['charge'] = $slot['charge'];
                        $data['lab_id'] = $input['lab_id'];
                        $data['status_id'] = STATUS_ACTIVE;
                        $data['created_at'] = date('Y-m-d H:i:s');
                        $data['created_by'] = $request->user()->id;
                        $insertData[] = $data;
                    }
                }
            }
            if (!empty($insertData)) {
                LabSlot::insert($insertData);
            }
        }

        $lab = \App\Models\Lab::where('id', $request->lab_id)->first();
        return redirect()->route('admin.lab.slot', ['id' => $lab->id])->with('success', 'Slot Details Added Successfully!');
    }

}
