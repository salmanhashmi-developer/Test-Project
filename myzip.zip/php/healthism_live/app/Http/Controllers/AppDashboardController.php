<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Helpers\PushNotifications;

class AppDashboardController extends Controller {

    public function sendPush() {
        $param = [];
        $param['device_token'] = "dgvpS-UuRpi0Scdbwyka59:APA91bG_PH59oq8l7FJL_r50B6vC5tzAwp9pLu5CL67XM3UjWm_lFqbVBE2QCcfX-UINeV3RIME_UvdjIkMnyscpWZR6R9H8CNTCWFHqlsghRgf0u4DVCBnL9pdaz_uGR4Oy9Bi4g05s";
        $param['title'] = "Hello Vinay";
        $param['body'] = "If you know rikin is biggest, I think you unedstand";
        //pr($param);
        print_r(PushNotifications::send_push($param));
    }

    public function testLinkPayment() {
        $data = array(
            'amount' => 100, //amount in paisa form
            'currency' => 'INR',
            'accept_partial' => true,
            'first_min_partial_amount' => 100, //amount in paisa form
            'description' => 'healthismplus payment',
            'reference_id' => '9849', //order id or code
            'customer' => array(
                'name' => 'Vinay Rana',
                'email' => 'vinayvirajrana@gmail.com',
                'contact' => '+917600905998'
            ),
            'notify' => array(
                'sms' => true,
                'email' => true
            ),
            'reminder_enable' => true,
            'notes' => array(
                'policy_name' => 'Healthismplus order payment'
            ),
            'callback_url' => env('APP_URL') . '/api/common/test-link-payment-callback',
            'callback_method' => 'get'
        );
        $ch = curl_init();
        $url = 'https://api.razorpay.com/v1/payment_links';
        curl_setopt($ch, CURLOPT_URL, $url);
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
        curl_setopt($ch, CURLOPT_POST, 1);
        curl_setopt($ch, CURLOPT_POSTFIELDS, json_encode($data));
        curl_setopt($ch, CURLOPT_USERPWD, env('RAZORPAY_KEY_ID') . ":" . env('RAZORPAY_SECRET_KEY'));
        curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
        $headers = array();
        $headers[] = 'Content-Type: application/json';
        curl_setopt($ch, CURLOPT_HTTPHEADER, $headers);
        $response = curl_exec($ch);
        curl_close($ch);
        paymentLog($url, json_encode($data), $response);
        return json_decode($response, true);
    }

    public function testLinkPaymentCallback(Request $request) {
        paymentLog("testLinkPaymentCallback", json_encode($request->all()), json_encode($request->all()));
        $linkPaymentResponse = $request->all();
        $ch = curl_init();
        $url = 'https://api.razorpay.com/v1/payment_links/' . $linkPaymentResponse['razorpay_payment_link_id'];
        curl_setopt($ch, CURLOPT_URL, $url);
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
        curl_setopt($ch, CURLOPT_USERPWD, env('RAZORPAY_KEY_ID') . ":" . env('RAZORPAY_SECRET_KEY'));
        curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
        $headers = array();
        $headers[] = 'Content-Type: application/json';
        curl_setopt($ch, CURLOPT_HTTPHEADER, $headers);
        $response = curl_exec($ch);
        curl_close($ch);
        paymentLog($url, json_encode($request->all()), $response);
    }

    public function copyImgesFromOtherFolder() {
        $data = \App\Models\MenuBasedServiceDetails::whereNotNull('gallery_json')->get();
        foreach ($data as $value) {
            if (!empty($value['gallery_json'])) {
                foreach ($value['gallery_json'] as $img) {
                    $s = base_path() . "\/public\/image\/common_service_gallery\/" . $img;
                    $d = base_path() . "\/public\/image\/menu_base_service_gallery\/" . $img;
                    if (file_exists($s)) {
                        \File::copy($s, $d);
                    }
                }
            }
        }
//        $data = \App\Models\MenuBasedService::all();
//        foreach ($data as $value) {
//            if (!empty($value['photo'])) {
//                $s = base_path() . "\/public\/image\/common_service\/" . $value['photo'];
//                $d = base_path() . "\/public\/image\/menu_base_service\/" . $value['photo'];
//                if (file_exists($s)) {
//                    \File::copy($s, $d);
//                }
//            }
//        }
    }

}
