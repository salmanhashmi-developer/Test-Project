<?php

namespace App\Http\Controllers;

use App\Http\Controllers\Controller;
use App\Http\Controllers\Api\OrderPaymentController;
use App\Http\Repository\NotificationRepository;
use App\Models\UserUpload;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Validator;

class LabBookingController extends Controller {

    private $orderPaymentController;
    private $notificationRepository;

    public function __construct(OrderPaymentController $orderPaymentController, NotificationRepository $notificationRepository) {
        $this->orderPaymentController = $orderPaymentController;
        $this->notificationRepository = $notificationRepository;
    }

    public function cancelBookingPage(Request $request) {
        $input = $request->all();
        $reasones = [
            'I am Unavailable',
            'I am busy',
            'I have another appointment'
        ];
        $order = \App\Models\LabBooking::findOrFail($input['id']);
        if ($request->user()->user_type_id == ADMIN) {
            return view('backend.lab_orders.cancel', compact('order', 'reasones'));
        } else {
            return view('backend.lab_partner.orders.cancel', compact('order', 'reasones'));
        }
    }

    public function cancelBooking(Request $request) {
        try {
            $input = $request->all();
            $input['login_user_id'] = $request->user()->id;
            $input['login_user_type'] = $request->user()->user_type_id;
            if (empty($request->appointment_id)) {
                return error("Sorry, Appointment id is empty");
            }
            if (empty($request->reason)) {
                return error("Sorry, Reason is empty");
            }
            $appintmentData = \App\Models\LabBooking::where('id', $input['appointment_id'])->first();
            if ($request->user()->user_type_id != ADMIN) {
                if ($input['login_user_type'] == LAB) {
                    $parentLab = \App\Models\Lab::where('user_id', $input['login_user_id'])->first();
                    if ($appintmentData->lab->user_id != $input['login_user_id']) {
                        if ($appintmentData->lab_parent_id != $parentLab->id) {
                            return error('Sorry, You are not authorized to reschedule this appointment');
                        }
                    }
                } else {
                    if ($appintmentData->lab->user_id != $input['login_user_id']) {
                        return error('Sorry, You are not authorized to reschedule this appointment');
                    }
                }
            }
            $orderDetail = \App\Models\OrderDetail::where('order_id', $appintmentData->order_id)
                            ->where('ref_id', $request->appointment_id)->first();
            if (empty($orderDetail)) {
                return error("Sorry, Order data not found");
            }
            $orderPayment = \App\Models\OrderPayment::where('order_id', $appintmentData->order_id)->first();
            $cancelationData['cancelationCharges'] = $request->user()->user_type_id == END_USER ? $this->cancelationCharges($appintmentData) : 0;
            if (!empty($orderPayment)) {
                if ($orderPayment->status_id == STATUS_DONE && $orderPayment->payment_mode_id == RAZORPAY) {
                    $cancelationData['refundAmount'] = $orderDetail->pg_amount - $cancelationData['cancelationCharges'];
                }
            }
            $cancelationData['reason'] = "Cancel by lab : " . $request->reason;
            $cancelationData['order_id'] = $appintmentData->order_id;
            $cancelationData['order_detail_id'] = $orderDetail->id;
            $cancelationData['ref_id'] = $appintmentData->id;
            $cancelationData['login_user_id'] = $request->user()->id;
            $cancelationData['login_user_type'] = $request->user()->user_type_id;
            $cancelationData['login_user_name'] = $request->user()->first_name . ' ' . $request->user()->last_name;
            $this->orderPaymentController->orderCancel($cancelationData);
            $appintmentData->fill(array('status_id' => STATUS_CANCELLED, 'updated_at' => date('Y-m-d H:i:s'),
                'refund_amount' => !empty($cancelationData['refundAmount']) ? $cancelationData['refundAmount'] : null))->save();
            $remark = "Cancel by lab - reason: " . $request->reason;
            $this->orderPaymentController->saveOrderHistory(['order_id' => $appintmentData->order_id, 'type' => 'TRACKING', 'status_id' => STATUS_CANCELLED, 'remark' => $remark, 'updated_by' => $request->user()->id]);

            $this->notificationRepository->labAppointmentNotification($appintmentData->order_id, 'CANCELLED');

            return success(array(), "Appointment cancelled!");
        } catch (Exception $exc) {
            errorLog($exc);
        }
        return error(COMMON_ERROR);
    }

    public function rescheduleBooking(Request $request) {
        try {
            $input = $request->all();
            $input['login_user_id'] = $request->user()->id;
            $input['login_user_mobile'] = $request->user()->mobile;
            $input['login_user_type'] = $request->user()->user_type_id;
            if (empty($input['appointment_id'])) {
                return error('Sorry, Appointment id is empty');
            }
            if (empty($input['lab_slot_id'])) {
                return error('Sorry, Lab slot id is empty');
            }
            if (empty($input['date'])) {
                return error('Sorry, Date is empty');
            }
            $appintmentData = \App\Models\LabBooking::where('id', $input['appointment_id'])->first();
            $oldDate = date_format(date_create($appintmentData->appointment_date), "d/m/Y") . ' ' . $appintmentData->appointment_time;
            if (empty($appintmentData)) {
                return error('Sorry, Invalid appointment id');
            }
            if ($request->user()->user_type_id != ADMIN) {
                if ($input['login_user_type'] == LAB) {
                    $parentLab = \App\Models\Lab::where('user_id', $input['login_user_id'])->first();
                    if ($appintmentData->lab->user_id != $input['login_user_id']) {
                        if ($appintmentData->lab_parent_id != $parentLab->id) {
                            return error('Sorry, You are not authorized to reschedule this appointment');
                        }
                    }
                } else {
                    if ($appintmentData->lab->user_id != $input['login_user_id']) {
                        return error('Sorry, You are not authorized to reschedule this appointment');
                    }
                }
            }
            if ($appintmentData->status_id != STATUS_SUCCESS) {
                return error('Sorry, Your appointment has not been confirmed. so you cannot reschedule the appointment');
            }
            $dateNow = strtotime(date('Y-m-d H:i:s'));
            $appointmentDateTime = $appintmentData->appointment_date . " " . $appintmentData->appointment_time;
            $appointmentDateTime = strtotime(date('Y-m-d H:i:s', strtotime($appointmentDateTime)));

            if ($dateNow > $appointmentDateTime) {
                return array('code' => 0, 'message' => "Sorry, Reschedule time has been over");
            }

            $slotData = \App\Models\LabSlot::where('id', $input['lab_slot_id'])->first();
            if (empty($slotData)) {
                return error('Sorry, Invalid lab slot id');
            }
            if ($appintmentData->lab_id != $slotData->lab_id) {
                return error("Sorry, Can't select other lab slot.");
            }
            $checkSlotBlocked = \App\Models\LabBlockSlot::where(
                            [
                                'lab_slot_id' => $input['lab_slot_id'],
                                'date' => $input['date']
                    ])->count();
            if ($checkSlotBlocked > 0) {
                return array(0, "Sorry, Slot has been blocked");
            }
            $result = $appintmentData->fill([
                        'lab_slot_id' => $input['lab_slot_id'],
                        'appointment_date' => $input['date'],
                        'appointment_time' => $slotData->from_time,
                    ])->save();

            $remark = "Reschedule appointment by lab : Old  Appointment - " . $oldDate
                    . ' New  Appointment - ' . date_format(date_create($input['date']), "d/m/Y") . ' ' . $slotData->from_time;
            $this->orderPaymentController->saveOrderHistory([
                'order_id' => $appintmentData->order_id,
                'type' => 'TRACKING', 'status_id' => STATUS_SUCCESS,
                'remark' => $remark,
                'updated_by' => $input['login_user_id']
            ]);
            $this->notificationRepository->labAppointmentNotification($appintmentData->order_id, 'RESCHEDULE', ['old_date' => $oldDate]);
            return success($result, "Appointment rescheduled successfully!");
        } catch (Exception $exc) {
            errorLog($exc);
        }
        return error(COMMON_ERROR);
    }

    public function index(Request $request) {
        $result = [];
        $query = UserUpload::query();
        $records_per_page = 5;
        $query->where('service_id', SERVICE_LAB_REPORT);
        if (!empty($request->user_name)) {
            $query->whereRelation('user', 'first_name', 'like', '%' . trim($request->user_name) . '%');
        }
        if (!empty($request->user_mobile)) {
            $query->whereRelation('user', 'mobile', '=', trim($request->user_mobile));
        }
        if (!empty($request->patient_name)) {
            $query->whereRelation('userPatient', 'first_name', 'like', '%' . trim($request->patient_name) . '%');
        }
        if (!empty($request->patient_mobile)) {
            $query->whereRelation('userPatient', 'mobile', '=', trim($request->patient_mobile));
        }
        if (!empty($request->start_date)) {
            $query->whereDate('created_at', '>=', date('Y-m-d', strtotime($request->start_date)));
        }
        if (!empty($request->end_date)) {
            $query->whereDate('created_at', '<=', date('Y-m-d', strtotime($request->end_date)));
        }
        $statusId = !empty($request->status_id) ? $request->status_id : STATUS_ACTIVE;
        if (!empty($statusId) && $statusId != -1) {
            $query->where('status_id', '=', $statusId);
        }
        $query->orderBy("id", "DESC");
        if (!empty($request->records_per_page) && is_numeric($request->records_per_page)) {
            $records_per_page = $request->records_per_page;
        }
        $userUpload = $query->paginate($records_per_page);
        $statusList = [
            array('id' => STATUS_ACTIVE, 'name' => 'Active'),
            array('id' => STATUS_CLOSED, 'name' => 'Closed'),
            array('id' => STATUS_CANCELLED, 'name' => 'Cancelled'),
        ];
        if ($request->ajax()) {
            return view('backend.lab_booking.ajax_content', compact('userUpload', 'statusList', 'statusId'));
        } else {
            return view('backend.lab_booking.index', compact('userUpload', 'statusList', 'statusId'));
        }
    }

    public function view(Request $request) {
        $uploadFiles = UserUpload::findOrFail($request->id);
        $user = $uploadFiles->user;
        $userPatient = $uploadFiles->userPatient;
        $userSubsciption = getUserSubscription($uploadFiles->user_id);
        $states = \App\Models\State::where('active', 1)->get();
        $address = \App\Models\UserAddress::where('user_id', $uploadFiles->user_id)->get();
        $patient = \App\Models\UserPatientMapping::where('user_id', $uploadFiles->user_id)
                ->where('is_deleted', 0)
                ->where('status_id', STATUS_ACTIVE)
                ->get();
        return view('backend.lab_booking.view', compact('uploadFiles', 'userSubsciption', 'address', 'patient', 'user', 'userPatient', 'states'));
    }

    public function directCall(Request $request) {
        $input = $request->all();
        $data = [];
        $errorMsg = "";
        $directCall = 1;
        $states = \App\Models\State::where('active', 1)->get();
        $data = compact('directCall', 'states');
        if (!empty($input)) {
            if (empty($input['user_id']) && empty($input['card_no'])) {

            } else {
                if (!empty($input['user_id'])) {
                    $userId = $input['user_id'];
                    $userSubsciption = getUserSubscription($userId);
                    $user = \App\Models\User::findOrFail($userId);
                } else {
                    $userSubsciption = \App\Models\UserSubscription::where('card_no', $input['card_no'])->first();
                    if (!empty($userSubsciption)) {
                        $userId = $userSubsciption->user_id;
                        $user = \App\Models\User::findOrFail($userId);
                    } else {
                        $errorMsg = "Sorry, Invalid card no.";
                    }
                }
                if (!empty($userId)) {
                    $address = \App\Models\UserAddress::where('user_id', $userId)->get();
                    $patient = \App\Models\UserPatientMapping::where('user_id', $userId)
                            ->where('is_deleted', 0)
                            ->where('status_id', STATUS_ACTIVE)
                            ->get();
                    $data = compact('userSubsciption', 'address', 'patient', 'user', 'directCall', 'errorMsg', 'states');
                }
            }
        }
        return view('backend.lab_booking.view', $data);
    }

    public function userDetail(Request $request) {
        $query = "SELECT
                        u.*,
                        us.id AS user_subscription_id,
                        us.card_no,
                        us.expiry_date,
                        us.status_id AS user_subscription_status_id,
                        s.`name` as subscription_name,
                        s.member,
                        s.validity_in_days
                 FROM
                        `user` AS u
                        LEFT JOIN user_subscription AS us ON (u.id = us.user_id AND us.status_id=" . STATUS_ACTIVE . ")
                        LEFT JOIN subscription AS s ON us.subscription_id=s.id
                        WHERE ";
        if (!empty($request->user_id)) {
            $query .= " us.user_id = " . $request->user_id;
        } else {
            if (empty($request->card_no)) {
                return error("Sorry, User id and card no both are empty");
            }
            $query .= " us.card_no = " . $request->card_no;
        }
        $result = executeSelectQueryOnMySQLDB($query);
        if (empty(count($result))) {
            return error("Sorry, User not found");
        }
        $result = $result[0];
        if ($result['status_id'] != STATUS_ACTIVE) {
            return error("Sorry, User is inactive/blocked");
        }
        $expiryDate = date('Y-m-d', strtotime($result['expiry_date']));
        if (date('Y-m-d') > $expiryDate) {
            $result['plan_expire'] = 1;
            //return null;
            return error("Sorry, User's plan is expired", $result);
        }
        return success($result, "User detail");
    }

}