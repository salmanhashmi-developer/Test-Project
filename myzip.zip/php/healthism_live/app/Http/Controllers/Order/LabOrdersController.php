<?php

namespace App\Http\Controllers\Order;

use App\Http\Controllers\Controller;
use App\Helpers\Helpers;
use App\Models\LabBooking;
use App\Models\Orders;
use App\Models\OrderDetail;
use App\Models\OrderPayment;
use App\Models\OrderHistories;
use App\Models\Service;
use App\Models\Subscription;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;

class LabOrdersController extends Controller {

    public function index(Request $request) {
        $logInUserType = $request->user()->user_type_id;
        $orders = LabBooking::query();
        $records_per_page = 5;
        if (!empty($request->patient_name)) {
            $orders->where('patient_name', 'like', '%' . $request->patient_name . '%');
        }
        if (!empty($request->order_code)) {
            $orders->whereRelation('order', 'order_code', '=', trim($request->order_code));
        }
        if (!empty($request->lab_name)) {
            $orders->whereRelation('lab', 'name', 'like', '%' . $request->lab_name . '%');
        }
        if (!empty($request->status_id) && is_numeric($request->status_id)) {
            $orders->whereRelation('order', 'status_id', '=', trim($request->status_id));
        }
        if (!empty($request->payment_status_id)) {
            $orders->whereRelation('order.payment', 'status_id', '=', $request->payment_status_id);
        }
        if (!empty($request->user_id) && is_numeric($request->user_id)) {
            $orders->where('user_id', '=', trim($request->user_id));
        }
        if (!empty($request->start_date)) {
            $orders->whereDate('created_at', '>=', date('Y-m-d', strtotime($request->start_date)));
        }
        if (!empty($request->end_date)) {
            $orders->whereDate('created_at', '<=', date('Y-m-d', strtotime($request->end_date)));
        }
        if ($logInUserType == LAB) {
            $lab = \App\Models\Lab::where('user_id', $request->user()->id)->first();
            if (!empty($request->branch_name)) {
                $orders->whereRelation('lab', 'parent_id', '=', $lab->id)
                        ->orWhereRelation('lab', 'name', 'like', '%' . $request->branch_name . '%');
            } else {
                if ($request->report_for == 1) {//SELF
                    $orders->where('lab_id', '=', $lab->id);
                }
                if ($request->report_for == 2) {//Branch
                    $orders->where('lab_parent_id', '=', $lab->id);
                }
                if (empty($request->report_for)) {//All
                    $id = $lab->id;
                    $orders->where(function ($orders) use ($id) {
                        $orders->where('lab_id', '=', $id)
                                ->orWhere('lab_parent_id', '=', $id);
                    });
                    // $orders->where('lab_id', '=', $lab->id)->orWhere('lab_parent_id', '=', $lab->id);
                }
            }
        }
        if ($logInUserType == LAB_BRANCH) {
            $lab = \App\Models\Lab::where('user_id', $request->user()->id)->first();
            $orders->where('lab_id', '=', $lab->id);
        }
        if (!empty($request->records_per_page) && is_numeric($request->records_per_page)) {
            $records_per_page = $request->records_per_page;
        }
        $orders->orderBy("id", 'DESC');
        $orders = $orders->paginate($records_per_page);
        $statusList = array(
            ['id' => 6, 'name' => 'PENDING'],
            ['id' => 9, 'name' => 'FAILED'],
            ['id' => 20, 'name' => 'DONE'],
            ['id' => 18, 'name' => 'SENT ON PG'],
            ['id' => 19, 'name' => 'RETURN FROM PG'],
            ['id' => 23, 'name' => 'PARTIAL REFUNDED'],
            ['id' => 24, 'name' => 'FULLY REFUNDED'],
            ['id' => 25, 'name' => 'REFUNDED INPROGRESS'],
            ['id' => 21, 'name' => 'PARTIAL CANCELLED'],
            ['id' => 22, 'name' => 'FULLY CANCELLED'],
        );
        $paymentStatusList = array(
            ['id' => 6, 'name' => 'PENDING'],
            ['id' => 9, 'name' => 'FAILED'],
            ['id' => 20, 'name' => 'DONE']
        );
        $reportFor = array(
            ['id' => 1, 'name' => 'SELF'],
            ['id' => 2, 'name' => 'BRANCH'],
        );
        $formValues = compact('orders', 'statusList', 'paymentStatusList', 'reportFor', 'logInUserType');
        if ($request->user()->user_type_id == LAB || $request->user()->user_type_id == LAB_BRANCH) {
            if ($request->ajax()) {
                return view('backend.lab_partner.orders.ajax_content', $formValues);
            } else {
                return view('backend.lab_partner.orders.index', $formValues);
            }
        } else {
            if ($request->ajax()) {
                return view('backend.lab_orders.ajax_content', $formValues);
            } else {
                return view('backend.lab_orders.index', $formValues);
            }
        }
    }

    public function view(Request $request, $id) {
        $order = LabBooking::findOrFail($id);
        if (!empty($order->detail)) {
            foreach ($order->detail as $key => $orderDetail) {
                $order->detail[$key]['status_list'] = getUpdateStatusList($orderDetail->status_id);
            }
        }
        if ($request->user()->user_type_id == LAB || $request->user()->user_type_id == LAB_BRANCH) {
            return view('backend.lab_partner.orders.view', compact('order'));
        } else {
            return view('backend.lab_orders.view', compact('order'));
        }
    }

    public function paymentCollected(Request $request) {
        if (empty($request->booking_id)) {
            return error('Sorry, Booking id is empty');
        }
        $booking = LabBooking::findOrFail($request->booking_id);
        if (empty($booking)) {
            return error('Sorry, Booking data not found');
        }
        $booking->status_id = STATUS_SUCCESS;
        $booking->save();
        OrderPayment::where('order_id', $booking->order_id)->update(['status_id' => STATUS_DONE, 'updated_at' => date('Y-m-d H:i:s')]);
        $this->saveOrderHistory(['order_id' => $booking->order_id, 'type' => 'ORDER', 'status_id' => STATUS_DONE, 'remark' => "PAYMENT COLLECTED BY LAB.(" . $request->user()->first_name . " " . $request->user()->first_last . '-' . $request->user()->mobile . ")", 'updated_by' => $request->user()->id]);
        $this->saveOrderHistory(['order_id' => $booking->order_id, 'type' => 'PAYMENT', 'status_id' => STATUS_DONE, 'remark' => "PAYMENT COLLECTED BY LAB.", 'updated_by' => $request->user()->id]);
        return success($booking, "Thank you!");
    }

    public function saveOrderHistory($input) {
        $input['created_at'] = date('Y-m-d H:i:s');
        $input['remark'] = !empty($input['remark']) ? substr($input['remark'], 0, 240) : null;
        $result = OrderHistories::create($input);
        return $result;
    }

}