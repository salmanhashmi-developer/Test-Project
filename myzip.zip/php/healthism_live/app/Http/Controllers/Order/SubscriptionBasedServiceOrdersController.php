<?php

namespace App\Http\Controllers\Order;

use App\Http\Controllers\Controller;
use App\Helpers\Helpers;
use App\Models\SubscriptionBasedServiceBooking;
use App\Models\Orders;
use App\Models\OrderDetail;
use App\Models\OrderPayment;
use App\Models\OrderHistories;
use App\Models\Service;
use App\Models\Subscription;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;

class SubscriptionBasedServiceOrdersController extends Controller {

    public function index(Request $request) {
        $logInUserType = $request->user()->user_type_id;
        $orders = SubscriptionBasedServiceBooking::query();
        $records_per_page = 5;
        if (!empty($request->patient_name)) {
            $orders->where('patient_name', 'like', '%' . $request->patient_name . '%');
        }
        if (!empty($request->order_code)) {
            $orders->whereRelation('order', 'order_code', '=', trim($request->order_code));
        }
        if (!empty($request->subscription_based_service_name)) {
            $orders->whereRelation('subscriptionBasedService', 'name', 'like', '%' . $request->subscription_based_service_name . '%');
        }
        if (!empty($request->status_id) && is_numeric($request->status_id)) {
            $orders->whereRelation('order', 'status_id', '=', trim($request->status_id));
        }
        if (!empty($request->payment_status_id)) {
            $orders->whereRelation('order.payment', 'status_id', '=', $request->payment_status_id);
        }
        if (!empty($request->user_id) && is_numeric($request->user_id)) {
            $orders->where('user_id', '=', trim($request->user_id));
        }
        if (!empty($request->start_date)) {
            $orders->whereDate('created_at', '>=', date('Y-m-d', strtotime($request->start_date)));
        }
        if (!empty($request->end_date)) {
            $orders->whereDate('created_at', '<=', date('Y-m-d', strtotime($request->end_date)));
        }
        if ($logInUserType == SBS_USER) {
            $subscriptionBasedService = \App\Models\SubscriptionBasedService::where('user_id', $request->user()->id)->first();
            if (!empty($request->branch_name)) {
                $orders->whereRelation('subscriptionBasedService', 'parent_id', '=', $subscriptionBasedService->id)
                        ->orWhereRelation('subscriptionBasedService', 'name', 'like', '%' . $request->branch_name . '%');
            } else {
                if ($request->report_for == 1) {//SELF
                    $orders->where('subscription_based_service_id', '=', $subscriptionBasedService->id);
                }
                if ($request->report_for == 2) {//Branch
                    $orders->where('subscription_based_service_parent_id', '=', $subscriptionBasedService->id);
                }
                if (empty($request->report_for)) {//All
                    $id = $subscriptionBasedService->id;
                    $orders->where(function ($orders) use ($id) {
                        $orders->where('subscription_based_service_id', '=', $id)
                                ->orWhere('subscription_based_service_parent_id', '=', $id);
                    });
                }
            }
        }
        if ($logInUserType == SBS_BRANCH_USER) {
            $subscriptionBasedService = \App\Models\SubscriptionBasedService::where('user_id', $request->user()->id)->first();
            $orders->where('subscription_based_service_id', '=', $subscriptionBasedService->id);
        }
        if (!empty($request->records_per_page) && is_numeric($request->records_per_page)) {
            $records_per_page = $request->records_per_page;
        }
        $orders->orderBy("id", 'DESC');
        // pr($orders->toSql());
        $orders = $orders->paginate($records_per_page);
        $statusList = array(
            ['id' => 6, 'name' => 'PENDING'],
            ['id' => 9, 'name' => 'FAILED'],
            ['id' => 20, 'name' => 'DONE'],
            ['id' => 18, 'name' => 'SENT ON PG'],
            ['id' => 19, 'name' => 'RETURN FROM PG'],
            ['id' => 23, 'name' => 'PARTIAL REFUNDED'],
            ['id' => 24, 'name' => 'FULLY REFUNDED'],
            ['id' => 25, 'name' => 'REFUNDED INPROGRESS'],
            ['id' => 21, 'name' => 'PARTIAL CANCELLED'],
            ['id' => 22, 'name' => 'FULLY CANCELLED'],
        );
        $paymentStatusList = array(
            ['id' => 6, 'name' => 'PENDING'],
            ['id' => 9, 'name' => 'FAILED'],
            ['id' => 20, 'name' => 'DONE']
        );
        $reportFor = array(
            ['id' => 1, 'name' => 'SELF'],
            ['id' => 2, 'name' => 'BRANCH'],
        );
        $formValues = compact('orders', 'statusList', 'paymentStatusList', 'reportFor', 'logInUserType');
        if ($request->user()->user_type_id == SBS_USER || $request->user()->user_type_id == SBS_BRANCH_USER) {
            if ($request->ajax()) {
                return view('backend.subscription_based_service_partner.orders.ajax_content', $formValues);
            } else {
                return view('backend.subscription_based_service_partner.orders.index', $formValues);
            }
        } else {
            if ($request->ajax()) {
                return view('backend.subscription_based_service.orders.ajax_content', $formValues);
            } else {
                return view('backend.subscription_based_service.orders.index', $formValues);
            }
        }
    }

    public function view(Request $request, $id) {
        $order = SubscriptionBasedServiceBooking::findOrFail($id);
        if (!empty($order->detail)) {
            foreach ($order->detail as $key => $orderDetail) {
                $order->detail[$key]['status_list'] = getUpdateStatusList($orderDetail->status_id);
            }
        }
        if ($request->user()->user_type_id == SBS_USER || $request->user()->user_type_id == SBS_BRANCH_USER) {
            return view('backend.subscription_based_service_partner.orders.view', compact('order'));
        } else {
            return view('backend.subscription_based_service.orders.view', compact('order'));
        }
    }

    public function paymentCollected(Request $request) {
        if (empty($request->booking_id)) {
            return error('Sorry, Booking id is empty');
        }
        $booking = SubscriptionBasedServiceBooking::findOrFail($request->booking_id);
        if (empty($booking)) {
            return error('Sorry, Booking data not found');
        }
        $booking->status_id = STATUS_SUCCESS;
        $booking->save();
        OrderPayment::where('order_id', $booking->order_id)->update(['status_id' => STATUS_DONE, 'updated_at' => date('Y-m-d H:i:s')]);
        $this->saveOrderHistory(['order_id' => $booking->order_id, 'type' => 'ORDER', 'status_id' => STATUS_DONE, 'remark' => "PAYMENT COLLECTED BY SERVICE PROVIDER.(" . $request->user()->first_name . " " . $request->user()->last_name . '-' . $request->user()->mobile . ")", 'updated_by' => $request->user()->id]);
        $this->saveOrderHistory(['order_id' => $booking->order_id, 'type' => 'PAYMENT', 'status_id' => STATUS_DONE, 'remark' => "PAYMENT COLLECTED BY SERVICE PROVIDER.", 'updated_by' => $request->user()->id]);
        return success($booking, "Thank you!");
    }

    public function saveOrderHistory($input) {
        $input['created_at'] = date('Y-m-d H:i:s');
        $input['remark'] = !empty($input['remark']) ? substr($input['remark'], 0, 240) : null;
        $result = OrderHistories::create($input);
        return $result;
    }

}
