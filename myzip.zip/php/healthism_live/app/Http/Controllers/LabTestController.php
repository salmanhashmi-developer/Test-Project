<?php

namespace App\Http\Controllers;

use App\Helpers\Helpers;
use App\Http\Requests\LabTestRequest;
use App\Models\LabTest;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Auth;
use function Psr\Log\debug;

class LabTestController extends Controller {

    public function index(Request $request) {
        $tests = LabTest::query();
        $records_per_page = 10;
        $lab = "";
        if (!empty($request->name)) {
            $tests = $tests->where('name', 'like', '%' . $request->name . '%');
        }
        if (!empty($request->lab_id)) {
            $lab = \App\Models\Lab::findOrFail($request->lab_id);
            $tests = $tests->where('lab_id', '=', $request->lab_id);
        } else {
            if (Auth::user()->user_type_id == LAB) {
                $lab = \App\Models\Lab::where('user_id', $request->user()->id)->first();
                $tests = $tests->where('lab_id', '=', $lab->id);
            }
        }
        if ($request->type != '') {
            $tests = $tests->where('is_package', '=', $request->type);
        }
        if (!empty($request->status_id)) {
            $tests = $tests->where('status_id', '=', $request->status_id);
        }
        if (!empty($request->lab_name)) {
            $tests = $tests->whereRelation('lab', 'name', 'like', '%' . trim($request->lab_name) . '%');
        }
        if (!empty($request->records_per_page) && is_numeric($request->records_per_page)) {
            $records_per_page = $request->records_per_page;
        }
        $tests = $tests->orderBy("id", "DESC");
        $tests = $tests->paginate($records_per_page);
        if (Auth::user()->user_type_id == LAB) {
            if ($request->ajax()) {
                return view('backend.lab_partner.lab_test.ajax_content', compact('tests', 'lab'));
            } else {
                return view('backend.lab_partner.lab_test.index', compact('tests', 'lab'));
            }
        }
        if ($request->ajax()) {
            return view('backend.lab_test.ajax_content', compact('tests', 'lab'));
        } else {
            return view('backend.lab_test.index', compact('tests', 'lab'));
        }
    }

    public function add(Request $request) {
        $lab = "";
        if (!empty($request->lab_id)) {
            $lab = \App\Models\Lab::findOrFail($request->lab_id);
        }
        if (Auth::user()->user_type_id == LAB) {
            return view('backend.lab_partner.lab_test.add', compact('lab'));
        }
        return view('backend.lab_test.add', compact('lab'));
    }

    public function edit(Request $request, $id) {
        $test = LabTest::findOrFail($id);
        $test->test_desc_json = !empty($test->test_json) ? json_encode($test->test_json) : '';
        $flag = $request->flag;
        if (Auth::user()->user_type_id == LAB) {
            return view('backend.lab_partner.lab_test.edit', compact('test', 'flag'));
        }
        return view('backend.lab_test.edit', compact('test', 'flag'));
    }

    public function view(Request $request, $id) {
        $test = LabTest::findOrFail($id);
        $flag = $request->flag;
        if (Auth::user()->user_type_id == LAB) {
            return view('backend.lab_partner.lab_test.view', compact('test', 'flag'));
        }
        return view('backend.lab_test.view', compact('test', 'flag'));
    }

    public function update(LabTestRequest $request, $id) {
        $input = $request->all();
        $test = LabTest::findOrFail($id);
        $test->name = $request->name;
        $test->test_count = $request->test_count;
        $test->test_json = !empty($request->test_desc_json && $request->test_desc_json != 'null') ? $request->test_desc_json : null;
        $test->description = $request->description;
        $test->requirement = $request->requirement;
        $test->preparation = $request->preparation;
        $test->gender = !empty($request->gender) ? implode(",", $request->gender) : null;
        $test->is_package = $request->is_package == 'on' ? 1 : 0;
        $test->package_category = $request->package_category;
        $test->status_id = $request->status_id;
        $test->price = $request->price;
        $test->discount = $request->discount;
        $test->e_report_hours = $request->e_report_hours;
        $test->home_collection = $request->home_collection == 'on' ? 1 : 0;
        $test->lab_id = $request->lab_id;
        $test->lab_parent_id = $request->lab_parent_id;
        $test->alias_name = $request->alias_name;
        $test->body_part = $request->body_part;
        $test->disease_name = $request->disease_name;
        $test->save();
        if (Auth::user()->user_type_id == LAB) {
            return redirect()->route('lab.test.view', [$test->id, 'flag' => $request->flag])->with('success', 'Lab Test Master Details Updated Successfully!');
        }
        return redirect()->route('admin.lab.test.view', [$test->id, 'flag' => $request->flag])->with('success', 'Lab Test Master Details Updated Successfully!');
    }

    public function store(LabTestRequest $request) {
        $test = new LabTest;
        $test->name = $request->name;
        $test->test_count = $request->test_count;
        $test->test_json = !empty($request->test_desc_json && $request->test_desc_json != 'null') ? $request->test_desc_json : null;
        $test->description = $request->description;
        $test->requirement = $request->requirement;
        $test->preparation = $request->preparation;
        $test->gender = !empty($request->gender) ? implode(",", $request->gender) : null;
        $test->is_package = $request->is_package == 'on' ? 1 : 0;
        $test->package_category = $request->package_category;
        $test->status_id = $request->status_id;
        $test->price = $request->price;
        $test->discount = $request->discount;
        $test->e_report_hours = $request->e_report_hours;
        $test->home_collection = $request->home_collection == 'on' ? 1 : 0;
        $test->lab_id = $request->lab_id;
        $test->lab_parent_id = $request->lab_parent_id;
        $test->alias_name = $request->alias_name;
        $test->body_part = $request->body_part;
        $test->disease_name = $request->disease_name;
        $test->save();
        if (!empty($test->id)) {
            $this->updateLabSelfTestAvailable($test->lab_id);
        }
        if (Auth::user()->user_type_id == LAB) {
            return redirect()->route('lab.test.view', [$test->id, 'flag' => $request->flag])->with('success', 'Lab Test Master Details Added Successfully!');
        }
        return redirect()->route('admin.lab.test.view', [$test->id, 'flag' => $request->flag])->with('success', 'Lab Test Master Details Added Successfully!');
    }

    public function delete(Request $request) {
        $input = $request->all();
        if (empty($input['test_id'])) {
            return error('Sorry, Id is empty.');
        }
        $test = LabTest::findOrFail($input['test_id']);
        $test->delete();
        $this->updateLabSelfTestAvailable($test->lab_id);
        return success(array(), 'Test has been deleted successfully!');
    }

    public function updateLabSelfTestAvailable($labId) {
        $lab = \App\Models\Lab::findOrFail($labId);
        $testCount = count($lab->lab_tests);
        $lab->self_test_available = $testCount > 0 ? 1 : 0;
        $lab->save();
    }

    public function labTestList(Request $request) {
        $input = $request->all();
        if (empty($input['lab_id'])) {
            return error("Sorry, lab id is empty");
        }
        $lab = \App\Models\Lab::where('id',$input['lab_id'])->with('city','state')->first();
        if (empty($lab)) {
            return error("Sorry, Test not found.");
        }
        if ($lab->status_id != STATUS_ACTIVE) {
            return error("Sorry, Lab is blocked.");
        }
        $input['self_test_available'] = $lab->self_test_available;
        $input['lab_id'] = $lab->id;
        $input['parent_id'] = $lab->parent_id;
        $input['type'] = isset($input['type']) ? $input['type'] : 'TEST';
        $result = [];
        $page = !empty($input['page']) ? $input['page'] : 1;
        $skip = $page > 1 ? ($page * 25) - 25 : 0;
        if (!empty($input['lab_id']) && !empty($input['self_test_available'])) {
            $query = LabTest::where('lab_id', $input['lab_id']);
        } else {
            $query = LabTest::where('lab_id', $input['parent_id']);
        }
        $query->where('status_id', STATUS_ACTIVE);
        if ($input['type'] == 'PACKAGE') {
            $query->where('is_package', 1);
        } else {
            $query->where('is_package', 0);
        }
        if (!empty($input['name'])) {
            $name = $input['name'];
            $query->where('name', 'like', '%' . $name . '%');
        }
        $result['total_records'] = $query->count();
        $query->limit(25);
        if (isset($input['offset'])) {
            $query->offset($input['offset']);
        }
        $result['records'] = $query->get();
        $result['lab'] = $lab;
        return success($result, 'Lab test list');
    }

}
