<?php

/* ...........STATUS........... */
define('STATUS_ACTIVE', 1);
define('STATUS_INACTIVE', 2);
define('STATUS_OPEN', 3);
define('STATUS_INPROGRESS', 4);
define('STATUS_CLOSED', 5);
define('STATUS_PENDING', 6);
define('STATUS_APPROVED', 7);
define('STATUS_SUCCESS', 8);
define('STATUS_FAILED', 9);
define('STATUS_CANCELLED', 10);
define('STATUS_PAYMENT_PENDING', 13);
define('STATUS_PAYMENT_INPROCESS', 14);
define('STATUS_PAYMENT_RECEIVED', 15);
define('STATUS_PAYMENT_FAILED', 16);
define('STATUS_EXPIRE', 17);
define('STATUS_SENT_ON_PG', 18);
define('STATUS_RETURN_FROM_PG', 19);
define('STATUS_DONE', 20);
define('STATUS_PARTIAL_CANCELLED', 21);
define('STATUS_FULLY_CANCELLED', 22);
define('STATUS_PARTIAL_REFUNDED', 23);
define('STATUS_FULLY_REFUNDED', 24);
define('STATUS_REFUNDED_INPROGRESS', 25);
define('STATUS_BLOCK', 26);
define('STATUS_USED', 27);

/* ...........SMS........... */
define('SMS_LOGIN_OTP', 1);
define('OTP_TIME_INTERVEL', 5);
define('APP_UNIQUE_ID', 'E+SFJPxxtTr');

/* ...........SERVICE........... */
define('SERVICE_DOCTOR_APPOINTMENT', 1);
define('SERVICE_LAB_REPORT', 2);
define('SERVICE_SUBSCRIPTION_PLAN', 3);
define('SERVICE_COMMON', 4);
define('MENU_BASED_SERVICE', 5);
define('SUBSCRIPTION_BASED_SERVICE', 6);
define('SERVICE_MEDICINE', 7);

/* ...........PLATFORM ........... */
define('ANDROID', 1);
define('IOS', 2);
define('WEB', 3);
/* ...........USER TYPE........... */
define('ADMIN', 1);
define('DOCTOR', 2);
define('END_USER', 3);
define('LAB', 4);
define('LAB_BRANCH', 5);
define('MBS_USER', 6);
define('MBS_BRANCH_USER', 7);
define('SBS_USER', 8);
define('SBS_BRANCH_USER', 9);
define('CORPORATE_USER', 10);
define('PHARMACY_USER', 11);

/* ...........APP TYPE........... */
define('END_USER_APP', 1);
define('MERCHANT_APP', 2);

define('END_USER_APP_USER_TYPE', [END_USER]);
define('MERCHANT_APP_USER_TYPE', [DOCTOR]);

/* ...........PACKAGE CATEGORY TYPE........... */
define('FEVER', 1);
define('DIABETES', 2);
define('FITNESS', 3);
define('COVID', 4);

/* ...........QUERY........... */
define('LIMIT', 10);
define('COMMON_SERVICE_DISTANCE', 60000);
define('LAB_DISTANCE', 60000);
define('MENU_BASED_SERVICE_DISTANCE', 60000);
define('SUBSCRIPTION_BASED_SERVICE_DISTANCE', 60000);
define('HOSPITAL_DISTANCE', 1000000);

/* ...........CATEGORY........... */
define('CATEGORY_DOCTOR', 3);

/* ............BOOKING............. */
define('BOOKING_CHARGES', 50);
define('BOOKING_RESCHEDULE_TIME', 2); //HOUR
define('CANCEL_POLICY_SETTING', array(
    array('hours' => 1, 'charge' => 100),
    array('hours' => 3, 'charge' => 50),
));
define('LAB_CANCEL_POLICY_SETTING', array(
    array('hours' => 1, 'charge' => 100),
    array('hours' => 3, 'charge' => 50),
));
define('MENU_BASED_SERVICE_CANCEL_POLICY_SETTING', array(
    array('hours' => 1, 'charge' => 100),
    array('hours' => 3, 'charge' => 50),
));
define('SUBSCRIPTION_BASED_SERVICE_CANCEL_POLICY_SETTING', array(
    array('hours' => 1, 'charge' => 100),
    array('hours' => 3, 'charge' => 50),
));
define('allow_file_type_uploads', ['png', 'jpg', 'jpeg', 'gif']);
define('hospital_status', [1 => 'Active', 2 => 'In Active', 7 => 'Approved']);
define('COMMON_STATUS', [1 => 'Active', 2 => 'Inactive']);
define('GENDER', ['Male', 'Female', 'Unisex']);
define('doctor_status', [1 => 'Active', 2 => 'In Active', 7 => 'Approved']);
define('HOSPITAL_CANCEL_POLICY', array('No Cancellation Charges will be deducted since appointment time is more than 3 hours away.',
    '50% of the booking amount will be deducted since you are cancelling within 1 -3 hours of your scheduled appointment.',
    'Your entire amount will be deducted since you are cancelling 1 hour before your scheduled appointment time.')
);
define('LAB_CANCEL_POLICY', array('No Cancellation Charges will be deducted since appointment time is more than 3 hours away.',
    '50% of the booking amount will be deducted since you are cancelling within 1 -3 hours of your scheduled appointment.',
    'Your entire amount will be deducted since you are cancelling 1 hour before your scheduled appointment time.')
);
define('MENU_BASED_SERVICE_CANCEL_POLICY', array('No Cancellation Charges will be deducted since appointment time is more than 3 hours away.',
    '50% of the booking amount will be deducted since you are cancelling within 1 -3 hours of your scheduled appointment.',
    'Your entire amount will be deducted since you are cancelling 1 hour before your scheduled appointment time.')
);
define('SUBSCRIPTION_BASED_SERVICE_CANCEL_POLICY', array('No Cancellation Charges will be deducted since appointment time is more than 3 hours away.',
    '50% of the booking amount will be deducted since you are cancelling within 1 -3 hours of your scheduled appointment.',
    'Your entire amount will be deducted since you are cancelling 1 hour before your scheduled appointment time.')
);

/* ...........REDIS........... */
define('KEY_LOGIN_OTP', "LOGIN_OTP");
define('KEY_UPDATE_MOBILE_OTP', "UPDATE_MOBILE_OTP");
define('KEY_UPDATE_EMAIL_OTP', "UPDATE_EMAIL_OTP");
define('KEY_STATUS', "STATUS");
define('KEY_PLATFORM', "PLATFORM");
define('KEY_SERVICE', "SERVICE");
define('KEY_PAYMENT_MODE', "PAYMENT_MODE");
define('KEY_APPLICATION_CONSTANT', "APPLICATION_CONSTANT");
define('KEY_ORDER_REF_ID', "ORDER_REF_ID");
define('KEY_PROMO_CODE_ORDER', "ORDER_PROMO_CODE");

/* ............PAYMENT MODE.......... */
define('OFFLINE', 1);
define('RAZORPAY', 2);
define('COUPON', 3);

/* ............HELP CENTER .......... */
define('LAB_CLICK_TO_CALL', '+91 95949 64321');
define('MENU_BASED_SERVICE_CLICK_TO_CALL', '+91 95949 64321');
define('SUBSCRIPTION_BASED_SERVICE_CLICK_TO_CALL', '+91 95949 64321');
define('COMMON_MOBILE_NO', '+91 86910 19117');
define('SUPPORT_CONTACT_NO', '+91 95949 64321');
define('SUPPORT_EMAIL', 'operations@healthismplus.com');

define('EMAIL_TPL_SUPPORT_CONTACT_NO', '+91 95949 64321');
define('EMAIL_TPL_SUPPORT_EMAIL', 'operations@healthismplus.com');

define('ADMIN_EMAIL_FOR_NOTIFICATION', env('ADMIN_EMAIL_FOR_NOTIFICATION'));
define('ADMIN_MOBILE_FOR_NOTIFICATION', env('ADMIN_MOBILE_FOR_NOTIFICATION'));
define('ADMIN_EMAIL_NAME', 'Healthismplus');

/* ............GST .......... */
define('SERVICE_DOCTOR_APPOINTMENT_TAX', 18);
define('SERVICE_LAB_REPORT_TAX', 18);
define('SERVICE_SUBSCRIPTION_PLAN_TAX', 18);
define('SERVICE_COMMON_TAX', 18);

/* ...........ERROR............. */
define('COMMON_ERROR', 'Something went wrong try after some time!');

/* ...........APPLICATION CONSTANTS............. */
define('APP_CONSTANTS_SPECIAL_SUBSCRIPTION_PLAN', 2);
define('APP_CONSTANTS_PLAN_UPGRADE_RESTRICTIONS', 3);
define('APP_ADMIN_EMAIL_FOR_NOTIFICATION', 4);
define('APP_ADMIN_MOBILE_FOR_NOTIFICATION', 5);

define('HEALTHISMPLUS_DOCTOR_LIST', array(
    '1' => array('id' => 1, 'name' => 'Dr Sarthak Snehi', 'qualification' => 'General Physician', 'experience' => '5 Years experience overall', 'mobile' => '8037517198', 'image' => "", 'gender' => 'Male'),
    '2' => array('id' => 2, 'name' => 'Dr. Almas Fatma', 'qualification' => 'General Physician', 'experience' => '8 Years experience overall', 'mobile' => '8037517198', 'image' => "", 'gender' => 'Female'),
    '3' => array('id' => 3, 'name' => ' Dr. Sangeet Chaudhary', 'qualification' => 'General Physician', 'experience' => '2 Years experience overall', 'mobile' => '8037517198', 'image' => "", 'gender' => 'Male'),
));

define('SPA_FACILITY_CATEGORY', array(
    'All', 'Destination', 'Ayurvedic', 'Detox', 'Thalassotherapy', 'Healthy Anti-Ageing', 'Stress Management'
));

define('MBS_CATEGORY', array(
    array('id' => 10, 'name' => 'Spa'),
    array('id' => 11, 'name' => 'Salon'),
));
define('SBS_CATEGORY', array(
    array('id' => 9, 'name' => 'GYM'),
    array('id' => 8, 'name' => 'Dietician'),
));
define('RELATIONSHIP', array('GRAND FATHER', 'GRAND MOTHER', 'FATHER', 'MOTHER', 'WIFE', 'HUSBAND', 'SISTER', 'BROTHER', 'SON', 'DAUGHTER', 'COUSIN', 'AUNT', 'UNCLE', 'GUEST', 'OTHER'));
define('BLOOD_GROUP', ["A+", "A-", "B+", "B-", "AB+", "AB-", "O+", "O-"]);

define("DEFAULT_PLAN_FOR_NEW_USER", 1);
define("HEALTHISM_LAB_ID", 4101);
