<?php

namespace App\Http\Resources;

use Illuminate\Http\Resources\Json\ResourceCollection;

class DoctorCollection extends ResourceCollection
{
    /**
     * Transform the resource collection into an array.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return array|\Illuminate\Contracts\Support\Arrayable|\JsonSerializable
     */
    public function toArray($request)
    {
        return [
            'data' => $this->collection->map(function ($data) {
                return [
                    'id' => $data->id,
                    'first_name' => $data->first_name,
                    'last_name' => $data->last_name,
                    'phone' => $data->phone,
                    'email' => $data->email,
                    'specialization' => $data->specialization,
                    'short_desc' => $data->short_desc,
                    'photo' => $data->photo,
                    'gender' => $data->gender,
                    'sub_category' => $data->sub_category->name,
                    'experience' => $data->experience,
                    'status' => $data->status->name,
                    'doctor_details' => [
                        'description' => $data->doctor_details->description,
                        'registration_number' => $data->doctor_details->registration_number,
                        'registration_council' => $data->doctor_details->registration_council,
                        'registration_date' => $data->doctor_details->registration_date,
                        'identity_proof' => $data->doctor_details->identity_proof,
                        'registration_proof' => $data->doctor_details->registration_proof,
                        'registration_proof' => $data->doctor_details->registration_proof,
                        'last_degree_obtained' => $data->doctor_details->last_degree_obtained,
                        'date_of_completion' => $data->doctor_details->date_of_completion,
                        'college_institute_name' => $data->doctor_details->college_institute_name,
                        'qualification_certificates' => $data->doctor_details->qualification_certificates,
                        'service_json' => json_decode($data->doctor_details->service_json),
                        'specialization_json' => json_decode($data->doctor_details->specialization_json),
                        'education_json' => json_decode($data->doctor_details->education_json),
                        'membership_json' => json_decode($data->doctor_details->membership_json),
                        'experience_json' => json_decode($data->doctor_details->experience_json),
                        'registration_json' => json_decode($data->doctor_details->registration_json),
                    ]
                ];
            })
        ];
    }

    public function with($request)
    {
        return [
            'success' => true,
            'status' => 200
        ];
    }
}
