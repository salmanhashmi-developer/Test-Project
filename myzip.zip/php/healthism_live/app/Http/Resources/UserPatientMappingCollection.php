<?php

namespace App\Http\Resources;

use Illuminate\Http\Resources\Json\ResourceCollection;

class UserPatientMappingCollection extends ResourceCollection {

    /**
     * Transform the resource collection into an array.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return array|\Illuminate\Contracts\Support\Arrayable|\JsonSerializable
     */
    public function toArray($request) {
        return [
            'data' => $this->collection->map(function($data) {
                        return [
                            'id' => $data->id,
                            'user' => "{$data->user->first_name} {$data->user->last_name}",
                            'first_name' => $data->first_name,
                            'last_name' => $data->last_name,
                            'email' => $data->email,
                            'mobile' => $data->mobile,
                            'dob' => $data->dob,
                            'blood_group' => $data->blood_group,
                            'relation' => $data->relation,
                            'status_id' => $data->status_id,
                            'user_id' => $data->user_id,
                        ];
                    })
        ];
    }

    public function with($request) {
        return [
            'message' => "User mapped patients list",
            'status' => 200
        ];
    }

}
