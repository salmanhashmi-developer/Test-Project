<?php

namespace App\Http\Resources;

use Illuminate\Http\Resources\Json\ResourceCollection;

class HospitalCollection extends ResourceCollection
{
    /**
     * Transform the resource collection into an array.
     *
     * @param \Illuminate\Http\Request $request
     * @return array|\Illuminate\Contracts\Support\Arrayable|\JsonSerializable
     */
    public function toArray($request)
    {
        return [
            'data' => $this->collection->map(function ($data) {
                return [
                    'id' => $data->id,
                    'name' => $data->name,
                    'phone' => $data->phone,
                    'address1' => $data->address1,
                    'address2' => $data->address2,
                    'area' => $data->area,
                    'pincode' => $data->pincode,
                    'state_name' => $data->state->name,
                    'city_name' => $data->city->name,
                    'latitude' => $data->latitude,
                    'longitude' => $data->longitude,
                    'longitude' => $data->longitude,
                    'cash_booking_allowed' => $data->cash_booking_allowed,
                    'cancellation_allowed' => $data->cancellation_allowed,
                    'cancel_policy' => json_decode($data->cancel_policy),
                    'cancel_policy_setting' => json_decode($data->cancel_policy_setting),
                    'type' => $data->type,
                    'photo' => $data->photo,
                    'status' => $data->status->name,
                    'hospital_details' => [
                        'gallery_json' => json_decode($data->hospital_details->gallery_json),
                        'pancard_number' => $data->hospital_details->pancard_number,
                        'pancard_document' => $data->hospital_details->pancard_document,
                        'gst_number' => $data->hospital_details->gst_number,
                        'gst_certificate' => $data->hospital_details->gst_certificate,
                        'bank_account_number' => $data->hospital_details->bank_account_number,
                        'bank_account_name' => $data->hospital_details->bank_account_name,
                        'bank_name' => $data->hospital_details->bank_name,
                        'bank_ifsc_code' => $data->hospital_details->bank_ifsc_code,
                    ]
                ];
            })
        ];
    }

    public function with($request)
    {
        return [
            'success' => true,
            'status' => 200
        ];
    }
}
