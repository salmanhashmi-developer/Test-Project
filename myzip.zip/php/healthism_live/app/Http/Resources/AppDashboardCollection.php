<?php

namespace App\Http\Resources;

use Illuminate\Http\Resources\Json\ResourceCollection;

class AppDashboardCollection extends ResourceCollection {

    /**
     * Transform the resource collection into an array.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return array|\Illuminate\Contracts\Support\Arrayable|\JsonSerializable
     */
    public function toArray($request) {
        return [
            'data' => $this->collection->map(function($data) {
                        return [
                            'id' => $data->id,
                            'type' => $data->type,
                            'name' => $data->name,
                            'file' => getImageUrl('dashboard/' . $data->file),
                            'file_type' => $data->file_type,
                            'sort_order' => $data->sort_order,
                        ];
                    })
        ];
    }

    public function with($request) {
        return [
            'success' => true,
            'status' => 200
        ];
    }

}
