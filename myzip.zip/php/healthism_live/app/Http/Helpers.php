<?php

use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Redis;
use Illuminate\Http\Request;

/* * *REDIS RELATED FUNCTION* */

function clearRedis() {
    Redis::command('flushdb');
}

function setRedisData($redisKey, $data) {
    $redis = Redis::connection();
    if (is_array($data)) {
        $redis->set($redisKey, json_encode($data));
    } else {
        $redis->set($redisKey, $data);
    }
    return 1;
}

function getRedisData($redisKey, $dataKey = "") {
    $redis = Redis::connection();
    $data = $redis->get($redisKey);
    if (!empty($data)) {
        $response = json_decode($data, true);
        if (!empty($dataKey)) {
            if (!empty($response[$dataKey])) {
                return $response[$dataKey];
            } else {
                return FALSE;
            }
        } else {
            return $response;
        }
    } else {
        return FALSE;
    }
}

function deleteRedisData($redisKey, $dataKey = []) {
    $redis = Redis::connection();
    $data = $redis->get($redisKey);
    if (!empty($data)) {
        if (!empty($dataKey)) {
            $response = json_decode($data, true);
            if (!empty($response[$dataKey])) {
                unset($response[$dataKey]);
            } else {
                return FALSE;
            }
        } else {
            Redis::del($redisKey);
        }
    } else {
        return FALSE;
    }
}

function getPaymentMode($serviceId, $cashBooking = 1) {
    $paymentMethods = getRedisData(KEY_PAYMENT_MODE);
    if (empty($paymentMethod)) {
        $paymentModeData = \App\Models\PaymentMode::where('status_id', STATUS_ACTIVE)->get();
        $redisData = [];
        foreach ($paymentModeData as $value) {
            $redisData[$value->id] = $value;
        }
        setRedisData(KEY_PAYMENT_MODE, $redisData);
    }
    $paymentMethods = getRedisData(KEY_PAYMENT_MODE);
    $result = [];
    if (!empty($paymentMethods)) {
        if (empty($cashBooking)) {
            unset($paymentMethods[OFFLINE]);
        }
        foreach ($paymentMethods as $key => $value) {
            if ($value['service_id'] == 0) {
                unset($value['service_id']);
                $result[] = $value;
            }
            if (!empty($value['service_id'])) {
                $serviceArr = explode(',', $value['service_id']);
                if (!empty($serviceArr)) {
                    if (in_array($serviceId, $serviceArr)) {
                        unset($value['service_id']);
                        $result[] = $value;
                    }
                }
            }
        }
    }
    return $result;
}

function getStatus($statusId = "") {
    $paymentMethods = getRedisData(KEY_STATUS);
    if (empty($paymentMethod)) {
        $paymentModeData = \App\Models\Status::all();
        $redisData = [];
        foreach ($paymentModeData as $value) {
            $redisData[$value->id] = $value;
        }
        setRedisData(KEY_STATUS, $redisData);
    }
    $paymentMethods = getRedisData(KEY_STATUS, $statusId);
    return $paymentMethods;
}

function getAppliicationConstant($id) {
    $applicationConstant = getRedisData(KEY_APPLICATION_CONSTANT);
    if (empty($applicationConstant)) {
        $applicationConstant = \App\Models\ApplicationConstant::all();
        $redisData = [];
        foreach ($applicationConstant as $value) {
            $redisData[$value->id] = $value;
        }
        setRedisData(KEY_APPLICATION_CONSTANT, $redisData);
    }
    $applicationConstant = getRedisData(KEY_APPLICATION_CONSTANT);
    $result = [];
    if (!empty($applicationConstant)) {
        if (!empty($applicationConstant[$id])) {
            $result = $applicationConstant[$id];
        }
    }
    return $result;
}

function getDataFromRedisKey($key) {
    return getRedisData($key);
}

/* * **********************END REDIS FUNCTION**************************** */

function paymentMethodValidation($paymentMode) {
    $result['code'] = 0;
    $paymentMethod = getRedisData(KEY_PAYMENT_MODE, $paymentMode);
    if (empty($paymentMethod)) {
        $paymentModeData = \App\Models\PaymentMode::all();
        $redisData = [];
        foreach ($paymentModeData as $value) {
            $redisData[$value->id] = $value;
        }
        setRedisData(KEY_PAYMENT_MODE, $redisData);
    }
    $paymentMethod = getRedisData(KEY_PAYMENT_MODE, $paymentMode);
    if (empty($paymentMethod)) {
        $result['message'] = "Sorry, Invalid payment mode.";
    }
    if ($paymentMethod['status_id'] != STATUS_ACTIVE) {
        $result['message'] = "Sorry,Payment mode is inactive.";
    }
    $result['code'] = 1;
    $result['data'] = $paymentMethod;
    return $result;
}

function getUserSubscription($id, $flage = "") {
    $result = \App\Models\UserSubscription::where('user_id', $id)
                    ->where('status_id', STATUS_ACTIVE)
                    ->with('subscription')->first();
    if (!empty($result)) {
        $result['expire'] = 0;
        $expiryDate = date('Y-m-d', strtotime($result['expiry_date']));
        $result['action'] = "Upgrade";
        $result['subscription']['terms'] = json_decode($result['subscription']['terms']);
        if (date('Y-m-d') > $expiryDate) {
            $result['expire'] = 1;
            //return null;
        }
    } else {
        $user = App\Models\User::findOrFail($id);
        if (!empty($user)) {
            if (!empty($user->mobile)) {
                return getParentPlan($user->mobile);
            }
        }
    }
    return $result;
}

function getParentPlan($mobile) {
    $result = \App\Models\UserFamilyMember::where('mobile', $mobile)
            ->where('status_id', STATUS_ACTIVE)
            ->where('expiry_date', '>', date('Y-m-d'))
            ->orderBy('expiry_date', 'DESC')
            ->with('usersubscription', 'usersubscription.subscription')
            ->first();
    if (!empty($result) && !empty($result['usersubscription'])) {
        $result = $result['usersubscription'];
        $result['action'] = "Buy";
        //$resul['user_data'] = App\Models\User::findOrFail($result->user_id);
        $result['subscription']['terms'] = json_decode($result['subscription']['terms']);
    }
    return $result;
}

function getSpecialPlanBenefits($userId) {
    $plan = \App\Models\ApplicationConstant::where('id', APP_CONSTANTS_PLAN_UPGRADE_RESTRICTIONS)->first();
    if (empty($plan) || empty($plan->value)) {
        return false;
    }
    $planIds = explode(',', $plan->value);
    $userSubscription = \App\Models\UserSubscription::where('user_id', $userId)
            ->where('status_id', STATUS_ACTIVE)
            ->where('expiry_date', '>', date('Y-m-d'))
            ->whereIn('subscription_id', $planIds)
            ->first();
    if (!empty($userSubscription)) {
        if ($userSubscription->subscription_id == 8) {
            //For plan id wise
        }
        $result['image'] = getUrl('image/plan/') . 'free-consult.png';
        $result['doctor_list'] = HEALTHISMPLUS_DOCTOR_LIST;
        return $result;
    }
    return false;
}

function checkSpecialPlan($userId) {
    $plan = \App\Models\ApplicationConstant::where('id', APP_CONSTANTS_PLAN_UPGRADE_RESTRICTIONS)->first();
    if (empty($plan) || empty($plan->value)) {
        return 1;
    }
    $planIds = explode(',', $plan->value);
    $userSubscription = \App\Models\UserSubscription::where('user_id', $userId)
            ->where('status_id', STATUS_ACTIVE)
            ->where('expiry_date', '>', date('Y-m-d'))
            ->whereIn('subscription_id', $planIds)
            ->first();
    if (!empty($userSubscription)) {
        return 0;
    }
    return 1;
}

function executeSelectQueryOnMySQLDB($query, $bindingParams = array()) {
    $connection = DB::connection('mysql');
    $result = $connection->select($query, $bindingParams);
    $result = json_decode(json_encode($result), true);
    return $result;
}

function getFirstRowOfResult($query) {
    $data = executeSelectQueryOnMySQLDB($query);
    if (!empty($data)) {
        $result = $data;
        if (!empty($data[0])) {
            $result = $data[0];
        }
    }
    return $result;
}

function curl_GET($url) {
    $ch = curl_init();
    curl_setopt($ch, CURLOPT_URL, $url);
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
    curl_setopt($ch, CURLOPT_CONNECTTIMEOUT, 10);
    curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
    curl_setopt($ch, CURLOPT_USERAGENT, "dskjfdsfjksjdk Gecko/20100101 Firefox/31.0");
    $response = curl_exec($ch);
    curl_close($ch);
    if ($response === false) {
        return $response;
    }
    return json_decode($response, true);
}

function pr($content = null, $exit = 1) {
    if (is_array($content) || is_object($content)) {
        echo "<pre>";
        print_r($content);
    } else {
        echo $content;
    }
    if ($exit) {
        exit;
    }
}

function success($data, $message) {
    $result = [];
    $result['code'] = 200;
    $result['message'] = $message;
    $result['data'] = $data;
    return response()->json($result);
}

function error($message, $data = []) {
    $error = [];
    $error['code'] = 201;
    $error['message'] = $message;
    if (!empty($data)) {
        $error['data'] = $data;
    }
    return response()->json($error);
}

function warning($message) {
    $error = [];
    $error['code'] = 299;
    $error['message'] = $message;
    return response()->json($error);
}

function unauthorized() {
    $error = [];
    $error['code'] = 401;
    $error['message'] = 'Unauthenticated...';
    return response()->json($error);
}

function loginUserDetail($request, $field = "") {
    $loginUser = $request->user();
    if (empty($loginUser)) {
        return unauthorized();
    }
    if (!empty($field)) {
        return $loginUser[$field];
    } else {
        return $loginUser;
    }
}

function getUrl($path, $secure = null) {
    //return app('url')->asset($path, $secure) . '/';
    return "http://api.healthismplus.com/" . $path . '/';
}

function dateFormat($date, $formate = '') {
    $result = $date->format('Y-m-d H:i:s');
    if (!empty($formate)) {
        $result = $date->format($formate);
    }
    return $result;
}

function timeInterval($date) {
    $now = date('Y-m-d H:i:s');
    $diff = strtotime($now) - strtotime($date);
    $array = [];
    $array['year'] = ($diff / (60 * 60 * 24 * 365));
    $array['month'] = ($diff / (60 * 60 * 24 * 30)) % 365;
    $array['day'] = ($diff / (60 * 60 * 24)) % 365;
    $array['hour'] = ($diff / (60 * 60)) % 24;
    $array['minutes'] = ($diff / (60)) % 60;
    $array['second'] = ($diff) % 60;
    foreach ($array as $key => $value) {
        $value = (int) $value;
        if (!empty($value)) {
            return $value >= 1 ? $value . ' ' . $key . 's ago' : $value . ' ' . $key . ' ago';
// return $value . $key;
        }
    }
}

function uploadFile($tempFile, $path) {
    if (move_uploaded_file($tempFile, $path)) {
        return array("status" => 1, "file" => $path);
    } else {
        return array("status" => 0, "message" => 'Upload Failed...');
    }
}

function deleteFile($path) {
    if (file_exists($path)) {
        unlink($path);
        return 1;
    } else {
        return 0;
    }
}

if (!function_exists('request_display')) {

    function request_display($str = '', $data = '') {
        if (isset($_REQUEST[$str])) {
            return htmlspecialchars(trim($_REQUEST[$str]));
        } else {
            return htmlspecialchars(trim($data));
        }
    }

}

if (!function_exists('post_display')) {

    function post_display($str = '', $data = '') {
        if (\Request::old($str)) {
            return htmlspecialchars(trim(\Request::old($str)));
        } else {
            return htmlspecialchars(trim($data));
        }
    }

}
if (!function_exists('sort_field_display')) {

    function sort_field_display($sort_field, $label) {
        if (isset($_REQUEST['sort_action']) && $_REQUEST['sort_action'] == 'DESC' && $_REQUEST['sort_field'] == $sort_field) {
            ?>
            <a onClick="javascript:set_sort_data('<?php echo $sort_field; ?>', 'ASC')" style="color:#000;"><?php echo $label; ?><img border="0" src="/admin-assets/images/icons/sortdown.gif"/></a>
            <?php
        } else if (isset($_POST['sort_action']) && $_POST['sort_action'] == 'ASC' && $_POST['sort_field'] == $sort_field) {
            ?>
            <a onClick="javascript:set_sort_data('<?php echo $sort_field; ?>', 'DESC');" style="color:#000;" ><?php echo $label; ?><img border="0" src="/admin-assets/images/icons/sortup.gif"/></a>
            <?php
        } else {
            ?>
            <a onClick="javascript:set_sort_data('<?php echo $sort_field; ?>', 'ASC');" style="color:#000;" ><?php echo $label; ?></a><?php
        }
    }

}

if (!function_exists('form_helper')) {

    function form_helper($inputs) {
        switch ($inputs['type']) {
            case 'text':
                $label_attr = ' ';
                $input_attr = ' ';
                if (!empty($inputs['label_attr'])) {
                    foreach ($inputs['label_attr'] as $key => $val) {
                        $label_attr .= "$key='{$val}' ";
                    }
                }
                if (!empty($inputs['input_attr'])) {
                    foreach ($inputs['input_attr'] as $key => $val) {
                        $input_attr .= "$key='{$val}' ";
                    }
                }
                ?>
                <label <?= $label_attr ?>><?= $inputs['label'] ?></label>
                <input type="text" name="<?= $inputs['name'] ?>" <?= $input_attr ?>>
                <?php
                break;
        }
    }

}

function flash($type, $title, $message) {
    $flash = app('App\Http\Flash');
    return $flash->message($type, $title, $message);
}

function convertToArray($data) {
    if (is_array($data) || is_object($data)) {
        if (is_object($data)) {
            $data = get_object_vars($data);
        }
        return print_r($data, true);
    }
    return $data;
}

function platformCode($platformId) {
    if ($platformId == WEB) {
        return 'W';
    }
    if ($platformId == ANDROID) {
        return 'A';
    }
    if ($platformId == IOS) {
        return 'I';
    }
}

function change_filename($path, $name) {
    $actual_name = pathinfo($name, PATHINFO_FILENAME);
    $original_name = $actual_name;
    $extension = pathinfo($name, PATHINFO_EXTENSION);
    $i = 1;
    while (file_exists($path . $actual_name . "." . $extension)) {
        $actual_name = (string) $original_name . $i;
        $name = $actual_name . "." . $extension;
        $i++;
    }
    return $name;
}

function seo_url($string) {
    $string = preg_replace("`\[.*\]`U", "", $string);
    $string = preg_replace('`&(amp;)?#?[a-z0-9]+;`i', '-', $string);
    $string = htmlentities($string, ENT_COMPAT, 'utf-8');
    $string = preg_replace("`&([a-z])(acute|uml|circ|grave|ring|cedil|slash|tilde|caron|lig|quot|rsquo);`i", "\\1", $string);
    $string = preg_replace(array("`[^a-z0-9]`i", "`[-]+`"), "-", $string);
    return strtolower(trim($string, '-')) . time();
}

function resizeImage($file, $w, $h, $crop = FALSE) {
    header("Content-type: image/jpeg");
    list($width, $height) = getimagesize($file);
    $r = $width / $height;
    if ($crop) {
        if ($width > $height) {
            $width = ceil($width - ($width * abs($r - $w / $h)));
        } else {
            $height = ceil($height - ($height * abs($r - $w / $h)));
        }
        $newwidth = $w;
        $newheight = $h;
    } else {
        if ($w / $h > $r) {
            $newwidth = $h * $r;
            $newheight = $h;
        } else {
            $newheight = $w / $r;
            $newwidth = $w;
        }
    }
    $src = imagecreatefromjpeg($file);
    $dst = imagecreatetruecolor($newwidth, $newheight);
    imagecopyresampled($dst, $src, 0, 0, 0, 0, $newwidth, $newheight, $width, $height);
    return $dst;
}

function parPageRecordDropDown($sizeArr = []) {
    $html = '<div class="d-flex justify-content-between align-items-center header-actions mx-2 row mt-75">
                        <div class="col-sm-12 col-lg-4 d-flex justify-content-center justify-content-lg-start p-0">
                            <div class="dataTables_length" id="DataTables_Table_0_length">
                                <label class="lbl">
                                    <span>Show</span>
                                    <select name="records_per_page" class="form-select">';
    $sizeArr = empty($sizeArr) ? [10, 50, 100, 500] : $sizeArr;
    $set_values = request_display('records_per_page');
    foreach ($sizeArr as $row) {
        $select = $row == $set_values ? "selected" : "";
        $html .= '<option value = ' . $row . ' ' . $select . '>' . $row . '</option>';
    }
    $html .= ' </select><span> entries</span></label></div></div></div>';
    return $html;
}

function pagination($data) {
    $html = '<div class="d-flex justify-content-between align-items-center header-actions mx-2 row mt-75 mb-2">
                        <div class="col-sm-12 col-lg-4 d-flex justify-content-center justify-content-lg-start">
                            Showing ' . $data->firstItem() . ' to ' . $data->lastItem() . ' of  ' . $data->total() . '  entries
                        </div>
                        <div class="col-sm-12 col-lg-8 ps-xl-75 ps-0">
                            <div
                                class="dt-action-buttons d-flex align-items-center justify-content-center justify-content-lg-end flex-lg-nowrap flex-wrap">
                                <div class="dt-buttons d-inline-flex mt-50">
                                    ' . $data->appends(request()->input())->links() . '
                                </div>
                            </div>
                        </div>
                    </div>';
    return $html;
}

function getOrderStatus($orderId, $status) {
    $orderDetail = App\Models\OrderDetail::where('order_id', $orderId)->get();
    if (!empty($orderDetail)) {
        foreach ($orderDetail as $key => $value) {
            if ($status == STATUS_FULLY_REFUNDED) {
                if ($value['status_id'] != STATUS_FULLY_REFUNDED) {
                    $status = STATUS_PARTIAL_REFUNDED;
                }
            }
            if ($status == STATUS_FULLY_CANCELLED) {
                if ($value['status_id'] != STATUS_FULLY_CANCELLED) {
                    $status = STATUS_PARTIAL_CANCELLED;
                }
            }
        }
    }
    return $status;
}

function getUpdateStatusList($statusId) {
    $statusArr = [['id' => STATUS_DONE, 'name' => 'DONE'], ['id' => STATUS_FAILED, 'name' => 'FAILED']];
    if ($statusId == STATUS_PENDING) {
        $statusArr;
    }
    if ($statusId == STATUS_SENT_ON_PG || $statusId == STATUS_RETURN_FROM_PG) {
        $statusArr[] = ['id' => STATUS_FULLY_CANCELLED, 'name' => 'FULLY CANCELLED'];
    }
    if ($statusId == STATUS_DONE) {
        $statusArr = [['id' => STATUS_FAILED, 'name' => 'FAILED']];
    }
    if ($statusId == STATUS_FAILED) {
        $statusArr = [['id' => STATUS_DONE, 'name' => 'DONE']];
    }
    if ($statusId == STATUS_REFUNDED_INPROGRESS) {
        $statusArr = [['id' => STATUS_FULLY_REFUNDED, 'name' => 'FULLY REFUNDED']];
    }
    if ($statusId == STATUS_FULLY_CANCELLED || $statusId == STATUS_FULLY_REFUNDED) {
        $statusArr = [];
    }
    return $statusArr;
}

function statusWiseColor($statusId, $codeRequired = "") {
    if ($statusId == STATUS_SENT_ON_PG || $statusId == STATUS_RETURN_FROM_PG || $statusId == STATUS_PENDING) {
        if (!empty($codeRequired)) {
            return 1;
        }
        return '#EC8E01';
    }
    if ($statusId == STATUS_DONE || $statusId == STATUS_FULLY_REFUNDED || $statusId == STATUS_PARTIAL_REFUNDED) {
        if (!empty($codeRequired)) {
            return 2;
        }
        return '#058E2A';
    }
    if ($statusId == STATUS_FAILED || $statusId == STATUS_FULLY_CANCELLED || $statusId == STATUS_PARTIAL_CANCELLED) {
        if (!empty($codeRequired)) {
            return 3;
        }
        return '#DE3326';
    }
    if (!empty($codeRequired)) {
        return 1;
    }
    return '#EC8E01';
}

function getCardRandNumber($cardPrefix) {
    for ($x = 0; $x <= 25; $x++) {
        $code = $cardPrefix . rand(100000000000, 999999999999);
        $codeExist = App\Models\UserSubscription::where('card_no', $code)->count();
        if (empty($codeExist)) {
            return $code;
        }
    }
}

function emailSend($data) {
    try {
        $cc = !empty($data['cc_address']) ? $data['cc_address'] : "";
        $bcc = !empty($data['bcc_address']) ? $data['bcc_address'] : "";
        $json = '{
                "bounce_address": "bounce@bounce.healthismplus.com",
                "from": {
                      "address": "' . $data['from'] . '"
                    },
                "to": [
                      {
                        "email_address": {
                          "address": "' . $data['email'] . '",
                          "name": "' . $data['name'] . '"
                        }
                      }
                    ],
                "cc":[
                        {
                          "email_address": 
                            {
                            "address": "' . $cc . '",
                            "name": "' . $cc . '"
                            }
                          }
                        ],
                "bcc":[
                        {
                          "email_address": 
                            {
                            "address": "' . $bcc . '",
                             "name": "' . $bcc . '"   
                            }
                          }
                        ],
                    "subject": "' . $data['subject'] . '",
                    "htmlbody": ' . json_encode($data['html_body']) . '
                }';
        $curl = curl_init();
        curl_setopt_array($curl, array(
            CURLOPT_URL => "https://api.zeptomail.in/v1.1/email",
            CURLOPT_RETURNTRANSFER => true,
            CURLOPT_ENCODING => "",
            CURLOPT_MAXREDIRS => 10,
            CURLOPT_TIMEOUT => 30,
            CURLOPT_SSLVERSION => CURL_SSLVERSION_TLSv1_2,
            CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
            CURLOPT_CUSTOMREQUEST => "POST",
            CURLOPT_POSTFIELDS => $json,
            CURLOPT_HTTPHEADER => array(
                "accept: application/json",
                "authorization: Zoho-enczapikey PHtE6r1eR7+/32Qu9BcI4/bsFMH3YYp89e9keQFB44pEC/cKTE1d/9t5l2Xjoh4qBvlGEvDOnt5ps7vO4brUJWq5PG5EXWqyqK3sx/VYSPOZsbq6x00ZtVUZdkDaV4XqddBu0SPXutjSNA==",
                "cache-control: no-cache",
                "content-type: application/json",
            ),
        ));
        $response = curl_exec($curl);
        $err = curl_error($curl);
        curl_close($curl);
        if ($err) {
            emailLog("cURL Error #:" . $err, $response);
        } else {
            emailLog($data['email'] . " - " . $data['subject'], $response);
            return $response;
        }
    } catch (Exception $exc) {
        notificationErrorLog($exc);
    }
}

function sendEmail($emailDat, $template) {
    return 0;
}

function getNotificationTemplate($service, $alertType, $subType) {
    $query = App\Models\NotificationTemplate::where('alert_type', $alertType);
    $query->where('service', $service);
    $query->where('active', STATUS_ACTIVE);
    if (!empty($subType)) {
        $query->where('sub_type', $subType);
    } else {
        $query->whereNull('sub_type');
    }
    $result = $query->get();
    return $result;
}

function sendTextMsg($mobile, $sms, $templateId, $gatewayId, $DLTTemplateId) {
    try {
        if (!empty($mobile)) {
            $smsText = urlencode($sms);
            $smsSendResponse = [];
            $url = env('SMS_API') . '&number=91' . $mobile . '&text=' . $smsText . '&DLTTemplateId=' . $DLTTemplateId;
            $smsSendResponse = curl_GET($url);
            $smsLogData = [];
            $smsLogData['created_at'] = date('Y-m-d H:i:s');
            $smsLogData['sms_content'] = $sms;
            $smsLogData['response'] = json_encode($smsSendResponse);
            $smsLogData['mobile'] = $mobile;
            $smsLogData['notification_template_id'] = $templateId;
            $smsLogData['gateway_id'] = $gatewayId;
            textSMSLog($url, json_encode($smsSendResponse));
            return App\Models\SmsLog::create($smsLogData);
        }
    } catch (Exception $exc) {
        notificationErrorLog($exc);
    }
}

function sendAppNotification($notificationArr) {
    try {
        $response = App\Helpers\PushNotifications::send_push($notificationArr);
        notificationLog($notificationArr, json_encode($response));
        return $response;
    } catch (Exception $exc) {
        //  notificationErrorLog($exc);
    }
}

function sendNotification($templateData, $param) {
    try {
        if (!empty($templateData['sms_text'])) {
            if (!empty($param['mobile'])) {
                sendTextMsg($param['mobile'], $templateData['sms_text'], $templateData['id'], $templateData['sms_gateway_id'], $templateData['dlt_templateid']);
            }
        }
        if (!empty($templateData['whats_app_text'])) {
            
        }
        if (!empty($templateData['app_notification_text'])) {
            $userRegistrationData = \App\Models\UserDeviceMapping::where('user_id', $param['user_id'])->where('status_id', STATUS_ACTIVE)->get();
            if (!empty($userRegistrationData)) {
                $pushNotificationData['user_id'] = $param['user_id'];
                $pushNotificationData['title'] = $param['title'];
                $pushNotificationData['details'] = $templateData['app_notification_text'];
                $pushNotificationData['notification_type'] = $param['type'];
                // $pushNotificationData['platform_id'] = $userRegistrationData->platform_id;
                $pushNotificationData['app_id'] = !empty($userRegistrationData[0]) ? $userRegistrationData[0]->app_id : null;
                $pushNotificationData['created_at'] = date('Y-m-d H:i:s');
                $newNotification = App\Models\Notification::create($pushNotificationData);
                foreach ($userRegistrationData as $key => $userRegistration) {
                    if (!empty($userRegistration->registration_id)) {
                        $notificationArr = ['title' => $pushNotificationData['title'],
                            'body' => $templateData['app_notification_text'],
                            'device_token' => $userRegistration->registration_id,
                        ];
                        $push = sendAppNotification($notificationArr);
                        if (!empty($push)) {
                            $pushNotificationResponse[] = $push;
                        }
                    }
                }
                if (!empty($pushNotificationResponse)) {
                    $newNotification->fill(['response' => json_encode($pushNotificationResponse)])->save();
                }
            }
        }
        if (!empty($templateData['html_body'])) {
            if (!empty($param['email'])) {
                $data['from'] = $templateData['from_address'];
                $data['email'] = $param['email'];
                $data['name'] = !empty($param['admin_email_name']) ? $param['admin_email_name'] : $param['user_name'];
                $data['subject'] = $templateData['subject'];
                $data['html_body'] = $templateData['html_body'];
                $data['bcc_address'] = $templateData['bcc_address'];
                $data['cc_address'] = $templateData['cc_address'];
                emailSend($data);
            }
        }
    } catch (Exception $exc) {
        notificationErrorLog($exc);
    }
}

function replaceTemplateString($template, $array) {
    try {
        $array['support_contact_no'] = EMAIL_TPL_SUPPORT_CONTACT_NO;
        $array['support_email'] = EMAIL_TPL_SUPPORT_EMAIL;
        foreach ($array as $key => $value) {
            if (!empty($template->html_body)) {
                $template->html_body = str_replace("##" . $key . "##", $value, $template->html_body);
            }
            if (!empty($template->sms_text)) {
                $template->sms_text = str_replace("##" . $key . "##", $value, $template->sms_text);
            }
            if (!empty($template->whats_app_text)) {
                $template->whats_app_text = str_replace("##" . $key . "##", $value, $template->whats_app_text);
            }
            if (!empty($template->app_notification_text)) {
                $template->app_notification_text = str_replace("##" . $key . "##", $value, $template->app_notification_text);
            }
            if (!empty($template->subject)) {
                $template->subject = str_replace("##" . $key . "##", $value, $template->subject);
            }
        }
        return $template;
    } catch (Exception $exc) {
        notificationErrorLog($exc);
    }
}

function notification($param, $service, $alert, $subType = null) {
    try {
        //Get Template From DB
        $templates = getNotificationTemplate($service, $alert, $subType);
        if (!empty($templates)) {
            //Replace Data
            foreach ($templates as $key => $template) {
                if (!empty($template)) {
                    $templateData = replaceTemplateString($template, $param);
                    if (!empty($templateData)) {
                        sendNotification($templateData, $param);
                    }
                }
            }
        }
    } catch (Exception $exc) {
        notificationErrorLog($exc);
    }
    return 1;
}

function numberFormat($number) {
    return number_format($number, 2, '.', '');
}

function validateLatLong($lat, $long) {
    $result = preg_match('/^(\+|-)?(?:90(?:(?:\.0{1,9})?)|(?:[0-9]|[1-8][0-9])(?:(?:\.[0-9]{1,9})?))$/', $lat);
    if (!empty($result)) {
        $result = preg_match('/^(\+|-)?(?:180(?:(?:\.0{1,9})?)|(?:[0-9]|[1-9][0-9]|1[0-7][0-9])(?:(?:\.[0-9]{1,9})?))$/', $long);
    }
    return $result;
}

/* * **********LOG FUNACTION************** */

function cronLog($data, $sms) {
    try {
        $stCurLogFileName = date('Y-m-d') . '.txt';
        $fHandler = fopen(storage_path() . '/logs/cron/' . $stCurLogFileName, 'a+');
        $fileContent = date("Y-m-d H:i:s") . "\n-------------------------------------------------\nDATA : " . convertToArray($data) . "\nMSG : " . $sms . "\n\n";
        fwrite($fHandler, $fileContent);
        fclose($fHandler);
    } catch (Exception $exc) {
        
    }
}

function notificationLog($data, $response) {
    try {
        $stCurLogFileName = date('Y-m-d') . '.txt';
        $fHandler = fopen(storage_path() . '/logs/notification/' . $stCurLogFileName, 'a+');
        $fileContent = date("Y-m-d H:i:s") . "\n-------------------------------------------------\nREQUEST : " . convertToArray($data) . "\nRESPONSE : " . convertToArray($response) . "\n\n";
        fwrite($fHandler, $fileContent);
        fclose($fHandler);
    } catch (Exception $exc) {
        
    }
}

function notificationErrorLog($exc) {
    try {
        $stCurLogFileName = date('Y-m-d') . '.txt';
        $fHandler = fopen(storage_path() . '/logs/notification-error/' . $stCurLogFileName, 'a+');
        $fileContent = date("Y-m-d H:i:s") . "\n-------------------------------------------------\nFILE  : " . $exc->getFile() . "\nLINE : " . $exc->getLine() . "\nMESSAGE: " . $exc->getMessage() . "\n";
        fwrite($fHandler, $fileContent);
        fclose($fHandler);
    } catch (Exception $exc) {
        
    }
}

function errorLog($exc) {
    $stCurLogFileName = date('Y-m-d') . '.txt';
    $fHandler = fopen(storage_path() . '/logs/error/' . $stCurLogFileName, 'a+');
    $fileContent = date("Y-m-d H:i:s") . "\n-------------------------------------------------\nFILE  : " . $exc->getFile() . "\nLINE : " . $exc->getLine() . "\nMESSAGE: " . $exc->getMessage() . "\n";
    fwrite($fHandler, $fileContent);
    fclose($fHandler);
}

function paymentLog($url, $data, $response) {
    $stCurLogFileName = date('Y-m-d') . '.txt';
    $fHandler = fopen(storage_path() . '/logs/payment/' . $stCurLogFileName, 'a+');
    $fileContent = date("Y-m-d H:i:s") . "\n-------------------------------------------------\nURL : " . $url . "\n\nREQUEST : " . convertToArray($data) . "\nRESPONSE : " . convertToArray($response) . "\n\n";
    fwrite($fHandler, $fileContent);
    fclose($fHandler);
}

function emailLog($email, $response) {
    $stCurLogFileName = date('Y-m-d') . '.txt';
    $fHandler = fopen(storage_path() . '/logs/email/' . $stCurLogFileName, 'a+');
    $fileContent = date("Y-m-d H:i:s") . "\n-------------------------------------------------\nEmail : " . $email . "\nRESPONSE : " . convertToArray($response) . "\n\n";
    fwrite($fHandler, $fileContent);
    fclose($fHandler);
}

function textSMSLog($url, $response) {
    try {
        $stCurLogFileName = date('Y-m-d') . '.txt';
        $fHandler = fopen(storage_path() . '/logs/sms/' . $stCurLogFileName, 'a+');
        $fileContent = date("Y-m-d H:i:s") . "\n-------------------------------------------------\nURL : " . $url . "\nRESPONSE : " . convertToArray($response) . "\n\n";
        fwrite($fHandler, $fileContent);
        fclose($fHandler);
    } catch (Exception $exc) {
        
    }
}

function debugApi($url, $requestData, $response) {
    try {
        $stCurLogFileName = date('Y-m-d') . '.txt';
        $fHandler = fopen(storage_path() . '/logs/debudAPI/' . $stCurLogFileName, 'a+');
        $fileContent = date("Y-m-d H:i:s") . "\n-------------------------------------------"
                . "------\nURL : " . $url . ""
                . "\nREQUEST : " . convertToArray($requestData) . ""
                . "\nRESPONSE : " . convertToArray($response) . ""
                . "\n\n";
        fwrite($fHandler, $fileContent);
        fclose($fHandler);
    } catch (Exception $exc) {
        
    }
}

function getServiceFromUserType($userType) {
    if ($userType == LAB || $userType == LAB_BRANCH) {
        return SERVICE_LAB_REPORT;
    }
    if ($userType == MBS_USER || $userType == MBS_BRANCH_USER) {
        return MENU_BASED_SERVICE;
    }
    if ($userType == SBS_USER || $userType == SBS_BRANCH_USER) {
        return SUBSCRIPTION_BASED_SERVICE;
    }
}

function redirectRoutePath($userType) {
    if ($userType == ADMIN) {
        return redirect()->route('admin.user');
    }
    if ($userType == LAB || $userType == LAB_BRANCH) {
        return redirect()->route('lab.profile');
    }
    if ($userType == MBS_USER || $userType == MBS_BRANCH_USER) {
        return redirect()->route('mbs.profile');
    }
    if ($userType == SBS_USER || $userType == SBS_BRANCH_USER) {
        return redirect()->route('sbs.profile');
    }
    if ($userType == CORPORATE_USER) {
        return redirect()->route('corporate.dashBoard');
    }
    if ($userType == PHARMACY_USER) {
        return redirect()->route('pharmacy.profile');
    }
}

function generateRandomString($length = 8) {
    $characters = '0123456789abcdefghijklmnopqrs092u3tuvwxyzaskdhfhf9882323ABCDEFGHIJKLMNksadf9044OPQRSTUVWXYZ';
    $charactersLength = strlen($characters);
    $randomString = '';
    for ($i = 0; $i < $length; $i++) {
        $randomString .= $characters[rand(0, $charactersLength - 1)];
    }
    return $randomString;
}
