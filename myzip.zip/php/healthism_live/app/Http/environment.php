<?php

define("RZP_KEY", 'rzp_test_RrmYHsOZpuOZmE');
define("RZP_SECRET_KEY", 'MA4D48lIQv50hJbFzFE1I5bS');



