<?php

namespace App\Http\Requests;

use Illuminate\Foundation\Http\FormRequest;

class CorporateUserPostRequest extends FormRequest
{
    /**
     * Determine if the user is authorized to make this request.
     *
     * @return bool
     */
    public function authorize()
    {
        return true;
    }
    public function messages()
    {
        return [
            'first_name.required' => 'First Name field is required',
            'last_name.required' => 'Last Name field is required',
            'email.required' => 'Email field is required',
            'mobile.required' => 'Mobile No field is required',
           // 'dob.required' => 'DOB is required',
          //  'blood_group.required' => 'Blood Group field is required',
          //  'gender.required' => 'Gender is required',
            'user_type_id.required' => 'User Type field is required',
            'status_id.required' => 'Status field is required',
           // 'branch_id.required' => 'Branch field is required',
            //'department_id.required' => 'Department field is required',
            //'designation_id.required' => 'Designation field is required',
        ];
    }


    /**
     * Get the validation rules that apply to the request.
     *
     * @return array<string, mixed>
     */
    public function rules()
    {
        return [
            'first_name' => 'required',
            'last_name' => 'required',
            'email' => 'required',
            'mobile' => 'required',
//            'email' => 'required|unique:user,email,'.$this->id,
//            'mobile' => 'required|unique:user,mobile,'.$this->id,
//            'dob' => 'required',
//            'blood_group' => 'required',
//            'gender' => 'required',
            'user_type_id' => 'required',
            'status_id' => 'required',
            //'branch_id' => 'required',
           // 'department_id' => 'required',
           // 'designation_id' => 'required',
        ];

    }
}
