<?php

namespace App\Http\Requests;

use Illuminate\Foundation\Http\FormRequest;

class DoctorPostRequest extends FormRequest
{
    /**
     * Determine if the user is authorized to make this request.
     *
     * @return bool
     */
    public function authorize()
    {
        return true;
    }
    public function messages()
    {
        return [
            'first_name.required' => 'First Name field is required',
            'user_id.unique' => 'The user has already been taken to another doctor please select another user',
          /*  'last_name.required' => 'Last Name field is required',
            'email.required' => 'Email field is required',
            'mobile.required' => 'Mobile No field is required',
            'dob.required' => 'DOB is required',
            'blood_group.required' => 'Blood Group field is required',
            'gender.required' => 'Gender is required',
            'user_type_id.required' => 'User Type field is required',
            'status_id.required' => 'Status field is required',*/
        ];
    }


    /**
     * Get the validation rules that apply to the request.
     *
     * @return array<string, mixed>
     */
    public function rules()
    {
        return [
            'first_name' => 'required',
            'user_id' => 'required|unique:doctor,user_id,'.$this->id,
        ];

    }
}
