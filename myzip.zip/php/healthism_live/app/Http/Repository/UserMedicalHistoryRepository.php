<?php

namespace App\Http\Repository;

use App\Models\UserMedicalHistory;
use App\Models\UserUpload;
use App\Models\UserMedicalHistoryMapping;

class UserMedicalHistoryRepository {

    public function uploadPrescription($input) {
        $input['created_at'] = date('Y-m-d H:i:s');
        $input['status_id'] = STATUS_ACTIVE;
        $result = UserMedicalHistory::create($input);
        $nameList = '';
        if (!empty($result)) {
            $imageName = null;
            foreach ($input['new_file'] as $key => $file) {
                if (!empty($_FILES["new_file"]["size"][$key])) {
                    $fileDetails = pathinfo($_FILES["new_file"]["name"][$key]);
                    $fileName = $fileDetails['basename'];
                    $imageName = 'USER-' . str_replace(' ', '-', $fileDetails['filename']) . '-' . time() . "." . $fileDetails['extension'];
                    uploadFile($_FILES["new_file"]['tmp_name'][$key], public_path('image/user_medical_history/' . $imageName));

                    $mapping = new UserMedicalHistoryMapping;
                    $mapping->user_medical_history_id = $result->id;
                    $mapping->file = $imageName;
                    $mapping->original_file_name = $fileName;
                    $mapping->created_at = date('Y-m-d H:i:s');
                    $mapping->save();
                    $nameList .= $imageName . ',';
                }
            }
        }
        return $nameList;
    }

    public function uploadReports($input) {
        $input['created_at'] = date('Y-m-d H:i:s');
        $input['status_id'] = STATUS_ACTIVE;
        $result = UserMedicalHistory::firstOrCreate(
                        [
                    'user_id' => $input['user_id'],
                    'service_id' => $input['service_id'],
                    'ref_id' => $input['ref_id'],
                    'service_ref_id' => $input['service_ref_id']
                        ], $input);
        $nameList = '';
        if (!empty($result)) {
            $imageName = null;
            $imagePrifix = !empty($input['image_prifix']) ? $input['image_prifix'] : 'USER-';
            foreach ($input['new_file'] as $key => $file) {
                if (!empty($_FILES["new_file"]["size"][$key])) {
                    $fileDetails = pathinfo($_FILES["new_file"]["name"][$key]);
                    $fileName = $fileDetails['basename'];
                    $imageName = $imagePrifix . str_replace(' ', '-', $fileDetails['filename']) . '-' . time() . "." . $fileDetails['extension'];
                    uploadFile($_FILES["new_file"]['tmp_name'][$key], public_path('image/user_medical_history/' . $imageName));

                    $mapping = new UserMedicalHistoryMapping;
                    $mapping->user_medical_history_id = $result->id;
                    $mapping->file = $imageName;
                    $mapping->original_file_name = $fileName;
                    $mapping->created_at = date('Y-m-d H:i:s');
                    $mapping->save();
                    $nameList .= $imageName . ',';
                }
            }
        }
        return $nameList;
    }

    public function saveMedicalHistory($input) {
        $input['created_at'] = date('Y-m-d H:i:s');
        $input['status_id'] = STATUS_ACTIVE;
        $result = UserMedicalHistory::firstOrCreate(
                        [
                    'user_id' => $input['user_id'],
                    'service_id' => $input['service_id'],
                    'ref_id' => $input['ref_id'],
                    'service_ref_id' => $input['service_ref_id']
                        ], $input);
        if (!empty($result)) {
            $imageName = null;
            if (!empty($input['file']) && !empty($_FILES["file"]["size"])) {
                $fileDetails = pathinfo($_FILES["file"]["name"]);
                $fileName = $fileDetails['basename'];
                $imageName = $input['image_prifix'] . str_replace(' ', '-', $fileDetails['filename']) . '-' . time() . "." . $fileDetails['extension'];
                uploadFile($_FILES["file"]['tmp_name'], public_path('image/user_medical_history/' . $imageName));
            }
            $mapping = new UserMedicalHistoryMapping;
            $mapping->user_medical_history_id = $result->id;
            $mapping->file = $imageName;
            $mapping->original_file_name = $fileName;
            $mapping->medicine = !empty($input['medicine']) ? $input['medicine'] : null;
            $mapping->days = !empty($input['days']) ? $input['days'] : null;
            $mapping->qty = !empty($input['qty']) ? $input['qty'] : null;
            $mapping->frequency_json = !empty($input['frequency_json']) ? $input['frequency_json'] : null;
            $mapping->created_at = date('Y-m-d H:i:s');
            $mapping->save();
        }
        return $result;
    }

    public function getMedicalHistory($input) {
        $result = UserMedicalHistory::where($input)->first();
        if (!empty($result)) {
            return UserMedicalHistoryMapping::where('user_medical_history_id', $result->id)->get();
        }
        return $result;
    }

    public function getMyPrescription($input, $skip) {
        $result = UserMedicalHistory::where($input)
                ->orderBy('id', 'DESC')
                ->with('mapping')
                ->skip($skip)
                ->limit(LIMIT)
                ->with('service')
                ->get();
        return $result;
    }
    
    public function getPharmacyPrescription($input, $skip) {
        $result = UserUpload::where($input)
                ->orderBy('id', 'DESC')
                ->with('mapping','status','userPatient','address','quotation')
                ->skip($skip)
                ->limit(LIMIT)
                ->get();
        return $result;
    }

    public function deleteMedicalHistoryMapping($id) {
        $result = UserMedicalHistoryMapping::where('id', $id)->first();
        if (!empty($result)) {
            if ($result->file) {
                deleteFile(public_path('image/user_medical_history/' . $result->file));
            }
            $result->delete();
        }
        return 1;
    }

}
