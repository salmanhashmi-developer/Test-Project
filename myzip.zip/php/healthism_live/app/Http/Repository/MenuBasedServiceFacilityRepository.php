<?php

namespace App\Http\Repository;

class MenuBasedServiceFacilityRepository {

    function getFacilityFromLocation($latitude, $longitude, $pincode, $input) {
        try {
            $query = "SELECT
                    mbs.id AS menu_based_service_id,
                    mbs.`name` AS menu_based_service_name,
                    mbsf.id,
                    mbsf.`name`,
                    mbsf.facility_count,
                    mbsf.discount,
                    mbsf.price,
                    mbsf.is_package,
                    mbsf.gender,
                    mbsf.time,
                    mbsf.category,
                    haversine ( '" . $latitude . "', '" . $longitude . "', mbss.latitude, mbss.longitude ) AS menu_based_service_distance 
                FROM
                    ( SELECT mbss.*, haversine ( '" . $latitude . "', '" . $longitude . "', mbss.latitude, mbss.longitude ) AS 'distance' FROM menu_based_service_search mbss ORDER BY distance ) mbss
                    JOIN menu_based_service AS mbs ON mbss.menu_based_service_id = mbs.id
                    JOIN menu_based_service_facility AS mbsf ON mbs.id = mbsf.menu_based_service_id 
                WHERE
                    mbs.status_id = " . STATUS_ACTIVE . " 
                    AND mbsf.status_id = " . STATUS_ACTIVE . " 
                    AND mbss.category_id=" . $input['category_id'] . "
                    AND ( mbss.pincode = '" . $pincode . "' OR mbss.distance < " . MENU_BASED_SERVICE_DISTANCE . " )";
            if (isset($input['is_package'])) {
                $query .= " AND mbsf.is_package=" . $input['is_package'];
            }
            if (!empty($input['name'])) {
                $name = $input['name'];
                $query .= " AND mbsf.name like '%" . $name . "%' ";
            }
            $query .= " GROUP BY
                    mbs.id 
                ORDER BY
                    mbss.distance 
                LIMIT 30 OFFSET 0";
            return executeSelectQueryOnMySQLDB($query);
        } catch (Exception $exc) {
            errorLog($exc);
        }
        return error(COMMON_ERROR);
    }
//JOIN lab_test AS lt ON ((l.self_test_available = 1 AND l.id = lt.lab_id) OR ((l.self_test_available is null OR l.self_test_available != 1) AND l.parent_id = lt.lab_id))
}
