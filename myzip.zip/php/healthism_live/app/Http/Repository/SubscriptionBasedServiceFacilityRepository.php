<?php

namespace App\Http\Repository;

class SubscriptionBasedServiceFacilityRepository {

    public function getFacilityFromLocation($latitude, $longitude, $pincode, $input) {
        try {
            $limit = 30;
            $page = !empty($input['page']) ? $input['page'] : 1;
            $skip = $page > 1 ? ($page * $limit) - $limit : 0;
            $query = "SELECT
                            sbs.id AS subscription_based_service_id,
                            sbs.`name` AS subscription_based_service_name,
                            sbsf.id,
                            sbsf.`name`,
                            sbsf.discount,
                            sbsf.price,
                            sbsf.gender,
                            sbsf.days,
                            haversine ( '" . $latitude . "', '" . $longitude . "', sbss.latitude, sbss.longitude ) AS subscription_based_service_distance 
                        FROM
                            ( SELECT sbss.*, haversine ( '" . $latitude . "', '" . $longitude . "', sbss.latitude, sbss.longitude ) AS 'distance' FROM subscription_based_service_search sbss ORDER BY distance ) sbss
                            JOIN subscription_based_service AS sbs ON sbss.subscription_based_service_id = sbs.id
                            JOIN subscription_based_service_facility AS sbsf ON sbs.id = sbsf.subscription_based_service_id 
                        WHERE
                            sbs.status_id = " . STATUS_ACTIVE . " 
                            AND sbsf.status_id = " . STATUS_ACTIVE . " 
                            AND sbss.category_id=" . $input['category_id'] . "
                            AND ( sbss.pincode = '" . $pincode . "' OR sbss.distance < " . SUBSCRIPTION_BASED_SERVICE_DISTANCE . " )";
            if (!empty($input['name'])) {
                $name = $input['name'];
                $query .= " AND sbsf.name like '%" . $name . "%' ";
            }
            if (!empty($input['sub_category_id'])) {
                $subCategory = "," . $input['sub_category_id'] . ",";
                $query .= " AND sbsf.sub_category_ids like '%" . $subCategory . "%' ";
            }
            $query .= " GROUP BY
                    sbs.id 
                ORDER BY
                    sbss.distance ";
            $query .= " LIMIT " . $limit . " OFFSET " . $skip;
            return executeSelectQueryOnMySQLDB($query);
        } catch (Exception $exc) {
            errorLog($exc);
        }
        return error(COMMON_ERROR);
    }

}
