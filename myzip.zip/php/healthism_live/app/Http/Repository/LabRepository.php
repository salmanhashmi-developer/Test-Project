<?php

namespace App\Http\Repository;

class LabRepository {

    function getTestFromLocation($latitude, $longitude, $pincode, $input) {
        try {
            $query = "SELECT
                    l.id AS lab_id,
                    l.`name` AS lab_name,
                    l.`area` AS lab_area,
                    lt.id,
                    lt.`name`,
                    lt.test_count,
                    lt.discount,
                    lt.price,
                    lt.is_package,
                    haversine ( '" . $latitude . "', '" . $longitude . "', ls.latitude, ls.longitude ) AS lab_distance 
                FROM
                    ( SELECT ls.*, haversine ( '" . $latitude . "', '" . $longitude . "', ls.latitude, ls.longitude ) AS 'distance' FROM lab_search ls ORDER BY distance ) ls
                    JOIN lab AS l ON ls.lab_id = l.id
                    JOIN lab_test AS lt ON ((l.self_test_available = 1 AND l.id = lt.lab_id) OR ((l.self_test_available is null OR l.self_test_available != 1) AND l.parent_id = lt.lab_id))
                WHERE
                    l.status_id = " . STATUS_ACTIVE . " 
                    AND lt.status_id = " . STATUS_ACTIVE . " 
                    AND ( ls.pincode = '" . $pincode . "' OR ls.distance < " . LAB_DISTANCE . " )";
            if (isset($input['is_package'])) {
                $query .= " AND lt.is_package=" . $input['is_package'];
            }
            if (!empty($input['name'])) {
                $name = $input['name'];
                $query .= " AND lt.name like '%" . $name . "%' ";
            }
// $query .= " GROUP BY l.id ";
            $query .= " GROUP BY lt.id ";
            $query .= " ORDER BY
                    ls.distance 
                LIMIT 30 OFFSET 0";
            return executeSelectQueryOnMySQLDB($query);
        } catch (Exception $exc) {
            errorLog($exc);
        }
        return error(COMMON_ERROR);
    }

    function getTopTestOrPackage($latitude, $longitude, $pincode, $input) {
        try {
            $query = "SELECT 
                            temp.*,
                            lt.id,
                            lt.name,
                            lt.test_count,
                            lt.discount,
                            lt.price,
                            lt.is_package FROM 
                        (
                            SELECT
                                l.id AS lab_id,
                                l.name AS lab_name,
                                l.area AS lab_area,
                                haversine ( '" . $latitude . "', '" . $longitude . "', ls.latitude, ls.longitude ) AS lab_distance,
                                    IF(l.self_test_available = 1, l.id, l.parent_id) as id_for_lab_test
                            FROM
                                ( SELECT ls.*, haversine ( '" . $latitude . "', '" . $longitude . "', ls.latitude, ls.longitude ) AS 'distance' FROM lab_search ls ORDER BY distance ) ls
                                JOIN lab AS l ON ls.lab_id = l.id
                            WHERE
                                l.status_id = " . STATUS_ACTIVE . "   
                                AND ( ls.pincode = '" . $pincode . "' OR ls.distance < " . LAB_DISTANCE . " ) 
                            GROUP BY
                                l.id 
                            ORDER BY
                                ls.distance 
                                LIMIT 30 OFFSET 0
                        ) temp,
                        lab_test lt 
                            WHERE 
                                lt.lab_id = temp.id_for_lab_test 
                                AND lt.status_id = " . STATUS_ACTIVE;
            if (isset($input['is_package'])) {
                $query .= " AND lt.is_package=" . $input['is_package'];
            }
            if (!empty($input['name'])) {
                $name = $input['name'];
                $query .= " AND lt.name like '%" . $name . "%' ";
            }
            $query .= " GROUP BY
                            lt.id
                        ORDER BY
                            temp.lab_distance
                        LIMIT 30 OFFSET 0 ";
            return executeSelectQueryOnMySQLDB($query);
        } catch (Exception $exc) {
            errorLog($exc);
        }
        return error(COMMON_ERROR);
    }

}
