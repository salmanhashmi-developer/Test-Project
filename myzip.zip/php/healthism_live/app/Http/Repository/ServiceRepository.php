<?php

namespace App\Http\Repository;

class ServiceRepository {

    function updateDoctorAppointmentBooking($orderDetailData) {
        $statusId = $orderDetailData->status_id == STATUS_DONE ? STATUS_SUCCESS : STATUS_FAILED;
        $appintmentData = \App\Models\DoctorAppointmentBooking::where('id', $orderDetailData->ref_id)->first();
        $appintmentData->update(
                array(
                    'status_id' => $statusId,
                    'updated_at' => date('Y-m-d H:i:s'),
                    'order_id' => $orderDetailData->order_id
                )
        );
    }

    function updateLabAppointmentBooking($orderDetailData) {
        $statusId = $orderDetailData->status_id == STATUS_DONE ? STATUS_SUCCESS : STATUS_FAILED;
        $appintmentData = \App\Models\LabBooking::where('id', $orderDetailData->ref_id)->first();
        $appintmentData->update(
                array(
                    'status_id' => $statusId,
                    'updated_at' => date('Y-m-d H:i:s'),
                    'order_id' => $orderDetailData->order_id
                )
        );
    }

    function updateMBSAppointmentBooking($orderDetailData) {
        $statusId = $orderDetailData->status_id == STATUS_DONE ? STATUS_SUCCESS : STATUS_FAILED;
        $appintmentData = \App\Models\MenuBasedServiceBooking::where('id', $orderDetailData->ref_id)->first();
        $appintmentData->update(
                array(
                    'status_id' => $statusId,
                    'updated_at' => date('Y-m-d H:i:s'),
                    'order_id' => $orderDetailData->order_id
                )
        );
    }

    function updateSBSAppointmentBooking($orderDetailData) {
        $statusId = $orderDetailData->status_id == STATUS_DONE ? STATUS_SUCCESS : STATUS_FAILED;
        $appintmentData = \App\Models\SubscriptionBasedService::where('id', $orderDetailData->ref_id)->first();
        if (!empty($appintmentData)) {
            $appintmentData->update(
                    array(
                        'status_id' => $statusId,
                        'updated_at' => date('Y-m-d H:i:s'),
                        'order_id' => $orderDetailData->order_id
                    )
            );
        }
    }

    function updateUserSubscription($orderDetailData) {
        $statusId = $orderDetailData->status_id == STATUS_DONE ? STATUS_ACTIVE : STATUS_FAILED;
        $userSubscription = \App\Models\UserSubscription::where('id', $orderDetailData->ref_id)->first();
        if ($orderDetailData->status_id == STATUS_DONE) {
            \App\Models\UserSubscription::where('user_id', $userSubscription->user_id)
                    ->update(array('status_id' => STATUS_INACTIVE, 'updated_at' => date('Y-m-d H:i:s')));

            \App\Models\UserFamilyMember::where('user_id', $userSubscription->user_id)
                    ->update(array('status_id' => STATUS_INACTIVE, 'updated_at' => date('Y-m-d H:i:s')));

            $loginUser = \App\Models\User::findOrFail($userSubscription->user_id);

            if (!empty($loginUser) && !empty($loginUser->mobile)) {
                \App\Models\UserFamilyMember::where('mobile', $loginUser->mobile)
                        ->update(array('status_id' => STATUS_INACTIVE, 'updated_at' => date('Y-m-d H:i:s')));
            }

            $userSubscription->update(array('status_id' => $statusId, 'updated_at' => date('Y-m-d H:i:s'), 'order_id' => $orderDetailData->order_id));
        } else {
            $userSubscription->update(array('status_id' => $statusId, 'updated_at' => date('Y-m-d H:i:s'), 'order_id' => $orderDetailData->order_id, 'card_no' => null));
        }
    }

}
