<?php

namespace App\Http\Repository;

use App\Models\OfferCode;
use App\Models\OfferCodeTrack;

class OfferRepository {

    function applyOfferCode($code, $serviceId, $userId, $amount) {
        $validation = $this->validateCode($code, $serviceId, $userId, $amount);
        if ($validation['code'] == 0) {
            return $validation;
        }
        $codeDetail = $validation['data'];
        if ($codeDetail->offer->discount_type == 1) {
            //Flat Discount
            $discount = !empty($codeDetail->offer->max_discount_per_user) && $codeDetail->offer->max_discount_per_user > 0 ? $codeDetail->offer->max_discount_per_user : $codeDetail->offer->max_discount_txn;
        } else {
            //Percentage Discount
            $discount = ($amount * $codeDetail->offer->max_discount_txn) / 100;
            if (!empty($codeDetail->offer->max_discount_per_user) && $codeDetail->offer->max_discount_per_user > 0) {
                if ($discount > $codeDetail->offer->max_discount_per_user) {
                    $discount = $codeDetail->offer->max_discount_per_user;
                }
            }
        }
        if ($discount > $amount) {
            $discount = $amount;
        }
        return ['code' => 1, 'promo_code_discount' => $discount, 'code_data' => $codeDetail];
    }

    function validateCode($code, $serviceId, $userId, $amount) {
        $response = ['code' => 0, 'message' => ""];
        $codeDetail = OfferCode::where('name', $code)->first();
        if (empty($codeDetail)) {
            $response['message'] = "Sorry, Invalid promo code.";
            return $response;
        }

        $now = strtotime(date('Y-m-d H:i:s'));

        /*         * **************************************** */
        /* Check offer code validation */
        /*         * **************************************** */
        if ($codeDetail->status_id == STATUS_USED) {
            $response['message'] = "Sorry, Promo code is already used.";
            return $response;
        }
        if ($codeDetail->status_id == STATUS_INACTIVE) {
            $response['message'] = "Sorry, Promo code is inactive.";
            return $response;
        }
        if (!empty($codeDetail->user_id)) {
            if ($codeDetail->user_id != $userId) {
                $response['message'] = "Sorry, Promo code not for you.";
                return $response;
            }
        }
        $expiry = strtotime($codeDetail->expiration_time);
        if ($now > $expiry) {
            $response['message'] = "Sorry, Promo code is expired.";
            return $response;
        }

        /*         * **************************************** */
        /* Check offer validation */
        /*         * **************************************** */
        if (empty($codeDetail->offer)) {
            $response['message'] = "Sorry, Offer is not found.";
            return $response;
        }
        if ($codeDetail->offer->is_active != 1) {
            $response['message'] = "Sorry, Offer is inactive.";
            return $response;
        }
        $start = strtotime($codeDetail->offer->start_time);
        $end = strtotime($codeDetail->offer->end_time);
        if ($now > $end) {
            $response['message'] = "Sorry, Offer is expired.";
            return $response;
        }
        if ($now < $start) {
            $response['message'] = "Sorry, Offer is not started.";
            return $response;
        }
        if ($codeDetail->offer->max_code_use > 0) {
            if ($codeDetail->offer->used_count >= $codeDetail->offer->max_code_use) {
                $response['message'] = "Sorry, Offer is over.";
                return $response;
            }
        }
        if ($codeDetail->offer->min_txn_amount > $amount) {
            $response['message'] = "Sorry, Cart value should be minimum " . $codeDetail->offer->min_txn_amount . " Rs";
            return $response;
        }
        if (!empty($codeDetail->offer->service_ids)) {
            $serviceIdArr = explode(',', $codeDetail->offer->service_ids);
            if (!empty($serviceIdArr)) {
                if (!in_array($serviceId, $serviceIdArr)) {
                    $response['message'] = "Sorry, Offer is not for this service.";
                    return $response;
                }
            }
        }
        if (!empty($codeDetail->offer->max_offer_use) && $codeDetail->offer->max_offer_use > 0) {
//            $codeUsedCount = OfferCodeTrack::where('offer_id', $codeDetail->offer_id)
//                    ->where('status_id', STATUS_SUCCESS)
//                    ->count();
            if ($codeDetail->offer->used_count >= $codeDetail->offer->max_offer_use) {
                $response['message'] = "Sorry, offer is over. Only first " . $codeDetail->offer->max_offer_use . " users get benefits of the offer";
                return $response;
            }
        }
        /*         * **************************************** */
        /* Check offer code tarck validation */
        /*         * **************************************** */

        if ($codeDetail->offer->fix_code == 1) {
            $codeTrack = OfferCodeTrack::where('offer_id', $codeDetail->offer_id)
                    ->where('user_id', $userId)
                    ->where('status_id', STATUS_SUCCESS)
                    ->count();
        } else {
            $codeTrack = OfferCodeTrack::where('offer_id', $codeDetail->offer_id)
                    ->where('offer_code_id', $codeDetail->id)
                    ->where('status_id', STATUS_SUCCESS)
                    ->count();
        }
        if ($codeDetail->offer->max_offer_use_per_user > 0 && $codeTrack >= $codeDetail->offer->max_offer_use_per_user) {
//            $response['message'] = "Sorry, This offer/promo code is only " . $codeDetail->offer->max_offer_use_per_user . " time use per user";
            $response['message'] = "Sorry, Promo code is already used.";
            return $response;
        }
        return ['code' => 1, 'data' => $codeDetail];
    }

    function checkPromoCodeApply($orderId, $orderStatus) {
        $response = array('code' => 0, 'message' => COMMON_ERROR);
        try {
            $orderPromoCode = getRedisData(KEY_PROMO_CODE_ORDER . "_" . $orderId);
            if (empty($orderPromoCode)) {
                return array('code' => 1);
            }
            if ($orderStatus == STATUS_DONE) {
                $validation = $this->validateCode($orderPromoCode['promo_code'], $orderPromoCode['service_id'], $orderPromoCode['user_id'], $orderPromoCode['order_sub_total']);
                paymentLog("sdfds", $orderPromoCode, []);
                if ($validation['code'] == 1) {
                    $offerCodeTrack['status_id'] = STATUS_SUCCESS;
                } else {
                    $offerCodeTrack['status_id'] = STATUS_FAILED;
                }
            } else {
                $offerCodeTrack['status_id'] = STATUS_FAILED;
            }
            $codeDetail = $validation['data']->toArray();
            $offerCodeTrack['benifit_amount'] = $orderPromoCode['promo_code_discount'];
            $offerCodeTrack['benifit_time'] = date('Y-m-d H:i:s');
            $offerCodeTrack['complimentary_offer_code'] = $orderPromoCode['promo_code'];
            $offerCodeTrack['offer_id'] = $codeDetail['offer_id'];
            $offerCodeTrack['order_amount'] = $orderPromoCode['order_sub_total'];
            $offerCodeTrack['order_id'] = $orderPromoCode['order_code'];
            $offerCodeTrack['service_id'] = $orderPromoCode['service_id'];
            $offerCodeTrack['user_id'] = $orderPromoCode['user_id'];
            $offerCodeTrack['offer_code_id'] = $codeDetail['id'];
            $insertedData = $this->addOfferCodeTrack($offerCodeTrack);
            if (!empty($insertedData) && $insertedData->status_id == STATUS_SUCCESS) {
                $this->offerCodeUpdate($codeDetail, $orderPromoCode['user_id']);
                $this->offerUpdate($codeDetail);
            }
            deleteRedisData(KEY_PROMO_CODE_ORDER . "_" . $orderId);
            return $validation;
        } catch (Exception $exc) {
            errorLog($exc);
        }
        return $response;
    }

    function addOfferCodeTrack($offerCodeTrack) {
        $offerCodeTrack['created_at'] = date('Y-m-d H:i:s');
        $offerCodeTrack['benifit_time'] = date('Y-m-d H:i:s');
        return OfferCodeTrack::create($offerCodeTrack);
    }

    function offerCodeUpdate($codeDetail, $userId) {
        if ($codeDetail['offer']['fix_code'] != 1) {
            $code = OfferCode::where('id', $codeDetail['id'])->first();
            if (!empty($code)) {
                $code->update(array(
                    'status_id' => STATUS_USED,
                    'updated_at' => date('Y-m-d H:i:s'),
                    'user_id' => $userId
                ));
            }
        }
    }

    function offerUpdate($codeDetail) {
        if ($codeDetail['offer_id']) {
            $offer = \App\Models\Offer::where('id', $codeDetail['offer_id'])->first();
            if (!empty($offer)) {
                $count = $offer->used_count + 1;
                $offer->update(array(
                    'updated_at' => date('Y-m-d H:i:s'),
                    'used_count' => $count
                ));
            }
        }
    }

}
