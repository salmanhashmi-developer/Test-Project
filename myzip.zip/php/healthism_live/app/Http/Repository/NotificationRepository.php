<?php

namespace App\Http\Repository;

class NotificationRepository {
    /*     * ******************************************* */
    /*              DOCTOR APPOINTMENT                   */
    /*     * ******************************************* */

    function doctorAppointmentNotification($orderId, $action, $extraData = []) {
        try {
            $mainOrder = \App\Models\Orders::where('id', $orderId)->with('detail', 'payment', 'payment.paymentmode', 'user')->first();
            if (empty($mainOrder)) {
                return FALSE;
            }
            $orderDetail = $mainOrder->detail;
            if (empty($orderDetail[0])) {
                return FALSE;
            }
            $appintmentData = \App\Models\DoctorAppointmentBooking::where('id', $orderDetail[0]->ref_id)->first();
            if (empty($appintmentData)) {
                return FALSE;
            }
            if (!empty($appintmentData->doctor->user_id)) {
                $doctorUser = \App\Models\User::where('id', $appintmentData->doctor->user_id)->first();
                $appintmentData->partner_mobile = $doctorUser->mobile;
                $appintmentData->partner_email = $doctorUser->email;
            }
            if ($action == "DONE") {
                $this->doctorAppointmentDone($mainOrder, $appintmentData);
            }
            if ($action == "RESCHEDULE") {
                $this->doctorAppointmentReschedule($mainOrder, $appintmentData, $extraData['old_date']);
            }
            if ($action == "CANCELLED") {
                $this->doctorAppointmentCancelled($mainOrder, $appintmentData);
            }
            if ($action == "REMINDER") {
                $this->doctorAppointmentReminder($mainOrder, $appintmentData);
            }
        } catch (Exception $exc) {
            notificationErrorLog($exc);
        }
    }

    function doctorAppointmentDone($mainOrder, $appintmentData) {
        try {
            $notificationData['user_name'] = $mainOrder->user->first_name . ' ' . $mainOrder->user->last_name;
            $notificationData['email'] = $mainOrder->user->email;
            $notificationData['mobile'] = $mainOrder->user->mobile;
            $notificationData['user_mobile'] = $mainOrder->user->mobile;
            $notificationData['order_code'] = $mainOrder->order_code;
            $notificationData['doctor_name'] = $appintmentData->doctor->first_name . ' ' . $appintmentData->doctor->last_name;
            $notificationData['date_time'] = date_format(date_create($appintmentData->appointment_date), "d/m/Y") . ' ' . $appintmentData->appointment_time;
            $notificationData['patient_name'] = $appintmentData->patient_name;
            $notificationData['hospital_name'] = $appintmentData->hospital->name;
            $notificationData['hospital_phone'] = $appintmentData->hospital->phone;
            $notificationData['hospital_address1'] = $appintmentData->hospital->address1 . ',' . $appintmentData->hospital->address2;
            $notificationData['hospital_address2'] = $appintmentData->hospital->area . ',' . $appintmentData->hospital->city->name . ',' . $appintmentData->hospital->state->name . '.-' . $appintmentData->hospital->pincode;
            $notificationData['amount'] = $mainOrder->amount;
            $notificationData['payment_mode'] = $mainOrder->payment->paymentmode->name;
            $notificationData['user_id'] = $mainOrder->user->id;
            $notificationData['title'] = "Healthismplus : Doctor appointment done";
            $notificationData['type'] = "DOCTOR_APPOINTMENT";
            notification($notificationData, 'DOCTOR_APPOINTMENT', 'DONE', 'USER');
            //SEND NOTIFICATION TO PARTNER
            $notificationData['email'] = !empty($appintmentData->partner_email) ? $appintmentData->partner_email : '';
            $notificationData['mobile'] = !empty($appintmentData->partner_mobile) ? $appintmentData->partner_mobile : '';
            notification($notificationData, 'DOCTOR_APPOINTMENT', 'DONE', 'PARTNER');
            //SEND NOTIFICATION TO ADMIN
            $notificationData['email'] = env('ADMIN_EMAIL_FOR_NOTIFICATION');
            $notificationData['mobile'] = env('ADMIN_MOBILE_FOR_NOTIFICATION');
            $notificationData['admin_email_name'] = ADMIN_EMAIL_NAME;
            notification($notificationData, 'DOCTOR_APPOINTMENT', 'DONE', 'ADMIN');
        } catch (Exception $exc) {
            notificationErrorLog($exc);
        }
    }

    function doctorAppointmentReschedule($mainOrder, $appintmentData, $oldDate) {
        try {
            $notificationData['user_name'] = $mainOrder->user->first_name . ' ' . $mainOrder->user->last_name;
            $notificationData['email'] = $mainOrder->user->email;
            $notificationData['mobile'] = $mainOrder->user->mobile;
            $notificationData['order_code'] = $mainOrder->order_code;
            $notificationData['doctor_name'] = $appintmentData->doctor->first_name . ' ' . $appintmentData->doctor->last_name;
            $notificationData['date_time'] = $oldDate;
            $notificationData['rescheduled_date'] = date_format(date_create($appintmentData->appointment_date), "d/m/Y") . ' ' . $appintmentData->appointment_time;
            $notificationData['patient_name'] = $appintmentData->patient_name;
            $notificationData['hospital_name'] = $appintmentData->hospital->name;
            $notificationData['hospital_phone'] = $appintmentData->hospital->phone;
            $notificationData['hospital_address1'] = $appintmentData->hospital->address1 . ',' . $appintmentData->hospital->address2;
            $notificationData['hospital_address2'] = $appintmentData->hospital->area . ',' . $appintmentData->hospital->city->name . ',' . $appintmentData->hospital->state->name . '.-' . $appintmentData->hospital->pincode;
            $notificationData['amount'] = $mainOrder->amount;
            $notificationData['payment_mode'] = $mainOrder->payment->paymentmode->name;
            $notificationData['user_id'] = $mainOrder->user->id;
            $notificationData['title'] = "Healthismplus : Doctor appointment reschedule";
            $notificationData['type'] = "DOCTOR_APPOINTMENT";
            notification($notificationData, 'DOCTOR_APPOINTMENT', 'RESCHEDULE');
        } catch (Exception $exc) {
            notificationErrorLog($exc);
        }
    }

    function doctorAppointmentCancelled($mainOrder, $appintmentData) {
        try {

            $notificationData['user_name'] = $mainOrder->user->first_name . ' ' . $mainOrder->user->last_name;
            $notificationData['email'] = $mainOrder->user->email;
            $notificationData['mobile'] = $mainOrder->user->mobile;
            $notificationData['order_code'] = $mainOrder->order_code;
            $notificationData['doctor_name'] = $appintmentData->doctor->first_name . ' ' . $appintmentData->doctor->last_name;
            $notificationData['date_time'] = date_format(date_create($appintmentData->appointment_date), "d/m/Y") . ' ' . $appintmentData->appointment_time;
            $notificationData['patient_name'] = $appintmentData->patient_name;
            $notificationData['hospital_name'] = $appintmentData->hospital->name;
            $notificationData['hospital_phone'] = $appintmentData->hospital->phone;
            $notificationData['hospital_address1'] = $appintmentData->hospital->address1 . ',' . $appintmentData->hospital->address2;
            $notificationData['hospital_address2'] = $appintmentData->hospital->area . ',' . $appintmentData->hospital->city->name . ',' . $appintmentData->hospital->state->name . '.-' . $appintmentData->hospital->pincode;
            $notificationData['amount'] = $mainOrder->amount;
            $notificationData['payment_mode'] = $mainOrder->payment->paymentmode->name;
            $notificationData['user_id'] = $mainOrder->user->id;
            $notificationData['title'] = "Healthismplus : Doctor appointment cancelled";
            $notificationData['type'] = "DOCTOR_APPOINTMENT";
            notification($notificationData, 'DOCTOR_APPOINTMENT', 'CANCELLED');
        } catch (Exception $exc) {
            notificationErrorLog($exc);
        }
    }

    function doctorAppointmentReminder($mainOrder, $appintmentData) {
        try {
            $appointmentTime = $appintmentData['appointment_date'] . ' ' . $appintmentData['appointment_time'];
            $notificationData['doctor_detail'] = $appintmentData->doctor->first_name . ' ' . $appintmentData->doctor->last_name;
            $notificationData['date_time'] = date_format(date_create($appointmentTime), "d/m/Y h:i A");
            $notificationData['user_id'] = $mainOrder->user->id;
            $notificationData['title'] = "Healthismplus : Doctor appointment reminder";
            $notificationData['type'] = "DOCTOR_APPOINTMENT";
            notification($notificationData, 'DOCTOR_APPOINTMENT', 'REMINDER');
        } catch (Exception $exc) {
            notificationErrorLog($exc);
        }
    }

    /*     * ******************************************* */
    /*                      SUBSCRIPTION                 */
    /*     * ******************************************* */

    function subscriptionNotification($orderId, $action, $extraData = []) {
        try {
            $mainOrder = \App\Models\Orders::where('id', $orderId)->with('detail', 'payment', 'payment.paymentmode', 'user')->first();
            if (empty($mainOrder)) {
                return FALSE;
            }
            $orderDetail = $mainOrder->detail;
            if (empty($orderDetail[0])) {
                return FALSE;
            }
            $userSubscription = \App\Models\UserSubscription::where('id', $orderDetail[0]->ref_id)->first();
            if (empty($userSubscription)) {
                return FALSE;
            }
            $userData = \App\Models\User::findOrFail($userSubscription->user_id);
            if (empty($userData)) {
                return FALSE;
            }
            if ($action == "DONE") {
                $activePlan = \App\Models\UserSubscription::where('status_id', STATUS_ACTIVE)
                        ->where('user_id', $userData->user_id)
                        ->count();
                if (!empty($activePlan) && $activePlan > 0) {
                    $this->subscriptionUpgread($userData, $userSubscription, $mainOrder);
                } else {
                    $this->subscriptionDone($userData, $userSubscription, $mainOrder);
                }
            }
        } catch (Exception $exc) {
            notificationErrorLog($exc);
        }
    }

    function subscriptionDone($userData, $userSubscription, $mainOrder) {
        try {
            $notificationData['user_name'] = $userData->first_name . ' ' . $userData->last_name;
            $notificationData['email'] = $userData->email;
            $notificationData['mobile'] = $userData->mobile;
            $notificationData['plan_name'] = $userSubscription->subscription->name;
            $notificationData['member_count'] = '(' . $userSubscription->subscription->member . ' Member)';
            $notificationData['expiry_date'] = date_format(date_create($userSubscription->expiry_date), "d-M-Y");
            $notificationData['card_no'] = $userSubscription->card_no;
            $notificationData['amount'] = $mainOrder->amount;
            $notificationData['payment_mode'] = $mainOrder->payment->paymentmode->name;
            $notificationData['user_id'] = $userData->id;
            $notificationData['type'] = "SUBSCRIPTION_PLAN";
            $notificationData['title'] = "Healthismplus - Subscription plan buy successfully ";
            if ($userSubscription->subscription_id == 8) {
                //special offer
                notification($notificationData, 'SUBSCRIPTION_PLAN', 'DONE', 'USER_SP_8_BUY');
            } else {
                notification($notificationData, 'SUBSCRIPTION_PLAN', 'DONE', 'USER_BUY');
            }
        } catch (Exception $exc) {
            notificationErrorLog($exc);
        }
    }

    function subscriptionUpgread($userData, $userSubscription, $mainOrder) {
        try {
            $notificationData['user_name'] = $userData->first_name . ' ' . $userData->last_name;
            $notificationData['email'] = $userData->email;
            $notificationData['mobile'] = $userData->mobile;
            $notificationData['plan_name'] = $userSubscription->subscription->name . '(' . $userSubscription->subscription->member . ' Member)';
            $notificationData['expiry_date'] = date_format(date_create($userSubscription->expiry_date), "d-M-Y");
            $notificationData['card_no'] = $userSubscription->card_no;
            $notificationData['amount'] = $mainOrder->amount;
            $notificationData['payment_mode'] = $mainOrder->payment->paymentmode->name;
            $notificationData['user_id'] = $userData->id;
            $notificationData['type'] = "SUBSCRIPTION_PLAN";
            $notificationData['title'] = "HealthismPlus - Subscription plan upgraded successfully";
            notification($notificationData, 'SUBSCRIPTION_PLAN', 'DONE', 'USER_UPGRADE');
        } catch (Exception $exc) {
            notificationErrorLog($exc);
        }
    }

    /*     * ******************************************* */
    /*                          USER                     */
    /*     * ******************************************* */

    function userNotification($userId, $action, $extraData = []) {
        try {
            if (!empty($userId)) {
                $userData = \App\Models\User::where('id', $userId)->first();
                if (empty($userData)) {
                    return FALSE;
                }
                if ($action == "MEMBER_ADD") {
                    $this->familyMemberAdd($userData, $extraData);
                }
                if ($action == "WELCOME") {
                    $this->welcomeMail($userData);
                }
                if ($action == "EMAIL_UPDATE_OTP") {
                    $this->emailUpdate($userData, $extraData);
                }
            }
            if ($action == "SIGN_IN_OTP") {
                $this->verifyMobile($extraData);
            }
        } catch (Exception $exc) {
            notificationErrorLog($exc);
        }
    }

    function familyMemberAdd($userData, $extraData) {
        try {
            $notificationData['user_name'] = $userData->first_name . ' ' . $userData->last_name;
            $notificationData['email'] = $userData->email;
            $notificationData['mobile'] = $userData->mobile;
            $notificationData['member_name'] = $extraData['member_name'];
            $notificationData['left_member_count'] = $extraData['left_member_count'];
            $notificationData['user_id'] = $userData->id;
            $notificationData['title'] = "Healthismplus - Add new family member ";
            $notificationData['type'] = "USER";
            notification($notificationData, 'USER', 'MEMBER_ADD');
        } catch (Exception $exc) {
            notificationErrorLog($exc);
        }
    }

    function welcomeMail($userData) {
        try {
            $notificationData['user_name'] = $userData->first_name . ' ' . $userData->last_name;
            $notificationData['email'] = $userData->email;
            $notificationData['user_id'] = $userData->id;
            $notificationData['title'] = "Welcome to HealthismPlus! ";
            $notificationData['type'] = "USER";
            notification($notificationData, 'USER', 'WELCOME');
        } catch (Exception $exc) {
            notificationErrorLog($exc);
        }
    }

    function emailUpdate($userData, $extraData) {
        try {
            $notificationData['user_name'] = $userData->first_name . ' ' . $userData->last_name;
            $notificationData['email'] = $extraData['email'];
            $notificationData['otp'] = $extraData['otp'];
            $notificationData['user_id'] = $userData->id;
            $notificationData['title'] = "HealthismPlus - Update email ";
            $notificationData['type'] = "USER";
            notification($notificationData, 'USER', 'EMAIL_UPDATE_OTP');
        } catch (Exception $exc) {
            notificationErrorLog($exc);
        }
    }

    function verifyMobile($extraData) {
        try {
            $notificationData['mobile'] = $extraData['mobile'];
            $notificationData['otp'] = $extraData['otp'];
            $notificationData['app_unique_id'] = APP_UNIQUE_ID;
            notification($notificationData, 'USER', 'SIGN_IN_OTP');
        } catch (Exception $exc) {
            notificationErrorLog($exc);
        }
    }

    /*     * ******************************************* */
    /*              COMMON SERVICE                       */
    /*     * ******************************************* */

    function commonServiceEnquiryNotification($enquiryId, $action, $extraData = []) {
        try {
            $enquiry = \App\Models\CommonServiceEnquiry::where('id', $enquiryId)->with('common_service', 'common_service.city', 'common_service.state', 'common_service.category')->first();
            if (empty($enquiry)) {
                return FALSE;
            }
            if (empty($enquiry['common_service'])) {
                return FALSE;
            }
            if ($action == "DONE") {
                $this->commonServiceEnquiryDone($enquiry);
            }
        } catch (Exception $exc) {
            notificationErrorLog($exc);
        }
    }

    function commonServiceEnquiryDone($enquiry) {
        try {
            $notificationData['user_name'] = $enquiry['name'] . '(' . $enquiry['mobile'] . ')';
            $notificationData['user_mobile'] = $enquiry['mobile'];
            $notificationData['partner_name'] = $enquiry['common_service']['name'] . '(' . $enquiry['common_service']['category']['name'] . ')';
            $notificationData['partner_phone'] = $enquiry['common_service']['phone'] . "," . $enquiry['common_service']['mobile'];
            $notificationData['partner_address'] = $enquiry['common_service']['address1'] . ',' . $enquiry['common_service']['address2'] . ',' . $enquiry['common_service']['area'] . ',' . $enquiry['common_service']['city']['name'] . ',' . $enquiry['common_service']['state']['name'] . '-' . $enquiry['common_service']['pincode'] . '.';
            $notificationData['description'] = $enquiry['description'];
            $notificationData['date_time'] = date_format(date_create($enquiry['appointment_date']), "d/m/Y");
            $notificationData['title'] = "HealthismPlus - Send Enquiry ";
            $notificationData['type'] = "COMMON_SERVICE";
            //SEND NOTIFICATION TO ADMIN
            $notificationData['mobile'] = env('ADMIN_MOBILE_FOR_NOTIFICATION');
            $notificationData['email'] = env('ADMIN_EMAIL_FOR_NOTIFICATION');
            $notificationData['admin_email_name'] = ADMIN_EMAIL_NAME;
            notification($notificationData, 'COMMON_SERVICE', 'DONE', 'ADMIN');
        } catch (Exception $exc) {
            notificationErrorLog($exc);
        }
    }

    /*     * ******************************************* */
    /*              LAB SERVICE                          */
    /*     * ******************************************* */

    function labAppointmentNotification($orderId, $action, $extraData = []) {
        try {
            $mainOrder = \App\Models\Orders::where('id', $orderId)->with('detail', 'payment', 'payment.paymentmode', 'user')->first();
            if (empty($mainOrder)) {
                return FALSE;
            }
            $orderDetail = $mainOrder->detail;
            if (empty($orderDetail[0])) {
                return FALSE;
            }
            $appintmentData = \App\Models\LabBooking::where('id', $orderDetail[0]->ref_id)->first();
            if (empty($appintmentData)) {
                return FALSE;
            }
            if (empty($appintmentData->labBookingDetail)) {
                return FALSE;
            }
            $testDataHTML = "";
            $testNameStr = "";
            foreach ($appintmentData->labBookingDetail as $key => $value) {
                if ($key != 0) {
                    $testNameStr .= ',';
                }
                $testNameStr .= $value->test->name;
                $testDataHTML .= ++$key . ". " . $value->test->name . '<br>';
                $testDataHTML .= ' <span style="font-weight: normal;font-size: 12px;padding-bottom: 10px;">Instruction: ' . $value->test->preparation . '</span><br><br>';
            }

            $appintmentData['test_data'] = $testDataHTML;
            $time = strtotime($appintmentData->appointment_date . ' ' . $appintmentData->appointment_time);
            $appintmentData['date_time'] = date('d/M/Y h:i A', $time);
            if (!empty($appintmentData->lab->user_id)) {
                $labUser = \App\Models\User::where('id', $appintmentData->lab->user_id)->first();
                $appintmentData->partner_mobile = $labUser->mobile;
                $appintmentData->partner_email = $labUser->email;
            }
            if ($action == "DONE") {
                $this->labAppointmentDone($mainOrder, $appintmentData);
            }
            if ($action == "RESCHEDULE") {
                $this->labAppointmentReschedule($mainOrder, $appintmentData, $extraData['old_date']);
            }
            if ($action == "CANCELLED") {
                $this->labAppointmentCancelled($mainOrder, $appintmentData);
            }
            if ($action == "REMINDER") {
                $this->labAppointmentReminder($mainOrder, $appintmentData, $testNameStr);
            }
        } catch (Exception $exc) {
            notificationErrorLog($exc);
        }
    }

    function labAppointmentReminder($mainOrder, $appintmentData, $testNameStr) {
        try {
            $appointmentTime = $appintmentData['appointment_date'] . ' ' . $appintmentData['appointment_time'];
            $notificationData['lab_detail'] = $appintmentData->lab->name . '(' . $appintmentData->lab->area . ')';
            $notificationData['date_time'] = date_format(date_create($appointmentTime), "d/m/Y h:i A");
            $notificationData['test'] = $testNameStr;
            $notificationData['user_id'] = $mainOrder->user->id;
            $notificationData['title'] = "Healthismplus : Lab appointment reminder";
            $notificationData['type'] = "LAB_TEST";
            notification($notificationData, 'LAB_TEST', 'REMINDER');
        } catch (Exception $exc) {
            notificationErrorLog($exc);
        }
    }

    function labAppointmentDone($mainOrder, $appintmentData) {
        try {
            $notificationData['user_name'] = $mainOrder->user->first_name . ' ' . $mainOrder->user->last_name;
            $notificationData['email'] = $mainOrder->user->email;
            $notificationData['mobile'] = $mainOrder->user->mobile;
            $notificationData['user_mobile'] = $mainOrder->user->mobile;
            $notificationData['order_code'] = $mainOrder->order_code;
            $notificationData['date_time'] = $appintmentData->date_time;
            $notificationData['patient_name'] = $appintmentData->patient_name;
            $notificationData['test'] = $appintmentData->test_data;
            $notificationData['lab_name'] = $appintmentData->lab->name;
            $notificationData['lab_mobile'] = $appintmentData->lab->mobile;
            $notificationData['lab_address'] = $appintmentData->lab->address1 . ',' . $appintmentData->lab->address2 . "," . $appintmentData->lab->area . ',' . $appintmentData->lab->city->name . ',' . $appintmentData->lab->state->name . '. - ' . $appintmentData->lab->pincode;
            $notificationData['test_mode'] = $appintmentData->is_home_collection == 1 ? "Home Pick up" : "Report At Lab";
            $notificationData['test_mode_note'] = $appintmentData->is_home_collection == 1 ? "Home Sample Collection" : "";
            $notificationData['amount'] = $mainOrder->amount;
            $notificationData['payment_mode'] = $mainOrder->payment->paymentmode->name;
            $notificationData['user_id'] = $mainOrder->user->id;
            $notificationData['title'] = "Healthismplus : Lab appointment done";
            $notificationData['type'] = "LAB_TEST";
            notification($notificationData, 'LAB_TEST', 'DONE', 'USER');
//            //SEND NOTIFICATION TO ADMIN
//            $notificationData['email'] = env('ADMIN_EMAIL_FOR_NOTIFICATION');
//            $notificationData['mobile'] = env('ADMIN_MOBILE_FOR_NOTIFICATION');
//            $notificationData['admin_email_name'] = ADMIN_EMAIL_NAME;
//            notification($notificationData, 'LAB_TEST', 'DONE', 'ADMIN');
            //SEND NOTIFICATION TO PARTNER
            $notificationData['email'] = !empty($appintmentData->partner_email) ? $appintmentData->partner_email : '';
            $notificationData['mobile'] = !empty($appintmentData->partner_mobile) ? $appintmentData->partner_mobile : '';
            notification($notificationData, 'LAB_TEST', 'DONE', 'PARTNER');
        } catch (Exception $exc) {
            notificationErrorLog($exc);
        }
    }

    function labAppointmentReschedule($mainOrder, $appintmentData, $oldDate) {
        try {
            $notificationData['user_name'] = $mainOrder->user->first_name . ' ' . $mainOrder->user->last_name;
            $notificationData['email'] = $mainOrder->user->email;
            $notificationData['mobile'] = $mainOrder->user->mobile;
            $notificationData['user_mobile'] = $mainOrder->user->mobile;
            $notificationData['order_code'] = $mainOrder->order_code;
            $notificationData['date_time'] = $oldDate;
            $notificationData['rescheduled_date'] = $appintmentData->date_time;
            $notificationData['patient_name'] = $appintmentData->patient_name;
            $notificationData['test'] = $appintmentData->test_data;
            $notificationData['lab_name'] = $appintmentData->lab->name;
            $notificationData['lab_mobile'] = $appintmentData->lab->mobile;
            $notificationData['lab_address'] = $appintmentData->lab->address1 . ',' . $appintmentData->lab->address2 . "," . $appintmentData->lab->area . ',' . $appintmentData->lab->city->name . ',' . $appintmentData->lab->state->name . '. - ' . $appintmentData->lab->pincode;
            $notificationData['test_mode'] = $appintmentData->is_home_collection == 1 ? "Home Pick up" : "Report At Lab";
            $notificationData['test_mode_note'] = $appintmentData->is_home_collection == 1 ? "Home Sample Collection" : "";
            $notificationData['amount'] = $mainOrder->amount;
            $notificationData['payment_mode'] = $mainOrder->payment->paymentmode->name;
            $notificationData['user_id'] = $mainOrder->user->id;
            $notificationData['title'] = "Healthismplus : Lab appointment reschedule";
            $notificationData['type'] = "LAB_TEST";
            notification($notificationData, 'LAB_TEST', 'RESCHEDULE');
        } catch (Exception $exc) {
            notificationErrorLog($exc);
        }
    }

    function labAppointmentCancelled($mainOrder, $appintmentData) {
        try {
            $notificationData['user_name'] = $mainOrder->user->first_name . ' ' . $mainOrder->user->last_name;
            $notificationData['email'] = $mainOrder->user->email;
            $notificationData['mobile'] = $mainOrder->user->mobile;
            $notificationData['user_mobile'] = $mainOrder->user->mobile;
            $notificationData['order_code'] = $mainOrder->order_code;
            $notificationData['date_time'] = $appintmentData->date_time;
            $notificationData['patient_name'] = $appintmentData->patient_name;
            $notificationData['test'] = $appintmentData->test_data;
            $notificationData['lab_name'] = $appintmentData->lab->name;
            $notificationData['lab_mobile'] = $appintmentData->lab->mobile;
            $notificationData['lab_address'] = $appintmentData->lab->address1 . ',' . $appintmentData->lab->address2 . "," . $appintmentData->lab->area . ',' . $appintmentData->lab->city->name . ',' . $appintmentData->lab->state->name . '. - ' . $appintmentData->lab->pincode;
            $notificationData['test_mode'] = $appintmentData->is_home_collection == 1 ? "Home Pick up" : "Report At Lab";
            $notificationData['test_mode_note'] = $appintmentData->is_home_collection == 1 ? "Home Sample Collection" : "";
            $notificationData['amount'] = $mainOrder->amount;
            $notificationData['payment_mode'] = $mainOrder->payment->paymentmode->name;
            $notificationData['user_id'] = $mainOrder->user->id;
            $notificationData['title'] = "Healthismplus : Lab appointment cancelled";
            $notificationData['type'] = "LAB_TEST";
            notification($notificationData, 'LAB_TEST', 'CANCELLED');
        } catch (Exception $exc) {
            notificationErrorLog($exc);
        }
    }

    /*     * ******************************************* */
    /*              MBS SERVICE                          */
    /*     * ******************************************* */

    function MBSAppointmentNotification($orderId, $action, $extraData = []) {
        return FALSE;
        try {
            $mainOrder = \App\Models\Orders::where('id', $orderId)->with('detail', 'payment', 'payment.paymentmode', 'user')->first();
            if (empty($mainOrder)) {
                return FALSE;
            }
            $orderDetail = $mainOrder->detail;
            if (empty($orderDetail[0])) {
                return FALSE;
            }
            $appintmentData = \App\Models\MenuBasedServiceBooking::where('id', $orderDetail[0]->ref_id)->first();
            if (empty($appintmentData)) {
                return FALSE;
            }
            if (empty($appintmentData->menu_based_service_booking_details)) {
                return FALSE;
            }
            $testDataHTML = "";
            foreach ($appintmentData->menu_based_service_booking_details as $key => $value) {
                $testDataHTML .= ++$key . ". " . $value->test->name . '<br>';
                $testDataHTML .= ' <span style="font-weight: normal;font-size: 12px;padding-bottom: 10px;">Instruction: ' . $value->test->preparation . '</span><br><br>';
            }

            $appintmentData['test_data'] = $testDataHTML;
            $time = strtotime($appintmentData->appointment_date . ' ' . $appintmentData->appointment_time);
            $appintmentData['date_time'] = date('d/M/Y h:i A', $time);

            if ($action == "DONE") {
                $this->MBSAppointmentDone($mainOrder, $appintmentData);
            }
            if ($action == "RESCHEDULE") {
                $this->MBSAppointmentReschedule($mainOrder, $appintmentData, $extraData['old_date']);
            }
            if ($action == "CANCELLED") {
                $this->MBSAppointmentCancelled($mainOrder, $appintmentData);
            }
        } catch (Exception $exc) {
            notificationErrorLog($exc);
        }
    }

    function MBSAppointmentDone($mainOrder, $appintmentData) {
        try {
            $notificationData['user_name'] = $mainOrder->user->first_name . ' ' . $mainOrder->user->last_name;
            $notificationData['email'] = $mainOrder->user->email;
            $notificationData['mobile'] = $mainOrder->user->mobile;
            $notificationData['user_mobile'] = $mainOrder->user->mobile;
            $notificationData['order_code'] = $mainOrder->order_code;
            $notificationData['date_time'] = $appintmentData->date_time;
            $notificationData['patient_name'] = $appintmentData->patient_name;
            $notificationData['test'] = $appintmentData->test_data;
            $notificationData['lab_name'] = $appintmentData->lab->name;
            $notificationData['lab_mobile'] = $appintmentData->lab->mobile;
            $notificationData['lab_address'] = $appintmentData->lab->address1 . ',' . $appintmentData->lab->address2 . "," . $appintmentData->lab->area . ',' . $appintmentData->lab->city->name . ',' . $appintmentData->lab->state->name . '. - ' . $appintmentData->lab->pincode;
            $notificationData['test_mode'] = $appintmentData->is_home_collection == 1 ? "Home Pick up" : "Report At Lab";
            $notificationData['test_mode_note'] = $appintmentData->is_home_collection == 1 ? "Home Sample Collection" : "";
            $notificationData['amount'] = $mainOrder->amount;
            $notificationData['payment_mode'] = $mainOrder->payment->paymentmode->name;
            $notificationData['user_id'] = $mainOrder->user->id;
            $notificationData['title'] = "Healthismplus : Lab appointment done";
            $notificationData['type'] = "LAB_TEST";
            notification($notificationData, 'LAB_TEST', 'DONE', 'USER');
//            //SEND NOTIFICATION TO ADMIN
//            $notificationData['email'] = env('ADMIN_EMAIL_FOR_NOTIFICATION');
//            $notificationData['mobile'] = env('ADMIN_MOBILE_FOR_NOTIFICATION');
//            $notificationData['admin_email_name'] = ADMIN_EMAIL_NAME;
//            notification($notificationData, 'LAB_TEST', 'DONE', 'ADMIN');
        } catch (Exception $exc) {
            notificationErrorLog($exc);
        }
    }

    function MBSAppointmentReschedule($mainOrder, $appintmentData, $oldDate) {
        try {
            $notificationData['user_name'] = $mainOrder->user->first_name . ' ' . $mainOrder->user->last_name;
            $notificationData['email'] = $mainOrder->user->email;
            $notificationData['mobile'] = $mainOrder->user->mobile;
            $notificationData['user_mobile'] = $mainOrder->user->mobile;
            $notificationData['order_code'] = $mainOrder->order_code;
            $notificationData['date_time'] = $oldDate;
            $notificationData['rescheduled_date'] = $appintmentData->date_time;
            $notificationData['patient_name'] = $appintmentData->patient_name;
            $notificationData['test'] = $appintmentData->test_data;
            $notificationData['lab_name'] = $appintmentData->lab->name;
            $notificationData['lab_mobile'] = $appintmentData->lab->mobile;
            $notificationData['lab_address'] = $appintmentData->lab->address1 . ',' . $appintmentData->lab->address2 . "," . $appintmentData->lab->area . ',' . $appintmentData->lab->city->name . ',' . $appintmentData->lab->state->name . '. - ' . $appintmentData->lab->pincode;
            $notificationData['test_mode'] = $appintmentData->is_home_collection == 1 ? "Home Pick up" : "Report At Lab";
            $notificationData['test_mode_note'] = $appintmentData->is_home_collection == 1 ? "Home Sample Collection" : "";
            $notificationData['amount'] = $mainOrder->amount;
            $notificationData['payment_mode'] = $mainOrder->payment->paymentmode->name;
            $notificationData['user_id'] = $mainOrder->user->id;
            $notificationData['title'] = "Healthismplus : Lab appointment reschedule";
            $notificationData['type'] = "LAB_TEST";
            notification($notificationData, 'LAB_TEST', 'RESCHEDULE');
        } catch (Exception $exc) {
            notificationErrorLog($exc);
        }
    }

    function MBSAppointmentCancelled($mainOrder, $appintmentData) {
        try {
            $notificationData['user_name'] = $mainOrder->user->first_name . ' ' . $mainOrder->user->last_name;
            $notificationData['email'] = $mainOrder->user->email;
            $notificationData['mobile'] = $mainOrder->user->mobile;
            $notificationData['user_mobile'] = $mainOrder->user->mobile;
            $notificationData['order_code'] = $mainOrder->order_code;
            $notificationData['date_time'] = $appintmentData->date_time;
            $notificationData['patient_name'] = $appintmentData->patient_name;
            $notificationData['test'] = $appintmentData->test_data;
            $notificationData['lab_name'] = $appintmentData->lab->name;
            $notificationData['lab_mobile'] = $appintmentData->lab->mobile;
            $notificationData['lab_address'] = $appintmentData->lab->address1 . ',' . $appintmentData->lab->address2 . "," . $appintmentData->lab->area . ',' . $appintmentData->lab->city->name . ',' . $appintmentData->lab->state->name . '. - ' . $appintmentData->lab->pincode;
            $notificationData['test_mode'] = $appintmentData->is_home_collection == 1 ? "Home Pick up" : "Report At Lab";
            $notificationData['test_mode_note'] = $appintmentData->is_home_collection == 1 ? "Home Sample Collection" : "";
            $notificationData['amount'] = $mainOrder->amount;
            $notificationData['payment_mode'] = $mainOrder->payment->paymentmode->name;
            $notificationData['user_id'] = $mainOrder->user->id;
            $notificationData['title'] = "Healthismplus : Lab appointment cancelled";
            $notificationData['type'] = "LAB_TEST";
            notification($notificationData, 'LAB_TEST', 'CANCELLED');
        } catch (Exception $exc) {
            notificationErrorLog($exc);
        }
    }

    /*     * ******************************************* */
    /*              SBS SERVICE                          */
    /*     * ******************************************* */

    function SBSAppointmentNotification($orderId, $action, $extraData = []) {
        return FALSE;
        try {
            $mainOrder = \App\Models\Orders::where('id', $orderId)->with('detail', 'payment', 'payment.paymentmode', 'user')->first();
            if (empty($mainOrder)) {
                return FALSE;
            }
            $orderDetail = $mainOrder->detail;
            if (empty($orderDetail[0])) {
                return FALSE;
            }
            $appintmentData = \App\Models\SubscriptionBasedServiceBooking::where('id', $orderDetail[0]->ref_id)->first();
            if (empty($appintmentData)) {
                return FALSE;
            }
            if (empty($appintmentData->subscription_based_service_booking_details)) {
                return FALSE;
            }
            $testDataHTML = "";
            foreach ($appintmentData->subscription_based_service_booking_details as $key => $value) {
                $testDataHTML .= ++$key . ". " . $value->test->name . '<br>';
                $testDataHTML .= ' <span style="font-weight: normal;font-size: 12px;padding-bottom: 10px;">Instruction: ' . $value->test->preparation . '</span><br><br>';
            }

            $appintmentData['test_data'] = $testDataHTML;
            $time = strtotime($appintmentData->appointment_date . ' ' . $appintmentData->appointment_time);
            $appintmentData['date_time'] = date('d/M/Y h:i A', $time);

            if ($action == "DONE") {
                $this->SBSAppointmentDone($mainOrder, $appintmentData);
            }
            if ($action == "RESCHEDULE") {
                $this->SBSAppointmentReschedule($mainOrder, $appintmentData, $extraData['old_date']);
            }
            if ($action == "CANCELLED") {
                $this->SBSAppointmentCancelled($mainOrder, $appintmentData);
            }
        } catch (Exception $exc) {
            notificationErrorLog($exc);
        }
    }

    /*     * ******************************************* */
    /*                          CORPORATE                */
    /*     * ******************************************* */

    function corporateNotification($userId, $action, $extraData = []) {
        try {
            if (!empty($userId)) {
                $userData = \App\Models\User::where('id', $userId)->first();
                if (empty($userData)) {
                    return FALSE;
                }
                if ($action == "SIGNING_TIPS") {
                    $this->signingTips($userData, $extraData);
                }
            }
        } catch (Exception $exc) {
            notificationErrorLog($exc);
        }
    }

    function signingTips($userData, $extraData) {
        try {
            $notificationData['user_name'] = $userData->first_name . ' ' . $userData->last_name;
            $notificationData['mobile'] = $userData->mobile;
            $notificationData['email'] = $userData->email;
            $notificationData['company_name'] = $extraData['company_name'];
            $notificationData['user_id'] = $userData->id;
            $notificationData['date'] = date_format(date_create($extraData['expiry_date']), "d-m-Y ");
            notification($notificationData, 'CORPORATE', 'SIGNING_TIPS');
        } catch (Exception $exc) {
            notificationErrorLog($exc);
        }
    }

    /*     * ******************************************* */
    /*              PRESCRIPTION UPLOAD                  */
    /*     * ******************************************* */

    function userPrescriptionUpload($userData) {
        try {
            $notificationData['user_name'] = $userData['name'];
            $notificationData['user_mobile'] = $userData['mobile'];
            $notificationData['user_email'] = $userData['email'];
            $notificationData['mobile'] = $userData['mobile'];
            notification($notificationData, 'USER', 'PRESCRIPTION_UPLOAD', 'USER');
            
            $emailArry = ['operations@healthismplus.com'];
            $notificationData['mobile'] = env('ADMIN_MOBILE_FOR_NOTIFICATION');
            foreach ($emailArry as $value) {
                $notificationData['email'] = $value;
                notification($notificationData, 'USER', 'PRESCRIPTION_UPLOAD', 'ADMIN');
            }
        } catch (Exception $exc) {
            notificationErrorLog($exc);
        }
    }

}
