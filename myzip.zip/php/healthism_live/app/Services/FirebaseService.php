<?php

namespace App\Services;

use Exception;
use Kreait\Firebase;
use Kreait\Firebase\Factory;
use Kreait\Firebase\Database;
use Kreait\Firebase\ServiceAccount;
use Kreait\Firebase\Exception\Auth\EmailExists as FirebaseEmailExists;

class FirebaseService {

    /**
     * @var Firebase
     */
    protected $firebase;

    public function __construct() {
        $serviceAccount = ServiceAccount::fromArray([
                    "type" => 'service_account',
                    "project_id" => 'healthism-plus-tech',
                    "private_key_id" => '3c8e3cbad7ab15bda2851047312603b86f96a19e',
                    "private_key" => "-----BEGIN PRIVATE KEY-----\nMIIEvQIBADANBgkqhkiG9w0BAQEFAASCBKcwggSjAgEAAoIBAQC3SSRCcpBy9Wt5\na8uqrIfirqMUH2g9633KkrwghPkWboIA522bYWVX8eoeGvLAI+j8Gwo8ee4rH9oF\nzVYJ2NyHa+5P7TC8gijd2wPByedfkcrA37Ze5lIIvWPQUiRdyC98XSPi05VH5M00\nPO96HeWzBIQnarbubjEK9yPdrDI9GInqFnW2Mk/F264s8DOvLvKX+OvBHrzaXWBk\n/wFamFgdKThfEHu/Kb8F3/wzB9MYQFBSe06KrsYiix4kGSG4Qj3qvLygH5f6fb44\nukkXr9RmqwIGok5MtylOl+jc8w2oOhMpSAngbuNq1jGKyiBJ/ckYC7B4HfWCEX+5\nSIQ5a2WpAgMBAAECggEAAY3jepPFoU/u+CHfoYQih9vSwrQsel/xmmLpqP3vrc7E\nl/Tec1OdXCRPR6+TUOlNC7w/9zjSefekbemqmd1Gq3hRFkjs4aBZ792wV7eaWG9g\nUIflIENkPTI78zOLHud4bZ3NlNoV+TzZt6BvqHGx9bVrWHk5cWaqUE09tt7Ds0xr\nCQJYJC4ydUkrEJf0U+oUf5mSaDmEK7TLYfBLozWd445VvS77APrhkv9gysP0V7Iv\nA+SABWj0Si5t6xcV9YDeujj6qXk7ftdA8/MkjAGVl1slQEyykcFUkFIuVYiQWJe3\nZ8COLjZ/5jt6UNzQQ3jnPLKU03bHJckbSSQZvvzW7QKBgQDsEi19Xq3bYzu3m+ET\n8jXgu5+bnZ8HfwuyBtPKJo7uJrZ9UUQvZE9Vq/T/LTm5P69a6aKrYWbNbA2AEYRb\n5peVKUQ2Wlwlb0ocRbVEHwZZCFyramLUSNbuU1OyPNH9cmOLRmpKDwObnFYm6dw3\nzzUma2TKIp2If4MfB3w9Pqqs5QKBgQDGwjNLPtUeI3WJvDwwCUBHU7yxT97g5lU1\nza0yIkzaKe/F/E7NlQ/SFldV3B5uw7XT3OuQM4qsEbYdbiGXI2TEHwAe4YINDeiH\nQPBKzf4UU/KfL60NyWvFreGuLXojI7qpwfLawcoe0W+NLZhJT/uOA65fznyS+8KD\nIN1B/KvNdQKBgBh4FeD91FV+Jq10adMQcwc1S2js4JP9VjAAxykX8A69UoMQzll/\nMz31EfL1NBuAf2OT/fl3ohk+zvNsXWTNNP8QBPMBULXMoEjn7M7/zD+kPz7BSzcn\nyadwWaeK6FU16x1/kfrVLZGOldt4uAvM3Xx6+zp8dgm09dlchEMw4K4FAoGAbWwc\nsSA2VBFRdDKdMBTnvlzrVPKT0Vz9LFG/OAqKJNFRn7335FZcD10dV7eHSZOVVr4Z\nMZoujexyRmGLPJnPr+khN98OqgEuMsgdghFGAAr3V4v3yc9J9dp0lF+VDiNtcGfG\nO4jUrYK/1wly/Wl7JAQCy9vx2TmhLG+7X8irDMECgYEAiPziVfORJcN0Cqba+n31\nNTgvQxzwHo8FhO6ur2tvZHSEXWQ+ylIKiyubUwZmaCD+ng0igZ7DAB63oL9rKykl\nYsmhmAj989HfQQCBBuHrOtfww/C4WXjdZCX6P3KpbATDwIEHz2JCfIMX9+e0eSGp\nY9TWyhUVecjdu/UIVMIiu/I=\n-----END PRIVATE KEY-----\n",
                    "client_email" => "firebase-adminsdk-m4ole@healthism-plus-tech.iam.gserviceaccount.com",
                    "client_id" => "115561335720789221591",
                    "auth_uri" => "https://accounts.google.com/o/oauth2/auth",
                    "token_uri" => "https://oauth2.googleapis.com/token",
                    "auth_provider_x509_cert_url" => "https://www.googleapis.com/oauth2/v1/certs",
                    "client_x509_cert_url" => "https://www.googleapis.com/robot/v1/metadata/x509/firebase-adminsdk-m4ole%40healthism-plus-tech.iam.gserviceaccount.com"
        ]);

        $this->firebase = (new Factory)
                ->withServiceAccount($serviceAccount)
                ->create();
    }

}
