<?php

// Code within app\Helpers\Helper.php

namespace App\Helpers;

use Config;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Str;

class Helpers {

    public static function static_asset($path, $secure = null) {
        return app('url')->asset('/' . $path, $secure);
    }

    public static function checkActiveMenu($name) {
        $name = explode(",", $name);
        return in_array(\Request::route()->getName(), $name) ? 'active' : '';
    }

    public static function getEnumValues($table, $column) {
        $type = DB::select(DB::raw("SHOW COLUMNS FROM $table WHERE Field = '{$column}'"))[0]->Type;
        preg_match('/^enum\((.*)\)$/', $type, $matches);
        $enums = array();
        foreach (explode(',', $matches[1]) as $value) {
            $enums[] = trim($value, "'");
        }
        return $enums;
    }

}
