<?php

namespace App\Helpers;

use Kreait\Firebase\Messaging\CloudMessage;
use Kreait\Firebase\Messaging\Notification;
use Kreait\Firebase\Messaging;

class PushNotifications {

    public static function send_push($param) {
        if (!empty($param['device_token'])) {
            $notification = Notification::fromArray([
                        'title' => $param['title'],
                        'body' => $param['body'],
            ]);

            $message = CloudMessage::withTarget('token', $param['device_token'])
                    ->withNotification($notification);

            $messaging = app('firebase.messaging');

            $result = $messaging->send($message);
            return $result;
        } else {
            return array('code' => 1, 'message' => 'SYSTEM - device_token is empty.');
        }
    }

}
